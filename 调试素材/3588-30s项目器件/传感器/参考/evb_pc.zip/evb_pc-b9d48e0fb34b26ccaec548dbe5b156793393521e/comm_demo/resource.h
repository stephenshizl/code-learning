//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� comm_demo.rc ʹ��
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_COMM_DEMO_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_BT_OPEN_COMM                1000
#define IDC_STATIC_PORT                 1001
#define IDC_EDIT_PORT                   1002
#define IDC_STATIC_SAMPLERATE           1003
#define IDC_STATIC_TITLE                1005
#define IDC_STATIC_MAGDATA              1006
#define IDC_STATIC_ACCDATA              1007
#define IDC_CHARTCTRL_1                 1009
#define IDC_EDIT_SAMPLERATE             1010
#define IDC_STATIC_STEPCOUNTER          1011
#define IDC_CHECK_SAVEDATA              1012
#define IDC_EDIT_REG_ADDR               1014
#define IDC_EDIT_REG_VALUE              1015
#define IDC_BUTTON_REG_WRITE            1016
#define IDC_BUTTON_REG_READ             1017
#define IDC_EDIT_SLAVE                  1019
#define IDC_STATIC_GROUP_DATA           1021
#define IDC_BUTTON_CALI                 1022
#define IDC_CHECK_PROTOCOL              1023
#define IDC_CHARTCTRL_2                 1024
#define IDC_CHARTCTRL_3                 1025
#define IDC_STATIC_PRESSDATA            1026
#define IDC_EDIT_IO                     1027
#define IDC_STATIC_IO                   1028
#define IDC_BUTTON_IO_WRITE             1029
#define IDC_STATIC_CONTROL              1030
#define IDC_MFCLINK_QSTCORP             1031
#define IDC_BUTTON                      1032
#define IDC_BT_START                    1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
