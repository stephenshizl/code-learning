/**
  ******************************************************************************
  * @file    qmp6988.c
  * @author  STMicroelectronics
  * @version V1.0
  * @date    2013-xx-xx
  * @brief    qmp6988����
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:���� ָ���� ������ 
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :https://fire-stm32.taobao.com
  *
  ******************************************************************************
  */ 
#include "stdafx.h"
#include "qmp6988.h"
#include <math.h>


#define QMP6988_LOG		_cprintf
#define QMP6988_ERR		_cprintf
extern void qst_delay(unsigned int delay);

#if !defined(QMP6988_CALC_INT)
static float const Conv_A_S[10][2] = {
	{-6.30E-03,4.30E-04},
	{-1.90E-11,1.20E-10},
	{1.00E-01,9.10E-02},
	{1.20E-08,1.20E-06},
	{3.30E-02,1.90E-02},
	{2.10E-07,1.40E-07},
	{-6.30E-10,3.50E-10},
	{2.90E-13,7.60E-13},
	{2.10E-15,1.20E-14},
	{1.30E-16,7.90E-17},
};
#endif

static void qmp6988_delay(unsigned int delay)
{
	Sleep(delay);
}

QMP6988_U8_t qmp6988_WriteReg(QMP6988_U8_t slave, QMP6988_U8_t reg_add,QMP6988_U8_t reg_dat)
{
	QMP6988_S32_t ret = 0;
	QMP6988_U32_t retry = 0;

	while((!ret) && (retry++ < 5))
	{
		if(get_device_protocol() == USB_SPI)
		{
			ret = spi_write_reg(reg_add, reg_dat);
		}
		else
		{
			ret = i2c_write_reg(slave, reg_add, reg_dat);
		}
	}

	return ret;
}

QMP6988_U8_t qmp6988_ReadData(QMP6988_U8_t slave, QMP6988_U8_t reg_add,unsigned char* Read,QMP6988_U8_t num)
{
	QMP6988_U8_t ret = 0;
	QMP6988_U32_t retry = 0;

	while((!ret) && (retry++ < 5))
	{
		if(get_device_protocol() == USB_SPI)
		{
			ret = spi_read_reg(reg_add, Read, num);
		}
		else
		{
			ret = i2c_read_reg(slave, reg_add, Read, (QMP6988_U16_t)num);
		}
	}

	return ret;
}

static QMP6988_U8_t qmp6988_device_check(qmp6988_data *qmp6988)
{
	QMP6988_U8_t slave_addr[2] = {QMP6988_SLAVE_ADDRESS_L, QMP6988_SLAVE_ADDRESS_H};
	QMP6988_U8_t ret = 0;
	QMP6988_U8_t i;

	for(i=0; i<2; i++)
	{
		qmp6988->slave = slave_addr[i];
		ret = qmp6988_ReadData(qmp6988->slave, QMP6988_CHIP_ID_REG, &(qmp6988->chip_id), 1);
		if(ret == 0){
			QMP6988_LOG("%s: read 0xD1 failed\n",__func__);
			continue;
		}
		QMP6988_LOG("qmp6988 slave:0x%x	read chip id = 0x%x\n", qmp6988->slave, qmp6988->chip_id);
		if(qmp6988->chip_id == QMP6988_CHIP_ID)
		{
			return 1;
		}
	}

	return 0;
}

static QMP6988_S32_t qmp6988_get_calibration_data(qmp6988_data *qmp6988)
{
	//BITFIELDS temp_COE;	
	QMP6988_S32_t status = 0;
	QMP6988_U8_t a_data_u8r[QMP6988_CALIBRATION_DATA_LENGTH] = {0};
	QMP6988_S32_t len;

#if 0
	status = qmp6988_ReadData(qmp6988_cali_data_START,a_data_u8r,qmp6988_cali_data_LENGTH);
	if (status == 0)
	{
		QMP6988_LOG("qmp6988 read 0xA0 error!");
		return status;
	}
#else
	for(len = 0; len < QMP6988_CALIBRATION_DATA_LENGTH; len += 1)
	{
		//if((qmp6988_cali_data_LENGTH-len) >= 8 )
		//	status = qmp6988_ReadData(qmp6988_cali_data_START+len,&a_data_u8r[len],8);
		//else
		//	status = qmp6988_ReadData(qmp6988_cali_data_START+len,&a_data_u8r[len],(qmp6988_cali_data_LENGTH-len));
		status = qmp6988_ReadData(qmp6988->slave,QMP6988_CALIBRATION_DATA_START+len,&a_data_u8r[len],1);
		if (status == 0)
		{
			QMP6988_LOG("qmp6988 read 0xA0 error!");
			return status;
		}
	}
#endif

	qmp6988->qmp6988_cali.COE_a0 = (QMP6988_S32_t)((((QMP6988_S32_t)a_data_u8r[18] << SHIFT_LEFT_12_POSITION) \
							| ((QMP6988_S32_t)a_data_u8r[19] << SHIFT_LEFT_4_POSITION) \
							| ((QMP6988_S32_t)a_data_u8r[24] & 0x0f))<<12);
	qmp6988->qmp6988_cali.COE_a0 = qmp6988->qmp6988_cali.COE_a0>>12;
	
	qmp6988->qmp6988_cali.COE_a1 = (QMP6988_S16_t)(((a_data_u8r[20]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[21]);
	qmp6988->qmp6988_cali.COE_a2 = (QMP6988_S16_t)(((a_data_u8r[22]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[23]);
	
	qmp6988->qmp6988_cali.COE_b00 = (QMP6988_S32_t)((((QMP6988_S32_t)a_data_u8r[0] << SHIFT_LEFT_12_POSITION) \
							| ((QMP6988_S32_t)a_data_u8r[1] << SHIFT_LEFT_4_POSITION) \
							| (((QMP6988_S32_t)a_data_u8r[24] & 0xf0) >> SHIFT_RIGHT_4_POSITION))<<12);
	qmp6988->qmp6988_cali.COE_b00 = qmp6988->qmp6988_cali.COE_b00>>12;

	qmp6988->qmp6988_cali.COE_bt1 = (QMP6988_S16_t)(((a_data_u8r[2]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[3]);
	qmp6988->qmp6988_cali.COE_bt2 = (QMP6988_S16_t)(((a_data_u8r[4]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[5]);
	qmp6988->qmp6988_cali.COE_bp1 = (QMP6988_S16_t)(((a_data_u8r[6]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[7]);
	qmp6988->qmp6988_cali.COE_b11 = (QMP6988_S16_t)(((a_data_u8r[8]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[9]);
	qmp6988->qmp6988_cali.COE_bp2 = (QMP6988_S16_t)(((a_data_u8r[10]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[11]);
	qmp6988->qmp6988_cali.COE_b12 = (QMP6988_S16_t)(((a_data_u8r[12]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[13]);		
	qmp6988->qmp6988_cali.COE_b21 = (QMP6988_S16_t)(((a_data_u8r[14]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[15]);
	qmp6988->qmp6988_cali.COE_bp3 = (QMP6988_S16_t)(((a_data_u8r[16]) << SHIFT_LEFT_8_POSITION) | a_data_u8r[17]);			

	QMP6988_LOG("<-----------calibration data-------------->\n");
	QMP6988_LOG("COE_a0[%d]	COE_a1[%d]	COE_a2[%d]	COE_b00[%d]\n",
			qmp6988->qmp6988_cali.COE_a0,qmp6988->qmp6988_cali.COE_a1,qmp6988->qmp6988_cali.COE_a2,qmp6988->qmp6988_cali.COE_b00);
	QMP6988_LOG("COE_bt1[%d]	COE_bt2[%d]	COE_bp1[%d]	COE_b11[%d]\n",
			qmp6988->qmp6988_cali.COE_bt1,qmp6988->qmp6988_cali.COE_bt2,qmp6988->qmp6988_cali.COE_bp1,qmp6988->qmp6988_cali.COE_b11);
	QMP6988_LOG("COE_bp2[%d]	COE_b12[%d]	COE_b21[%d]	COE_bp3[%d]\n",
			qmp6988->qmp6988_cali.COE_bp2,qmp6988->qmp6988_cali.COE_b12,qmp6988->qmp6988_cali.COE_b21,qmp6988->qmp6988_cali.COE_bp3);
	QMP6988_LOG("<-----------calibration data-------------->\n");

#if defined(QMP6988_CALC_INT)
	qmp6988->ik.a0 = qmp6988->qmp6988_cali.COE_a0; // 20Q4
	qmp6988->ik.b00 = qmp6988->qmp6988_cali.COE_b00; // 20Q4

	qmp6988->ik.a1 = 3608L * (QMP6988_S32_t)qmp6988->qmp6988_cali.COE_a1 - 1731677965L; // 31Q23
	qmp6988->ik.a2 = 16889L * (QMP6988_S32_t) qmp6988->qmp6988_cali.COE_a2 - 87619360L; // 30Q47

	qmp6988->ik.bt1 = 2982L * (QMP6988_S64_t)qmp6988->qmp6988_cali.COE_bt1 + 107370906L; // 28Q15
	qmp6988->ik.bt2 = 329854L * (QMP6988_S64_t)qmp6988->qmp6988_cali.COE_bt2 + 108083093L; // 34Q38
	qmp6988->ik.bp1 = 19923L * (QMP6988_S64_t)qmp6988->qmp6988_cali.COE_bp1 + 1133836764L; // 31Q20
	qmp6988->ik.b11 = 2406L * (QMP6988_S64_t)qmp6988->qmp6988_cali.COE_b11+ 118215883L; // 28Q34
	qmp6988->ik.bp2 = 3079L * (QMP6988_S64_t)qmp6988->qmp6988_cali.COE_bp2 - 181579595L; // 29Q43
	qmp6988->ik.b12 = 6846L * (QMP6988_S64_t)qmp6988->qmp6988_cali.COE_b12 + 85590281L; // 29Q53
	qmp6988->ik.b21 = 13836L * (QMP6988_S64_t)qmp6988->qmp6988_cali.COE_b21 + 79333336L; // 29Q60
	qmp6988->ik.bp3 = 2915L * (QMP6988_S64_t)qmp6988->qmp6988_cali.COE_bp3 + 157155561L; // 28Q65
	QMP6988_LOG("<----------- int calibration data -------------->\n");
	QMP6988_LOG("a0[%d]	a1[%d] a2[%d] b00[%d]\n",qmp6988->ik.a0,qmp6988->ik.a1,qmp6988->ik.a2,qmp6988->ik.b00);
	QMP6988_LOG("bt1[%lld]	bt2[%lld]	bp1[%lld]	b11[%lld]\n",qmp6988->ik.bt1,qmp6988->ik.bt2,qmp6988->ik.bp1,qmp6988->ik.b11);
	QMP6988_LOG("bp2[%lld]	b12[%lld]	b21[%lld]	bp3[%lld]\n",qmp6988->ik.bp2,qmp6988->ik.b12,qmp6988->ik.b21,qmp6988->ik.bp3);
	QMP6988_LOG("<----------- int calibration data -------------->\n");
#else
	qmp6988->fk.a0 = qmp6988->qmp6988_cali.COE_a0 /16.0f;
	qmp6988->fk.b00 = qmp6988->qmp6988_cali.COE_b00 /16.0f;

	qmp6988->fk.a1 = Conv_A_S[0][0] + Conv_A_S[0][1] * qmp6988->qmp6988_cali.COE_a1 / 32767.0f;
	qmp6988->fk.a2 = Conv_A_S[1][0] + Conv_A_S[1][1] * qmp6988->qmp6988_cali.COE_a2 / 32767.0f;
	qmp6988->fk.bt1 = Conv_A_S[2][0] + Conv_A_S[2][1] * qmp6988->qmp6988_cali.COE_bt1 / 32767.0f;
	qmp6988->fk.bt2 = Conv_A_S[3][0] + Conv_A_S[3][1] * qmp6988->qmp6988_cali.COE_bt2 / 32767.0f;
	qmp6988->fk.bp1 = Conv_A_S[4][0] + Conv_A_S[4][1] * qmp6988->qmp6988_cali.COE_bp1 / 32767.0f;
	qmp6988->fk.b11 = Conv_A_S[5][0] + Conv_A_S[5][1] * qmp6988->qmp6988_cali.COE_b11 / 32767.0f;
	qmp6988->fk.bp2 = Conv_A_S[6][0] + Conv_A_S[6][1] * qmp6988->qmp6988_cali.COE_bp2 / 32767.0f;
	qmp6988->fk.b12 = Conv_A_S[7][0] + Conv_A_S[7][1] * qmp6988->qmp6988_cali.COE_b12 / 32767.0f;
	qmp6988->fk.b21 = Conv_A_S[8][0] + Conv_A_S[8][1] * qmp6988->qmp6988_cali.COE_b21 / 32767.0f;
	qmp6988->fk.bp3 = Conv_A_S[9][0] + Conv_A_S[9][1] * qmp6988->qmp6988_cali.COE_bp3 / 32767.0f;
	
	QMP6988_LOG("<----------- float calibration data -------------->\n");
	QMP6988_LOG("a0[%lle]	a1[%lle]	a2[%lle]	b00[%lle]\n",qmp6988->fk.a0,qmp6988->fk.a1,qmp6988->fk.a2,qmp6988->fk.b00);
	QMP6988_LOG("bt1[%lle]	bt2[%lle]	bp1[%lle]	b11[%lle]\n",qmp6988->fk.bt1,qmp6988->fk.bt2,qmp6988->fk.bp1,qmp6988->fk.b11);
	QMP6988_LOG("bp2[%lle]	b12[%lle]	b21[%lle]	bp3[%lle]\n",qmp6988->fk.bp2,qmp6988->fk.b12,qmp6988->fk.b21,qmp6988->fk.bp3);
	QMP6988_LOG("<----------- float calibration data -------------->\n");
#endif

	return 1;
}

#if defined(QMP6988_CALC_INT)
static QMP6988_S16_t qmp6988_convTx_02e(qmp6988_ik_data *ik, QMP6988_S32_t dt) 
{
	QMP6988_S16_t ret;
	QMP6988_S64_t wk1, wk2;

	// wk1: 60Q4 // bit size
	wk1 = ((QMP6988_S64_t)ik->a1 * (QMP6988_S64_t)dt); // 31Q23+24-1=54 (54Q23)
	wk2 = ((QMP6988_S64_t)ik->a2 * (QMP6988_S64_t)dt) >> 14; // 30Q47+24-1=53 (39Q33)
	wk2 = (wk2 * (QMP6988_S64_t)dt) >> 10; // 39Q33+24-1=62 (52Q23)
	//wk2 = ((wk1 + wk2) / 32767) >> 19; // 54,52->55Q23 (20Q04)
	wk2 = ((wk1 + wk2) >> 15) >> 19; // 54,52->55Q23 (20Q04)
	ret = (QMP6988_S16_t)((ik->a0 + wk2) >> 4); // 21Q4 -> 17Q0
	return ret;
}

static QMP6988_S32_t qmp6988_get_pressure_02e(qmp6988_ik_data *ik, QMP6988_S32_t dp, QMP6988_S16_t tx)
{
	QMP6988_S32_t ret;
	QMP6988_S64_t wk1, wk2, wk3;

	// wk1 = 48Q16 // bit size
	wk1 = ((QMP6988_S64_t)ik->bt1 * (QMP6988_S64_t)tx); // 28Q15+16-1=43 (43Q15)
	wk2 = ((QMP6988_S64_t)ik->bp1 * (QMP6988_S64_t)dp) >> 5; // 31Q20+24-1=54 (49Q15)
	wk1 += wk2; // 43,49->50Q15
	wk2 = ((QMP6988_S64_t)ik->bt2 * (QMP6988_S64_t)tx) >> 1; // 34Q38+16-1=49 (48Q37)
	wk2 = (wk2 * (QMP6988_S64_t)tx) >> 8; // 48Q37+16-1=63 (55Q29)
	wk3 = wk2; // 55Q29
	wk2 = ((QMP6988_S64_t)ik->b11 * (QMP6988_S64_t)tx) >> 4; // 28Q34+16-1=43 (39Q30)
	wk2 = (wk2 * (QMP6988_S64_t)dp) >> 1; // 39Q30+24-1=62 (61Q29)
	wk3 += wk2; // 55,61->62Q29
	wk2 = ((QMP6988_S64_t)ik->bp2 * (QMP6988_S64_t)dp) >> 13; // 29Q43+24-1=52 (39Q30)
	wk2 = (wk2 * (QMP6988_S64_t)dp) >> 1; // 39Q30+24-1=62 (61Q29)
	wk3 += wk2; // 62,61->63Q29
	wk1 += wk3 >> 14; // Q29 >> 14 -> Q15
	wk2 = ((QMP6988_S64_t)ik->b12 * (QMP6988_S64_t)tx); // 29Q53+16-1=45 (45Q53)
	wk2 = (wk2 * (QMP6988_S64_t)tx) >> 22; // 45Q53+16-1=61 (39Q31)
	wk2 = (wk2 * (QMP6988_S64_t)dp) >> 1; // 39Q31+24-1=62 (61Q30)
	wk3 = wk2; // 61Q30
	wk2 = ((QMP6988_S64_t)ik->b21 * (QMP6988_S64_t)tx) >> 6; // 29Q60+16-1=45 (39Q54)
	wk2 = (wk2 * (QMP6988_S64_t)dp) >> 23; // 39Q54+24-1=62 (39Q31)
	wk2 = (wk2 * (QMP6988_S64_t)dp) >> 1; // 39Q31+24-1=62 (61Q20)
	wk3 += wk2; // 61,61->62Q30
	wk2 = ((QMP6988_S64_t)ik->bp3 * (QMP6988_S64_t)dp) >> 12; // 28Q65+24-1=51 (39Q53)
	wk2 = (wk2 * (QMP6988_S64_t)dp) >> 23; // 39Q53+24-1=62 (39Q30)
	wk2 = (wk2 * (QMP6988_S64_t)dp); // 39Q30+24-1=62 (62Q30)
	wk3 += wk2; // 62,62->63Q30
	wk1 += wk3 >> 15; // Q30 >> 15 = Q15
	//wk1 /= 32767L;
	wk1 = wk1 >> 15;
	wk1 >>= 11; // Q15 >> 7 = Q4
	wk1 += ik->b00; // Q4 + 20Q4
	//wk1 >>= 4; // 28Q4 -> 24Q0
	ret = (QMP6988_S32_t)wk1;
	return ret;
}
#endif

static void qmp6988_software_reset(qmp6988_data *qmp6988)
{
#if 0
	QMP6988_U8_t ret = 0; 

	ret = qmp6988_WriteReg(qmp6988->slave, QMP6988_RESET_REG, 0xe6);
	if(ret == 0)
	{
		QMP6988_LOG("qmp6988_software_reset fail!!! \n");
	}
	qmp6988_delay(20);
	ret = qmp6988_WriteReg(qmp6988->slave, QMP6988_RESET_REG, 0x00);
#endif
}

static void qmp6988_set_powermode(qmp6988_data *qmp6988, int power_mode)
{
	QMP6988_U8_t data;

	QMP6988_LOG("qmp_set_powermode %d \n", power_mode);
	//if(power_mode == qmp6988->power_mode)
	//	return;

	qmp6988->power_mode = power_mode;
	qmp6988_ReadData(qmp6988->slave, QMP6988_CTRLMEAS_REG, &data, 1);
	data = data&0xfc;
	if(power_mode == QMP6988_SLEEP_MODE)
	{
		data |= 0x00;
	}
	else if(power_mode == QMP6988_FORCED_MODE)
	{
		data |= 0x01;
	}
	else if(power_mode == QMP6988_NORMAL_MODE)
	{
		data |= 0x03;
	}
	qmp6988_WriteReg(qmp6988->slave, QMP6988_CTRLMEAS_REG, data);

	QMP6988_LOG("qmp_set_powermode 0xf4=0x%x \n", data);
	
	qmp6988_delay(20);
}


static void qmp6988_set_filter(qmp6988_data *qmp6988, unsigned char filter)
{	
	QMP6988_U8_t data;

	data = (filter&0x03);
	qmp6988_WriteReg(qmp6988->slave, QMP6988_CONFIG_REG, data);

	qmp6988_delay(20);
}

static void qmp6988_set_oversampling_p(qmp6988_data *qmp6988, unsigned char oversampling_p)
{
	QMP6988_U8_t data;

	qmp6988_ReadData(qmp6988->slave, QMP6988_CTRLMEAS_REG, &data, 1);
	data &= 0xe3;
	data |= (oversampling_p<<2);
	qmp6988_WriteReg(qmp6988->slave, QMP6988_CTRLMEAS_REG, data);
	qmp6988_delay(20);
}

static void qmp6988_set_oversampling_t(qmp6988_data *qmp6988, unsigned char oversampling_t)
{
	QMP6988_U8_t data;

	qmp6988_ReadData(qmp6988->slave, QMP6988_CTRLMEAS_REG, &data, 1);
	data &= 0x1f;
	data |= (oversampling_t<<5);
	qmp6988_WriteReg(qmp6988->slave, QMP6988_CTRLMEAS_REG, data);
	qmp6988_delay(20);
}

void qmp6988_set_app(qmp6988_data *qmp6988, unsigned char app)
{
	QMP6988_LOG("qmp6988 app:%d\n", app);
	if(app == 1)	//Weather monitoring, High speed
	{
		qmp6988_set_oversampling_p(qmp6988, QMP6988_OVERSAMPLING_2X);
		qmp6988_set_oversampling_t(qmp6988, QMP6988_OVERSAMPLING_1X);
		qmp6988_set_filter(qmp6988, QMP6988_FILTERCOEFF_OFF);
	}
	else if(app == 2)		//Drop detection, Low power
	{
		qmp6988_set_oversampling_p(qmp6988, QMP6988_OVERSAMPLING_2X);
		qmp6988_set_oversampling_t(qmp6988, QMP6988_OVERSAMPLING_1X);
		qmp6988_set_filter(qmp6988, QMP6988_FILTERCOEFF_OFF);
	}
	else if(app == 3)		//Elevator detection, Standard
	{
		qmp6988_set_oversampling_p(qmp6988, QMP6988_OVERSAMPLING_8X);
		qmp6988_set_oversampling_t(qmp6988, QMP6988_OVERSAMPLING_1X);
		qmp6988_set_filter(qmp6988, QMP6988_FILTERCOEFF_4);
	}
	else if(app == 4)		//Stair detection, High Accuracy
	{
		qmp6988_set_oversampling_p(qmp6988, QMP6988_OVERSAMPLING_16X);
		qmp6988_set_oversampling_t(qmp6988, QMP6988_OVERSAMPLING_2X);
		qmp6988_set_filter(qmp6988, QMP6988_FILTERCOEFF_8);
	}
	else if(app == 5)		//Indoor navigation, Ultra High Accuracy
	{
		qmp6988_set_oversampling_p(qmp6988, QMP6988_OVERSAMPLING_32X);
		qmp6988_set_oversampling_t(qmp6988, QMP6988_OVERSAMPLING_4X);
		qmp6988_set_filter(qmp6988, QMP6988_FILTERCOEFF_32);
	}
	else
	{
	}
}

//#define FILTER_NUM	5
//#define FILTER_A	0.1f
#if 0
#define Factor	0.05f
#define R	0.00801f
#else
#define Factor	0.01f
#define R	0.000000414975f
#endif
#define Q	R*Factor
static float x_now	= 0.0f;
static float  x_mid	= 0.0f;
static float  p_mid	= 0.0f;
static float  x_last = 0.0f;
static float  p_last = 0.0f;
static float  p_now = 0.0f;
static float  kg = 0.0f;

static float qmp6988_press_filter(float* in)
{
	if(x_last < 1.0)
	{
		x_last = * in;
	}
    x_mid=x_last; 
    p_mid=p_last+Q; 
    kg=p_mid/(p_mid+R); 
    x_now=x_mid+kg*(*in -x_mid); 
    p_now=(1-kg)*p_mid;
    p_last = p_now; 
    x_last = x_now; 

    return x_now;
}

void qmp6988_calc_pressure(qmp6988_data *qmp6988, float* temperature, float* pressure)
{
	QMP6988_U8_t err = 0;
//	QMP6988_U8_t retry_count = 0;
	QMP6988_U32_t P_read, T_read;
	QMP6988_S32_t P_raw, T_raw;
	QMP6988_U8_t a_data_u8r[6] = {0};
#if defined(QMP6988_CALC_INT)
	QMP6988_S32_t	T_int, P_int;
#else
	float a0,b00;
	float a1,a2,bt1,bt2,bp1,b11,bp2,b12,b21,bp3;
	double Tr;
#endif

#if 0
	a_data_u8r[0] = 0x08;
	retry_count = 0;

	while(a_data_u8r[0]&0x08)
	{
		err = qmp6988_ReadData(QMP6988_DEVICE_STAT_REG, a_data_u8r, 1);
		if(err == 0)
		{
			QMP6988_LOG("qmp6988 read status reg error! \n");
			return;
		}		
		QMP6988_LOG("qmp6988 read status 0xf3 = 0x%02x \n", a_data_u8r[0]);
		qmp6988_delay(10);
		retry_count++;
		if(retry_count > 5)
			return;
	}
#endif
	// press
	err = qmp6988_ReadData(qmp6988->slave, QMP6988_PRESSURE_MSB_REG, a_data_u8r, 6);
	if(err == 0)
	{
		QMP6988_LOG("qmp6988 read press raw error! \n");
		return;
	}
	P_read = (QMP6988_U32_t)(
	(((QMP6988_U32_t)(a_data_u8r[0])) << SHIFT_LEFT_16_POSITION) |
	(((QMP6988_U16_t)(a_data_u8r[1])) << SHIFT_LEFT_8_POSITION) | (a_data_u8r[2]));
	P_raw = (QMP6988_S32_t)(P_read - SUBTRACTOR);

	T_read = (QMP6988_U32_t)(
	(((QMP6988_U32_t)(a_data_u8r[3])) << SHIFT_LEFT_16_POSITION) |
	(((QMP6988_U16_t)(a_data_u8r[4])) << SHIFT_LEFT_8_POSITION) | (a_data_u8r[5]));
	T_raw = (QMP6988_S32_t)(T_read - SUBTRACTOR);

#if defined(QMP6988_CALC_INT)
	T_int = qmp6988_convTx_02e(&(qmp6988->ik),T_raw);
	P_int = qmp6988_get_pressure_02e(&(qmp6988->ik), P_raw, T_int);
	if(temperature)
		*temperature = (float)(T_int >> 8);
	if(pressure)
		*pressure = (float)(P_int >> 4);
//	QMP6988_LOG("int temp=%f	Pressure = %f\n",qmp6988->temperature, qmp6988->pressure);
#else
	a0 = qmp6988->fk.a0;
	b00 = qmp6988->fk.b00;
	a1 = qmp6988->fk.a1;
	a2 = qmp6988->fk.a2;
	bt1 = qmp6988->fk.bt1;
	bt2 = qmp6988->fk.bt2;
	bp1 = qmp6988->fk.bp1;
	b11 = qmp6988->fk.b11;
	bp2 = qmp6988->fk.bp2;
	b12 = qmp6988->fk.b12;
	b21 = qmp6988->fk.b21;
	bp3 = qmp6988->fk.bp3;

	Tr = a0 + a1*T_raw + a2*T_raw*T_raw;
	//Unit centigrade
	if(temperature)
		*temperature = (float)(Tr / 256.0f);
	//compensation pressure, Unit Pa
	if(pressure)
		*pressure = (float)(b00+bt1*Tr+bp1*P_raw+b11*Tr*P_raw+bt2*Tr*Tr+bp2*P_raw*P_raw+b12*P_raw*Tr*Tr+b21*P_raw*P_raw*Tr+bp3*P_raw*P_raw*P_raw);
#endif	
}


void qmp6988_dumpreg(qmp6988_data *qmp6988)
{
	QMP6988_U8_t data_u8r = 0;

	qmp6988_ReadData(qmp6988->slave, QMP6988_CTRLMEAS_REG, &data_u8r, 1);
	QMP6988_LOG("CTRLMEAS_REG (0x%x) = 0x%x \n", QMP6988_CTRLMEAS_REG, data_u8r);
	qmp6988_ReadData(qmp6988->slave, QMP6988_CONFIG_REG, &data_u8r, 1);
	QMP6988_LOG("CONFIG_REG (0x%x) = 0x%x \n", QMP6988_CONFIG_REG, data_u8r);
}

QMP6988_U8_t qmp6988_init(qmp6988_data *qmp6988)
{
	QMP6988_U8_t ret;

	qmp6988_delay(100);
	ret = qmp6988_device_check(qmp6988);
	if(ret == 0)
	{
		return 0;
	}
	qmp6988_software_reset(qmp6988);
	qmp6988_get_calibration_data(qmp6988);
	qmp6988_set_powermode(qmp6988, QMP6988_NORMAL_MODE);
	qmp6988_set_app(qmp6988, 1);
	qmp6988->press_cail_count = 5;
	//qmp6988_set_filter(qmp6988, QMP6988_FILTERCOEFF_OFF);
	//qmp6988_set_oversampling_p(qmp6988, QMP6988_OVERSAMPLING_2X);
	//qmp6988_set_oversampling_t(qmp6988, QMP6988_OVERSAMPLING_1X);
	qmp6988_dumpreg(qmp6988);

	return 1;
}


