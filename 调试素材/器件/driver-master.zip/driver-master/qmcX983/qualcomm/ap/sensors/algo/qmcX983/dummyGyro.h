#ifndef QMC_VIRTUAL_GYRO_H
#define QMC_VIRTUAL_GYRO_H
void dummyGyroInit();
void process_PG(float mag[],float acc[], int pg_out[]);
#endif


