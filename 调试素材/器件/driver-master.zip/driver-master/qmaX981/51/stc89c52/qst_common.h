#ifndef _QST_COMMON_H_
#define _QST_COMMON_H_

typedef char							int_8;
typedef char							s8;
typedef unsigned char					uint_8;
typedef unsigned char					u8;
typedef short							int_16;
typedef short							s16;
typedef unsigned short					uint_16;
typedef unsigned short					u16;
typedef int								int_32;
typedef int								s32;
typedef unsigned int					uint_32;
typedef unsigned int					u32;
//typedef long long							int_64;
//typedef unsigned long long		uint_64;


#endif
