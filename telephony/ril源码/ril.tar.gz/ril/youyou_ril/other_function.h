#ifndef _OTHER_FUNCTION_H_
#define _OTHER_FUNCTION_H_
/*other_function.h*/

/*when who why modified*/

#define KEYVALLEN 200


void  requestSendUSSD(void *data, size_t datalen, RIL_Token t);

void requestCancelUSSD(void *data, size_t datalen, RIL_Token t);

void requestOemHookStrings(void *data, size_t datalen, RIL_Token t);

void requestBasebandVersion(void *data, size_t datalen, RIL_Token t);

void requestGetIMEI(void *data, size_t datalen, RIL_Token t);

void requestGetIMEISV(void *data, size_t datalen, RIL_Token t);

void requestGetIMSI(void *data, size_t datalen, RIL_Token t);

/* added by nodecom begin */
void requestQueryClip(void *data, size_t datalen, RIL_Token t);

/* added by nodecom end */

//#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
/*Begin: Wujiabao changed it to '#if 1' in 2022/07/20*/
#if 1
/*End:   Wujiabao changed it to '#if 1' in 2022/07/20*/
void requestDeviceIdentity(void *data,size_t datalen,  RIL_Token t);
#endif

void get_Properties();
int getProfileString(char *AppName, char *KeyName, char *KeyVal, char *DefaultVal);
char *l_trim(char *szOutput, const char *szInput);
char *r_trim(char *szOutput, const char *szInput);
char *a_trim(char *szOutput, const char *szInput);

#endif /*_OTHER_FUNCTION_H_*/
