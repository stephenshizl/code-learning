#ifndef _GETDEVINFO_H_
#define _GETDEVINFO_H_

/*duanshitao add to get usb device information PID and interface class*/
/*to decide the net mode and at channel and data channel*/
int getdevinfors(char *vid, char *pid, char *atchannel, char *datachannel, int *mode);
int detect_usb_device(char *atchannel, char *datachannel);

/*
 *  diego add for campaticability M910 or other module match vid pid info
 *
 */
#define MAXLEN  15  // /dev/ttyUSB0
#define MAX_PATH 256
#define USBID_LEN 4
#define ARRAY_SIZE(a) (sizeof(a)/sizeof(a[0]))

#define MAX_TTYNAME_LEN 7
#define TTYNAME_DIAG   "ttyDiag"
#define TTYNAME_MODEM  "ttyModem"
#define TTYNAME_AT     "ttyAT"

typedef struct USBPORT{
    char atchannel[MAXLEN];
    char datachannel[MAXLEN];
    char diagchannel[MAXLEN];
}USBPortDevice;

struct fibo_module_info {
    const char idVendor[USBID_LEN+1];
    const char idProduct[USBID_LEN+1];
    char diag_inf;
    char modem_inf;
    char at_inf;
    char gps_inf;
    const char *id;
};

struct fibo_usb_device_info {
    const struct fibo_module_info *module_info;
    char usbdevice_pah[MAX_PATH];
    char ttyDM[16];
    char ttyAT[16];
    char ttyModem[16];
    char ttyGPS[16];
};

USBPortDevice s_usbPortDevice;

/*
 *  fibo support +gtusb mode static table
 */
static const struct fibo_module_info fibo_module_info_table[] = {
    {"1508", "1001", 0, 1, 2, -1, "NL668"}, //NL668
    {"2cb7", "0104", 0, 1, 2, -1, "NL678"}, //NL678
    {"2cb7", "0103", 0, 3, 2, 1, "M910"}, //M910
    {"2cb7", "0001", 5, 3, 4, -1, "L71x"}, //L716
    {"2cb7", "0106", 0, 1, 2, -1, "MA510"}, //MA510
    {"1782", "4D10", 5, 0, 6, -1, "L610"}, //L610, USBMODE:31,    PPP
    {"1782", "4D11", 7, 8, 2, -1, "L610"}, //L610, USBMODE:32,33, ECM
    {"1782", "4D30", 2, 0, 0, -1, "MC669"}, //MC669
    {"1782", "4D17", 2, 0, 4, -1, "MC669"}, //MC669, USBMODE:31, DEPRECATED
    {"1782", "4D13", 4, 2, 6, -1, "MC669"}, //MC669, USBMODE:32, DEPRECATED
    {"2cb7", "0c01", 4, 3, 4, -1, "MC919"}, //MC919, USBMODE:70, ECM
    {"2cb7", "0c02", 2, 4, 6, -1, "MC919"}, //MC919, USBMODE:71, RNDIS
    {"2cb7", "0c03", 2, 4, 3, -1, "MC919"}, //MC919, USBMODE:72, PPP
    {"2cb7", "0a0a", 1, 0, 3, -1, "MC669"}, //MC669, USBMODE:73, PPP
    {"2cb7", "0a0b", 3, 2, 5, -1, "MC669"}, //MC669, USBMODE:74, ECM
    {"2cb7", "0a0c", 3, 2, 5, -1, "MC669"}, //MC669, USBMODE:75, RNDIS
    {"2cb7", "0a01", 5, 0, 6, -1, "L610"}, //L610 PPP
    {"2cb7", "0a02", 7, 8, 2, -1, "L610"}, //L610 ECM
    {"2cb7", "0a03", 7, 8, 2, -1, "L610"}, //L610 RNDIS

    {"2cb7", "0a04", 3, 4, 2, -1, "FG621"}, //FG621-EA
    {"2cb7", "0a05", 3, 4, 2, -1, "FG621"}, //FG621-EA
    {"2cb7", "0a06", 3, 4, 2, -1, "FG621"}, //FG621-EA

    {"2cb7", "0a08", 1, 2, 0, -1, "H330S"}  //H330S
};

/*
 *  function: get usb device node path
 *  paras:    save find fibocom usb port device path 
 *  return:   0 success  others failure
 */
int getUsbPortInfo(USBPortDevice *usbPortDevice);

#endif/*_GETDEVINFO_H_*/

