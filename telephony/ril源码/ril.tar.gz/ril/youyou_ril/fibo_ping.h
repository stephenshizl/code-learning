/*************************************************************************
    Copyright (C)2015-2017 Fibocom Wireless Inc. All rights reserved
     File Name: pingtimer.h
     Author: LiuQiFeng
     Mail: liuqf@fibocom.com
     Created Time: Thu 25 Jan 2018 09:40:41 PM
     History:
     Date        Author       Comment:
     --------------------------------------------------------------------
                 LiuQiFeng
 ************************************************************************/
#define LOG_TAG GHT_RIL
#include <utils/Log.h>
#include "ril_common.h"
#include "other_function.h"

struct itimerval g_tmval;
int fibocom_pingcounter = 0;
int fibocom_pingflag = 0;
#define TIMER5    2
#define TIMER10  10
#define TIMER20  20
#define TIMER40  40
#define TIMER60  60

int ping_retry = 1;
int ping_interval = 60;
char ping_args[KEYVALLEN] = {0};
char ping_url[KEYVALLEN]  = {0};

#define RESTART_THRESHOLD 3
void fibocom_start_timer();
void fibocom_new_timer(int tv_sec);
void fibocom_stop_timer();

