/******************************************************************************
  Copyright (C), 2019, Shenzhen G&T Industrial Development Co., Ltd

  File:      network.c

  Author:  Fibocom-diego
  Version: 1.0
  Date:  2019.04

  Description:   networks APIs

** History:
**Author (core ID)                Date          Number     Description of Changes
**-----------------------------------------------------------------------------
** NODECOM-Aron                30-10-2018         **   init version 
** FIBOCOM-diego               10-01-2019         **   add requestDeviceIdentity support Androdi8.1
** FIBOCOM-diego               15-04-2019         **   add ****M910 function for M910
** -----------------------------------------------------------------------------
******************************************************************************/
#include <telephony/ril.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <alloca.h>
#include "atchannel.h"
#include "at_tok.h"
#include "misc.h"
#include <getopt.h>
#include <sys/socket.h>
#include <cutils/sockets.h>
#include <cutils/properties.h>
#include <termios.h>
#include <arpa/inet.h>
#include <dirent.h>
#include<sys/wait.h>

#include "ril_common.h"
#include "network.h"

#define LOG_TAG GHT_RIL
#include <utils/Log.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define LINUX_ROUTE "/proc/net/route"

/*begin:added by dengzq for ndis dial 20181208*/
#include <net/if.h>
#include <linux/sockios.h>
/*end:added by dengzq for ndis dial 20181208*/
/* BEGIN: Added by eric.li, 2019/1/22   PN:check dns if legal for issue 0015665 */
#include <regex.h>
#define ODM_DNS_SIZE 20
/* END:   Added by eric.li, 2019/1/22   PN:check dns if legal for issue 0015665 */
/* BEGIN: Added by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
#include <ctype.h>
/* END:   Added by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
/* pathname returned from RIL_REQUEST_SETUP_DATA_CALL / RIL_REQUEST_SETUP_DEFAULT_PDP */
#define PPP_TTY_PATH "ppp0"
#define NDIS_TTY_PATH "usb0"
#define ECM_TTY_PATH "eth1"

#define PPP_OPERSTATE_PATH "/sys/class/net/ppp0/operstate"
#define NDIS_OPERSTATE_PATH "/sys/class/net/usb0/operstate"
#define NDIS_MTU_PATH "/sys/class/net/usb0/mtu"
#define ECM_OPERSTATE_PATH "/sys/class/net/eth1/operstate"

#define SERVICE_PPPD_GPRS "pppd_gprs"
#define SERVICE_DHCPCD_ECM "dhcpcd_ecm"

#define PROPERTY_PPPD_EXIT_CODE "net.gprs.ppp-exit"
#define POLL_PPP_SYSFS_SECONDS    3
#define POLL_PPP_SYSFS_RETRY    5

#define POLL_NDIS_SYSFS_SECONDS    3
#define POLL_NDIS_SYSFS_RETRY    5

#ifdef PROP_NAME_MAX
#undef PROP_NAME_MAX
#endif //PROP_NAME_MAX
#define PROP_NAME_MAX 1000

#ifdef PROP_VALUE_MAX
#undef PROP_VALUE_MAX
#endif //PROP_VALUE_MAX
#define PROP_VALUE_MAX 1000

#ifdef SIGNAL_MODEM
// flag for pppd status. 1: started; 0: stoped
int pppd = 0;
#endif
//added for NL678-E-00
#define QUERY_NETWORK_TIMEOUT 300000
// --!>
/* BEGIN: Added by eric.li, 2019/1/3   PN:for ndis dial MTU size */
#define ODM_MTU_SIZE  1500
/* END:   Added by eric.li, 2019/1/3   PN:for ndis dial MTU size */
/* BEGIN: Added by eric.li, 2019/1/11   PN:0014445 ndis dail timeout */
#define ODM_RMNET_CALL_TIME_OUT     180000
/* END:   Added by eric.li, 2019/1/11   PN:0014445 ndis dail timeout */
extern dial_mode dialmode;
extern product_model mode_flag;
extern int eth1_interface;
static int isNBCard = 0;
bool ipv4_dial_flag = false;
bool ipv6_dial_flag = false;

//<--!Start:Added by Wujiabao:Variables associated with the "ril.fibocom.NetifName" property.
char cus_netifName[PROPERTY_VALUE_MAX]  = {0};   //Netif name specified by the customer
char cus_gw[100]         = {0};
char cus_local_ip[100]   = {0};
char cus_dns1[100]       = {0};
char cus_dns2[100]       = {0};
char cus_operstate[100]  = {0};
int  cus_netifName_flag  = 0;
//!-----End: Added by Wujiabao:Variables associated with the "ril.fibocom.NetifName" property.>

//<--!Start: Added by Wujiabao:Variables associated with the "ril.fibocom.cid" property.
int cus_cid = 1;
//!-----End: Added by Wujiabao:Variables associated with the "ril.fibocom.cid" property.>

//<--!Start: Added by Wujiabao:Variables associated with the "ril.fibocom.cgdcont0" property.
int cus_cgdcont0 = 0;
//!-----End: Added by Wujiabao:Variables associated with the "ril.fibocom.cgdcont0" property.>

//<--!Start: Added by Wujiabao:Variables associated with the "ril.fibocom.usbmode" property.
int cus_usbmode = NO_CUS_USBMODE;
//!-----End: Added by Wujiabao:Variables associated with the "ril.fibocom.usbmode" property.>


//<---!added by Wujiabao in 2022/2/28:Add global variables(flags) that indicate whether certain functionality is supported or not
int Voice_Support_Flag = 1;             //Whether voice calls are supported
int SMS_Support_Flag = 1;              //Whether SMS is supported
int GTRAT_Support_Flag = 1;            //Whether AT+GTRAT=XX is supported
int Net_3G_Support_Flag = 1;               //Whether to support 3G network
//!---->

//<!---Used only by ECM dials
char *ECM_NetifName = NULL;
char *ECM_local_ip  = NULL;
char *ECM_dns1      = NULL;
char *ECM_dns2      = NULL;
char *ECM_operstate = NULL;
//-----Used only by ECM dials--!>

int  ppp_fd = -1;
int  ndis_fd = -1;
int format_ip = 0;
extern int cur_oper;
extern int handover_flag;
extern int voice_handover_flag;
extern int script_type;
static int supportedTechs = -1;
//added for NL678-E-00
static int g_cops_lte = -1;

// <!--added by wangmengying@2017.12.13 for register network failed still need to send cops=0
static int g_SetNetworkSelectionManual = 0;
// end-->

// <!--added by wangmengying@2017.12.13 for  cops=0 need long timeout
#define TIME_OUT_COPS 300000
// end-->

/* BEGIN: Added by eric.li, 2018/12/28   PN:create a pid to trace the pppd */
int gPid_pppd_died = -1;
int gPid_pppd_live = -1;
/* END:   Added by eric.li, 2018/12/28   PN:create a pid to trace the pppd */

//#diego add for replace syscall for ndis all 20181208 

/* BEGIN: Modified by wujiabao in 2022/05/20 PN: Record the current APN information*/
//modify by zhengjianrong for IPV4V6 switch to IPV6 issue 20190528 begin
#define MAX_APN_NAME_LEN 20
#define DEFAULT_APN_CID  0
char Cur_Pdp_Type[8] = {0};                    //Current PDP type
char Cur_APN_Name[MAX_APN_NAME_LEN] = {0};     //Current APN name
int Get_Default_APN_Flag = 0;
//modify by zhengjianrong for IPV4V6 switch to IPV6 issue 20190528 end
/* END:  Modified by wujiabao in 2022/05/20 PN: Record the current APN information*/

static int g_mcc = 0xffff;
static int g_mnc = 0xffff;
static int g_lac = 0xffff;
static int g_cid = 0xffff;
static int g_pci = 0xffff;

extern int ifc_init();
extern int ifc_up(const char *name);
extern int do_dhcp(char*);
extern void ifc_close();
#define DEFAULTIP "0:0:0:0"
int fibo_get_ip(const char *interface, char *ip);
int fibo_bring_up_interface_do_dhcp(const char * iname);
static pthread_mutex_t s_ndismutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t s_ndiscond = PTHREAD_COND_INITIALIZER;
//diego add end 20181208 
/* BEGIN: Added by eric.li, 2019/1/28   PN:add interface for mark apn pdp type */
#define ODM_PDP_TYPE_SIZE 10
typedef enum{
    PDP_IPV4 = 0,
    PDP_IPV4V6 = 1,
    PDP_IPV6 = 2,
    PDP_IPUNKOWN = 3 ,
}RIL_Pdptype;

RIL_Pdptype g_apn_pdptype = PDP_IPV4;

typedef struct IPV6{
    char ipv6addr[256];
    char ipv6gateway[256];
    char ipv6dns1[256];
    char ipv6dns2[256];
}RIL_IPv6;





/* BEGIN: Modified by eric.li, 2018/12/29   PN:modify this function for ndis dial */
void get_gateway(char ** strGW)
{
        char *gw = NULL;
        FILE *input;
        char *a;
        struct in_addr * in = malloc(sizeof(struct in_addr));
        unsigned int num;

        gw = (char *)malloc(64);
        memset(gw, 0, 64);
        input = fopen(LINUX_ROUTE, "r");
        while(!feof(input) && fgetc(input) != '\n');
        fscanf(input, "%*s %*s %s %*s\n", gw);
        fclose(input);

        sscanf(gw, "%x", &num);
        free(gw);
        in->s_addr = num;
        a = (char *)inet_ntoa(*in);
        free(in);
        RLOGD("[%s,%d],a[%s] \r",__FUNCTION__, __LINE__, a);

        if (!(strcmp(a, "")) || !(strcmp(a, "0.0.0.0")) || getProfileBool("NETWORK", "GWFIX", false))
        {
            RLOGE("Fix the gateway...");
            odm_fix_gw(a);
            RLOGD("fixed a[%s]!", a);
        }

        strcpy(strGW[0], a);

        return ;
}
/* END:   Modified by eric.li, 2018/12/29   PN:modify this function for ndis dial */

void setIPv6(RIL_IPv6 ril_IPv6)
{
    if(dialmode == DIAL_RAS_MOD){
        property_set("net.ppp0.local-ip", ril_IPv6.ipv6addr);
        property_set("net.ppp0.gw", ril_IPv6.ipv6gateway);
        property_set("net.ppp0.dns1", ril_IPv6.ipv6dns1);
        property_set("net.ppp0.dns2", ril_IPv6.ipv6dns2);
    }
    else if(cus_netifName_flag)
    {
        property_set(cus_local_ip, ril_IPv6.ipv6addr);
        property_set(cus_gw, ril_IPv6.ipv6gateway);
        property_set(cus_dns1, ril_IPv6.ipv6dns1);
        property_set(cus_dns2, ril_IPv6.ipv6dns2);
    }
    else if(eth1_interface == 1){
        property_set("net.eth1.local-ip", ril_IPv6.ipv6addr);
        property_set("net.eth1.gw", ril_IPv6.ipv6gateway);
        property_set("net.eth1.dns1", ril_IPv6.ipv6dns1);
        property_set("net.eth1.dns2", ril_IPv6.ipv6dns2);
    }
    else{
    // <!--added by wangmengying@2020.2.24 fix bug41458,bug40979,bug41449,ECM dial support IPV6
        property_set("net.usb0.local-ip", ril_IPv6.ipv6addr);
        property_set("net.usb0.gw", ril_IPv6.ipv6gateway);
        property_set("net.usb0.dns1", ril_IPv6.ipv6dns1);
        property_set("net.usb0.dns2", ril_IPv6.ipv6dns2);
    // end-->
    }
    return;
}
void ConvertIPv6fomat(char *dest,char *src)
{
    int i =0;
    int index = 1;
    char *str = src;
    char delims[] = ".";
    char buf[10] = {0};
    char ipbuf[256] = {0};
   
    char *result = NULL;
    result = strtok(str,delims);
    while( result != NULL ) {
        i = atoi(result);
        sprintf(buf, "%02x", i);
        strcat(ipbuf,buf);
        if(index %2 == 0 && (index < 16)){
            strcat(ipbuf,":");
        }
        result = strtok(NULL,delims);
        index +=1;
    }
    //RLOGD("result ipbuf is [%s]",ipbuf);
    strcpy(dest,ipbuf);
}

/*
"192.168.1.3.255.1.1.1"  -> "192.168.1.1"
"36.14.0.191.212.4.167.175.0.1.0.2.28.142.36.126.255.255.255.255.255.255.255.255.0.0.0.0.0.0.0.0" -> "36.14.0.191.212.4.167.175.0.1.0.2.28.142.36.126"

*/
void split_subnet_mask(char *dest,char *str,bool is_ipv6)
{
    int i,j;
    for(i=0,j=0;str[i] != '\0';++i)
    {
        if('.' == str[i])
            ++j;
        if(j == 4 && !is_ipv6)
        {
            strncpy(dest,str,i);
            break;
        }
        if(j == 16 && is_ipv6)
        {
            strncpy(dest,str,i);
            break;
        }
    }
    return;
}

int get_global_ipv6addr(struct in6_addr *addr6, char *iface)
{
    #define IF_INET6 "/proc/net/if_inet6"
    #define IPV6_ADDR_GLOGBAL 0x0000U

    char str[128], address[64];
    char *addr, *index, *prefix, *scope, *flags, *name;
    char *delim = " \t\n", *p, *q;
    FILE *fp;
    int count, found_addr_flag = RET_FAIL;
    
    if (!addr6 || !iface)
    {
        RLOGE("addr6 and iface can't be NULL!");
        return RET_FAIL;
    }
    
    if (NULL == (fp = fopen(IF_INET6, "r")))
    {
        RLOGE("fopen %s error", IF_INET6);
        return RET_FAIL;
    }

    while (fgets(str, sizeof(str), fp))
    {
        RLOGD("str:%s", str);
        addr = strtok(str, delim);
        index = strtok(NULL, delim);
        prefix = strtok(NULL, delim);
        scope = strtok(NULL, delim);
        flags = strtok(NULL, delim);
        name = strtok(NULL, delim);
        RLOGD("addr:%s, index:0x%s, prefix:0x%s, scope:0x%s, flags:0x%s, name:%s",
        addr, index, prefix, scope, flags, name);

        if (strcmp(name, iface))
            continue;

        /* Just get IPv6 global address */
        if (IPV6_ADDR_GLOGBAL != (unsigned int)strtoul(scope, NULL, 16))
            continue;

        memset(address, 0x00, sizeof(address));
        p = addr;
        q = address;
        count = 0;
        while (*p != '\0') {
            if (count == 4) {
                *q++ = ':';
                count = 0;
            }
            *q++ = *p++;
            count++;
        }

        RLOGD("find out %s's global IPv6 address: %s\n", iface, address);
        inet_pton(AF_INET6, address, addr6);
        found_addr_flag = RET_SUCCESS;
        break;
    }
    fclose(fp);

    return found_addr_flag;
}
int getIPv6addr(char *dest)
{
    struct in6_addr addr6;
    char *ifname = "ppp0";
    if (dialmode == DIAL_RAS_MOD)
    {
        ifname = "ppp0";
    }
    else
    {
        ifname = "usb0";
    }
    char address[128];

    if (get_global_ipv6addr(&addr6, ifname)) {
        RLOGD("Get IPv6 global address of %s failed \n", ifname);
        return -1;
    }
    if (inet_ntop(AF_INET6, &addr6, address, sizeof(address)))
        RLOGD("IPv6 global address of %s is %s \n", ifname, address);

    strncpy(dest,address,strlen(address));
    return 0;
}

int getIPv6DefaultGateWay(char *dest)
{
   char defaultgw[] = "fe80::1";
   strcpy(dest,defaultgw);
   return 0;
}

int getIPv6GetDns(char *dest1,char *dest2)
{
    int err =0 ;
    ATResponse *p_response = NULL;
    char *line;
    int cid;
    char *pdns = NULL;
    char *sdns = NULL;
    char pdnsbuf[256] = {0};
    char sdnsbuf[256] = {0};
    char hexbuf[256] ={0};

    err = at_send_command_singleline("AT+GTDNS?", "+GTDNS:", &p_response);
    /*
     *+GTDNS: 1, "36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8", "36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
     *<cid>    : 1
     *<dns1> : "36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8"
     *<dns2> : "36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
     */
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &cid);
        if (err < 0) goto error;
        RLOGD("+GTDNS:<cid>[%d]", cid);
        err = at_tok_nextstr(&line, &pdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &sdns);
        if (err < 0) goto error;
        strncpy(pdnsbuf,pdns,strlen(pdns));
        strncpy(sdnsbuf,sdns,strlen(sdns));
        RLOGD("+GTDNS:<pdnsAddress>[%s]",pdnsbuf);
        RLOGD("+GTDNS:<sdnsAddress>[%s]",sdnsbuf);
    }
    //wangmengying@2020.2.12 add IPV6
    if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || 1 == format_ip || GHT_MC66x == mode_flag)
    {
        strncpy(dest1,pdnsbuf,strlen(pdnsbuf));
        strncpy(dest2,sdnsbuf,strlen(sdnsbuf));
    }
    else
    //end-->
    {
        ConvertIPv6fomat(hexbuf,pdnsbuf);
        RLOGD("getIPv6GetDns:<pdns>[%s]",hexbuf);
        strncpy(dest1,hexbuf,strlen(hexbuf));
        memset(hexbuf,0,sizeof(hexbuf));
        ConvertIPv6fomat(hexbuf,sdnsbuf);
        RLOGD("getIPv6GetDns:<sdns>[%s]",hexbuf);
        strncpy(dest2,hexbuf,strlen(hexbuf));
    }
error:
    at_response_free(p_response);
    p_response = NULL;
    return err;

}
// <!--added by wangmengying@2020.2.24 fix bug41458,bug40979,bug41449,ECM dial support IPV6
int getRndisInfo(char *addr,char *gateway,char *dest1,char *dest2)
{
    int err =0 ;
    ATResponse *p_response = NULL;
    char *line;
    int cid;
    int state;
    char *ip = NULL;
    char *pdns = NULL;
    char *sdns = NULL;
    char *dnsbuf;
    char *ipv4addr = NULL;
    char *ipv6addr = NULL;
    char gw4_addr[PROPERTY_VALUE_MAX]={0};
    char defaultgw_v6[] = "fe80::1";
    char *ipv4pdns = NULL;
    char *ipv6pdns = NULL;
    char *ipv4sdns = NULL;
    char *ipv6sdns = NULL;
    char buf[256] = {0};
    struct in6_addr addr6;
    char address[128] = {0};
    char *ifname = "usb0";
    char local_ip[PROPERTY_VALUE_MAX]={0};

    memset(buf,0,sizeof(buf));

    err = at_send_command_singleline("AT+GTRNDIS?", "+GTRNDIS:", &p_response);
    /*
     *+GTRNDIS: 1,1,"ip","pdns","sdns"
     *<state> : 1
     *<cid>   : 1
     *<ip>    : "ipv4,ipv6"
     *<pdns>  : "pdns_v4,pdns_v6"
     *<sdns>  : "sdns_v4,sdns_v6"
     */
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &state);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &cid);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ip);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &pdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &sdns);
        if (err < 0) goto error;
    }
    else
    {
        goto error;
    }

    if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
    {
        sleep(1);

        if (get_global_ipv6addr(&addr6, ECM_NetifName)) {
            RLOGD("Get IPv6 global address of %s failed, and we continue to try to get the IPV6 address from GTRNDIS command!", ECM_NetifName);
        }
        else
        {
            if (inet_ntop(AF_INET6, &addr6, address, sizeof(address)))
                RLOGD("IPv6 global address of %s is %s \n", ECM_NetifName, address);
        }
    }

    if (PDP_IPV6 == g_apn_pdptype)
    {
        //strncpy(dest,address,strlen(address));
        if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
        {
            strcpy(addr,address);
        }
        else
        {
            strcpy(addr,ip);
        }
        strcpy(gateway,defaultgw_v6);
        strcpy(dest1,pdns);
        strcpy(dest2,sdns);
    }
    else
    {
        ipv4addr = strtok(ip, ",");
        //RLOGD("ipv4addr:%s", ipv4addr);
        if (GHT_FG621 == mode_flag || GHT_FG650 == mode_flag)
        {
            property_get("net.usb0.local-ip", local_ip, "");
            strcpy(buf,local_ip);
        }
        else
        {
            strcpy(buf,ipv4addr);
        }
        //RLOGD("ipv4 buf:%s", buf);
        //RLOGD("mode_flag:%d, strlen(address):%d, sizeof(address):%d", mode_flag, strlen(address), sizeof(address));


        if ((GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag) && (0 != strlen(address)))
        {
            RLOGD("address:%s", address);
            strcat(buf," ");
            strcat(buf,address);
            strcpy(addr,buf);
        }
        else
        {
            ipv6addr = strtok(NULL, ",");
            if (NULL != ipv6addr)
            {
                //RLOGD("ipv6addr:%s", ipv6addr);
                strcat(buf," ");
                strcat(buf,ipv6addr);
                strcpy(addr,buf);
            }
            else
            {
                //RLOGD("ipv6addr is null");
                strcpy(addr,buf);
            }
        }
        //RLOGD("ipv4v6 addr:%s", addr);
        memset(buf,0,sizeof(buf));

        strcpy(gateway,defaultgw_v6);     //Why is the default ipv6 gateway set to fe80::1 ?
        memset(buf,0,sizeof(buf));

        ipv4pdns = strtok(pdns, ",");
        strcpy(buf,ipv4pdns);
        ipv6pdns = strtok(NULL, ",");
        if (NULL != ipv6pdns)
        {
            strcat(buf," ");
            strcat(buf,ipv6pdns);
            strcpy(dest1,buf);
        }
        else
        {
            strcpy(dest1,buf);
        }
        memset(buf,0,sizeof(buf));

        ipv4sdns = strtok(sdns, ",");
        strcpy(buf,ipv4sdns);
        ipv6sdns = strtok(NULL, ",");
        if (NULL != ipv6sdns)
        {
            strcat(buf," ");
            strcat(buf,ipv6sdns);
            strcpy(dest2,buf);
        }
        else
        {
            strcpy(dest2,buf);
        }
        memset(buf,0,sizeof(buf));
    }
error:
    at_response_free(p_response);
    p_response = NULL;
    return err;

}
// end-->
int getIPV6Info(RIL_IPv6 *riL_IPv6)
{
    int err =0;
// <!--added by wangmengying@2020.2.24 fix bug41458,bug40979,bug41449,ECM dial support IPV6
    if (1 == dialmode)
    {
        err = getRndisInfo(riL_IPv6->ipv6addr,riL_IPv6->ipv6gateway,riL_IPv6->ipv6dns1,riL_IPv6->ipv6dns2);
    }
    else
    {
        err = getIPv6addr(riL_IPv6->ipv6addr);
        err = getIPv6DefaultGateWay(riL_IPv6->ipv6gateway);
        err = getIPv6GetDns(riL_IPv6->ipv6dns1,riL_IPv6->ipv6dns2);
    }

    return err;
}

int getIPV4V6Info_new(RIL_IPv6 * riL_IPv6)
{
    int err =0;
    ATResponse *p_response = NULL;
    char *line;
    char *line_ipv6 = NULL;
    int cid;
    int bearer_id;
    char *apn = NULL;
    char *ipv4addr = NULL;
    char *ipv6addr = NULL;
    char *gw4_addr1 = (char *)calloc(PROPERTY_VALUE_MAX, sizeof(char));
    char  gw4_addr[PROPERTY_VALUE_MAX]={0};
    char *gw6_addr = NULL;
    char *ipv4pdns = NULL;
    char *ipv6pdns = NULL;
    char *ipv4sdns = NULL;
    char *ipv6sdns = NULL;
    char buf[256] = {0};
    char ipv4_subnet_buf[256] = {0};
    char ipv6_subnet_buf[256] = {0};
    char hexbuf[256] ={0};
    char *ptr = NULL;
    ATLine  *p_cur;
    struct in6_addr addr6;
    char address[128];
    char *ifname = "ppp0";
    err = at_send_command_multiline("AT+CGCONTRDP=1", "+CGCONTRDP:", &p_response);
/*
     //new AT+CGCONTRDP format as show

    AT+CGCONTRDP=1
    +CGCONTRDP: 1,5,"ctnet","10.122.197.109.255.0.0.0","0.0.0.0","61.134.1.6","218.30.19.40","0.0.0.0","0.0.0.0"
    +CGCONTRDP: 1,5,"ctnet","36.14.0.191.212.4.167.175.0.1.0.2.28.142.36.126.255.255.255.255.255.255.255.255.0.0.0.0.0.0.0.0","254.128.0.0.0.0.0.0.0.0.0.0.0.0.0.5","36.14.0.15.0.10.0.0.0.0.0.0.0.0.0.8","0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0","0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0","0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0"
      *<cid>         : 1,
      *<bearer_id>   : 5,
      *<apn>         : cmnet,
      *<ipv6addr and subnet_mask>:"36.14.0.191.212.4.167.175.0.1.0.2.28.142.36.126.255.255.255.255.255.255.255.255.0.0.0.0.0.0.0.0",
      *<gw6_addr>:"254.128.0.0.0.0.0.0.0.0.0.0.0.0.0.5"
      *<ipv6pdns>:"36.14.0.15.0.10.0.0.0.0.0.0.0.0.0.8"
      *<ipv6sdns>:"0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0"
      *<ipv6P-CSCF_prim_addr>:"0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0"
      *<ipv64P-CSCF_sec_addr>:"0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0"
*/

    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        // Split IPV6 strings 
        p_cur = p_response->p_intermediates;
        p_cur = p_cur->p_next;
        line_ipv6 = p_cur->line;

        RLOGD("**********line_ipv4: [%s] \n",line);

        //ipv4 info
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &cid);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &bearer_id);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &apn);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4addr);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &gw4_addr);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4pdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4sdns);
        if (err < 0) goto error;

        //ipv6 info
        if(line_ipv6 != NULL)
        {
            RLOGD("**********line_ipv6: [%s] \n",line_ipv6);

            err = at_tok_start(&line_ipv6);
            if (err < 0) goto error;
            err = at_tok_nextint(&line_ipv6, &cid);
            if (err < 0) goto error;
            err = at_tok_nextint(&line_ipv6, &bearer_id);
            if (err < 0) goto error;
            err = at_tok_nextstr(&line_ipv6, &apn);
            if (err < 0) goto error;
            err = at_tok_nextstr(&line_ipv6, &ipv6addr);
            if (err < 0) goto error;
            err = at_tok_nextstr(&line_ipv6, &gw6_addr);
            RLOGD("**********gw6_addr: [%s]",gw6_addr);
            if (err < 0) goto error;
            err = at_tok_nextstr(&line_ipv6, &ipv6pdns);
            if (err < 0) goto error;
            err = at_tok_nextstr(&line_ipv6, &ipv6sdns);
            if (err < 0) goto error;
        }
        else
        {
           RLOGD("Split IPV6 info error \n");
        }
    }

    if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
    {
        if (get_global_ipv6addr(&addr6, ifname)) {
            RLOGD("Get IPv6 global address of %s failed \n", ifname);
            return -1;
        }
        if (inet_ntop(AF_INET6, &addr6, address, sizeof(address)))
            RLOGD("IPv6 global address of %s is %s \n", ifname, address);
    }

    //split ipv4 subnet mask
    split_subnet_mask(ipv4_subnet_buf,ipv4addr,0);
    strncpy(buf,ipv4_subnet_buf,strlen(ipv4_subnet_buf));
    strcat(buf," ");

    if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
    {
        strcat(buf,address);
    }
    else
    {
        //split ipv6 subnet mask
        split_subnet_mask(ipv6_subnet_buf,ipv6addr,1);
        RLOGD("split ipv6 subnet mask =%s\n",ipv6_subnet_buf);
        ConvertIPv6fomat(hexbuf,ipv6_subnet_buf);
        strcat(buf,hexbuf);
    }
    strncpy(riL_IPv6->ipv6addr,buf,strlen(buf));
    memset(buf,0,sizeof(buf));
    memset(hexbuf,0,sizeof(hexbuf));

    property_get("net.ppp0.remote-ip", gw4_addr, "");
    RLOGD("gw4_addr [%s]", gw4_addr);
    strncpy(buf,gw4_addr,strlen(gw4_addr));
    strcat(buf," ");
    ConvertIPv6fomat(hexbuf,gw6_addr);
    strcat(buf,hexbuf);
    RLOGD("*********gw4-gw6-buf: [%s]",buf);
    strncpy(riL_IPv6->ipv6gateway,buf,strlen(buf));
    memset(buf,0,sizeof(buf));
    memset(hexbuf,0,sizeof(hexbuf));

    strncpy(buf,ipv4pdns,strlen(ipv4pdns));
    strcat(buf," ");
    ConvertIPv6fomat(hexbuf,ipv6pdns);
    strcat(buf,hexbuf);
    strncpy(riL_IPv6->ipv6dns1,buf,strlen(buf));
    memset(buf,0,sizeof(buf));
    memset(hexbuf,0,sizeof(hexbuf));

    strncpy(buf,ipv4sdns,strlen(ipv4sdns));
    strcat(buf," ");
    ConvertIPv6fomat(hexbuf,ipv6sdns);
    strcat(buf,hexbuf);
    strncpy(riL_IPv6->ipv6dns2,buf,strlen(buf));
    memset(buf,0,sizeof(buf));
    memset(hexbuf,0,sizeof(hexbuf));
error:
    at_response_free(p_response);
    p_response = NULL;
    return err;
}


int getIPV4V6Info_GTRNDIS(RIL_IPv6 * riL_IPv6)
{
    int err =0;
    ATResponse *p_response = NULL;
    char *line;
    int cid;
    int state;
    char *apn = NULL;
    char *ipv4v6addr = NULL;
    char *ipv6addr = NULL;
    char gw4_addr[PROPERTY_VALUE_MAX]={0};
    char *gw6_addr = NULL;
    char *ipv4v6pdns = NULL;
    char *ipv6pdns = NULL;
    char *ipv4v6sdns = NULL;
    char *ipv6sdns = NULL;
    char buf[256] = {0};
    char hexbuf[256] ={0};
    char *ptr = NULL;
    err = at_send_command_singleline("AT+GTRNDIS?", "+GTRNDIS:", &p_response);
    /*
     *+GTRNDIS: 1,1,"10.124.228.66,2408:84fb:1221:e985:0000:0000:0000:0001","221.11.1.67,2408:8888:0000:0000:0000:0000:0000:0008","221.11.1.68,2408:8899:0000:0000:0000:0000:0000:0008"
     *<state>         : 1,
     *<cid>   : 1,
     *<ipv4addr>:"10.124.228.66",
     *<ipv6addr>:"2408:84fb:1221:e985:0000:0000:0000:0001",
     *<ipv4pdns> : "221.11.1.67"
     *<ipv6pdns> : "2408:8888:0000:0000:0000:0000:0000:0008",
     *<ipv4sdns> : "221.11.1.68,"
     *<ipv6sdns> : "2408:8899:0000:0000:0000:0000:0000:0008"
     */
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &state);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &cid);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4v6addr);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4v6pdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4v6sdns);
        if (err < 0) goto error;
        
    }
    else
    {
        RLOGD("getIPV4V6Info:<err>[%d]",err);
        goto error;
    }
   
    
error:
    at_response_free(p_response);
    p_response = NULL;
    return err;
}


int getIPV4V6Info(RIL_IPv6 *riL_IPv6)
{
    int err =0;
    ATResponse *p_response = NULL;
    char *line;
    int cid;
    int bearer_id;
    char *apn = NULL;
    char *ipv4addr = NULL;
    char *ipv6addr = NULL;
    char gw4_addr[PROPERTY_VALUE_MAX]={0};
    char *gw6_addr = NULL;
    char *ipv4pdns = NULL;
    char *ipv6pdns = NULL;
    char *ipv4sdns = NULL;
    char *ipv6sdns = NULL;
    char buf[256] = {0};
    char hexbuf[256] ={0};
    char *ptr = NULL;
    err = at_send_command_singleline("AT+CGCONTRDP=1", "+CGCONTRDP:", &p_response);
    /*
     *+CGCONTRDP: 1,5,"cmnet",
     *  "10.118.223.168","36.9.137.84.48.84.49.23.125.103.123.85.198.141.4.208",
     *  "254.128.0.0.0.0.0.0.0.0.0.0.0.0.0.1",
     *  "120.196.165.7" "36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8",
     *  "221.179.38.7" "36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
     *<cid>         : 1,
     *<bearer_id>   : 5,
     *<apn>         : cmnet,     
     *<ipv4addr>:"10.118.223.168",
     *<ipv6addr>:"36.9.137.84.48.84.49.23.125.103.123.85.198.141.4.208",
     *<gw6_addr>     : 254.128.0.0.0.0.0.0.0.0.0.0.0.0.0.1,
     *<ipv4pdns> : "120.196.165.7"
     *<ipv6pdns> : "36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8",
     *<ipv4sdns> : "120.196.165.7"
     *<ipv6sdns> : "36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
     */
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &cid);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &bearer_id);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &apn);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4addr);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv6addr);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &gw6_addr);
        if (err < 0) goto error;
        /*
         * handle Null char instead of ','
         *"120.196.165.7" "36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8","120.196.165.7" "36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
         *"120.196.165.7","36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8","120.196.165.7","36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
         */
        ptr = line;
        while(*ptr != '\0'){
            if(*ptr == ' '){
                *ptr = ',';
            }
            ptr++;
        }
        err = at_tok_nextstr(&line, &ipv4pdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv6pdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4sdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv6sdns);
        if (err < 0) goto error;
    }
    // <!--[ODM]wangmengying@2019.12.20 fix bug36697,switch network,RIL reset,dial-up failed
    else
    {
        RLOGD("getIPV4V6Info:<err>[%d]",err);
        goto error;
    }
    // end--!>

    if (1 == format_ip)
    {
        strncpy(buf,ipv4addr,strlen(ipv4addr));
        strcat(buf," ");
        strcat(buf,ipv6addr);
        strncpy(riL_IPv6->ipv6addr,buf,strlen(buf));
        memset(buf,0,sizeof(buf));

        property_get("net.ppp0.remote-ip", gw4_addr, "");
        strncpy(buf,gw4_addr,strlen(gw4_addr));
        strcat(buf," ");
        strcat(buf,gw6_addr);
        strncpy(riL_IPv6->ipv6gateway,buf,strlen(buf));
        memset(buf,0,sizeof(buf));

        strncpy(buf,ipv4pdns,strlen(ipv4pdns));
        strcat(buf," ");
        strcat(buf,ipv6pdns);
        strncpy(riL_IPv6->ipv6dns1,buf,strlen(buf));
        memset(buf,0,sizeof(buf));

        strncpy(buf,ipv4sdns,strlen(ipv4sdns));
        strcat(buf," ");
        strcat(buf,ipv6sdns);
        strncpy(riL_IPv6->ipv6dns2,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
    }
    else
    {
        strncpy(buf,ipv4addr,strlen(ipv4addr));
        strcat(buf," ");
        ConvertIPv6fomat(hexbuf,ipv6addr);
        strcat(buf,hexbuf);
        strncpy(riL_IPv6->ipv6addr,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
        memset(hexbuf,0,sizeof(hexbuf));

        property_get("net.ppp0.remote-ip", gw4_addr, "");
        strncpy(buf,gw4_addr,strlen(gw4_addr));
        strcat(buf," ");
        ConvertIPv6fomat(hexbuf,gw6_addr);
        strcat(buf,hexbuf);
        strncpy(riL_IPv6->ipv6gateway,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
        memset(hexbuf,0,sizeof(hexbuf));

        strncpy(buf,ipv4pdns,strlen(ipv4pdns));
        strcat(buf," ");
        ConvertIPv6fomat(hexbuf,ipv6pdns);
        strcat(buf,hexbuf);
        strncpy(riL_IPv6->ipv6dns1,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
        memset(hexbuf,0,sizeof(hexbuf));

        strncpy(buf,ipv4sdns,strlen(ipv4sdns));
        strcat(buf," ");
        ConvertIPv6fomat(hexbuf,ipv6sdns);
        strcat(buf,hexbuf);
        strncpy(riL_IPv6->ipv6dns2,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
        memset(hexbuf,0,sizeof(hexbuf));
    }
error:
    at_response_free(p_response);
    p_response = NULL;
    return err;

}
int getIPV4V6InfoL716(RIL_IPv6 *riL_IPv6)
{
    int err =0;
    ATResponse *p_response = NULL;
    char *line;
    int cid;
    int bearer_id;
    char *apn = NULL;
    char *ipv4addr = NULL;
    char *ipv6addr = NULL;
    char gw4_addr[PROPERTY_VALUE_MAX]={0};
    char *gw6_addr = NULL;
    char *ipv4pdns = NULL;
    char *ipv6pdns = NULL;
    char *ipv4sdns = NULL;
    char *ipv6sdns = NULL;
    char buf[256] = {0};
    char hexbuf[256] ={0};
    char *ptr = NULL;
    err = at_send_command_singleline("AT+CGCONTRDP=1", "+CGCONTRDP:", &p_response);
    /*
     *+CGCONTRDP: 1,5,"cmnet",
     *  "10.118.223.168","36.9.137.84.48.84.49.23.125.103.123.85.198.141.4.208",
     *  "254.128.0.0.0.0.0.0.0.0.0.0.0.0.0.1",
     *  "120.196.165.7" "36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8",
     *  "221.179.38.7" "36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
     *<cid>         : 1,
     *<bearer_id>   : 5,
     *<apn>         : cmnet,     
     *<ipv4addr>:"10.118.223.168",
     *<ipv6addr>:"36.9.137.84.48.84.49.23.125.103.123.85.198.141.4.208",
     *<gw6_addr>     : 254.128.0.0.0.0.0.0.0.0.0.0.0.0.0.1,
     *<ipv4pdns> : "120.196.165.7"
     *<ipv6pdns> : "36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8",
     *<ipv4sdns> : "120.196.165.7"
     *<ipv6sdns> : "36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
     */
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &cid);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &bearer_id);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &apn);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4addr);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv6addr);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &gw6_addr);
        if (err < 0) goto error;
        /*
         * handle Null char instead of ','
         *"120.196.165.7" "36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8","120.196.165.7" "36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
         *"120.196.165.7","36.9.128.87.32.0.0.0.0.0.0.0.0.0.0.8","120.196.165.7","36.9.128.87.32.0.0.4.0.0.0.0.0.0.0.8"
         */
        ptr = line;
        while(*ptr != '\0'){
            if(*ptr == ' '){
                *ptr = ',';
            }
            ptr++;
        }
        err = at_tok_nextstr(&line, &ipv4pdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv6pdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv4sdns);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &ipv6sdns);
        if (err < 0) goto error;
    }
    // <!--[ODM]wangmengying@2019.12.20 fix bug36697,switch network,RIL reset,dial-up failed
    else
    {
        RLOGD("getIPV4V6Info:<err>[%d]",err);
        goto error;
    }
    // end--!>

    if (1 == format_ip)
    {
        strncpy(buf,ipv4addr,strlen(ipv4addr));
        strcat(buf," ");
        strcat(buf,ipv6addr);
        strncpy(riL_IPv6->ipv6addr,buf,strlen(buf));
        memset(buf,0,sizeof(buf));

        property_get("net.ppp0.remote-ip", gw4_addr, "");
        strncpy(buf,gw4_addr,strlen(gw4_addr));
        strcat(buf," ");
        strcat(buf,gw6_addr);
        strncpy(riL_IPv6->ipv6gateway,buf,strlen(buf));
        memset(buf,0,sizeof(buf));

        strncpy(buf,ipv4pdns,strlen(ipv4pdns));
        strcat(buf," ");
        strcat(buf,ipv6pdns);
        strncpy(riL_IPv6->ipv6dns1,buf,strlen(buf));
        memset(buf,0,sizeof(buf));

        strncpy(buf,ipv4sdns,strlen(ipv4sdns));
        strcat(buf," ");
        strcat(buf,ipv6sdns);
        strncpy(riL_IPv6->ipv6dns2,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
    }
    else
    {
        strncpy(buf,ipv4addr,strlen(ipv4addr));
        strcat(buf," ");
        ConvertIPv6fomat(hexbuf,ipv6addr);
        strcat(buf,hexbuf);
        strncpy(riL_IPv6->ipv6addr,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
        memset(hexbuf,0,sizeof(hexbuf));

        property_get("net.ppp0.remote-ip", gw4_addr, "");
        strncpy(buf,gw4_addr,strlen(gw4_addr));
        strcat(buf," ");
        ConvertIPv6fomat(hexbuf,gw6_addr);
        strcat(buf,hexbuf);
        strncpy(riL_IPv6->ipv6gateway,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
        memset(hexbuf,0,sizeof(hexbuf));

        strncpy(buf,ipv4pdns,strlen(ipv4pdns));
        strcat(buf," ");
        ConvertIPv6fomat(hexbuf,ipv6pdns);
        strcat(buf,hexbuf);
        strncpy(riL_IPv6->ipv6dns1,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
        memset(hexbuf,0,sizeof(hexbuf));

        strncpy(buf,ipv4sdns,strlen(ipv4sdns));
        strcat(buf," ");
        ConvertIPv6fomat(hexbuf,ipv6sdns);
        strcat(buf,hexbuf);
        strncpy(riL_IPv6->ipv6dns2,buf,strlen(buf));
        memset(buf,0,sizeof(buf));
        memset(hexbuf,0,sizeof(hexbuf));
    }
error:
    at_response_free(p_response);
    p_response = NULL;
    return err;

}

int rilInitIPV6(void)
{
    ENTER_FUNC;
    int ret = 0;
    RIL_IPv6 ril_IPv6;

    memset(&ril_IPv6,0,sizeof(RIL_IPv6));

    if (PDP_IPV6 == g_apn_pdptype)
    {
        ret = getIPV6Info(&ril_IPv6);
    }
    else
    {
        if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
        {
            //ret = getIPV4V6Info_new(&ril_IPv6);
            goto done;
        }
        else if(GHT_FG621 == mode_flag || (GHT_FG650==mode_flag ))
        {
            ret = getIPV4V6Info_GTRNDIS(&ril_IPv6);
        }
        else if(GHT_L716 == mode_flag)
        {
            ret = getIPV4V6Info(&ril_IPv6);
        }
        else
        {
            ret = getIPV4V6Info(&ril_IPv6);
        }
    }
    if(ret){
        RLOGE("getIPv6 fail");
        goto done;
    }
    RLOGD("RIL IPV6 ipv6addr: [%s]",ril_IPv6.ipv6addr);
    RLOGD("RIL IPV6 ipv6gateway: [%s]",ril_IPv6.ipv6gateway);
    RLOGD("RIL IPV6 ipv6dns1: [%s]",ril_IPv6.ipv6dns1);
    RLOGD("RIL IPV6 ipv6dns2: [%s]",ril_IPv6.ipv6dns2);
    setIPv6(ril_IPv6);
 done:
    LEAVE_FUNC;
    return ret;
}

static char * strupr(char * str)
{
    char * origin = str;
    for (; *str != '\0'; str++)
    {
        *str = toupper(*str);
    }
    return origin;
}

static RIL_Pdptype odm_get_pdptype(const char * pdp_str)
{
    RIL_Pdptype type = 0;
    char *p_tmp = (char *) alloca(ODM_PDP_TYPE_SIZE * sizeof(char));

    if (NULL == pdp_str)
    {
        RLOGD("odm_get_pdptype input null");
        type = PDP_IPUNKOWN;
        return type;
    }
    
    if (NULL == p_tmp)
    {
        RLOGD("odm_get_pdptype alloca for p_tmp failed");
        type = PDP_IPUNKOWN;
        return type;
    }

    memset(p_tmp, 0, ODM_PDP_TYPE_SIZE);

    strcpy(p_tmp, pdp_str);

    p_tmp = strupr(p_tmp);

    if (0 == strcmp(p_tmp, "IP"))
    {
        type = PDP_IPV4;
    }
    else if (0 == strcmp(p_tmp, "IPV4V6"))
    {
        type = PDP_IPV4V6;
    }
    else if (0 == strcmp(p_tmp, "IPV6"))
    {
        type = PDP_IPV6;
    }
    else
    {
        type = PDP_IPUNKOWN;
    }
    
    RLOGD("odm_get_pdptype  %d", type);

    return type;
}

/* END:   Added by eric.li, 2019/1/28   PN:add interface for mark apn pdp type */
int at_send_command_dial(int fd, const char * command);
extern int dhcp_do_request(const char *ifname,
        in_addr_t *ipaddr,
        in_addr_t *gateway,
        in_addr_t *mask,
        in_addr_t *dns1,
        in_addr_t *dns2,
        in_addr_t *server,
        uint32_t  *lease);

extern int dhcp_stop(const char *interface);
//added for NL678-E-00
static int parseRegistrationState(char *str, int *type, int *items, int **response);

/* BEGIN: Added by eric.li, 2019/1/17   PN:add function odm_get_dns_gtdns */
int  odm_get_dns_gtdns(char ** dns1, char **dns2)
{
	int err;
	ATResponse *p_response = NULL;
	char *line;
	int cid;

	err = at_send_command_singleline("AT+GTDNS?", "+GTDNS:", &p_response);
	/*
	*AT+GTDNS?
	*+GTDNS: 1,"120.80.80.80","221.5.88.88"
	*<cid>    : 1
	*<dns1> : "120.80.80.80"
	*<dns2> : "221.5.88.88"
	*/
	if (err == 0 && p_response->success != 0)
	{
		line = p_response->p_intermediates->line;
		err = at_tok_start(&line);
		if (err < 0) goto error;

		err = at_tok_nextint(&line, &cid);
		if (err < 0) goto error;

		err = at_tok_nextstr(&line, &dns1);
		if (err < 0) goto error;

		err = at_tok_nextstr(&line, &dns2);
		if (err < 0) goto error;
	}

    at_response_free(p_response);
    p_response = NULL;
    return err;

error:
    at_response_free(p_response);
    err = -1;
    return err;	
}

/* END:   Added by eric.li, 2019/1/17   PN:add function odm_get_dns_gtdns */
/* BEGIN: Added by eric.li, 2019/1/21   PN:check dns if legal */

int odm_regex_exe(const char *regex_pattern, const char *to_match)
{
    regex_t r;
    int ret;
    int match;
    char errmsg[128];
 
    if(regcomp(&r, regex_pattern, REG_EXTENDED | REG_NEWLINE)) {
        RLOGD("regcomp failed!\n");
        regfree(&r);
        return -1;
    }
 
    ret = regexec(&r, to_match, 0, NULL, 0);
    if(!ret) {
        match = 1;
        RLOGD("match!\n");
    } else if(ret == REG_NOMATCH) {
        match = 0;
        RLOGD("not match!\n");
    } else {
        regerror(ret, &r, errmsg, sizeof(errmsg));
        RLOGD("regexec failed: %s!\n", errmsg);
        regfree(&r);
        return -1;
    }
 
    regfree(&r);
    return match;
}

int odm_check_dns(const char * pdns, const char * sdns)
{
    int match;
    const char validDnsRegex[] = "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\\-]*[A-Za-z0-9])$";
 
    RLOGD("odm_check_dns1:%s\n", pdns);
    match = odm_regex_exe(validDnsRegex, pdns);
    if(match != 1) {
        return -1;
    }

    RLOGD("odm_check_dns2:%s\n", sdns);
    match = odm_regex_exe(validDnsRegex, sdns);
    if(match != 1) {
        return -1;
    }
 
    return 0;
}

void odm_fix_gw(char *gw)
{
    int dot_count = 0, i = 0;
    char *cmd = NULL;

    property_get(ECM_local_ip, gw, "0.0.0.0");
    RLOGD("[%s,%d] get local_ip: %s", __FUNCTION__, __LINE__, gw);

    if(CHECK_DNS_AVAILABLE(gw))
    {
        do
        {
            //RLOGD("local_ip[%d]:%c", i, gw[i]);
            if('.' == gw[i])
            {
                dot_count++;
                //RLOGD("get '.', counter:%d", dot_count);
            }
            i++;
        }
        while (dot_count < 3);

        //RLOGD("i:%d, local_ip[i]:%c", i, gw[i]);
        strcpy(&gw[i], "1");
        RLOGD("new gw:%s", gw);

        cmd = (char *)malloc(128 * sizeof(char));

        i = 3;
        do
        {
            asprintf(&cmd, "/system/bin/ip route add default via %s dev %s", gw, ECM_NetifName);
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);
            sleep(1);
        }
        while (--i);
        


        asprintf(&cmd, "/system/bin/ip rule add from all lookup main pref 31999");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);
    }

}

int odm_fix_dns(char *p_pdns,  char *p_sdns)
{
    int err = -1;
    ATResponse *p_response = NULL;
    char *line;
    int cid;

    char *pdns =  (char *)calloc(ODM_DNS_SIZE, sizeof(char));
    char *sdns =  (char *)calloc(ODM_DNS_SIZE, sizeof(char));
    if (NULL == pdns)
    {
        err = -1;
        RLOGD("odm_fix_dns calloc pdns failed");
        return err;
    }

    if (NULL == sdns)
    {
        err = -1;
        RLOGD("odm_fix_dns calloc sdns failed");
        return err;
    }

// <!--added by wangmengying@2020.2.24 fix bug40975,ECM DNS report error
    //err = odm_get_dns_gtdns(&pdns, &sdns);
    err = at_send_command_singleline("AT+GTDNS?", "+GTDNS:", &p_response);
    /*
    *AT+GTDNS?
    *+GTDNS: 1,"120.80.80.80","221.5.88.88"
    *<cid>    : 1
    *<dns1> : "120.80.80.80"
    *<dns2> : "221.5.88.88"
    */
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &cid);
        if (err < 0) goto error;

        err = at_tok_nextstr(&line, &pdns);
        if (err < 0) goto error;

        err = at_tok_nextstr(&line, &sdns);
        if (err < 0) goto error;
    }
    else
    {
        goto error;
    }
// end-->
    RLOGD("[%s,%d]pdns[%s](%d), sdns[%s](%d)", __FUNCTION__, __LINE__, pdns, CHECK_DNS_AVAILABLE(pdns), sdns, CHECK_DNS_AVAILABLE(sdns));

    if(!CHECK_DNS_AVAILABLE(p_pdns) && CHECK_DNS_AVAILABLE(pdns))
    {
        RLOGD("p_pdns needs to be changed!");
        strcpy(p_pdns, pdns);
    }
    else if(!CHECK_DNS_AVAILABLE(p_pdns) && !CHECK_DNS_AVAILABLE(pdns))
    {
        RLOGD("Set p_pdns to the default %s!", DEFAULT_PDNS);
        strcpy(p_pdns, DEFAULT_PDNS);
    }
    else
    {
        RLOGD("p_pdns does not need to change!");
    }

    if(!CHECK_DNS_AVAILABLE(p_sdns) && CHECK_DNS_AVAILABLE(sdns))
    {
        RLOGD("p_sdns needs to be changed!");
        strcpy(p_sdns, sdns);
    }
    else if(!CHECK_DNS_AVAILABLE(p_sdns) && !CHECK_DNS_AVAILABLE(sdns))
    {
        RLOGD("Set p_sdns to the default %s!", DEFAULT_SDNS);
        strcpy(p_sdns, DEFAULT_SDNS);
    }
    else
    {
        RLOGD("p_sdns does not need to change!");
    }

    RLOGD("odm_fix_dns : p_pdns[%s](%d),p_sdns[%s](%d), err:%d",p_pdns, CHECK_DNS_AVAILABLE(p_pdns), p_sdns, CHECK_DNS_AVAILABLE(p_sdns), err);
    at_response_free(p_response);
    p_response = NULL;
    return err;
error:
    at_response_free(p_response);
    err = -1;
    return err;
}

/* END:   Added by eric.li, 2019/1/21   PN:check dns if legal */
static int readfile(char *pathname, char* buffer, int size)
{
    int fd;
    int count=0;

    if((fd=open(pathname,O_RDONLY))==-1)
    {
        return 0;
    }
    count=read(fd,buffer,size);
    close(fd);
    return 1;
}

static int readinterfaceprop(char *dir)
{
    char tmp[20];
    struct dirent *filename;
    static char* dot=".";
    static char* dotdot="..";
    DIR*dp=NULL;
    char pathname[256];
    dp=opendir(dir);
    while((filename=readdir(dp))!=NULL)
    {
        if((filename->d_type == DT_DIR || filename->d_type == DT_LNK) && strcmp(filename->d_name,dot) && strcmp(filename->d_name,dotdot))
        {
            continue;
        }
        else
        {
            memset(pathname,0,sizeof(pathname));
            strcpy(pathname,dir);
            strcat(pathname,"/");
            strcat(pathname,filename->d_name);
            memset(tmp,0,sizeof(tmp));
            readfile(pathname, tmp, 10);
            RLOGD("%s = %s",filename->d_name,tmp);
        }
    }
    return 1;
}
static const char* networkStatusToRilString(int state)
{
    switch(state)
    {
        case 0:
            return("unknown");
            break;
        case 1:
            return("available");
            break;
        case 2:
            return("current");
            break;
        case 3:
            return("forbidden");
            break;
        default:
            return NULL;
    }
}
int networktypeToRilType(int type)
{
    switch(type)
    {
        case 0:
        case 1:
            return 16;
            break;
        case 2:
            return 3;
            break;
        case 3:
            return 1;
            break;
        case 4:
            return 9;
            break;
        case 5:
            return 10;
            break;
        case 6:
            return 11;
            break;
        case 7:
            return 14;
            break;
            // <!--[ODM]for cdma/evdo network
#if 0
        case 8:
            return 6;
            break;
        case 9:
        case 10:
            return 8;
            break;
#else
        case 8:
            return 16;
            break;
        case 9:
        case 10:
            return 3;
            break;
#endif
            // end-->
        default:
            return 0;
    }
}

char * get_network_type()
{
    int err;
    ATResponse *p_response = NULL;
    char *responsenet = NULL;
    char *line;
    const char *cmd;
    const char *prefix;
    int response[4];
    char *p_responsnet = NULL;

    at_send_command("AT+COPS=3,2",NULL);
    cmd = "AT+COPS?";  //+COPS: 0,2,"46001",7
    prefix = "+COPS:";
    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (err == 0 && p_response->success != 0) 
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
	   
	if (err < 0) goto error;
	err = at_tok_nextint(&line, &response[0]);
	if (err < 0) goto error;
	err = at_tok_nextint(&line, &response[1]);
	if (err < 0) goto error;
	err = at_tok_nextint(&line, &response[2]);
	if (err < 0) goto error;
	err = at_tok_nextint(&line, &response[3]);
	if (err < 0) goto error;

    g_cops_lte = response[3];
    RLOGD("network type %d,   g_cops_lte %d ,mode_flag: %d",response[3],g_cops_lte,mode_flag);
       
    if(mode_flag != GHT_FG650)
    {
        switch(response[3])
        {
            case 0://GSM
                responsenet = "GSM";
                break;
            case 1://GSM Compact
                responsenet = "GSM Compact";
                break;
            case 2://UTRAN
                responsenet = "UTRAN";
                break;
            case 3://GSM w/EGPRS
				responsenet = "GSM w/EGPRS";
				break;
			case 4://UTRAN w/HSDPA
				responsenet = "UTRAN w/HSDPA";
				break;
			case 5://UTRAN w/HSUPA
				responsenet = "UTRAN w/HSUPA";
				break;
			case 6://UTRAN w/HSDPA and HSUPA
				responsenet = "UTRAN w/HSDPA and HSUPA ";
				break;
			case 7://E-UTRAN
				responsenet = "E-UTRAN";
				break;
			case 8:
				responsenet = "CDMA";
				break;
			case 9:
				responsenet = "CDMA&EVDO";
				break;
			case 10:
				responsenet = "EVDO";
				break;
			case 11:
				responsenet = "eMTC";
				break;
			case 12:
				responsenet = "NB-IoT";
				break;
			default:
				responsenet = "UNKNOWN";
				goto error;
				break;
	             }
        }
       else
        {
            switch(response[3])
            {
                case 0://GSM
                    responsenet = "GSM";
                    break;
                case 1://GSM Compact
                    responsenet = "GSM Compact";
                    break;
                case 2://UTRAN
                    responsenet = "UTRAN";
                    break;
                case 3://GSM w/EGPRS
                    responsenet = "GSM w/EGPRS";
                    break;
                case 4://UTRAN w/HSDPA
                    responsenet = "UTRAN w/HSDPA";
                    break;
                case 5://UTRAN w/HSUPA
                    responsenet = "UTRAN w/HSUPA";
                    break;
                case 6://UTRAN w/HSDPA and HSUPA
                    responsenet = "UTRAN w/HSDPA and HSUPA ";
                    break;
                case 7://E-UTRAN
                    responsenet = "E-UTRAN";
                    break;
                case 8:
                    responsenet = "CDMA";
                    break;
                case 9:
                    responsenet = "CDMA&EVDO";
                    break;
                case 10:
                    responsenet = "EVDO";
                    break;
                case 11:
                    responsenet = "NR";
                    break;
                case 12:
                    responsenet = "NG-RAN";
                    break;
                case 13:
                    responsenet = "NR-RAN/LTE";
                    break;
                default:
                    RLOGD("[%d] response[3]=%d can't match network type,so default set UNKNOWN ", __LINE__,response[3]);
                    responsenet = "UNKNOWN";
                    goto error;
                    break;
            }
        }
    }
    else
    {
        RLOGD("%s,%d failed to get cops", __FUNCTION__, __LINE__);
        goto error;
    }
error:
    if(responsenet == NULL)
    {
    	responsenet = "UNKNOWN";
    }
    at_response_free(p_response);
    RLOGD("network type %s",responsenet);
    return responsenet;
}

int odm_get_current_network_type()
{
    int err;
    int response = 0;
    const char *cmd;
    const char *prefix;
    char *line;
    int *registration = NULL;
    int count = 0;
    int type = 0;
    ATResponse *p_response = NULL;

   registration = get_network_type();
   RLOGD("get current network22222 %s\r",registration);
   if(!strncmp(registration, "GPRS",strlen("GPRS")))
        response = 1;
   else if(!strncmp(registration, "GSM",strlen("GSM")))
        response = 16;
    else if(!strncmp(registration, "TDSCDMA",strlen("TDSCDMA")))
        response = 3;
    else if(!strncmp(registration, "EGPRS",strlen("EGPRS")))
        response = 2;
    else if(!strncmp(registration, "UTRAN",strlen("UTRAN")))
        response = 3;
    else if(!strncmp(registration, "HSDPA",strlen("HSDPA")))
        response = 9;
    else if(!strncmp(registration, "HSUPA",strlen("HSUPA")))
        response = 10;
    else if(!strncmp(registration, "HSPA+",strlen("HSPA+")))
        response = 15;
    else if(!strncmp(registration, "E-UTRAN",strlen("E-UTRAN")))
        response = 14;
    else if(!strncmp(registration, "EVDO",strlen("EVDO")) || !strncmp(registration, "CDMA&EVDO",strlen("CDMA&EVDO")))
        response = 7;
    else if(!strncmp(registration, "CDMA",strlen("CDMA")))
        response = 6;
    else if(!strncmp(registration, "EHRPD",strlen("EHRPD")))
        response = 13;
    else if((!strncmp(registration, "NR-RAN/LTE",strlen("NR-RAN/LTE"))) || (!strncmp(registration, "NR",strlen("NR"))) || (!strncmp(registration, "NG-RAN",strlen("NG-RAN"))))
        response = 20;
    else
    {
        response = 0;
    }
    RLOGD("network type %d",response);
    return response;
}
void onDeactiveDataCallList()
{
    int err = 0;
    char*cmd;
    RLOGD("%s: Enter onDeactiveDataCallList", __FUNCTION__);
#if 0
/*begin:modfied by lisf for android 8 response 20190114*/
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        RIL_Data_Call_Response_v11 *responses = alloca(sizeof(RIL_Data_Call_Response_v11));
#else
    RIL_Data_Call_Response_v6 *responses = alloca(sizeof(RIL_Data_Call_Response_v6));
#endif
/*end:modfied by lisf for android 8 response 20190114*/
#endif
    RIL_Data_Call_Response_v6 *responses = (RIL_Data_Call_Response_v6 *)alloca(sizeof(RIL_Data_Call_Response_v6) + 64);
    int response_len = sizeof(RIL_Data_Call_Response_v6);

    if(dialmode == DIAL_RAS_MOD)
    {
        RLOGD("onDeactiveDataCallList pppd = %d",pppd);
        if(pppd)
        {
            RLOGD("Stop existing PPPd");
//modified by lisf for debug 20181210
#if 0
            at_send_command("ATH", NULL);
            property_set("ctl.stop", SERVICE_PPPD_GPRS);
#else
            if(get_pid("pppd"))
            {
                err = at_send_command("ATH", NULL);
                property_set("ctl.stop", SERVICE_PPPD_GPRS);
/*begin:modified for android5x , don't kill pppd by lisf 20181221*/
//#ifndef GHT_FEATURE_ANDROID5X
                if(Ght_Android_Version != ANDROID_5)
                {
                    RLOGD("[%s,%d]: version_check Ght_Android_Version:%d !=5 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                    ril_kill_pppd(0);
                }
//#endif
/*end:modified for android5x , don't kill pppd by lisf 20181221*/
            }
#endif
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }
            pppd = 0;
        }
        responses->ifname = "ppp0";
    }	
    else if(dialmode == DIAL_NDIS_MOD)
    {
       /*begin:modified "AT$QCRMCALL=0,1" timeout 45s by lisf 20190418 for mantis 0019714*/
     //   err = at_send_command("AT$QCRMCALL=0,1", NULL);
        err = at_send_command_timeout("AT$QCRMCALL=0,1",NULL, ATSEND_TIMEOUT_MSEC*4+5000);
       /*end:modified "AT$QCRMCALL=0,1" timeout 45s by lisf 20190418 for mantis 0019714*/
        if(ndis_fd > 0)
        {
            close(ndis_fd);
            ndis_fd = -1;
        }
        responses->ifname = "usb0";
    }
    else if(dialmode == DIAL_ECM_MOD)
    {
        RLOGD("%s: ECM_cus_cid:%d", __FUNCTION__, cus_cid);
        asprintf(&cmd, "AT+GTRNDIS=0,%d", cus_cid);
        err = at_send_command_timeout(cmd, NULL, 30000);
        free(cmd);
        if (GHT_MA510_GL == mode_flag)
        {
            responses->ifname = "eth1";
        }
        else
        {
            responses->ifname = "usb0";
        }

/*BEGIN: Modified by wujiabao in 2022/05/23, because Android 7 and others need this feature as well*/
#if 1
//#if defined GHT_FEATURE_ANDROID10X
       RLOGD("%s: ECM_NetifName:%s", __FUNCTION__, ECM_NetifName);

       if(mode_flag ==GHT_L716)
       {
          asprintf(&cmd, "/system/bin/ip route del default dev %s", ECM_NetifName);
          RLOGD("%s",cmd);
          system(cmd);
          free(cmd);
       }
       asprintf(&cmd, "/system/bin/busybox ifconfig %s down", ECM_NetifName);
       RLOGD("%s",cmd);
       system(cmd);
       free(cmd);
#endif
/*END:  Modified by wujiabao in 2022/05/23, because Android 7 and others need this feature as well*/
    }

    responses->status = -1;
    responses->suggestedRetryTime = -1;
    responses->cid = 1;
    responses->active = 0;
    responses->type = "";
    responses->addresses = "";
    responses->dnses = "";
    responses->gateways = "";

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        response_len = sizeof(RIL_Data_Call_Response_v11);
        ((RIL_Data_Call_Response_v11 *)responses)->pcscf="";
        ((RIL_Data_Call_Response_v11 *)responses)->mtu=ODM_MTU_SIZE;
    }

    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
        responses, response_len);

    fibocom_pingflag = 0;

#if 0
/*begin:modfied by lisf for android 8 response 20190114*/
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
      responses->status = -1;
	responses->suggestedRetryTime = -1;
	responses->cid = 1;
	responses->active = 0;
	responses->type = "";
	responses->addresses = "";
	responses->dnses = "";
	responses->gateways = "";
	responses->pcscf="";
	responses->mtu=ODM_MTU_SIZE;
    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
            responses, sizeof(RIL_Data_Call_Response_v11));
#else
    responses->status = -1;
    responses->suggestedRetryTime = -1;
    responses->cid = 1;
    responses->active = 0;
    responses->type = "";
    responses->addresses = "";
    responses->dnses = "";
    responses->gateways = "";
    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
            responses, sizeof(RIL_Data_Call_Response_v6));
#endif
/*end:modfied by lisf for android 8 response 20190114*/
#endif

}

void OnResumeLTENetwork()
{
    int err = 0;
	//modifed for NL678 
	if (mode_flag <GHT_NL668)
	{
		RLOGD("OnResumeLTENetwork to mododr 2");
		err = at_send_command("AT+MODODR=2",NULL);
	}
	else if(((mode_flag >= GHT_NL668) && (mode_flag <= GHT_NL678_E) )  || (mode_flag == GHT_L716))//modified support for NL668 NORMAL by lisf 20190318 add L716 by gr 20220801
	{
	    RLOGD("OnResumeLTENetwork to GTRAT 10");
	    err = at_send_command("AT+GTRAT=10",NULL);
	}
        else if(mode_flag == GHT_FG650)
        {
	    RLOGD("OnResumeLTENetwork to GTRAT 20");
	    err = at_send_command("AT+GTRAT=20",NULL);
	}
    onDeactiveDataCallList();
    return;
}

//add by gaojing to test at+ecm begin
static void requestOrSendDataCallList(RIL_Token *t)
{
    ATResponse *p_response = NULL;
    ATLine *p_cur;
    int err;
    int n = 0;
    char *out;
    char gw[PROPERTY_VALUE_MAX]={0};
    char *gw_ndis = (char *)calloc(PROPERTY_VALUE_MAX, sizeof(char));
    char *cmd = NULL; //added route for network unreachable

    /*Begin: Deleted by wujiabao in 2022/07/19, becaues it was not been used*/
    /*begin:added by lisf for android 5x ping fail 20190115*/
    //#ifdef GHT_FEATURE_ANDROID5X
    #if 0
    char *active_addr = NULL; //added 20190115
    #endif
    /*end:added by lisf for android 5x ping fail 20190115*/
    /*Begin: Deleted by wujiabao in 2022/07/19, becaues it was not been used*/

    int network_type = 0;

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        RIL_Data_Call_Response_v11 *responses = alloca(sizeof(RIL_Data_Call_Response_v11));
#else
        RIL_Data_Call_Response_v6 *responses = alloca(sizeof(RIL_Data_Call_Response_v6));
#endif
#endif
    RIL_Data_Call_Response_v6 *responses = (RIL_Data_Call_Response_v6 *)alloca(sizeof(RIL_Data_Call_Response_v6) + 64);
    int response_len = sizeof(RIL_Data_Call_Response_v6);


    if (NULL == gw_ndis || NULL == responses)
    {
        RLOGD("calloc mem for gw_ndis or responses failed");
        goto error;
    }
      get_gateway(&gw_ndis);
      if (DIAL_NDIS_MOD == dialmode || DIAL_ECM_MOD == dialmode)
      {
            RLOGD("gateway  [%s]", gw_ndis);
            strcpy(gw, gw_ndis);
      }

/*begin:modified by lisf 20181121*/
    if(mode_flag == GHT_M910_GL)
    {
        network_type = odm_get_current_network_type_m910();
    }
    else if (mode_flag == GHT_MA510_GL)
    {
        network_type = odm_get_current_network_type_ma510();
    }
    else
    {
        network_type = odm_get_current_network_type();
    }
    /*end:added by lisf 20181121*/

     if(6 == network_type || 7 == network_type || 13 == network_type)
/*end:modified by lisf 20181121*/
    {
        char local_ip[PROPERTY_VALUE_MAX]={0};
        char local_pdns[PROPERTY_VALUE_MAX]={0};
        char local_sdns[PROPERTY_VALUE_MAX]={0};
        char dns[PROPERTY_VALUE_MAX*2]={0};
	//added by lisf for debug 20181220	
	//char gw[PROPERTY_VALUE_MAX]={0};
	char remote_ip[PROPERTY_VALUE_MAX]={0};
        if(dialmode == DIAL_RAS_MOD)
        {
            property_get("net.ppp0.local-ip", local_ip, "");
            property_get("net.ppp0.dns1", local_pdns, "");
            property_get("net.ppp0.dns2", local_sdns, "");  
            property_get("net.ppp0.gw", gw, "");
            property_get("net.ppp0.remote-ip", remote_ip, "");
            responses->ifname = "ppp0";
        }
        else if(dialmode == DIAL_NDIS_MOD)
        {
            property_get("net.usb0.local-ip", local_ip, "");
            property_get("net.usb0.dns1", local_pdns, "");
            property_get("net.usb0.dns2", local_sdns, "");
            responses->ifname = "usb0";
        }
        else if(dialmode == DIAL_ECM_MOD)
        {
            if (GHT_MA510_GL == mode_flag)
            {
                property_get("net.eth1.local-ip", local_ip, "");
                property_get("net.eth1.dns1", local_pdns, "");
                property_get("net.eth1.dns2", local_sdns, "");
                responses->ifname = "eth1";
            }
            else
            {
                property_get("net.usb0.local-ip", local_ip, "");
                property_get("net.usb0.dns1", local_pdns, "");
                property_get("net.usb0.dns2", local_sdns, "");
                property_get("net.usb0.gw", gw, "");
                responses->ifname = "usb0";
            }
        }
//<!-- add default dns set by wmy@20171019
/* BEGIN: Modified by eric.li, 2019/1/22   PN:check dns if legal for issue 0015665 */
        if (PDP_IPV4 == g_apn_pdptype )
        {
            if ((dialmode == DIAL_NDIS_MOD||dialmode == DIAL_ECM_MOD) && (-1 == odm_check_dns(local_pdns, local_sdns)))
            {
                    if (-1 == odm_fix_dns(local_pdns, local_sdns))
                    {
                        memset(local_pdns, 0, sizeof(local_pdns));
                        sprintf(local_pdns,"%s","8.8.8.8");
                        memset(local_sdns, 0, sizeof(local_sdns));
                        sprintf(local_sdns,"%s","8.8.4.4");
                    }
            }
        }
        sprintf(dns,"%s %s",local_pdns,local_sdns);

        if(0 == strcmp(gw, ""))
        {
            memset(gw, 0, sizeof(gw));
      //      sprintf(gw,"%s","10.64.64.64");
               strcpy(gw, remote_ip);
        }
//end -->

        responses->status = 0;
        responses->suggestedRetryTime = -1;
        responses->cid = 1;
        responses->active = 1;
        if(PDP_IPV6 == g_apn_pdptype ){
            responses->type = "IPV6";
        }
        else if(PDP_IPV4V6 == g_apn_pdptype){
            responses->type = "IPV4V6";
        }
        else{
            responses->type = "IP";
        }
        responses->addresses = local_ip;
        responses->dnses = dns;
        responses->gateways = gw;
        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            response_len = sizeof(RIL_Data_Call_Response_v11);
            ((RIL_Data_Call_Response_v11 *)responses)->pcscf="";
            ((RIL_Data_Call_Response_v11 *)responses)->mtu=ODM_MTU_SIZE;
        }

        if (t != NULL)
		{  RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_SUCCESS, responses, response_len);}
        else
        {    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED, responses, response_len);}


#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
	{//for  RIL_Data_Call_Response_v11
	        responses->status = 0;
	        responses->suggestedRetryTime = -1;
	        responses->cid = 1;
	        responses->active = 1;
            if(PDP_IPV6 == g_apn_pdptype ){
                responses->type = "IPV6";
            }
            else if(PDP_IPV4V6 == g_apn_pdptype){
                responses->type = "IPV4V6";
            }
            else{
	            responses->type = "IP";
            }
	        responses->addresses = local_ip;
	        responses->dnses = dns;
	        responses->gateways = gw;
		 responses->pcscf="";
		 responses->mtu=ODM_MTU_SIZE;
	}

#else
	{// for RIL_Data_Call_Response_v06
	        responses->status = 0;
	        responses->suggestedRetryTime = -1;
	        responses->cid = 1;
	        responses->active = 1;
            if(PDP_IPV6 == g_apn_pdptype ){
                 responses->type = "IPV6";
            }
            else if(PDP_IPV4V6 == g_apn_pdptype){
                 responses->type = "IPV4V6";
            }
            else{
                 responses->type = "IP";
            }
	        responses->addresses = local_ip;
	        responses->dnses = dns;
	        responses->gateways = gw;
	}
#endif

#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        if (t != NULL)
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_SUCCESS, responses, sizeof(RIL_Data_Call_Response_v11));
        else
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED, responses, sizeof(RIL_Data_Call_Response_v11));
#else
        if (t != NULL)
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_SUCCESS, responses, sizeof(RIL_Data_Call_Response_v6));
        else
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED, responses, sizeof(RIL_Data_Call_Response_v6));
#endif
        //RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t,RIL_E_SUCCESS,responses,sizeof(RIL_Data_Call_Response_v6));
                /* BEGIN: Added by eric.li, 2018/10/11   PN:debug SRCLTE CONNECT FAILURE */
#endif

        if (NULL != t)
	{
		RLOGD("eric debug RIL_E_SUCCESS");
	}
	else
	{
		RLOGD("eric debug RIL_UNSOL_DATA_CALL_LIST_CHANGED");
	}
        /* END:   Added by eric.li, 2018/10/11   PN:debug SRCLTE CONNECT FAILURE */

    }
    else
    {
        err = at_send_command_multiline ("AT+CGACT?", "+CGACT:", &p_response);
        if (err != 0 || p_response->success == 0)
        {
            if (t != NULL)
			{RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_GENERIC_FAILURE, NULL, 0);}
            else
			{ RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED, NULL, 0);}
        /* BEGIN: Added by eric.li, 2019/2/18   PN:solve mem leak for switch CT-4g to CT-3g lead to AT+CGACT err */
            at_response_free(p_response);
            p_response = NULL;
            RLOGD("%s,%d,err[%d]", __FUNCTION__,__LINE__,err);
        /* END:   Added by eric.li, 2019/2/18   PN:solve mem leak for switch CT-4g to CT-3g lead to AT+CGACT err */            
            return;
        }
        responses->status = -1;
        responses->suggestedRetryTime = -1;
        responses->cid = -1;
        responses->active = -1;
        responses->type = "";
        responses->ifname = "";
        responses->addresses = "";
        responses->dnses = "";
        responses->gateways = "";


        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            response_len = sizeof(RIL_Data_Call_Response_v11);
            ((RIL_Data_Call_Response_v11 *)responses)->pcscf="";
            ((RIL_Data_Call_Response_v11 *)responses)->mtu=ODM_MTU_SIZE;
        }
#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X     //init for  RIL_Data_Call_Response_v11
        for (i = 0; i < n; i++) {
            responses[i].status = -1;
            responses[i].suggestedRetryTime = -1;
            responses[i].cid = -1;
            responses[i].active = -1;
            responses[i].type = "";
            responses[i].ifname = "";
            responses[i].addresses = "";
            responses[i].dnses = "";
            responses[i].gateways = "";
	     responses[i].pcscf="";
	     responses[i].mtu=-1;
        }
#else                                   //init for RIL_Data_Call_Response_v06
        for (i = 0; i < n; i++) {
            responses[i].status = -1;
            responses[i].suggestedRetryTime = -1;
            responses[i].cid = -1;
            responses[i].active = -1;
            responses[i].type = "";
            responses[i].ifname = "";
            responses[i].addresses = "";
            responses[i].dnses = "";
            responses[i].gateways = "";
        }
#endif
#endif

/*Begin:Deleted by wujiabao in 2022/07/19, because it is useless.*/
#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    /*begin:modified by lisf 20181201 for RIL8*/
        RIL_Data_Call_Response_v11 *response = responses;
    /*end:modified by lisf 20181201 for RIL8*/
#else
        RIL_Data_Call_Response_v6 *response = responses;
#endif
#endif
/*End:Deleted by wujiabao in 2022/07/19, because it is useless.*/


            int cid, found_flag = 0;

            p_cur = p_response->p_intermediates;
            char *line = p_cur->line;

            do
            {
                err = at_tok_start(&line);
                if (err < 0)
                    goto error;

                err = at_tok_nextint(&line, &responses->cid);
                if (err < 0)
                    goto error;

                if(responses->cid != cus_cid)
                {
                    p_cur = p_cur->p_next;
                    line = p_cur->line;
                }
                else
                {
                    found_flag = 1;
                    break;
                }
            }while(p_cur != NULL);

            if(mode_flag == GHT_L716)
            {
                //L716 is NULL
            }
            else
            {
                if(1 != found_flag)
                {
                RLOGE("CGACT of the cid %d was not found!", cus_cid);
                goto error;
                }
             }

            err = at_tok_nextint(&line, &(responses->active));
            if(mode_flag == GHT_L716)
            {
                //L716 is NULL
            }
            else
            {
                if (err < 0)
                {
                    goto error;
                }
            }
        at_response_free(p_response);
        err = at_send_command_multiline ("AT+CGDCONT?", "+CGDCONT:", &p_response);
        if (err != 0 || p_response->success == 0) {
            if (t != NULL)
			{RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_GENERIC_FAILURE, NULL, 0);}
            else
			{   RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
			NULL, 0);}
            /* BEGIN: Added by eric.li, 2019/2/18   PN:debug mem leak */
            RLOGD("%s,%d,err[%d]", __FUNCTION__,__LINE__,err);
            at_response_free(p_response);
            p_response = NULL;
            /* END:   Added by eric.li, 2019/2/18   PN:debug mem leak */
            return;
        }

        int i = 0;
        found_flag = 0;

        for(p_cur = p_response->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next)
        {
            line = p_cur->line;

            err = at_tok_start(&line);
            if (err < 0)
                goto error;
        
            err = at_tok_nextint(&line, &cid);
            if (err < 0)
                goto error;

            if(cid != cus_cid)
            {
                continue;
            }
            else
            {
                found_flag = 1;
                break;
            }

        }

            if(!found_flag)
            {
                RLOGE("CGDCONT of the cid %d was not found!", cus_cid);
                goto error;
            }

            // Assume no error
            responses[i].status = 0;

            // apn type
            err = at_tok_nextstr(&line, &out);
            if (err < 0)
                goto error;
            responses[i].type = alloca(strlen(out) + 1);
            strcpy(responses[i].type, out);

            // APN ignored for v5
            err = at_tok_nextstr(&line, &out); //apn name
            if (err < 0)
                goto error;

/*begin:added by lisf for android 5x ping fail 20190115*/
//<---Start:Modified by Wujiabao in 2022/04/01, because it gets the IP address but it doesn't do anything
//#ifdef GHT_FEATURE_ANDROID5X
#if 0
//----End:Modified by Wujiabao in 2022/04/01, because it gets the IP address but it doesn't do anything>
            err = at_tok_nextstr(&line, &out);
            if (err < 0)
                goto error;
            active_addr = alloca(strlen(out) + 1);
            strcpy(active_addr, out);
#endif
   /*end:added by lisf for android 5x ping fail 20190115*/

            if(dialmode == DIAL_RAS_MOD)
            {
                responses[i].ifname = alloca(strlen(PPP_TTY_PATH) + 1);
                strcpy(responses[i].ifname, PPP_TTY_PATH);
            }
            else if(dialmode == DIAL_NDIS_MOD)
            {
                responses[i].ifname = alloca(strlen(NDIS_TTY_PATH) + 1);
                strcpy(responses[i].ifname, NDIS_TTY_PATH);
            }
            else if(dialmode == DIAL_ECM_MOD)
            {
                if(cus_netifName_flag)
                {
                    responses[i].ifname = alloca(strlen(cus_netifName) + 1);
                    strcpy(responses[i].ifname, cus_netifName);
                }
                else if(GHT_MA510_GL == mode_flag || 1 == eth1_interface)
                {
                    responses[i].ifname = alloca(strlen(ECM_TTY_PATH) + 1);
                    strcpy(responses[i].ifname, ECM_TTY_PATH);
                }
                else
                {
                    responses[i].ifname = alloca(strlen(NDIS_TTY_PATH) + 1);
                    strcpy(responses[i].ifname, NDIS_TTY_PATH);
                }
            }

            err = at_tok_nextstr(&line, &out);  //ip address
            if (err < 0)
                goto error;
            RLOGD("[%s,%d]AT+CGDCONT: ip_addr:%s", __FUNCTION__, __LINE__, out);

            {
                char local_ip[PROPERTY_VALUE_MAX]={0};
                char local_pdns[PROPERTY_VALUE_MAX]={0};
                char local_sdns[PROPERTY_VALUE_MAX]={0};
                char dns[PROPERTY_VALUE_MAX*2]={0};
                char remote_ip[PROPERTY_VALUE_MAX]={0};
                char *line = NULL;
                int active = -1;
                int cid = -1;
                if(dialmode == DIAL_RAS_MOD)
                {
                    property_get("net.ppp0.local-ip", local_ip, "");
                    property_get("net.ppp0.dns1", local_pdns, "");
                    property_get("net.ppp0.dns2", local_sdns, "");		
                    property_get("net.ppp0.gw", gw, "");
                    property_get("net.ppp0.remote-ip", remote_ip, "");
                }
                else if(dialmode == DIAL_NDIS_MOD)
                {
                    property_get("net.usb0.local-ip", local_ip, "");
                    property_get("net.usb0.dns1", local_pdns, "");
                    property_get("net.usb0.dns2", local_sdns, "");
                }
                else if(dialmode == DIAL_ECM_MOD)
                {
                    if(cus_netifName_flag)
                    {
                        property_get(cus_local_ip, local_ip, "");
                        property_get(cus_dns1, local_pdns, "");
                        property_get(cus_dns2, local_sdns, "");
                        responses->ifname = cus_netifName;
                    }
                    else if (GHT_MA510_GL == mode_flag || 1 == eth1_interface)
                    {
                        property_get("net.eth1.local-ip", local_ip, "");
                        property_get("net.eth1.dns1", local_pdns, "");
                        property_get("net.eth1.dns2", local_sdns, "");
                        responses->ifname = "eth1";
                    }
                    else
                    {
                        property_get("net.usb0.local-ip", local_ip, "");
                        property_get("net.usb0.dns1", local_pdns, "");
                        property_get("net.usb0.dns2", local_sdns, "");
                        responses->ifname = "usb0";
                    }
                }

                if(PDP_IPV4 == g_apn_pdptype && GHT_MC919 != mode_flag)    //The AT+GTDNS? command of MC919 returns ERROR
                {
                    if ((dialmode == DIAL_NDIS_MOD||dialmode == DIAL_ECM_MOD) && (-1 == odm_check_dns(local_pdns, local_sdns)))
                    {
                            if (-1 == odm_fix_dns(local_pdns, local_sdns))
                            {
                                if(!CHECK_DNS_AVAILABLE(local_pdns))
                                {
                                    RLOGE("local_pdns:%s is unavailable, and set to default %s!", local_pdns, DEFAULT_PDNS);
                                    memset(local_pdns, 0, sizeof(local_pdns));
                                    sprintf(local_pdns,"%s",DEFAULT_PDNS);
                                }

                                if(!CHECK_DNS_AVAILABLE(local_sdns))
                                {
                                    RLOGE("local_sdns:%s is unavailable, and set to default %s!", local_sdns, DEFAULT_SDNS);
                                    memset(local_sdns, 0, sizeof(local_sdns));
                                    sprintf(local_sdns,"%s",DEFAULT_SDNS);
                                }
                            }
                            if(cus_netifName_flag)
                            {
                                property_set(cus_dns1, local_pdns);
                                property_set(cus_dns2, local_sdns);
                            }
                            else if(1 == eth1_interface)
                            {
                                property_set("net.eth1.dns1", local_pdns);
                                property_set("net.eth1.dns2", local_sdns);
                            }
                            else
                            {
                                property_set("net.usb0.dns1", local_pdns);
                                property_set("net.usb0.dns2", local_sdns);
                            }

                    }
                }

                sprintf(dns,"%s %s",local_pdns,local_sdns);
                responses[i].dnses = alloca(strlen(dns) + 1);
                strcpy(responses[i].dnses, dns);
//                property_set("net.usb0.dns1", local_pdns);
//                property_set("net.usb0.dns2", local_sdns);

                RLOGD("dns:%s",dns);


                if(strcmp(local_ip, "") != 0)
                {
                    responses[i].addresses = alloca(strlen(local_ip) + 1);
                    strcpy(responses[i].addresses, local_ip);

                    RLOGD("ip(get from net.xx.local-ip):%s",local_ip);
                }
                else
                {
                    responses[i].addresses = alloca(strlen(out) + 1);
                    strcpy(responses[i].addresses, out);
                    RLOGD("ip(get from AT+CGDCONT):%s",out);
                }
                if ((strcmp(gw, "") == 0)||(strcmp(gw, "0.0.0.0") == 0))
                {
                    get_gateway(&gw_ndis);
                    RLOGD("if gateway  [%s]", gw_ndis);
                    strcpy(gw, gw_ndis);
                }
                    RLOGD("gw:[ %s]",gw);
                    if(dialmode == DIAL_RAS_MOD)
                        property_set("net.ppp0.gw", gw);
                    else if (cus_netifName_flag)
                        property_set(cus_gw,gw);
                    else if(eth1_interface == 1)
                        property_set("net.eth1.gw",gw);
                    else
                        property_set("net.usb0.gw", gw);
                    responses[i].gateways = alloca(strlen(gw) + 1);
                    strcpy(responses[i].gateways, gw);

                    RLOGD("gateways:[%s]",responses[i].gateways);

#if 0
/* BEGIN: Added by eric.li, 2019/1/3   PN:for ndis dial MTU size */
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
                {
                    responses[i].mtu = ODM_MTU_SIZE;
                }
#endif
/* END:   Added by eric.li, 2019/1/3   PN:for ndis dial MTU size */
#endif
            }

        at_response_free(p_response);

		RLOGD("status [%d],suggestedRetryTime [%d], cid[%d], active[%d], type[%s], ifname[%s], addresses[%s],dnses[%s],gateways[%s]", \
		                                                    responses->status, \
		                                                    responses->suggestedRetryTime, \
		                                                    responses->cid, \
		                                                    responses->active, \
		                                                    responses->type, \
		                                                    responses->ifname, \
		                                                    responses->addresses, \
		                                                    responses->dnses, \
		                                                    responses->gateways);

        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            RLOGD("pcscf[%s], mtu[%d]", ((RIL_Data_Call_Response_v11 *)responses)->pcscf, ((RIL_Data_Call_Response_v11 *)responses)->mtu);
        }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
		/* BEGIN: Added by eric.li, 2018/10/9   PN:debug CT ppp dail issue */
		RLOGD("status [%d],suggestedRetryTime [%d], cid[%d], active[%d], type[%s], ifname[%s], addresses[%s],dnses[%s],gateways[%s], pcscf[%s], mtu[%d]", \
		                                                    responses[0].status, \
		                                                    responses[0].suggestedRetryTime, \
		                                                    responses[0].cid, \
		                                                    responses[0].active, \
		                                                    responses[0].type, \
		                                                    responses[0].ifname, \
		                                                    responses[0].addresses, \
		                                                    responses[0].dnses, \
		                                                    responses[0].gateways, \
		                                                    responses[0].pcscf, \
		                                                    responses[0].mtu);
		/* END:   Added by eric.li, 2018/10/9   PN:debug CT ppp dail issue */
#else
		/* BEGIN: Added by eric.li, 2018/10/9   PN:debug CT ppp dail issue */
		RLOGD("status [%d],suggestedRetryTime [%d], cid[%d], active[%d], type[%s], ifname[%s], addresses[%s],dnses[%s],gateways[%s]", \
		                                                    responses[0].status, \
		                                                    responses[0].suggestedRetryTime, \
		                                                    responses[0].cid, \
		                                                    responses[0].active, \
		                                                    responses[0].type, \
		                                                    responses[0].ifname, \
		                                                    responses[0].addresses, \
		                                                    responses[0].dnses, \
		                                                    responses[0].gateways);
		/* END:   Added by eric.li, 2018/10/9   PN:debug CT ppp dail issue */
#endif
#endif

//added for deactive pdp ,don't reply response  by lisf   20181221
#if 1
      if(mode_flag == GHT_L716)
      {
      }
      else
      {
	    if(!responses->active)
	    {
            RLOGD(" debug active #######22222");
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED, responses, response_len);

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
	  /*begin:modified by lisf 20181201 for RIL8*/		
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
                    responses,
                    n * sizeof(RIL_Data_Call_Response_v11));
	   /*end:modified by lisf 20181201 for RIL8*/
#else
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
                    responses,
                    n * sizeof(RIL_Data_Call_Response_v6));
#endif
#endif
            return;
         }
       }
#endif

        if (t != NULL)
        {
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_SUCCESS, responses,response_len);

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            /*begin:modified by lisf 20181201 for RIL8*/
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_SUCCESS, responses,n * sizeof(RIL_Data_Call_Response_v11));/*modify by eric.li, n -> */
            /*end:modified by lisf 20181201 for RIL8*/
#else
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_SUCCESS, responses,n * sizeof(RIL_Data_Call_Response_v6));/*modify by eric.li, n -> */
#endif
#endif
        }
        else
        {
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED, responses, response_len);

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            /*begin:modified by lisf 20181201 for RIL8*/
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,responses,n * sizeof(RIL_Data_Call_Response_v11));
            /*end:modified by lisf 20181201 for RIL8*/
#else
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,responses,n * sizeof(RIL_Data_Call_Response_v6));
#endif
#endif
        }

    if(ANDROID_5 == Ght_Android_Version)
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 5 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
/*begin:added route for network unreachable  20190112*/
//#ifdef GHT_FEATURE_ANDROID5X
/*end:added route for network unreachable  20190112*/
        if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
        {
            if(dialmode == DIAL_RAS_MOD)
            {
                char local_ip[PROPERTY_VALUE_MAX]={0};
                property_get("net.ppp0.local-ip", local_ip, "");
                asprintf(&cmd, "busybox ifconfig ppp0 %s",  local_ip);
                system(cmd);
                free(cmd);
                asprintf(&cmd, "ip route del default dev ppp0");
                RLOGD("%s",cmd);
                system(cmd);
                sleep(1);
                free(cmd);
                asprintf(&cmd, "ip route add default dev ppp0");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);
                asprintf(&cmd, "ip route add default dev ppp0 table ppp0");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);
            }
        }
//#endif
    }
    return;

error:
        if (t != NULL)
		{  RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(*t, RIL_E_GENERIC_FAILURE, NULL, 0);}
        else
		{  RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED, NULL, 0);}
        if(p_response != NULL)
            at_response_free(p_response);
    }
    free(gw_ndis);
    gw_ndis = NULL;
}

//add by gaojing to test at+ecm end

static void requestOrSendDataCallList(RIL_Token *t);

/*called by onUnsolicited() */
void onDataCallListChanged(void *param __unused)
{
    requestOrSendDataCallList(NULL);
}

void requestDataCallList(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    requestOrSendDataCallList(&t);
}


void requestQueryNetworkSelectionMode(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    int response = 0;
    char *line;

    err = at_send_command_singleline("AT+COPS?", "+COPS:", &p_response);

    if (err < 0 || p_response->success == 0)
    {
        goto error;
    }

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);

    if (err < 0)
    {
        goto error;
    }

    err = at_tok_nextint(&line, &response);

    if (err < 0)
    {
        goto error;
    }

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

//add by  nodecom aron
void requestQueryAvailableNetworks(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    /* We expect an answer on the following form:
       +COPS: (2,"AT&T","AT&T","310410",0),(1,"T-Mobile ","TMO","310260",0)
       */

    int err, operators, i, status;
    ATResponse *p_response = NULL;
    char * c_skip, *line, *p = NULL;
    char ** response = NULL;

    // <!--[ODM]lindong@2017.11.24 for manual select network
    RLOGD("[%s,%d],QueryAvailableNetworks Timeout is [%d]ms.\r",__FUNCTION__, __LINE__, QUERY_NETWORK_TIMEOUT);
    err = at_send_command_singleline_timeout("AT+COPS=?", "+COPS:", QUERY_NETWORK_TIMEOUT, &p_response);
    // --!>

    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    /* Count number of '(' in the +COPS response to get number of operators*/
    operators = 0;
    for (p = line ; *p != '\0' ; p++)
    {
        if (*p == '(') operators++;
    }

    response = (char **)alloca(operators * 4 * sizeof(char *));

    RLOGD("[%s,%d],operators num[%d],response[%p]\r",__FUNCTION__, __LINE__, operators, response);
    for (i = 0 ; i < operators ; i++ )
    {
        err = at_tok_nextstr(&line, &c_skip);
        if (err < 0) goto error;
        RLOGD("[%s,%d],Index[%d], c_skip[%s]\r",__FUNCTION__, __LINE__, i, c_skip);
        if (strcmp(c_skip,"") == 0)
        {
            operators = i;
            continue;
        }
        status = atoi(&c_skip[1]);
        response[i*4+3] = (char*)networkStatusToRilString(status);
        RLOGD("[%s,%d],Index[%d], status[%d][%s]\r",__FUNCTION__, __LINE__, i, status, response[i*4+3]);

        err = at_tok_nextstr(&line, &(response[i*4+0]));
        if (err < 0) goto error;
        RLOGD("[%s,%d],Index[%d], long[%s]\r",__FUNCTION__, __LINE__, i, response[i*4+0]);

        err = at_tok_nextstr(&line, &(response[i*4+1]));
        if (err < 0) goto error;
        RLOGD("[%s,%d],Index[%d], short[%s]\r",__FUNCTION__, __LINE__, i, response[i*4+1]);

        err = at_tok_nextstr(&line, &(response[i*4+2]));
        if (err < 0) goto error;
        RLOGD("[%s,%d],Index[%d], digit[%s]\r",__FUNCTION__, __LINE__, i, response[i*4+2]);

        err = at_tok_nextstr(&line, &c_skip);

        if (err < 0) goto error;
    }

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, response, (operators * 4 * sizeof(char *)));
    at_response_free(p_response);
    return;

error:
    RLOGD("[%s,%d],QueryAvailableNetworks Error\r",__FUNCTION__, __LINE__);
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

// <!--added by wangmengying@2017.12.06 for ShunFengFengChao NL660-757S LTE->EVDO shows 1x.
static void check_net_mode(void)
{
    int err;
    ATResponse *p_response = NULL;
    int response[4], sys_response[4];
    char *line;

    int supportedTechs_old = supportedTechs;

    if(GHT_L610 != mode_flag)                //L610 doesn't support this AT
    {
        const char *cmd;
        const char *prefix;

        cmd = "AT^SYSINFO";
        prefix = "^SYSINFO:";

        err = at_send_command_singleline(cmd, prefix, &p_response);

        if ((err != 0) || (p_response->success == 0) ) goto error;

        line = p_response->p_intermediates->line;

        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &sys_response[0]);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &sys_response[1]);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &sys_response[2]);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &sys_response[3]);
        if (err < 0) goto error;
    }

   char *registration = NULL;
   registration = get_network_type();
   RLOGD("get current network1111 %s\r",registration);
   if(!strncmp(registration, "GPRS",strlen("GPRS")))
   {
        response[3]  = 1;
        supportedTechs = RADIO_TECH_GPRS;
   }
   else if(!strncmp(registration, "GSM",strlen("GSM")))
   {
        /*begin:modifed supportedTechs 1 ,because of android4  framework can't recognize 16  by lisf 20190418 for mantis 0020107 */
        response[3]  = 1;//16;
         supportedTechs = RADIO_TECH_GPRS;//RADIO_TECH_GSM;
        /*end:modifed supportedTechs 1 ,because of android4  framework can't recognize 16  by lisf 20190418 for mantis 0020107 */
   }
    else if(!strncmp(registration, "TDSCDMA",strlen("TDSCDMA")))
    {
        response[3]  = 3;
        supportedTechs = RADIO_TECH_UMTS;
    }
    else if(!strncmp(registration, "EGPRS",strlen("EGPRS")))
    {
        response[3]  = 2;
       supportedTechs = RADIO_TECH_EDGE;
    }
    else if(!strncmp(registration, "UTRAN",strlen("UTRAN")))
    {
        response[3]  = 3;
        supportedTechs = RADIO_TECH_UMTS;
    }
    else if(!strncmp(registration, "HSDPA",strlen("HSDPA")))
    {
        response[3]  = 9;
        supportedTechs = RADIO_TECH_HSDPA;
    }
    else if(!strncmp(registration, "HSUPA",strlen("HSUPA")))
    {
        response[3]  = 10;
        supportedTechs = RADIO_TECH_HSUPA;
    }
    else if(!strncmp(registration, "HSPA+",strlen("HSPA+")))
    {
         response[3] = 15;
        supportedTechs = RADIO_TECH_HSPAP;
    }
    else if(!strncmp(registration, "E-UTRAN",strlen("E-UTRAN")))
    {
        response[3]  = 14;
        supportedTechs = RADIO_TECH_LTE;
    }
     else if((!strncmp(registration, "NR-RAN/LTE",strlen("NR-RAN/LTE"))) || (!strncmp(registration, "NR",strlen("NR"))) || (!strncmp(registration, "NG-RAN",strlen("NG-RAN"))))
    {
        response[3]  = 20;
        supportedTechs = RADIO_TECH_LTE_NR;
    }
    else if(!strncmp(registration, "E-EVDO",strlen("E-EVDO")) || !strncmp(registration, "CDMA&EVDO",strlen("CDMA&EVDO")))
    {
        response[3]  = 7;
        if((RADIO_TECH_1xRTT != supportedTechs)
            && (RADIO_TECH_EVDO_0 != supportedTechs)
            && (RADIO_TECH_EVDO_A != supportedTechs)
            && (RADIO_TECH_EVDO_B != supportedTechs)
            && (1 == pppd)
        )
        {
            if((GHT_L610 != mode_flag) && (( 4 == sys_response[3] ) || ( 8 == sys_response[3] ) || ( 2 == sys_response[3] )))
            {
              supportedTechs = RADIO_TECH_EVDO_0;
              onDeactiveDataCallList();
            }
        }
        else
        {
            supportedTechs = RADIO_TECH_EVDO_0;
        }
    }
    else if(!strncmp(registration, "CDMA",strlen("CDMA")))
    {
        response[3]  = 6;
        if((RADIO_TECH_1xRTT != supportedTechs)
            && (RADIO_TECH_EVDO_0 != supportedTechs)
            && (RADIO_TECH_EVDO_A != supportedTechs)
            && (RADIO_TECH_EVDO_B != supportedTechs)
            && (1 == pppd)
        )
        {
            if ((GHT_L610 != mode_flag) && (( 2 == sys_response[3] ) || ( 8 == sys_response[3] ) || ( 4 == sys_response[3] )))
            {
                supportedTechs = RADIO_TECH_1xRTT;
                onDeactiveDataCallList();
            }
        }
        else
        {
            supportedTechs = RADIO_TECH_1xRTT;
        }
    }
    else if(!strncmp(registration, "EHRPD",strlen("EHRPD")))
    {
        response[3]  = 13;
        supportedTechs = RADIO_TECH_EHRPD;
    }
    else
    {
        response[3]  = 0;
        supportedTechs = -1;
    }
    
    RLOGD("[%s,%d],supportedTechs_old[%d], supportedTechs[%d] ",__FUNCTION__, __LINE__, supportedTechs_old, supportedTechs);
    if(supportedTechs_old != supportedTechs)
    {
        RLOGD("[%s,%d],RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED",__FUNCTION__, __LINE__);
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED,
                NULL, 0);
    }
    at_response_free(p_response);
    return;

error:
    at_response_free(p_response);
}
//end -->

//<!-- modify signal trans by caogang@20171025
#define CDMA_RSSI_THRESH        125
#define CDMA_RSSI_SPAN      (CDMA_RSSI_THRESH - 75)
static int SignalStrengthTransform(int Signal)  
{     
    if(Signal == 99){
        return 140;  
    }
    return (Signal*3 - 140)*(-1);  //RSRP(44~140)
} 

static int RSRPTransform(int rsrp)
{
    if (rsrp >97 || rsrp <= 0)
    {
        return 0x7FFFFFFF;
    }
	else
	{
	    return 141 - rsrp;
	}
}

int getCSQInfo(CSQInfo *csqInfo)
{
    int err = -1;
    ATResponse *p_response = NULL;
    char *line;
    int signalStrength = 0;
    int bitErrorRate = 0;


#if 0
    {
        int rxlev,ber,rscp,ecno,rsrq,rsrp;
		
	    err = at_send_command_singleline("AT+CESQ", "+CESQ:", &p_response);

	    if (err < 0 || p_response->success == 0) 
		{
		    goto error;
	    }

		line = p_response->p_intermediates->line;

	    err = at_tok_start(&line);
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(rxlev));//GERAN
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(ber));
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(rscp));//WCDMA
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(ecno));
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(rsrq));//LTE
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(rsrp));
	    if (err < 0) goto error;

		RLOGD("It is LTE network, and get rsrp : %d",rsrp);
		csqInfo->rsrp = rsrp;

    }
#endif

	{
	    err = at_send_command_singleline("AT+CSQ", "+CSQ:", &p_response);
        if (err < 0 || p_response->success == 0) 
		{
            goto error;
        }
		
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &signalStrength);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &bitErrorRate);
        if (err < 0) goto error;

        if( signalStrength > 99 && signalStrength < 200)
        {
            signalStrength = (signalStrength - 100)*31/91;
        }

        RLOGD("[%s] get signalStrength :[%d]",__FUNCTION__,signalStrength);
        RLOGD("[%s] get bitErrorRate :[%d]",__FUNCTION__,bitErrorRate);

        csqInfo->rssi = signalStrength;
        csqInfo->ber  = bitErrorRate;
	    csqInfo->rsrp = -1;        // -1 means UNKNOWN
	}

    if(g_cops_lte == 7 || g_cops_lte == 11 || g_cops_lte == 13)
    {
        int rxlev,ber,rscp,ecno,rsrq,rsrp;
        int ss_rsrq,ss_rsrp,ss_sinr;
		
	    err = at_send_command_singleline("AT+CESQ", "+CESQ:", &p_response);

	    if (err < 0 || p_response->success == 0) 
		{
		    goto error;
	    }

		line = p_response->p_intermediates->line;

	    err = at_tok_start(&line);
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(rxlev));//GERAN
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(ber));
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(rscp));//WCDMA
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(ecno));
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(rsrq));//LTE
	    if (err < 0) goto error;

	    err = at_tok_nextint(&line, &(rsrp));
	    if (err < 0) goto error;

        if(mode_flag == GHT_FG650)
        {
            err = at_tok_nextint(&line, &(ss_rsrq));
            if (err < 0) goto error;

            err = at_tok_nextint(&line, &(ss_rsrp));
            if (err < 0) goto error;

            err = at_tok_nextint(&line, &(ss_sinr));
            if (err < 0) goto error;
        }

		RLOGD("It is LTE network, and get rsrp : %d",rsrp);
        if(g_cops_lte == 7)
        {
            csqInfo->rsrp = rsrp;
        }
        else if(g_cops_lte == 11 || g_cops_lte == 13)
        {
            csqInfo->rsrp = ss_rsrp;
        }
    }


	
error:
    at_response_free(p_response);
    return err;
}


/*Begin: Deleted by wujiabao in 2022/07/19, because we don't need it*/
#if 0
void requestSignalStrength_CESQ(void *data, size_t datalen, RIL_Token t)
{
    RLOGD("[%s] ====== Enter ",__FUNCTION__);
    ATResponse *p_response = NULL;
    int err;
    char *line;
    int rxlev = 0;//GERAN
    int ber = 0;
    int rscp = 0;//WCDMA
    int ecno = 0;
    int rsrq = 0;//LTE
    int rsrp = 0;
    int ss_rsrq = 0;//NR
    int ss_rsrp = 0;
    int ss_sinr = 0;
    
    
    int cdma_rssi = 0;//wcdma
    int lte_rssi = 0;//lte

    RIL_SignalStrength_v6 response;
#if defined GHT_FEATURE_ANDROID6X || defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    RIL_SignalStrength_v10 res;
    memset(&res, 0, sizeof(res));
#endif
    memset(&response, 0, sizeof(response));

    check_net_mode();

    err = at_send_command_singleline("AT+CESQ", "+CESQ:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(rxlev));//GERAN
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(ber));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(rscp));//WCDMA
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(ecno));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(rsrq));//LTE
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(rsrp));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(ss_rsrq));//NR
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(ss_rsrp));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(ss_sinr));
    if (err < 0) goto error;

    if(g_cops_lte == 2 || g_cops_lte == 6)
        cdma_rssi = 120 - ecno; // Change it following the modem code.
    else
        cdma_rssi = 120;
    if(g_cops_lte == 7 || g_cops_lte == 13)
    {
        lte_rssi = 140 - rsrp; // Change it following the modem code.for LTE
        if(g_cops_lte == 13)
        {
            if(rsrp != 255)
                lte_rssi = 140 - rsrp;
            else if(ss_rsrp != 255)
                lte_rssi = 156 - ss_rsrp;
            else
                lte_rssi = 156;
        }
    }
    else if(g_cops_lte == 11 || g_cops_lte == 12)
        lte_rssi = 156 - ss_rsrp; // Change it following the modem code.
    else
        lte_rssi = 156;


#if defined GHT_FEATURE_ANDROID6X || defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    res.GW_SignalStrength.signalStrength = rxlev;
    res.GW_SignalStrength.bitErrorRate = ber;
/* BEGIN: Modified by eric.li, 2019/2/18   PN:modify for signal strength display issue on UI when switch to CT-3G */
    res.CDMA_SignalStrength.dbm = cdma_rssi;//-1;
    res.CDMA_SignalStrength.ecio = cdma_rssi;//-1;
    res.EVDO_SignalStrength.dbm = cdma_rssi;//-1;
    res.EVDO_SignalStrength.ecio = cdma_rssi;//-1;
    res.EVDO_SignalStrength.signalNoiseRatio =0;// -1;
/* END:   Modified by eric.li, 2019/2/18   PN:modify for signal strength display issue on UI */

    res.LTE_SignalStrength.signalStrength = 0x7FFFFFFF;
    res.LTE_SignalStrength.rsrp = lte_rssi;
    res.LTE_SignalStrength.rsrq = 0x7FFFFFFF;
    res.LTE_SignalStrength.rssnr = 0x7FFFFFFF;
    res.LTE_SignalStrength.cqi = 0x7FFFFFFF;
    res.LTE_SignalStrength.timingAdvance = 0x7FFFFFFF;
    res.TD_SCDMA_SignalStrength.rscp = 0x7FFFFFFF;

    RLOGD("RES***LTE signalStrength=%d, rsrp=%d, rsrq=%d, rssnr=%d, cqi=%d, timingAdvance=%d, rscp=%d\r\n", res.LTE_SignalStrength.signalStrength,\
    res.LTE_SignalStrength.rsrp, \
    res.LTE_SignalStrength.rsrq, \
    res.LTE_SignalStrength.rssnr, \
    res.LTE_SignalStrength.cqi, \
    res.LTE_SignalStrength.timingAdvance, \
    res.TD_SCDMA_SignalStrength.rscp);

    RLOGD("CDMA/EVDO dbm=%d, ecio=%d, dbm=%d, ecio=%d, signalNoiseRatio=%d\r\n", res.CDMA_SignalStrength.dbm,\
    res.CDMA_SignalStrength.ecio, \
    res.EVDO_SignalStrength.dbm, \
    res.EVDO_SignalStrength.ecio, \
    res.EVDO_SignalStrength.signalNoiseRatio);

    RLOGD("GSM signalStrength=%d, bitErrorRate=%d\r\n", \
    res.GW_SignalStrength.signalStrength, res.GW_SignalStrength.bitErrorRate);

    
    if (NULL == t)
    {
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_SIGNAL_STRENGTH, &res, sizeof(RIL_SignalStrength_v10));
    }
    else
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &res, sizeof(RIL_SignalStrength_v10));
    }
#else

//GW
    response.GW_SignalStrength.signalStrength = rxlev;
    response.GW_SignalStrength.bitErrorRate = ber;
//CDMA
//EVDO
    /**
     *  Fill the cdma rssi value here. When we fill the actual rssi with 75, the
     *  SignalStrength.java will deal with it as -75
     */
    
    response.CDMA_SignalStrength.dbm = cdma_rssi;
    response.CDMA_SignalStrength.ecio = cdma_rssi;
    response.EVDO_SignalStrength.dbm = cdma_rssi;
    response.EVDO_SignalStrength.ecio = cdma_rssi;
//LTE
    response.LTE_SignalStrength.signalStrength = 0x7FFFFFFF;
    response.LTE_SignalStrength.rsrp = lte_rssi;
    response.LTE_SignalStrength.rsrq = 0x7FFFFFFF;
    response.LTE_SignalStrength.rssnr = 0x7FFFFFFF;
    response.LTE_SignalStrength.cqi = 0x7FFFFFFF;

    RLOGD("response****LTE signalStrength=%d, rsrp=%d, rsrq=%d, rssnr=%d, cqi=%d\r\n", response.LTE_SignalStrength.signalStrength,\
    response.LTE_SignalStrength.rsrp, \
    response.LTE_SignalStrength.rsrq, \
    response.LTE_SignalStrength.rssnr, \
    response.LTE_SignalStrength.cqi);

    RLOGD("CDMA/EVDO dbm=%d, ecio=%d, dbm=%d, ecio=%d, signalNoiseRatio=%d\r\n", response.CDMA_SignalStrength.dbm,\
    response.CDMA_SignalStrength.ecio, \
    response.EVDO_SignalStrength.dbm, \
    response.EVDO_SignalStrength.ecio, \
    response.EVDO_SignalStrength.signalNoiseRatio);

    RLOGD("GSM signalStrength=%d, bitErrorRate=%d\r\n", \
    response.GW_SignalStrength.signalStrength, response.GW_SignalStrength.bitErrorRate);

    if (NULL == t)
    {
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_SIGNAL_STRENGTH, &response, sizeof(response));
    }
    else
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(response));
    }
#endif
    at_response_free(p_response);
   // err = checkIP();
  //if (err < 0) goto error; 
    RLOGD("[%s] ====== Leave ",__FUNCTION__);

    return;

error:
    RLOGD("requestSignalStrength must never return an error when radio is on");
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}
#endif
/*End: Deleted by wujiabao in 2022/07/19, because we don't need it*/



static int setSignalStrength(RIL_SignalStrength_v6 *response, int *response_len)
{
    int err = -1;
	int lte_rsrp = 0x7FFFFFFF;
    CSQInfo csqInfo;
    int cdma_rssi = 0;
    
    if(response == NULL){
        RLOGE("[%s] parameter err",__FUNCTION__);
        goto error;
    }
    
    err = getCSQInfo(&csqInfo);
    if(err){
        RLOGE("[%s] getCSQInfo err",__FUNCTION__);
        goto error;
    }
    // Change it following the modem code.
    cdma_rssi = CDMA_RSSI_THRESH - ((csqInfo.rssi * CDMA_RSSI_SPAN) / 31);
	RLOGD("cdma_rssi : %d",cdma_rssi);
		
	
//These parameters are common
//GW
    response->GW_SignalStrength.signalStrength = csqInfo.rssi;
    response->GW_SignalStrength.bitErrorRate = csqInfo.ber;

//CDMA
    response->CDMA_SignalStrength.dbm = 0x7FFFFFFF;//-1;
    response->CDMA_SignalStrength.ecio = 0x7FFFFFFF;//-1;

//EVDO
    response->EVDO_SignalStrength.dbm = 0x7FFFFFFF;//-1;
    response->EVDO_SignalStrength.ecio = 0x7FFFFFFF;//-1;
    response->EVDO_SignalStrength.signalNoiseRatio =0x7FFFFFFF;// -1;

//LTE
    response->LTE_SignalStrength.signalStrength = csqInfo.rssi;
    response->LTE_SignalStrength.rsrp = RSRPTransform(csqInfo.rsrp);
    RLOGD("LTE_SignalStrength.signalStrength: %d",response->LTE_SignalStrength.signalStrength);
    RLOGD("rsrp after conversion : %d",response->LTE_SignalStrength.rsrp);
    response->LTE_SignalStrength.rsrq = 0x7FFFFFFF;
    response->LTE_SignalStrength.rssnr = 0x7FFFFFFF;
    response->LTE_SignalStrength.cqi = 0x7FFFFFFF;

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        ((RIL_SignalStrength_v10 *)response)->LTE_SignalStrength.timingAdvance = 0x7FFFFFFF;
        ((RIL_SignalStrength_v10 *)response)->TD_SCDMA_SignalStrength.rscp = 0x7FFFFFFF;
        *response_len = sizeof(RIL_SignalStrength_v10);
    }

#if 0
//These parameters are specific to Android 8,9, and 10
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
//Additional LTE
    response->LTE_SignalStrength.timingAdvance = 0x7FFFFFFF;

//TD-SCDMA
    response->TD_SCDMA_SignalStrength.rscp = 0x7FFFFFFF;
#endif
#endif

error:
    return err;
    RLOGD("Leave %s error.",__FUNCTION__);
}
void requestSignalStrength_Generic(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err = -1;

    RIL_SignalStrength_v6 *response = NULL;
    int response_len = sizeof(RIL_SignalStrength_v6);

    response = (RIL_SignalStrength_v6 *)malloc(sizeof(RIL_SignalStrength_v6) + 64);

    RLOGD("[%s] ====== Enter ",__FUNCTION__);

    memset(response, 0, sizeof(*response));

    if (!((GHT_FG621 == mode_flag) || (GHT_MC919 == mode_flag) || GHT_MC66x == mode_flag))
    {
      check_net_mode();
    }

    err = setSignalStrength(response, &response_len);
    if(err){
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else{
        if (NULL == t){
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_SIGNAL_STRENGTH, response, response_len);
        }
        else{
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, response, response_len);
        }
    }
    RLOGD("[%s] ====== Leave ",__FUNCTION__);
    return;
}

#if 0
void requestSignalStrength(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    char *line;    
    int signalStrength = 0;
    int bitErrorRate = 0;
    int cdma_rssi = 0;
    RIL_SignalStrength_v6 response;
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    RIL_SignalStrength_v10 res;
    memset(&res, 0, sizeof(res));
#endif
    memset(&response, 0, sizeof(response));

// <!--added by wangmengying@2017.12.06 for ShunFengFengChao NL660-757S LTE->EVDO shows 1x.
    check_net_mode();
//end-->
    err = at_send_command_singleline("AT+CSQ", "+CSQ:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(signalStrength));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(bitErrorRate));
    if (err < 0) goto error;

    RLOGD("signalStrength=%d\r\n", signalStrength);
    RLOGD("bitErrorRate=%d\r\n", bitErrorRate);

    if( signalStrength > 99 && signalStrength < 200)
    {
        signalStrength = (signalStrength - 100)*31/91;
    }

//GW
    response.GW_SignalStrength.signalStrength = signalStrength;
    response.GW_SignalStrength.bitErrorRate = bitErrorRate;
//CDMA
//EVDO
    /**
     *  Fill the cdma rssi value here. When we fill the actual rssi with 75, the
     *  SignalStrength.java will deal with it as -75
     */
    cdma_rssi = CDMA_RSSI_THRESH - ((signalStrength * CDMA_RSSI_SPAN) / 31); // Change it following the modem code.
    response.CDMA_SignalStrength.dbm = cdma_rssi;
    response.CDMA_SignalStrength.ecio = cdma_rssi;
    response.EVDO_SignalStrength.dbm = cdma_rssi;
    response.EVDO_SignalStrength.ecio = cdma_rssi;
//LTE
    response.LTE_SignalStrength.signalStrength = signalStrength;
    response.LTE_SignalStrength.rsrp = SignalStrengthTransform(signalStrength);
    response.LTE_SignalStrength.rsrq = 0x7FFFFFFF;
    response.LTE_SignalStrength.rssnr = 0x7FFFFFFF;
    response.LTE_SignalStrength.cqi = 0x7FFFFFFF;

    RLOGD("LTE signalStrength=%d, rsrp=%d, rsrq=%d, rssnr=%d, cqi=%d\r\n", response.LTE_SignalStrength.signalStrength,\
    response.LTE_SignalStrength.rsrp, \
    response.LTE_SignalStrength.rsrq, \
    response.LTE_SignalStrength.rssnr, \
    response.LTE_SignalStrength.cqi);

    RLOGD("CDMA/EVDO dbm=%d, ecio=%d, dbm=%d, ecio=%d, signalNoiseRatio=%d\r\n", response.CDMA_SignalStrength.dbm,\
    response.CDMA_SignalStrength.ecio, \
    response.EVDO_SignalStrength.dbm, \
    response.EVDO_SignalStrength.ecio, \
    response.EVDO_SignalStrength.signalNoiseRatio);

    RLOGD("GSM signalStrength=%d, bitErrorRate=%d\r\n", \
    response.GW_SignalStrength.signalStrength, response.GW_SignalStrength.bitErrorRate);

#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    res.GW_SignalStrength.signalStrength = signalStrength;
    res.GW_SignalStrength.bitErrorRate = bitErrorRate;
/* BEGIN: Modified by eric.li, 2019/2/18   PN:modify for signal strength display issue on UI when switch to CT-3G */
    res.CDMA_SignalStrength.dbm = cdma_rssi;//-1;
    res.CDMA_SignalStrength.ecio = cdma_rssi;//-1;
    res.EVDO_SignalStrength.dbm = cdma_rssi;//-1;
    res.EVDO_SignalStrength.ecio = cdma_rssi;//-1;
    res.EVDO_SignalStrength.signalNoiseRatio =0;// -1;
/* END:   Modified by eric.li, 2019/2/18   PN:modify for signal strength display issue on UI */

    res.LTE_SignalStrength.signalStrength = signalStrength;
    res.LTE_SignalStrength.rsrp = 0x7FFFFFFF;
    res.LTE_SignalStrength.rsrq = 0x7FFFFFFF;
    res.LTE_SignalStrength.rssnr = 0x7FFFFFFF;
    res.LTE_SignalStrength.cqi = 0x7FFFFFFF;
    res.LTE_SignalStrength.timingAdvance = 0x7FFFFFFF;
    res.TD_SCDMA_SignalStrength.rscp = 0x7FFFFFFF;
    if (NULL == t)
    {
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_SIGNAL_STRENGTH, &res, sizeof(RIL_SignalStrength_v10));
    }
    else
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &res, sizeof(RIL_SignalStrength_v10));
    }
#else
    if (NULL == t)
    {
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_SIGNAL_STRENGTH, &response, sizeof(response));
    }
    else
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(response));
    }
#endif
    at_response_free(p_response);
    return;

error:
    RLOGD("requestSignalStrength must never return an error when radio is on");
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}
#else
void requestSignalStrength(void *data __unused, size_t datalen __unused, RIL_Token t)
{
}
#endif
//end -->
//added for NL678-E-00
static int parseRegistrationState(char *str, int *type __unused, int *items, int **response)
{
    int err;
    char *line = str, *p;
    int *resp = NULL;
    int skip;
    int count = 3;
    int commas;

    RLOGD("parseRegistrationState. Parsing: %s",str);
    err = at_tok_start(&line);
    if (err < 0) goto error;

    /* Ok you have to be careful here
     * The solicited version of the CREG response is
     * +CREG: n, stat, [lac, cid]
     * and the unsolicited version is
     * +CREG: stat, [lac, cid]
     * The <n> parameter is basically "is unsolicited creg on?"
     * which it should always be
     *
     * Now we should normally get the solicited version here,
     * but the unsolicited version could have snuck in
     * so we have to handle both
     *
     * Also since the LAC and CID are only reported when registered,
     * we can have 1, 2, 3, or 4 arguments here
     *
     * finally, a +CGREG: answer may have a fifth value that corresponds
     * to the network type, as in;
     *
     *   +CGREG: n, stat [,lac, cid [,networkType]]
     */
    /* count number of commas */
    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }

    resp = (int *)calloc(commas + 1, sizeof(int));
    if (!resp) goto error;
    RLOGD("commas = %d\n",commas);
    switch (commas) {
        case 0: /* +CREG: <stat> */
            err = at_tok_nextint(&line, &resp[0]);
            if (err < 0) goto error;
            resp[1] = -1;
            resp[2] = -1;
            resp[3] = -1;
            break;
            
            case 1: /* +CREG: <n>, <stat> */
                err = at_tok_nextint(&line, &skip);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                resp[1] = 0;
                resp[2] = 0;
                resp[3] = 0;
                if (err < 0) goto error;
                RLOGD("resp[] = %d, %d, %d",resp[0], resp[1], resp[2]);
                break;
                
            case 2: /* +CREG: <stat>, <lac>, <cid> */
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[1]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[2]);
                if (err < 0) goto error;
                resp[3] = -1;
                RLOGD("resp[] = %d, %d, %d",resp[0], resp[1], resp[2]);
                break;
            case 3: /* +CREG: <n>, <stat>, <lac>, <cid> */
                err = at_tok_nextint(&line, &skip);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[1]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[2]);
                if (err < 0) goto error;
                resp[3] = -1;
                RLOGD("resp[] = %d, %d, %d",resp[0], resp[1], resp[2]);
                break;
            /* special case for CGREG, there is a fourth parameter
             * that is the network type (unknown/gprs/edge/umts)
             */
            case 4: /* +CGREG: <n>, <stat>, <lac>, <cid>, <networkType> */
            //case 5: /* +CGREG: <n>, <stat>, <lac>, <cid>, <networkType> */
            case 5: /* +CGREG: <n>, <stat>, <lac>, <cid>, <networkType> */
            case 6:/*+C5GREG:<n>,<stat>,<tac>,<ci>,<AcT>,<Allowed_NSSAI_length>,<Allowed_NSSAI>*/
                err = at_tok_nextint(&line, &skip);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[1]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[2]);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[3]);
                if (err < 0) goto error;
                count = 4;
                RLOGD("resp[] = %d, %d, %d, %d",resp[0], resp[1], resp[2], resp[3]);
                break;
            default:
                goto error;
            }
    RLOGD("resp[] = %d, %d, %d, %d",resp[0], resp[1], resp[2], resp[3]);
    if (response)
        *response = resp;
    if (items)
        *items = commas + 1;
    return 0;
error:
    free(resp);
    return -1;
}


void requestRegistrationState(int request, void *data __unused,size_t datalen __unused, RIL_Token t)
{
    int err;
    int *registration = NULL;
    char **responseStr = NULL;
    ATResponse *p_response = NULL;
    int response[4];
    const char *cmd;
    const char *prefix;
    char *line;
    int i = 0, j, numElements = 0;
    int type, startfrom = 0;
    bool flag_creg = false;
    bool flag_cereg = false;
    int count = 3;

    RLOGD("********enter %s********",__FUNCTION__);
    if (mode_flag < GHT_NL668)
    {
    if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE) {
        cmd = "AT^SYSINFO";
        prefix = "^SYSINFO:";

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        numElements = 15;
    }
    else
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        numElements = 4;
    }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
	/*begin:modified by lisf 20181201 for RIL8*/	
	numElements = 15;
	/*end:modified by lisf 20181201 for RIL8*/
#else
        numElements = 4;
#endif
#endif
    } else if (request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
        cmd = "AT^SYSINFO";
        prefix = "^SYSINFO:";

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        numElements = 6;
    }
    else
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        numElements = 4;
    }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
	/*begin:modified by lisf 20181201 for RIL8*/		
	numElements = 6;
	/*end:modified by lisf 20181201 for RIL8*/
#else
        numElements = 4;
#endif
#endif
    } else {
        assert(0);
        goto error;
    }

    err = at_send_command_singleline(cmd, prefix, &p_response);

    if ((err != 0) || (p_response->success == 0) ) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &response[0]);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &response[1]);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &response[2]);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &response[3]);
    if (err < 0) goto error;
    
    at_response_free(p_response);
    p_response = NULL;
    
    responseStr = malloc(numElements * sizeof(char *));
    if (!responseStr) goto error;
    memset(responseStr, 0, numElements * sizeof(char *));
    /**
     * The first '4' bytes for both registration states remain the same.
     * But if the request is 'DATA_REGISTRATION_STATE',
     * the 5th and 6th byte(s) are optional.
     */

    if((request == RIL_REQUEST_VOICE_REGISTRATION_STATE) && (response[0] != 0) && (response[0] != 4)){
        if(response[1] == 0)
            asprintf(&responseStr[0], "%d", 0);
        else if(response[1] == 4)
            asprintf(&responseStr[0], "%d", 2);
        else if(response[2] == 1)
            asprintf(&responseStr[0], "%d", 5);
        else
            asprintf(&responseStr[0], "%d", 1);
    }else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
        asprintf(&responseStr[0], "%d", 0);

    if((request == RIL_REQUEST_DATA_REGISTRATION_STATE) && (response[0] != 0) && ((response[1] == 2) || (response[1] == 3) || (response[1] == 255))){
        if(response[2] == 1)
            asprintf(&responseStr[0], "%d", 5);
        else
            asprintf(&responseStr[0], "%d", 1);
    }else if(request == RIL_REQUEST_DATA_REGISTRATION_STATE)
        asprintf(&responseStr[0], "%d", 0);

    {
    cmd = "AT+PSRAT";
    prefix = "+PSRAT:";
    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (err == 0 && p_response->success != 0) {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err == 0) {
            if ((strstr(line, "FDD LTE") != NULL)||(strstr(line, "TDD LTE") != NULL) ||
                 strstr(line, "SRLTE")||(strstr(line, "LTE")))
            {
                response[3] = 14;
                supportedTechs = RADIO_TECH_LTE;
            }
            else if (strstr(line, "TDSCDMA") != NULL)
            {
                response[3] = 3;
                supportedTechs = RADIO_TECH_UMTS;
            }
            else if (strstr(line, "HSDPA") != NULL)
            {
                response[3] = 9;
                supportedTechs = RADIO_TECH_HSDPA;
            }
            else if (strstr(line, "HSUPA") != NULL)
            {
                response[3] = 10;
                supportedTechs = RADIO_TECH_HSUPA;
            }
            else if (strstr(line, "HSPA+") != NULL)
            {
                response[3] = 15;
                supportedTechs = RADIO_TECH_HSPAP;
            }
            else if (strstr(line, "GPRS") != NULL)
            {
                response[3] = 1;
                supportedTechs = RADIO_TECH_GPRS;
            }
            else if (strstr(line, "EDGE") != NULL)
            {
                response[3] = 2;
                supportedTechs = RADIO_TECH_EDGE;
            }
            else if (strstr(line, "WCDMA") != NULL)
            {
                response[3] = 3;
                supportedTechs = RADIO_TECH_UMTS;
            }
            else if ((strstr(line, "EVDO") != NULL) || (0 == strcmp(line,"CDMA&EVDO")) || (strstr(line, "HDR") != NULL))
            {
                response[3] = 7;
                supportedTechs = RADIO_TECH_EVDO_0;
            }
            else if (strstr(line, "CDMA") != NULL)
            {
                response[3] = 6;
                supportedTechs = RADIO_TECH_1xRTT;
            }
            else if (strstr(line, "GSM") != NULL)
            {
                response[3] = 16;
                supportedTechs = RADIO_TECH_GSM;
            }
            else if (strstr(line, "EHRPD") != NULL)
            {
                response[3] = 13;
                supportedTechs = RADIO_TECH_EHRPD;
            }
            else
            {
                response[3] = 0;
                supportedTechs = -1;
            }
        }
    }
    at_response_free(p_response);
    p_response = NULL;

    asprintf(&responseStr[3], "%d", response[3]);
    }

    if ((supportedTechs == 6) || (supportedTechs == 7) || (supportedTechs == 13)) {
        startfrom = 0;
        asprintf(&responseStr[1], "%x", 0);
        asprintf(&responseStr[2], "%x", 0);
/*******************************************************************************/
        if((GHT_NL660 == mode_flag) || (GHT_NL668 == mode_flag))
        {
            err = at_send_command_multiline("AT+SCELLINFO","", &p_response);
            if (err != 0){
                RLOGD("There is no CELL INFO!");
            }else{
             char *skip;
            ATLine *p_cur;
            for (i = 0,p_cur = p_response->p_intermediates
                    ; p_cur != NULL
                    ; p_cur = p_cur->p_next, i++) {
                char *line = p_cur->line;

                if (!at_tok_hasmore(&line)) {
                    continue;
                }
                if(i==0){
                    at_tok_start(&line);
                    at_tok_nextstr(&line, &skip);
                    at_tok_nextstr(&line, &skip);
                }
                if(i==1){
                    at_tok_start(&line);
                    at_tok_nextstr(&line, &skip);
                }
                if(i==2){
                    at_tok_start(&line);
                    at_tok_nexthexint(&line, &response[1]);
                    response[1] = -1;
                    asprintf(&responseStr[1], "%x", response[1]);
                }
                if(i==3){
                    at_tok_start(&line);
                    at_tok_nexthexint(&line, &response[2]);
                    response[2] = -1;
                    asprintf(&responseStr[2], "%x", response[2]);
                }
                if(i==4){
                    at_tok_start(&line);
                    at_tok_nextstr(&line, &skip);
                }
                if(i==5){
                    at_tok_start(&line);
                    at_tok_nextstr(&line, &skip);
                }
                if (!at_tok_hasmore(&line)) {
                    continue;
                }
                at_tok_nextstr(&line, &skip);
                if (!at_tok_hasmore(&line)) {
                    continue;
                }
                at_tok_nextstr(&line, &skip);

            }
        }
    }

/*******************************************************************************/
       else{
       err = at_send_command_multiline("AT+LCTCELLINFO","", &p_response);
       if (err != 0){
           RLOGD("There is no CELL INFO!");
       }else{
             char *skip;
            ATLine *p_cur;
            for (i = 0,p_cur = p_response->p_intermediates
                    ; p_cur != NULL
                    ; p_cur = p_cur->p_next, i++) {
                char *line = p_cur->line;

                if (!at_tok_hasmore(&line)) {
                    continue;
                }
                if(i==0){
                    at_tok_start(&line);
                    at_tok_nextstr(&line, &skip);
                    at_tok_nextstr(&line, &skip);
                }
                if(i==1){
                    at_tok_start(&line);
                    at_tok_nextstr(&line, &skip);
                }
                if(i==2){
                    at_tok_start(&line);
                    at_tok_nexthexint(&line, &response[1]);
                    response[1] = -1;
                    asprintf(&responseStr[1], "%x", response[1]);
                }
                if(i==3){
                    at_tok_start(&line);
                    at_tok_nexthexint(&line, &response[2]);
                    response[2] = -1;
                    asprintf(&responseStr[2], "%x", response[2]);
                }
                if(i==4){
                    at_tok_start(&line);
                    at_tok_nextstr(&line, &skip);
                }
                if(i==5){
                    at_tok_start(&line);
                    at_tok_nextstr(&line, &skip);
                }
                if (!at_tok_hasmore(&line)) {
                    continue;
                }
                at_tok_nextstr(&line, &skip);
                if (!at_tok_hasmore(&line)) {
                    continue;
                }
                at_tok_nextstr(&line, &skip);

            }
        }
        }
/***************************************************************************/
    }else if(supportedTechs == 14){
        asprintf(&responseStr[1], "%x", 0);
        asprintf(&responseStr[2], "%x", 0);
        startfrom = 0;
        if(!flag_cereg){
        err = at_send_command("AT+CEREG=2", NULL);
        if (err < 0 )
                flag_cereg = false;
            else
                flag_cereg = true;
        }
        
        if(flag_cereg){
            err = at_send_command_singleline("AT+CEREG?", "+CEREG:", &p_response);
            if ((err == 0) && (p_response->success != 0)){
                char *p;
                int commas = 0;
                line = p_response->p_intermediates->line;
                at_tok_start(&line);
                commas = 0;
                for (p = line ; *p != '\0' ;p++) {
                    if (*p == ',') commas++;
                }
                if(commas > 2) {
                    at_tok_nextint(&line, &err);
                    at_tok_nextint(&line, &err);
                    at_tok_nexthexint(&line, &response[1]);
                    // at_tok_nextint(&line, &err); //modified get lte cell id by lisf 20181217
                    at_tok_nexthexint(&line, &response[2]);
                    asprintf(&responseStr[1], "%x", response[1]);
                    asprintf(&responseStr[2], "%x", response[2]);
                }
            }
        }
    }else if (supportedTechs != -1){
        asprintf(&responseStr[1], "%x", 0);
        asprintf(&responseStr[2], "%x", 0);
        startfrom = 0;
        if(!flag_creg){
        err = at_send_command("AT+CREG=2", NULL);
        if (err < 0)
                flag_creg = false;
            else
                flag_creg = true;
        }
        
        if(flag_creg){
            err = at_send_command_singleline("AT+CREG?", "+CREG:", &p_response);
            if ((err == 0) && (p_response->success != 0)){
                char *p;
                int commas = 0;
                line = p_response->p_intermediates->line;
                at_tok_start(&line);
                commas = 0;
                for (p = line ; *p != '\0' ;p++) {
                    if (*p == ',') commas++;
                }
                if(commas > 2) {
                    at_tok_nextint(&line, &err);
                    at_tok_nextint(&line, &err);
                    at_tok_nexthexint(&line, &response[1]);
                    at_tok_nexthexint(&line, &response[2]);
                    asprintf(&responseStr[1], "%x", response[1]);
                    asprintf(&responseStr[2], "%x", response[2]);
                }
            }
        }
    }

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        if(request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
            asprintf(&responseStr[4],"%d", 0);
            asprintf(&responseStr[5],"%d",1);
        }
        else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
        {
            for(j = 4 ; j < numElements;j++)
            {
                asprintf(&responseStr[j],"%d", 0);
            }
        }
    }
    else
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        for (j = startfrom; j < numElements; j++)
        {
            if (!responseStr[j])
            {
                RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
                goto error;
            }
        }
    }

#if 0
	/*begin:modified by lisf 20181201 for RIL8*/		
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    if(request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
            asprintf(&responseStr[4],"%d", 0);
            asprintf(&responseStr[5],"%d",1);
    }
    else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
    {
	     for(j = 4 ; j < numElements;j++)
	     {
            		asprintf(&responseStr[j],"%d", 0);
	     }
    }
#else
    for (j = startfrom; j < numElements; j++)
    {
        if (!responseStr[j])
        {
            RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
            goto error;
        }
    }
#endif
	/*end:modified by lisf 20181201 for RIL8*/	
#endif

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, numElements*sizeof(responseStr));
    for (j = 0; j < numElements; j++ ) {
        free(responseStr[j]);
        responseStr[j] = NULL;
    }
    free(responseStr);
    responseStr = NULL;
    at_response_free(p_response);
    return;

    }
    else if (((mode_flag >= GHT_NL668) && (mode_flag <= GHT_NL678_E)) || (mode_flag == GHT_L716))//modified support for NL668 NORMAL by lisf 20190318
    {
        int network_type = 0;
        network_type = odm_get_current_network_type();
        at_send_command("AT+CREG=2", NULL);
        at_send_command("AT+CGREG=2", NULL);
        at_send_command("AT+CEREG=2", NULL);
           
	    if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
	    {
	        if (network_type == 14)
	        {
	            cmd = "AT+CEREG?";
	            prefix = "+CEREG:";
	        }
	        else
	        {
	            cmd = "AT+CREG?";
	            prefix = "+CREG:";
	        }

            if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 15;
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 4;
            }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
		numElements = 15;
#else
		numElements = 4;
#endif
#endif

	    }
	    else if (request == RIL_REQUEST_DATA_REGISTRATION_STATE)
	    {
	        if (network_type == 14)
	        {
	            cmd = "AT+CEREG?";
	            prefix = "+CEREG:";
	        }
	        else
            {
                if((ODM_CT_OPERATOR_3G == cur_oper) || (ODM_CT_OPERATOR_4G == cur_oper))
                {
                    cmd = "AT+CREG?";
                    prefix = "+CREG:";
                }
                else
                {
                    cmd = "AT+CGREG?";
                    prefix = "+CGREG:";
                }
            }

            if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 6;
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 4;
            }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
	        numElements = 6;
#else
    	    numElements = 4;
#endif
#endif
	    } 
	    else 
	    {
	        assert(0);
	        goto error;
	    }

	    err = at_send_command_singleline(cmd, prefix, &p_response);

	    if ((err != 0) || (p_response->success == 0) ) goto error;

	    line = p_response->p_intermediates->line;

	    if (parseRegistrationState(line, &type, &count, &registration)) goto error;

	    responseStr = malloc(numElements * sizeof(char *));
	    if (!responseStr) goto error;
	    memset(responseStr, 0, numElements * sizeof(char *));
	    /**
	     * The first '4' bytes for both registration states remain the same.
	     * But if the request is 'DATA_REGISTRATION_STATE',
	     * the 5th and 6th byte(s) are optional.
	     */
	    startfrom = 0;
	    asprintf(&responseStr[1], "%x", registration[1]);
	    asprintf(&responseStr[2], "%x", registration[2]);
           RLOGD("[%d]registration[0][1][2][3] == %d,%d,%d,%d\r\n",__LINE__,registration[0],registration[1],registration[2],registration[3]);

        if (count > 3)
        {
            switch(registration[3])
            {
                 case 0:
                 case 1:
                     registration[3] = RADIO_TECH_GPRS;
                     break;
                 case 2:
                     registration[3] = RADIO_TECH_UMTS;
                     break;
                 case 3:
                     registration[3] = RADIO_TECH_EDGE;
                     break;
                 case 4:
                     registration[3] = RADIO_TECH_HSDPA;
                     break;
                 case 5:
                     registration[3] = RADIO_TECH_HSUPA;
                     break;
                 case 6:
                     registration[3] = RADIO_TECH_HSPA;
                     break;
                 case 7:
                 case 12:
                     registration[3] = RADIO_TECH_LTE;
                     break;
                 case 8:
                     registration[3] = RADIO_TECH_HSPAP;
                 case 9:
                     if(!Net_3G_Support_Flag)
                     {
                         registration[3] = RADIO_TECH_LTE;
                         break;
                     }
                 default:
                     registration[3] = RADIO_TECH_UNKNOWN;
                     break;
           }
           asprintf(&responseStr[3], "%d", registration[3]);
           RLOGD("registration[3] == %d\r\n",registration[3]);
        }

	    if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
	    {
	        if (registration[0] == 6)
	        {
	            registration[0] = 1;
	            RLOGD("registration[0] ==  %d \r\n",registration[0] );
	        }
	    }
	    asprintf(&responseStr[0], "%d", registration[0]);
	    RLOGD("registration[0] == %d\r\n",registration[0]);
	    free(registration);
	    registration = NULL;

        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            if(request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
                asprintf(&responseStr[4],"%d", 0);
                asprintf(&responseStr[5],"%d",1);
            }
            else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
            {
                for(j = 4 ; j < numElements;j++)
                {
                    asprintf(&responseStr[j],"%d", 0);
                }
            }
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            for (j = startfrom; j < numElements; j++)
            {
                if (!responseStr[j])
                {
                    RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
                    goto error;
                }
            }
        }

#if 0
//added by lisf for android8 report data registration and voice registration 20181221
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    if(request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
            asprintf(&responseStr[4],"%d", 0);
            asprintf(&responseStr[5],"%d",1);
    }
    else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
    {
        for(j = 4 ; j < numElements;j++)
        {
            asprintf(&responseStr[j],"%d", 0);
        }
    }
#else
    for (j = startfrom; j < numElements; j++)
    {
        if (!responseStr[j])
        {
            RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
            goto error;
        }
    }
#endif
#endif
	    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, numElements*sizeof(responseStr));
	    for (j = 0; j < numElements; j++ ) {
	        free(responseStr[j]);
	        responseStr[j] = NULL;
	    }
	    free(responseStr);
	    responseStr = NULL;
	    at_response_free(p_response);
	    return;


    }
    else if(mode_flag == GHT_FG650)
    {
        at_send_command("AT+CREG=2", NULL);
        at_send_command("AT+CGREG=2", NULL);
        at_send_command("AT+CEREG=2", NULL);
        at_send_command("AT+C5GREG=2", NULL);

        if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
        {
            if ((g_cops_lte == 7) || (g_cops_lte ==13))
            {
                cmd = "AT+CEREG?";
                prefix = "+CEREG:";
            }
            else if ((g_cops_lte == 11)||(g_cops_lte == 12))
            {
                cmd = "AT+C5GREG?";
                prefix = "+C5GREG:";
            }
            else if ((g_cops_lte == 6)||(g_cops_lte == 2))
            {
                cmd = "AT+CGREG?";
                prefix = "+CGREG:";
            }
            else if((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
            {
                cmd = "AT+CGREG?";
                prefix = "+CGREG:";
            }
            else
            {
                cmd = "AT+CREG?";
                prefix = "+CREG:";
            }

            if((ANDROID_6 == Ght_Android_Version) || (Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11))
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11, or == 6 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 15;
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11, and != 6 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 4;
            }

#if 0
#if defined GHT_FEATURE_ANDROID6X || defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            numElements = 15;
#else
            numElements = 4;
#endif
#endif
        }
        else if (request == RIL_REQUEST_DATA_REGISTRATION_STATE)
        {
            if ((g_cops_lte == 7) || (g_cops_lte == 13) )
            {
                cmd = "AT+CEREG?";
                prefix = "+CEREG:";
            }
            else if ((g_cops_lte == 11) || (g_cops_lte == 12))
            {
                cmd = "AT+C5GREG?";
                prefix = "+C5GREG:";
            }
            else
            {
                cmd = "AT+CGREG?";
                prefix = "+CGREG:";
            }

            if((ANDROID_6 == Ght_Android_Version) || (Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11))
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11, or == 6 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 6;
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11, and != 6 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 4;
            }

#if 0
#if defined GHT_FEATURE_ANDROID6X || defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            numElements = 6;
#else
            numElements = 4;
#endif
#endif
        }
        else
        {
            assert(0);
            goto error;
        }

        err = at_send_command_singleline(cmd, prefix, &p_response);
        if ((err != 0) || (p_response->success == 0) )
            goto error;

        line = p_response->p_intermediates->line;
        if (parseRegistrationState(line, &type, &count, &registration))
            goto error;

        responseStr = malloc(numElements * sizeof(char *));
        if (!responseStr)
            goto error;

        memset(responseStr, 0, numElements * sizeof(char *));
        /**
        * The first '4' bytes for both registration states remain the same.
        * But if the request is 'DATA_REGISTRATION_STATE',
        * the 5th and 6th byte(s) are optional.
        */
        startfrom = 0;
        asprintf(&responseStr[1], "%x", registration[1]);
        asprintf(&responseStr[2], "%x", registration[2]);
        if (count > 3)
        {
            switch(registration[3])
            {
                /* AT response */
                // 0 GSM
                // 2 UTRAN
                // 3 GSM w/EGPRS
                // 4 UTRAN w/HSDPA
                // 5 UTRAN w/HSUPA
                // 6 UTRAN w/HSDPA and HSUPA
                case 0:
                    registration[3] = RADIO_TECH_GPRS;
                    break;
                case 1:
                    registration[3] = RADIO_TECH_GPRS;
                    break;
                case 2:
                    registration[3] = RADIO_TECH_UMTS;
                    break;
                case 3:
                    registration[3] = RADIO_TECH_EDGE;
                    break;
                case 4:
                    registration[3] = RADIO_TECH_HSDPA;
                    break;
                case 5:
                    registration[3] = RADIO_TECH_HSUPA;
                    break;
                case 6:
                    registration[3] = RADIO_TECH_HSPA;
                    break;
                case 7:
                    registration[3] = RADIO_TECH_LTE;
                    break;
                case 11:
                case 12:
                case 13:
                    registration[3] = RADIO_TECH_LTE_NR;
                    break;
                case 8:
                    registration[3] = RADIO_TECH_HSPAP;
                    break;
                default:
                    registration[3] = RADIO_TECH_UNKNOWN;
                    break;
            }
            asprintf(&responseStr[3], "%d", registration[3]);
            RLOGD("registration[3] == %d\r\n",registration[3]);
        }
        if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
        {
            if (registration[0] == 6)
            {
                registration[0] = 1;
                RLOGD("voice registration[0] ==  %d \r\n",registration[0] );
            }
        }
        asprintf(&responseStr[0], "%d", registration[0]);
        RLOGD("registration[0] == %d\r\n",registration[0]);
        free(registration);
        registration = NULL;

        if((ANDROID_6 == Ght_Android_Version) || (Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11))
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11, or == 6 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            if(request == RIL_REQUEST_DATA_REGISTRATION_STATE)
            {
                asprintf(&responseStr[4],"%d", 0);
                asprintf(&responseStr[5],"%d",1);
            }
            else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
            {
                for(j = 4 ; j < numElements;j++)
                {
                    asprintf(&responseStr[j],"%d", 0);
                }
            }
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11, and != 6 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            for (j = startfrom; j < numElements; j++)
            {
                if (!responseStr[j])
                {
                    RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
                    goto error;
                }
            }
        }

#if 0
#if defined GHT_FEATURE_ANDROID6X || defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        if(request == RIL_REQUEST_DATA_REGISTRATION_STATE)
        {
            asprintf(&responseStr[4],"%d", 0);
            asprintf(&responseStr[5],"%d",1);
        }
        else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
        {
            for(j = 4 ; j < numElements;j++)
            {
                asprintf(&responseStr[j],"%d", 0);
            }
        }
#else
        for (j = startfrom; j < numElements; j++)
        {
            if (!responseStr[j])
            {
                RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
                goto error;
            }
        }
#endif
#endif
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, numElements*sizeof(responseStr));
        for (j = 0; j < numElements; j++ )
        {
            free(responseStr[j]);
            responseStr[j] = NULL;
        }
        free(responseStr);
        responseStr = NULL;
        at_response_free(p_response);
        return;
    }
    else if(GHT_H330S == mode_flag)
    {
        int network_type = 0;
        network_type = odm_get_current_network_type();
        at_send_command("AT+CREG=2", NULL);
        at_send_command("AT+CGREG=2", NULL);

        cmd = "AT+CREG?";
        prefix = "+CREG:";

        if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
        {

            if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 15;
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 4;
            }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            numElements = 15;
#else
            numElements = 4;
#endif
#endif
        }
        else if (request == RIL_REQUEST_DATA_REGISTRATION_STATE)
        {

            if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 6;
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                numElements = 4;
            }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            numElements = 6;
#else
            numElements = 4;
#endif
#endif
        } 
        else 
        {
            assert(0);
            goto error;
        }

        err = at_send_command_singleline(cmd, prefix, &p_response);
        if ((err != 0) || (p_response->success == 0) ) goto error;

        line = p_response->p_intermediates->line;
        if (parseRegistrationState(line, &type, &count, &registration)) goto error;

        responseStr = malloc(numElements * sizeof(char *));
        if (!responseStr) goto error;
        memset(responseStr, 0, numElements * sizeof(char *));
        /**
        * The first '4' bytes for both registration states remain the same.
        * But if the request is 'DATA_REGISTRATION_STATE',
        * the 5th and 6th byte(s) are optional.
        */
        startfrom = 0;
        asprintf(&responseStr[1], "%x", registration[1]);
        asprintf(&responseStr[2], "%x", registration[2]);
        RLOGD("[%d]registration[0][1][2][3] == %d,%d,%d,%d\r\n",__LINE__,registration[0],registration[1],registration[2],registration[3]);
        
        if (count > 3)
        {
            switch(registration[3])
            {
                case 0:
                case 1:
                case 3:
                    registration[3] = RADIO_TECH_GPRS;
                    break;
                case 2:
                case 6:                      //NOTE :The return value from this command does not match the AT manual, and there may be an error
                    registration[3] = RADIO_TECH_UMTS;
                    break;
                default:
                    registration[3] = RADIO_TECH_UNKNOWN;
                    break;
            }
            asprintf(&responseStr[3], "%d", registration[3]);
            RLOGD("registration[3] == %d\r\n",registration[3]);
        }
        
        if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
        {
            if (registration[0] == 6)
            {
                registration[0] = 1;
                RLOGD("registration[0] ==  %d \r\n",registration[0] );
            }
        }
        asprintf(&responseStr[0], "%d", registration[0]);
        RLOGD("registration[0] == %d\r\n",registration[0]);
        free(registration);
        registration = NULL;

        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            if(request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
                asprintf(&responseStr[4],"%d", 0);
                asprintf(&responseStr[5],"%d",1);
            }
            else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
            {
                for(j = 4 ; j < numElements;j++)
                {
                    asprintf(&responseStr[j],"%d", 0);
                }
            }
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            for (j = startfrom; j < numElements; j++)
            {
                if (!responseStr[j])
                {
                    RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
                    goto error;
                }
            }
        }

#if 0
        //added by lisf for android8 report data registration and voice registration 20181221
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        if(request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
            asprintf(&responseStr[4],"%d", 0);
            asprintf(&responseStr[5],"%d",1);
        }
        else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
        {
            for(j = 4 ; j < numElements;j++)
            {
                asprintf(&responseStr[j],"%d", 0);
            }
        }
#else
        for (j = startfrom; j < numElements; j++)
        {
            if (!responseStr[j])
            {
                RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
                goto error;
            }
        }
#endif
#endif

        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, numElements*sizeof(responseStr));
        for (j = 0; j < numElements; j++ ) {
            free(responseStr[j]);
            responseStr[j] = NULL;
        }
        free(responseStr);
        responseStr = NULL;
        at_response_free(p_response);
        return;
    }
    else{
        RLOGD("Unknown module, so registration status cannot be recognized");
        goto error;
    }
    RLOGD("********leave %s********",__FUNCTION__);

error:
    if (responseStr) {
        for (j = 0; j < numElements; j++) {
            free(responseStr[j]);
            responseStr[j] = NULL;
        }
        free(responseStr);
        responseStr = NULL;
    }
    RLOGD("RequestRegistrationState must never return an error when radio is on");
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    //at_response_free(p_response);
    RLOGD("*********Leave %s***********", __FUNCTION__);
}
int getCOPSInfo(COPSInfo *copsInfo)
{
    int err = -1;
    ATResponse *p_response = NULL;
    char *line = NULL;
    int mode = -1;
    int format = -1;
    char *oper = NULL;
    int Act = 0;

    if(copsInfo == NULL){
        RLOGE("[%s] parameters err",__FUNCTION__);
        goto error;
    }
    err = at_send_command_singleline("AT+COPS?", "+COPS:", &p_response);
    if (err < 0 || p_response->success == 0){
        RLOGE("[%s] at_send_command_singleline err",__FUNCTION__);
        goto error;
    }
    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &mode);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &format);
    if (err < 0) goto error;
    err = at_tok_nextstr(&line, &oper);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &Act);

    copsInfo->mode = mode;
    copsInfo->format = format;
    copsInfo->oper = strdup(oper);
    copsInfo->Act = Act;

error:
    at_response_free(p_response);
    return err;
}

static int getOperaterStr(char **oper,char **oper1,char **oper2)
{
    int err = -1;
    int i = 0;
    char *cmd = NULL;
    COPSInfo copsInfo[3];
//    int network_debounce_time = 2;

//__operator_restart:

    memset(&copsInfo,0,sizeof(COPSInfo));
    for(i = 0; i < 3; i++){
        asprintf(&cmd, "AT+COPS=3,%d", i);
        at_send_command(cmd, NULL);
        err = getCOPSInfo(&copsInfo[i]);
        if(err){
            goto error;
        }
        free(cmd);
    }
    
    RLOGD("[%s] oper:[%s] ",__FUNCTION__,copsInfo[0].oper);
    RLOGD("[%s] oper:[%s] ",__FUNCTION__,copsInfo[1].oper);
    RLOGD("[%s] oper:[%s] ",__FUNCTION__,copsInfo[2].oper);
    
    *oper   = copsInfo[0].oper;
    *oper1  = copsInfo[1].oper;
    *oper2  = copsInfo[2].oper;

    g_cops_lte = copsInfo[2].Act;
    RLOGD("[%s] set g_cops_lte:[%d] ",__FUNCTION__,g_cops_lte);

error:
/*
    if(err && (network_debounce_time > 0)){
        sleep(1);
        network_debounce_time--;
        goto __operator_restart;
    }
*/
    return err;
}
void requestOperator_Generic(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err = -1;
    int i = 0;
    char *response[3];

    RLOGD("[%s] ====== Enter ",__FUNCTION__);
    memset(response,0,sizeof(response));
    
    err = getOperaterStr(&response[0],&response[1],&response[2]);
    if(err){
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else{
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
        for(i = 0; i< 3 ; i++){
            free(response[i]);
        }
    }
	RLOGE("===4 stephen-ril Response requestOperator_Generic RIL_E_SUCCESS(%s) data:(response[0]:%s,response[1]:%s,response[2]:%s) len:(%d)",__FUNCTION__,response[0],response[1],response[2],sizeof(response));

    RLOGD("[%s] ====== Leave ",__FUNCTION__);
    return;
}
/*begin:modified by lisf for get operator 20181208*/
void requestOperator(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    int i;
    int skip;

    char *response[3] = {0};
    char *usol_reresponse[3] = {0};
    char cmd[32] = {0};
    char *line = NULL;
    int findCount = 0;
    int size_cnt = 0;

    memset(response, 0, sizeof(response));

    ATResponse *p_response = NULL;

    for (i = 0; i < 3; i++)
    {
        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd), "AT+COPS=3,%d", i);
/* BEGIN: Modified by eric.li, 2018/12/24   PN:sovle issue 0014206 that at+cops=3,0 timeout to reset modem */
        at_send_command(cmd, NULL);
/* END:   Modified by eric.li, 2018/12/24   PN:sovle issue 0014206 that at+cops=3,0 timeout to reset modem */
        err = at_send_command_singleline("AT+COPS?", "+COPS:", &p_response);

        if (err < 0 || p_response->success == 0)
        {
            goto error;
        }
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &skip);
        if (err < 0) goto error;

        // If we're unregistered, we may just get
        // a "+COPS: 0" response
        if (!at_tok_hasmore(&line))
        {
            response[i] = NULL;
            /*Begin: [NA] Moded by liuqifeng if network on register exit SETUP_DATA_CALL 20170801*/
            g_cops_lte = -1;
            /*End  : [NA] Moded by liuqifeng if network on register exit SETUP_DATA_CALL 20170801*/
            if(NULL != p_response)
            {
                at_response_free(p_response);
                p_response = NULL;
            }
            continue;
        }

        err = at_tok_nextint(&line, &skip);
        if (err < 0) goto error;

        // a "+COPS: 0, n" response is also possible
        if (!at_tok_hasmore(&line))
        {
            response[i] = NULL;
            /*Begin: [NA] Moded by liuqifeng if network on register exit SETUP_DATA_CALL 20170801*/
            g_cops_lte = -1;
            /*End  : [NA] Moded by liuqifeng if network on register exit SETUP_DATA_CALL 20170801*/
            if(NULL != p_response)
            {
                at_response_free(p_response);
                p_response = NULL;
            }
            continue;
        }

        err = at_tok_nextstr(&line, &(response[i]));
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &g_cops_lte);
        if (err < 0) goto error;
        RLOGD("######### g_cops_lte[%d] ########\r\n",g_cops_lte);

        size_cnt = strlen(response[i]) + 1;
        usol_reresponse[i] = alloca(size_cnt);
        memset(usol_reresponse[i], 0, size_cnt);
        strcpy(usol_reresponse[i], response[i]);

        findCount++;
        
        at_response_free(p_response);
        p_response = NULL;     
    }

    if (findCount != 3)
    {
        /* expect 3 lines exactly */
        /*Begin: [NA] Moded by liuqifeng if network on register exit SETUP_DATA_CALL 20170801*/
        g_cops_lte = -1;
        /*End  : [NA] Moded by liuqifeng if network on register exit SETUP_DATA_CALL 20170801*/
        goto error;
    }

    RLOGD("%s,%d,[%zu][%zu][%zu]", __FUNCTION__, __LINE__, strlen(usol_reresponse[0]), strlen(usol_reresponse[1]), strlen(usol_reresponse[2]));
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, usol_reresponse, 3 * sizeof(char *));
    if(NULL != p_response)
    {
        at_response_free(p_response);
        p_response = NULL;
    }

    return;
error:
    RLOGE("requestOperator must not return error when radio is on");
    /*Begin: [NA] Moded by liuqifeng if network on register exit SETUP_DATA_CALL 20170801*/
    g_cops_lte = -1;
    /*End  : [NA] Moded by liuqifeng if network on register exit SETUP_DATA_CALL 20170801*/
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    if(NULL != p_response)
    {
        at_response_free(p_response);
        p_response = NULL;
    }
}
/*end:modified by lisf for get operator 20181208*/
/**
 *called by setupDataCallRASMode
 *
 * rerurn 0 for success
 * return 1 for failure
 */
static int isReadyForConnetion()
{
    return 1;
#if 0
#define SUCCESS 0
#define FAILURE 1
    ATResponse *p_response;
    int err;
    char *line;
    char *network_type;
    char *domain;

    err = at_send_command_singleline("AT+ZPAS?", "+ZPAS:", &p_response);
    if (err < 0 || p_response->success == 0)
    {
        goto error;
    }
    line = p_response->p_intermediates->line;

    /**
     * we expect response such as :
     * +ZPAS:"UMTS","CS_PS"
     * but sometimes it return
     * limited service
     */

    err = at_tok_start(&line);
    if (err < 0)
    {
        goto error;
    }

    err = at_tok_nextstr(&line,&network_type);
    if (err < 0)
    {
        goto error;
    }
    RLOGD("********network_type:%s********",network_type);

    if(at_tok_hasmore(&line))

    {
        err = at_tok_nextstr(&line,&domain);

        if (err < 0)
        {
            goto error;
        }
        RLOGD("********domain:%s********",domain);

        if(!strcmp(domain,"CS_PS") || !strcmp(domain,"PS_ONLY") || !strcmp(domain,"cs_ps") || !strcmp(domain,"ps_only"))
        {
            return SUCCESS;
        }
        else
        {
            return FAILURE;
        }

    }
    else
    {
        return FAILURE;
    }

error:

    RLOGD("********isReadyForConnetion() error happened********");
    return FAILURE;
#endif
}

//<!-- build 32/64 by caogang@20171025
#ifndef ODM_ARM64
//replace system func
extern char **environ;
int ril_exec_cmd(const char *command)
{
    pid_t pid;
    sig_t intsave, quitsave;
    sigset_t mask, omask;
    int pstat = -1;
    /*Begin DTS2013101000098  wujiacheng  2013-10-10 for modified*/
    char buffer[1024] = {0};
    /*End DTS2013101000098  wujiacheng  2013-10-10 for modified*/
    char *argp[32] = {0};
    char *next = buffer;
    char *tmp = NULL;
    int i = 0;

    if (!command)
        return 1;

    if (strnlen(command, sizeof(buffer) - 1) == sizeof(buffer) - 1) {
        RLOGD("command line too long while processing: %s", command);
        return -1;
    }

    strcpy(buffer, command); // Command len is already checked.
    while ((tmp = strsep(&next, " "))) {
        if(0 == strlen(tmp))
        {
            continue;
        }
        argp[i++] = tmp;
        if (i == 32) {
            RLOGD("argument overflow while processing: %s", command);
            return -1;
        }
    }
    argp[i] = NULL;

    sigemptyset(&mask);
    sigaddset(&mask, SIGCHLD);
    sigprocmask(SIG_BLOCK, &mask, &omask);
    switch (pid = vfork())
    {
        case -1:                        /* error */
            sigprocmask(SIG_SETMASK, &omask, NULL);
            return(-1);
        case 0:                                 /* child */
            sigprocmask(SIG_SETMASK, &omask, NULL);
            execve(argp[0], argp, environ);
            _exit(127);
    }

    intsave = (sig_t)  bsd_signal(SIGINT, SIG_IGN);
    quitsave = (sig_t) bsd_signal(SIGQUIT, SIG_IGN);
    pid = waitpid(pid, (int *)&pstat, 0);
    sigprocmask(SIG_SETMASK, &omask, NULL);
    (void)bsd_signal(SIGINT, intsave);
    (void)bsd_signal(SIGQUIT, quitsave);
    return (pid == -1 ? -1 : pstat);
}
#endif //ODM_ARM64
//end -->

/**
 * called by requestSetupDataCall
 *
 * return 0 for success
 * return 1 for error;
 */
static int setupDataCallDefault(const char* apn)
{
#define SUCCESS 0
#define ERROR 1
    int fd, qmistatus;
    size_t cur = 0;
    size_t len;
    ssize_t written, rlen;
    char status[32] = {0};
    int retry = 10;
    char *cmd;
    ATResponse *p_response = NULL;

    int err = 0;

    fd = open ("/dev/qmi", O_RDWR);
    if (fd >= 0)   /* the device doesn't exist on the emulator */
    {

        RLOGD("opened the qmi device\n");
        asprintf(&cmd, "up:%s", apn);
        len = strlen(cmd);

        while (cur < len)
        {
            do
            {
                written = write (fd, cmd + cur, len - cur);
            }
            while (written < 0 && errno == EINTR);

            if (written < 0)
            {
                RLOGD("### ERROR writing to /dev/qmi");
                close(fd);
                goto error;
            }

            cur += written;
        }
        // wait for interface to come online
        do
        {
            sleep(1);
            do
            {
                rlen = read(fd, status, 31);
            }
            while (rlen < 0 && errno == EINTR);

            if (rlen < 0)
            {
                RLOGD("### ERROR reading from /dev/qmi");
                close(fd);
                goto error;
            }
            else
            {
                status[rlen] = '\0';
                RLOGD("### status: %s", status);
            }
        }
        while (strncmp(status, "STATE=up", 8) && strcmp(status, "online") && --retry);

        close(fd);

        if (retry == 0)
        {
            RLOGD("### Failed to get data connection up\n");
            goto error;
        }

        qmistatus = system("netcfg rmnet0 dhcp");

        RLOGD("netcfg rmnet0 dhcp: status %d\n", qmistatus);

        if (qmistatus < 0) goto error;

    }
    else
    {
        asprintf(&cmd, "AT+CGDCONT=%d,\"IP\",\"%s\",,0,0", cus_cid, apn);
        //FIXME check for error here
        err = at_send_command(cmd, NULL);
        free(cmd);

        // Set required QoS params to default
        err = at_send_command("AT+CGQREQ=1", NULL);

        // Set minimum QoS params to default
        err = at_send_command("AT+CGQMIN=1", NULL);

        // packet-domain event reporting
        err = at_send_command("AT+CGEREP=2,1", NULL);

        // Hangup anything that's happening there now
        err = at_send_command("AT+CGACT=1,0", NULL);

        // Start data on PDP context 1
        err = at_send_command("ATD*99***1#", &p_response);

        if (err < 0 || p_response->success == 0)
        {
            goto error;
        }
    }
    at_response_free(p_response);
    return SUCCESS;
error:
    at_response_free(p_response);
    return ERROR;
}
//added by lisf for get pid 20181210
int get_pid(char *name)
{
    char cmd[20] = { 0 };
    char szbuf[100] = { 0 };
    char *p_pid = NULL;
    FILE *pFile = NULL;
    int pid = 0;

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        sprintf(cmd, "ps  -e| grep %s", name);
    }
    else
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        sprintf(cmd, "ps | grep %s", name);
    }

#if 0
/* BEGIN: Modified by eric.li, 2018/12/28   PN:0015062 */
/*Begin: [NA] Moded by liuqifeng fixed kill pppd or dhcp failed in android6.0 system 20170814*/
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
	sprintf(cmd, "ps  -e| grep %s", name);
#else
	sprintf(cmd, "ps | grep %s", name);
#endif
/*End  : [NA] Moded by liuqifeng fixed kill pppd or dhcp failed in android6.0 system 20170814*/
/* END:   Modified by eric.li, 2018/12/28   PN:0015062 */
#endif

    pFile = popen(cmd, "r");
    if (pFile != NULL) {
        while (fgets(szbuf, sizeof(szbuf), pFile)) {
            if (strstr(szbuf, name)) {
                p_pid = strstr(szbuf, " ");
                if(p_pid!=NULL)
                {
                    pid = strtoul(p_pid, NULL, 10);
                }
                RLOGD("--- PPPD PID = %d ---", pid);
                break;
            }
        }
        pclose(pFile);
    }

    pclose(pFile);
    return pid;
}
//added by lisf for kill pppd 20181210
void ril_kill_pppd(int flag)
{
    int pppd_pid ;
    //= get_pid("pppd");
    int count = 50;

 while(--count >= 0)
    {
        pppd_pid = get_pid("pppd");
        if (pppd_pid)
        {
            if(1 == flag && count > 45)
            {
                kill(pppd_pid, SIGTERM);
            }
            else
            {
                kill(pppd_pid, SIGKILL);
            }
            sleep(1);
        }
        else
        {
            break;
        }
    }
    pppd_pid = get_pid("pppd");
    RLOGD("pppd is %d , killed %d times", pppd_pid, 50-count);
}

static int dial_at_modem(int fd)
{
    int readlen = 0;
    char pch[129] = { 0 };
    time_t readtime;
    const char *match_msg = "CONNECT";
    const char *match_err_msg = "NO CARRIER";
    const char *match_err_msg_2 = "ERROR";
    time_t gettime;
    int  cur, i;
    i = 0;
    cur = 0;

    // disable echo on serial lines and set a 10 second timeout
    RLOGD("modem : read");
    readtime = time(&gettime);
    // <!--[ODM]wangmengying@2019.8.16 [SN-20190712001,SN-20190608001]optimization ppp time
    while ((time(&gettime) - readtime) <= 3)
    // end-->
	{
        readlen = read(fd, pch, 64);
        if (readlen <= 0 &&( errno == EINTR ||errno == EAGAIN)) {
          //  RLOGD("read none");
	     //sleep(1);
            continue;
        } else if (readlen > 0) {
            pch[readlen] = '\0';
	     RLOGD("====== read from modem:readlen,%d=======", readlen);
            RLOGD("====== read from modem:%s=======", pch);
            if (strstr(pch, match_msg)) {
                RLOGD("read CONNECT");
                return 0;
            } else if (strstr(pch, match_err_msg)) {
                RLOGD("read NO CARRIER");
                return AT_ERROR_GENERIC;
            }
            else if(strstr(pch, match_err_msg_2))
            {
                RLOGD("read ERROR");
                return AT_ERROR_GENERIC;
            }
        }
    }
    RLOGD("dial_at_modem return");
    return 1;
}

/**
 * called by requestSetupDataCall
 *
 * return 0 for success
 * return 1 for error;
 * return 2 for ppp_error;
 */
static int setupDataCallRASMode(char**response_local_ip,const char* apn,const char* auth_type,const char* username,const  char* password,const char* pdp_type)
{
    #define SUCCESS 0
    #define ERROR 1
    #define PPP_ERROR 2

    int fd;
    char buffer[20];
    char exit_code[PROPERTY_VALUE_MAX]={0};
    char local_ip[PROPERTY_VALUE_MAX]={0};
    char local_pdns[PROPERTY_VALUE_MAX]={0};
    char local_sdns[PROPERTY_VALUE_MAX]={0};

    char gw[PROPERTY_VALUE_MAX]={0};
    char remote_ip[PROPERTY_VALUE_MAX]={0};

    int retry = POLL_PPP_SYSFS_RETRY;
    char apntype[PROPERTY_VALUE_MAX];
    ATResponse *p_response = NULL;
    int err = 0;
    char*cmd =NULL;
    char*line =NULL;
    /*begin:added by for NL678 ppp dial 20190129*/
    char *pppd_cmd = NULL ; 

    int network_type = 0;
    char datachannel[PROPERTY_VALUE_MAX]={0};

    RLOGD("******** Enter setupDataCallRASMode ********");

    property_get("ril.datachannel",datachannel,"");

// <!--added by wangmengying@2020.2.27 add CGPIAF set IPV6 address format
    err = at_send_command_singleline("AT+CGPIAF?", "+CGPIAF:", &p_response);
    if (err < 0 || p_response->success == 0)
    {
        RLOGD("Not support this command!!!");
    }
    else
    {
        line = p_response->p_intermediates->line;
        at_tok_start(&line);
        at_tok_nextint(&line,&format_ip);
    }

    at_response_free(p_response);
    p_response = NULL;

    network_type = odm_get_current_network_type();

    pppd = 0;//added by lisf for debug 20190131
    if(get_pid("pppd"))
    {
        err = at_send_command("ATH", NULL);
        property_set("ctl.stop", SERVICE_PPPD_GPRS);

        if(ANDROID_5 != Ght_Android_Version)
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d != 5 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            ril_kill_pppd(0);
        }

#if 0
        /*begin:modified for android5x , don't kill pppd by lisf 20181221*/
        #ifndef GHT_FEATURE_ANDROID5X
        ril_kill_pppd(0);
        #endif
        /*end:modified for android5x , don't kill pppd by lisf 20181221*/
#endif
    }

    g_apn_pdptype = odm_get_pdptype(pdp_type);

    getSetAPN(cus_cid, pdp_type, apn);

    if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
    {
        if((username != NULL) && (password != NULL))
        {
            if (mode_flag < GHT_NL668)
            {
                asprintf(&cmd, "AT^PPPCFG=\"%s\",\"%s\"", username, password);
                err = at_send_command(cmd, NULL);
                free(cmd);
            }
        }
    }

    if((username != NULL) && (password != NULL))
    {
        if ((0 != strlen(username)) || (0 != strlen(password)))
        {
            if (mode_flag < GHT_NL668)
            {
                asprintf(&cmd, "AT$QCPDPP=1,%s,\"%s\",\"%s\"", auth_type, password, username);
            }
            else
            {
                asprintf(&cmd, "AT+MGAUTH=1,%s,\"%s\",\"%s\"",auth_type,username,password);
            }
            err = at_send_command(cmd, NULL);
            free(cmd);

            property_set("net.ppp0.user", username);
            property_set("net.ppp0.password", password);
        }
    }

    property_set(PROPERTY_PPPD_EXIT_CODE, "");

    RLOGD("[%s,%d]script_type:%d, ppp_fd:%d", __FUNCTION__, __LINE__, script_type, ppp_fd);
    if(0 == script_type)
    {
        do
        {
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }

        /*begin:modified for NL678-E ppp dial 20190129*/
        if(mode_flag  <= GHT_NL678_E || mode_flag == GHT_L716)
        {
            ppp_fd = open(datachannel, O_RDWR | O_NONBLOCK | O_NOCTTY);
        }
        else
        {
                 ppp_fd = open(datachannel, O_RDWR);
        }
        /*end:modified for NL678-E ppp dial 20190129*/

        if (ppp_fd > 0)
        {
            struct termios ios;

            tcgetattr(ppp_fd, &ios);
            ios.c_lflag = 0;

            /*begin:added for NL678-E ppp dial 20190129*/
            if(mode_flag  <= GHT_NL678_E|| mode_flag == GHT_L716)
            {
                ios.c_oflag &= (~ONLCR);
                ios.c_iflag &= (~(ICRNL | INLCR));
                ios.c_iflag |= (IGNCR | IXOFF);
                ios.c_cc[VTIME] = 10;
                ios.c_cc[VMIN] = 0;
            }
            /*end:added for NL678-E ppp dial 20190129*/
            tcsetattr(ppp_fd, TCSANOW, &ios);
            tcflush(ppp_fd, TCIOFLUSH);

            //network_type = odm_get_current_network_type();
            if(!network_type)
            {
                RLOGD("No service,can not setup data call");
                if(ppp_fd > 0)
                {
                    close(ppp_fd);
                    ppp_fd = -1;
                }
                goto error;
            }
            else if(6 == network_type || 7 ==network_type || 13 ==network_type)
            {
                /*begin:added by lisf for switch cdma & evdo*/
                if(GHT_MDM_NORMAL == mode_flag)
                {
                    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse( RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED, NULL, 0);  //added by lisf 20190323
                }
                err = at_send_command_dial(ppp_fd, "ATD#777");
            }
            else
            {
                err = at_send_command_dial(ppp_fd, "ATD*99#");
            }

            if(mode_flag  <= GHT_NL678_E || mode_flag == GHT_L716)
            {
                err = dial_at_modem(ppp_fd);
                if(err < 0 || err ==1)
                {
                    RLOGD("send dial command failed!");
                    close(ppp_fd);
                    ppp_fd = -1;
                }
                else
               {
                    break;
               }
            }
            else
            {
                if (err < 0 && mode_flag  != GHT_NL678_E)
                {
                    RLOGD("send dial command failed!");
                    close(ppp_fd);
                     ppp_fd = -1;
                }
                break;
            }
        }
        else
        {
            close(ppp_fd);
            ppp_fd = -1;
            RLOGD("retry %d after %d seconds", retry, POLL_PPP_SYSFS_SECONDS);
            sleep(POLL_PPP_SYSFS_SECONDS);
        }
        }while(--retry);

        if ((ppp_fd < 0) && (retry == 0))
        {
            close(ppp_fd);
            ppp_fd = -1;
            RLOGD("open ppp_fd fail!");

            /* BEGIN: Added by eric.li, 2019/2/1   PN:fix exception with ppp dial in modem */
            err = at_send_command("ATH", NULL);
            RLOGD("ppp dial  force hang up in case exception");
            /* END:   Added by eric.li, 2019/2/1   PN:fix exception with ppp dial in modem */

            goto error;
        }

        if(!network_type)
        {
            RLOGD("No service,can not setup data call");
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }
            goto error;
        }
        else if(6 == network_type || 7 ==network_type || 13 ==network_type)
        {
            if (0 == strcmp(auth_type,"1"))
            {
                /* BEGIN: Modified by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
                if (PDP_IPV4V6 == g_apn_pdptype || PDP_IPV6 == g_apn_pdptype)
                {
                    asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns noipdefault debug ipcp-accept-local ipcp-accept-remote defaultroute -chap +ipv6 ipv6cp-use-ipaddr",datachannel,username,password);
                }
                else
                {
                    asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns noipdefault debug ipcp-accept-local ipcp-accept-remote defaultroute -chap ",datachannel,username,password);
                }
                /* END:   Modified by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
            }
            else
            {
                /* BEGIN: Modified by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
                if (PDP_IPV4V6 == g_apn_pdptype || PDP_IPV6 == g_apn_pdptype)
                {
                    asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns  noipdefault debug ipcp-accept-local ipcp-accept-remote defaultroute +ipv6 ipv6cp-use-ipaddr",datachannel,username,password);
                }
                else
                {
                    asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns  noipdefault debug ipcp-accept-local ipcp-accept-remote defaultroute",datachannel,username,password);
                }
                /* END:   Modified by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
            }
        }
        else
        {
            //modify by zhengjianrong for IPV4V6 switch to IPV6 issue 20190528 begin
            if(PDP_IPV6 == g_apn_pdptype || PDP_IPV4V6 == g_apn_pdptype || PDP_IPV4 == g_apn_pdptype)
            {
                property_set("net.ppp0.gw", "");
            }
            //modify by zhengjianrong for IPV4V6 switch to IPV6 issue 20190528 end

            if((username != NULL) && (password != NULL))
            {
                /* BEGIN: Modified by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
                if (PDP_IPV4V6 == g_apn_pdptype || PDP_IPV6 == g_apn_pdptype)
                {
                  asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns noipdefault debug ipcp-accept-local ipcp-accept-remote defaultroute +ipv6 ipv6cp-use-ipaddr",datachannel,username,password);
                }
                else
                {
                  asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns noipdefault debug ipcp-accept-local ipcp-accept-remote defaultroute",datachannel,username,password);
                }
                /* END:   Modified by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
            }
            else
            {
                /* BEGIN: Modified by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
                if (PDP_IPV4V6 == g_apn_pdptype || PDP_IPV6 == g_apn_pdptype)
                {
                  asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts usepeerdns noipdefault debug ipcp-accept-local ipcp-accept-remote defaultroute +ipv6 ipv6cp-use-ipaddr",datachannel);
                }
                else
                {
                  asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts usepeerdns noipdefault debug ipcp-accept-local ipcp-accept-remote defaultroute",datachannel);
                }
                /* END:   Modified by eric.li, 2019/1/28   PN:solve issue 0016245 that support IPV4V6 */
            }
        }
        RLOGD("%s",cmd);
        system(cmd);

        /*begin: modified for NL678-E ppp dial by lisf 20190111*/
        if(mode_flag  == GHT_NL678_E)
        {
            asprintf(&pppd_cmd,"%s",cmd); 
        }
        /*end: modified for NL678-E ppp dial by lisf 20190111*/

        gPid_pppd_live = get_pid("pppd");
        RLOGD(" gPid_pppd_died[%d], gPid_pppd_live[%d]", gPid_pppd_died, gPid_pppd_live);
        if (gPid_pppd_died  == gPid_pppd_live)
        {
            RLOGD("!!!!!!!!!!!pppd call failed as kill pppd failed!");
        }
        free(cmd);
    }
    else if(1 == script_type)
    {
        do
        {
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }

            ppp_fd = open(datachannel, O_RDWR);
            if (ppp_fd > 0)
            {
                struct termios ios;
                tcgetattr(ppp_fd, &ios);
                ios.c_lflag = 0;
                tcsetattr(ppp_fd, TCSANOW, &ios);
                tcflush(ppp_fd, TCIOFLUSH);

                //network_type = odm_get_current_network_type();
                if(!network_type)
                {
                    RLOGD("No service,can not setup data call");
                    if(ppp_fd > 0)
                    {
                        close(ppp_fd);
                        ppp_fd = -1;
                    }
                    goto error;
                }
                else if(6 == network_type || 7 ==network_type || 13 ==network_type)
                {
                    err = at_send_command_dial(ppp_fd, "ATD#777");
                }
                else
                {
                    err = at_send_command_dial(ppp_fd, "ATD*99#");
                }

                if (err < 0)
                {
                    RLOGD("send dial command failed!");
                }
                break;
            }
            else
            {
                close(ppp_fd);
                ppp_fd = -1;
                RLOGD("retry %d after %d seconds", retry, POLL_PPP_SYSFS_SECONDS);
                sleep(POLL_PPP_SYSFS_SECONDS);
            }
        }while(--retry);

        if ((ppp_fd < 0) && (retry == 0))
        {
            RLOGD("open ppp_fd fail!");
            goto error;
        }

        retry = POLL_PPP_SYSFS_RETRY;
        property_set(PROPERTY_PPPD_EXIT_CODE, "");
        err = property_set("ctl.start", SERVICE_PPPD_GPRS);
        if (err < 0)
        {
            RLOGD("Can not start PPPd");
            goto error;
        }
    }
    else if(2 == script_type)
    {
        if(!network_type)
        {
            RLOGD("No service,can not setup data call");
            goto error;
        }

        err = property_set("ctl.start", SERVICE_PPPD_GPRS);
        if (err < 0)
        {
            RLOGD("Can not start use modem to connect internet\n");
            goto ppp_error;
        }
    }
    else if(3 == script_type)
    {
        if(!network_type)
        {
            RLOGD("No service,can not setup data call");
            goto error;
        }
        property_set("net.gprs.enable", "1");
        err = property_set("ctl.start", SERVICE_PPPD_GPRS);
    }

    RLOGD("[%s,%d] g_apn_pdptype:%d", __FUNCTION__, __LINE__, g_apn_pdptype);
    sleep(3);
    pppd = 1;

    if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
    {
        retry = 15;
    }
    else
    {
        retry = 3;
    }

    if (PDP_IPV6 == g_apn_pdptype || PDP_IPV4V6 == g_apn_pdptype)
    {
        if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
        {
            sleep(5);
        }
        if (6 == network_type || 7 ==network_type || 13 ==network_type)
        {
            RLOGD("Not support 3GPP2");
        }
        else
        {
            rilInitIPV6();
        }
    }

    do
    {
        property_get(PROPERTY_PPPD_EXIT_CODE, exit_code, "");
        if(strcmp(exit_code, "") != 0)
        {
            RLOGD("PPPd exit with code %s", exit_code);
            retry = 0;
            break;
        }

        fd  = open(PPP_OPERSTATE_PATH, O_RDONLY);
        if (fd >= 0)
        {
            buffer[0] = 0;
            memset(buffer,0,sizeof(buffer)) ;//added by lisf for debug 20181219
            read(fd, buffer, sizeof(buffer));
            close(fd);

            if(!strncmp(buffer, "up", strlen("up")) || !strncmp(buffer, "unknown", strlen("unknown")))
            {
                local_ip[0] = 0;

                property_get("net.ppp0.local-ip", local_ip, "");
                property_get("net.ppp0.dns1", local_pdns, "");
                property_get("net.ppp0.dns2", local_sdns, "");
                property_get("net.ppp0.gw", gw, "");
                property_get("net.ppp0.remote-ip", remote_ip, "");

                RLOGD("local_pdns:%s",local_pdns);
                RLOGD("local_sdns:%s",local_sdns);
                RLOGD("local_ip:%s",local_ip);
                RLOGD("remote_ip:%s",remote_ip);
                RLOGD("gw:%s",gw);

                if ((!strcmp(apntype, "mms")))
                {
                    if((!strcmp(local_ip, "")))
                    {
                        RLOGD("PPP link is up but no local IP is assigned. Will retry %d times after %d seconds", \
                                retry, POLL_PPP_SYSFS_SECONDS);
                    }
                    else
                    {
                        RLOGD("PPP link is up with local IP address %s", local_ip);
                        *response_local_ip = local_ip;
                        break;
                    }
                }
                else
                {
                    if((!strcmp(local_ip, "")) || (!strcmp(local_ip, "0.0.0.0")))
                    {
                        RLOGD("PPP link is up but no local IP is assigned. Will retry %d times after %d seconds", \
                                    retry, POLL_PPP_SYSFS_SECONDS);
                    }
                    else
                    {
                        RLOGD("PPP link is up with local IP address %s", local_ip);
                        *response_local_ip = local_ip;
                        // now we think PPPd is ready
                        break;
                    }
                }
            }
            else
            {
                RLOGD("PPP link status in %s is %s. Will retry %d times", \
                        PPP_OPERSTATE_PATH, buffer, retry);

                asprintf(&cmd, "/system/bin/ifconfig ppp0 up");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);
            }
        }
        else
        {
            RLOGD("Can not detect PPP state,PPPD PID %d ",get_pid("pppd"));
            RLOGD("Can not detect PPP state in %s. Will retry %d times after %d seconds", \
                    PPP_OPERSTATE_PATH, retry, POLL_PPP_SYSFS_SECONDS);

            /*begin: modified for NL678-E ppp dial by lisf 20190111*/
            if( mode_flag == GHT_NL678_E)
            {
                if(!get_pid("pppd"))
                {
                    pppd = 0;
                    system(pppd_cmd);
                    retry = 3;
                    pppd =1 ;
                    free(pppd_cmd);
                    pppd_cmd = NULL;
                }
            }
           /*end: modified for NL678-E ppp dial by lisf 20190111*/
        }

        sleep(POLL_PPP_SYSFS_SECONDS-1);
    }while (--retry);

    if(retry == 0)
    {
        goto ppp_error;
    }

    close(ppp_fd);
    ppp_fd = -1;
    if(pppd_cmd)
    {
        free(pppd_cmd);
        pppd_cmd = NULL;
    }

    at_response_free(p_response);
    return SUCCESS;
error:
    close(ppp_fd);
    ppp_fd = -1;
    if(pppd_cmd)
    {
	free(pppd_cmd);
	pppd_cmd = NULL;
    }

    at_response_free(p_response);
    return ERROR;
ppp_error:
    close(ppp_fd);
    ppp_fd = -1;
	
    if(pppd_cmd)
    {
	free(pppd_cmd);
	pppd_cmd = NULL;
    }
    at_response_free(p_response);
    return PPP_ERROR;
}

/**
 * called by requestSetupDataCall
 *
 * return 0 for success
 * return 1 for error;
 * return 2 for ndis_error;
 */

static int setupDataCallNDISMode(char**response_local_ip,const char* apn,const char* auth_type,const char* username,const  char* password,const char* pdp_type)
{
#define SUCCESS 0
#define ERROR 1
#define NDIS_ERROR 2
#define RMNET_DIAL_TIME_OUT 75 

    int fd;
    int ret = 0;
    char bufsrc[100]={0};
    char *bufdest;

    char buffer[20];
    static char local_ip[PROPERTY_VALUE_MAX]={0};
    static char local_pdns[PROPERTY_VALUE_MAX]={0};
    static char local_sdns[PROPERTY_VALUE_MAX]={0};
    static char kernel_version[PROPERTY_VALUE_MAX]={0};
    int retry = POLL_NDIS_SYSFS_RETRY;
    char apntype[PROPERTY_VALUE_MAX];
    ATResponse *p_response = NULL;
    int err = 0;
    char*cmd;
    char *gw_ndis = (char *)calloc(PROPERTY_VALUE_MAX, sizeof(char));
    char local_gateway[PROPERTY_VALUE_MAX]={0};
    long secTime;
    struct timeval beginTime, endTime;
    gettimeofday(&beginTime, NULL);

    int network_type = 0;
    network_type = odm_get_current_network_type();

    RLOGD("******** Enter setupDataCallNDISMode ********");

    err = at_send_command_timeout("AT$QCRMCALL=0,1",NULL, ATSEND_TIMEOUT_MSEC*4+5000);

    if(!network_type)
    {
        RLOGD("No service,can not setup data call");
        goto error;
    }

    if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
    {
         /*begin:added by lisf for switch cdma & evdo*/
        if(GHT_MDM_NORMAL == mode_flag)
        {
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse( RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED, NULL, 0);  //added by lisf 20190323
        }
         /*end:added by lisf for switch cdma & evdo*/
        if((username != NULL) && (password != NULL))
        {
            if (mode_flag < GHT_NL668)
            {
                asprintf(&cmd, "AT^PPPCFG=\"%s\",\"%s\"", username, password);
                err = at_send_command(cmd, NULL);
                free(cmd);
            }
        }
    }

    if((username != NULL) && (password != NULL))
    {
        if ((0 != strlen(username)) || (0 != strlen(password)))
        {
          if (mode_flag < GHT_NL668)
          {
              asprintf(&cmd, "AT$QCPDPP=1,%s,\"%s\",\"%s\"", auth_type, password, username);
          }
          else
          {
              asprintf(&cmd, "AT+MGAUTH=1,%s,\"%s\",\"%s\"",auth_type,username,password);
          }
          err = at_send_command(cmd, NULL);
          free(cmd);
        }
    }

    if(mode_flag == GHT_NL678_E)
    {
        //weak up ndis_do_dhcp_pthread
        pthread_mutex_lock(&s_ndismutex);
        pthread_cond_broadcast (&s_ndiscond);
        pthread_mutex_unlock(&s_ndismutex);
    }
    do
    {
        network_type = odm_get_current_network_type();
        if(6 == network_type || 7 ==network_type || 13 ==network_type)
        {
            if (GHT_NL660 == mode_flag)
            {
                if (0 == strcmp(auth_type,"1"))
                {
                    asprintf(&cmd, "AT+NETCFG=1,2,\"%s\",\"%s\",\"%s\",\"%s\",\"PAP\"",apn,pdp_type,username,password);
                }
                else
                {
                    asprintf(&cmd, "AT+NETCFG=1,2,\"%s\",\"%s\",\"%s\",\"%s\",\"PAP_CHAP\"",apn,pdp_type,username,password);
                }
                err = at_send_command(cmd, NULL);
                free(cmd);
                err = at_send_command_singleline_timeout("AT$QCRMCALL=1,1,1,1,,101", "$QCRMCALL:", ODM_RMNET_CALL_TIME_OUT, &p_response);
            }
            else if((mode_flag >= GHT_NL668) && (mode_flag <= GHT_NL678_E))
            {
                asprintf(&cmd, "AT+MGAUTH=1,%s,\"%s\",\"%s\"",auth_type,username,password);
                err = at_send_command(cmd, NULL);
                free(cmd);
                err = at_send_command_singleline_timeout("AT$QCRMCALL=1,1", "$QCRMCALL:", ODM_RMNET_CALL_TIME_OUT, &p_response);
            }
            else
            {
                    if (0 == strcmp(auth_type,"1"))
                    {
                        asprintf(&cmd, "AT+EHRPDINFO=1,101,\"APN_String:%s;PDN_Label:internet;PDN_IP_Version:IPV4V6;RAN_Type:HRPD_EHRPD;PDN_Level_Auth_Protocol:PAP;PDN_Level_Auth_User_ID:%s;PDN_Level_Auth_Password:%s;\"",apn,username,password);
                        err = at_send_command(cmd, NULL);
                        free(cmd);

    					asprintf(&cmd, "AT+NETCFG=1,2,%s,%s,%s,%s,PAP",apn,pdp_type,username,password);
                        err = at_send_command(cmd, NULL);
                        free(cmd);
                    }
                    else
                    {
                        asprintf(&cmd, "AT+EHRPDINFO=1,101,\"APN_String:%s;PDN_Label:internet;PDN_IP_Version:IPV4V6;RAN_Type:HRPD_EHRPD;PDN_Level_Auth_Protocol:PAP_CHAP;PDN_Level_Auth_User_ID:%s;PDN_Level_Auth_Password:%s;\"",apn,username,password);
                        err = at_send_command(cmd, NULL);
                        free(cmd);

    					asprintf(&cmd, "AT+NETCFG=1,2,%s,%s,%s,%s,PAP_CHAP",apn,pdp_type,username,password);
                        err = at_send_command(cmd, NULL);
                        free(cmd);
                    }
                    
                    err = at_send_command_singleline_timeout("AT$QCRMCALL=1,1,1,1,,101", "$QCRMCALL:", ODM_RMNET_CALL_TIME_OUT, &p_response);
            }            
        }
        else
        {          
            #ifdef ODM_ARM64    //"ifconfig ..." for 64-bit and "busybox ifconfig ..." for 32-bit
            RLOGD("ODM_ARM64 has been defined!");
            asprintf(&cmd, "ifconfig usb0 up");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);
            sleep(1);
            #else
            asprintf(&cmd, "busybox ifconfig usb0 up");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);
            #endif
            if(PDP_IPV4 == g_apn_pdptype )
            {
                err = at_send_command_singleline_timeout("AT$QCRMCALL=1,1", "$QCRMCALL:", ODM_RMNET_CALL_TIME_OUT, &p_response);
                RLOGD("err=%d,p_response->sucess=%d",err,p_response->success);
                if (err != 0 || p_response->success == 0)
                {
                    RLOGD("IPV4 rmnet send dial command failed!");
                    goto error;
                }
                break;
            }
            else if(PDP_IPV6 == g_apn_pdptype )
            {
                err = at_send_command_singleline_timeout("AT$QCRMCALL=1,1,2", "$QCRMCALL:", ODM_RMNET_CALL_TIME_OUT, &p_response);
                RLOGD("err=%d,p_response->sucess=%d",err,p_response->success);
                if (err != 0 ||  p_response->success == 0)
                {
                    RLOGD("IPV6 rmnet send dial command failed!");
                    goto error;
                }
                break;
            }
            else
            {
                err = at_send_command_singleline_timeout("AT$QCRMCALL=1,1", "$QCRMCALL:", ODM_RMNET_CALL_TIME_OUT, &p_response);
                RLOGD("err=%d,p_response->sucess=%d",err,p_response->success);
                if (err != 0 || p_response->success == 0)
                {
                    RLOGD("IPV4 rmnet send dial command failed!");
                }
                else
                {
                    ipv4_dial_flag = true;
                    RLOGD("rmnet ipv4 dial sucess!");
                }
                err = at_send_command_singleline_timeout("AT$QCRMCALL=1,1,2", "$QCRMCALL:", ODM_RMNET_CALL_TIME_OUT, &p_response);
                RLOGD("err=%d,p_response->sucess=%d",err,p_response->success);
                if (err != 0 ||  p_response->success == 0)
                {
                    RLOGD("IPV6 rmnet send dial command failed!");
                }
                else
                {
                    ipv6_dial_flag = true;
                    RLOGD("rmnet ipv6 dial sucess!");
                }
                if(!ipv4_dial_flag && !ipv6_dial_flag)
                {
                    RLOGD("rmnet ipv4ipv6 send dial command failed!");
                    gettimeofday(&endTime, NULL);
                    secTime  = endTime.tv_sec - beginTime.tv_sec;
                    at_response_free(p_response);
                    if(secTime >= RMNET_DIAL_TIME_OUT)
                    {
                        RLOGD("rmnet dial failed and time out %d seconds, will reboot modem",secTime);
                        at_send_command("at+syscmd=\"reboot\"", NULL);
                    }
                    RLOGD("Dialling failed.Will redial in three seconds!");
                    sleep(3);
                    continue;
                }
                break;                
            }
        }
        
    }while(--retry);
    if(retry == 0)
    {
        RLOGD("Rmnet dial failed five times!!!!");
        goto error;
    }
#ifdef ODM_ARM64

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_9)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 9 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        asprintf(&cmd, "/system/bin/ip rule add from all lookup main pref 1");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);
    }

#if 0
#if defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID8X
/*    	asprintf(&cmd, "echo 1 > proc/sys/net/ipv4/ip_forward");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

		
        asprintf(&cmd, "/system/bin/ip route add default via 192.168.0.1");
        RLOGD("%s",cmd);
        system(cmd);
	    free(cmd);
*/
	    asprintf(&cmd, "/system/bin/ip rule add from all lookup main pref 1");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);
#endif
#endif

    if(PDP_IPV4 == g_apn_pdptype )
    {
        fibo_bring_up_interface_do_dhcp("usb0");
        fibo_get_ip("usb0", bufsrc);
        property_set("net.usb0.local-ip", bufsrc);
        get_gateway(&gw_ndis);
        RLOGD("gw_ndis [%s]", gw_ndis);
        strcpy(local_gateway, gw_ndis);
        free(gw_ndis);
        gw_ndis = NULL;
        property_set("net.usb0.gw", local_gateway);
    }
     else if( PDP_IPV4V6 == g_apn_pdptype)
    {
        fibo_bring_up_interface_do_dhcp("usb0");
        fibo_get_ip("usb0", bufsrc);
        property_set("net.usb0.local-ip", bufsrc);
        get_gateway(&gw_ndis);
        RLOGD("gw_ndis [%s]", gw_ndis);
        strcpy(local_gateway, gw_ndis);
        free(gw_ndis);
        gw_ndis = NULL;
        property_set("net.usb0.gw", local_gateway);
        err = rilInitIPV6();
        if (err < 0) 
            RLOGD("get IPV6 information failed");
    }
    else if(PDP_IPV6 == g_apn_pdptype )
    {
        fibo_get_ip("usb0", bufsrc);
        property_set("net.usb0.local-ip", bufsrc);
        err = rilInitIPV6();
        if (err < 0) 
            RLOGD("get IPV6 information failed");
        property_set("net.usb0.dns1", "2400:3200::1");
        property_set("net.usb0.dns2", "2400:3200:baba::1");
    }
    else
    {
        RLOGD("g_apn_pdptype error!");
        goto error;
    }
#else
    if(PDP_IPV4 == g_apn_pdptype )
    {
        property_get("odm.kernel.version", kernel_version, "");
        asprintf(&cmd, "busybox ifconfig usb0 mtu 1428");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

        RLOGD("@@kernel_version:%s",kernel_version);
        if (0 > strcmp(kernel_version, Kernel_Version))
        {
            if(!(mode_flag == GHT_NL678_E))
            {
                asprintf(&cmd, "busybox ifconfig usb0 up");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);
                asprintf(&cmd, "netcfg usb0 dhcp");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);
            }
            asprintf(&cmd, "ifconfig usb0 > /data/ODM_IP");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);

            fd = open("/data/ODM_IP", O_RDONLY);
            ret = read(fd, bufsrc, sizeof(bufsrc));
            close(fd);
        
            bufdest = strtok(bufsrc, " ");
            bufdest = strtok(NULL, " ");
            bufdest = strtok(NULL, " ");

            property_set("net.usb0.local-ip", bufdest);
        }
        else
        {
            asprintf(&cmd, "dhcptool usb0");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);
            asprintf(&cmd, "ifconfig usb0|grep \"inet addr:\"|cut -d\":\" -f2|cut -d\" \" -f1 > /data/ODM_IP");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);

            fd = open("/data/ODM_IP", O_RDONLY);
            ret = read(fd, bufsrc, sizeof(bufsrc));
            close(fd);
            property_set("net.usb0.local-ip", bufsrc);
        }
    }
    if((PDP_IPV4V6== g_apn_pdptype))
    {
        property_get("odm.kernel.version", kernel_version, "");
        asprintf(&cmd, "busybox ifconfig usb0 mtu 1428");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

        RLOGD("@@kernel_version:%s",kernel_version);
        if (0 > strcmp(kernel_version, Kernel_Version))
        {
            if(!(mode_flag == GHT_NL678_E))
            {
                asprintf(&cmd, "busybox ifconfig usb0 up");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);
                asprintf(&cmd, "netcfg usb0 dhcp");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);
            }
            asprintf(&cmd, "ifconfig usb0 > /data/ODM_IP");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);

            fd = open("/data/ODM_IP", O_RDONLY);
            ret = read(fd, bufsrc, sizeof(bufsrc));
            close(fd);
        
            bufdest = strtok(bufsrc, " ");
            bufdest = strtok(NULL, " ");
            bufdest = strtok(NULL, " ");

            property_set("net.usb0.local-ip", bufdest);
        }
        else
        {
            asprintf(&cmd, "dhcptool usb0");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);
            asprintf(&cmd, "ifconfig usb0|grep \"inet addr:\"|cut -d\":\" -f2|cut -d\" \" -f1 > /data/ODM_IP");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);

            fd = open("/data/ODM_IP", O_RDONLY);
            ret = read(fd, bufsrc, sizeof(bufsrc));
            close(fd);
            property_set("net.usb0.local-ip", bufsrc);
        }
        rilInitIPV6();
    }
    if (PDP_IPV6 == g_apn_pdptype )
    {
        rilInitIPV6();
    }
#endif	
    retry = POLL_NDIS_SYSFS_RETRY;
    do
    {   
        fd = open(NDIS_OPERSTATE_PATH, O_RDONLY);
        if (fd >= 0)
        {
            buffer[0] = 0;
            read(fd, buffer, sizeof(buffer));
            close(fd);
            if(!strncmp(buffer, "up", strlen("up")) || !strncmp(buffer, "unknown", strlen("unknown")))
            {
             
                local_ip[0] = 0;
                property_get("net.usb0.local-ip", local_ip, "");
                property_get("net.usb0.dns1", local_pdns, "");
                property_get("net.usb0.dns2", local_sdns, "");
                property_get("net.usb0.gw", local_gateway, "");

                RLOGD("local_pdns:%s",local_pdns);
                RLOGD("local_sdns:%s",local_sdns);
                RLOGD("local_ip:%s",local_ip);
                RLOGD("local_gateway:%s",local_gateway);

                 if((!strcmp(local_ip, "")) || (!strcmp(local_ip, "0.0.0.0")))
                {
                    strcpy(local_ip,bufsrc);
                    RLOGD("local_ipp:%s",local_ip);
                    property_set("net.usb0.local-ip", bufsrc);
                }
                if((!strcmp(local_pdns, "")) || (!strcmp(local_sdns, "")))
                {
                    char *pdns =  (char *)calloc(ODM_DNS_SIZE, sizeof(char));
                    char *sdns =  (char *)calloc(ODM_DNS_SIZE, sizeof(char));
                    err = odm_get_dns_gtdns(&pdns, &sdns);
                    //Because China unicom network has DNS issure so set up a default DNS when you can't get it from the network side
                    if((err < 0) && (ODM_CU_OPERATOR == cur_oper))
                    {
                        strcpy(pdns,"8.8.8.8");
                        strcpy(sdns,"114.114.114.114");
                    }

                    if(((0 == strcmp(pdp_type,"IPV4"))||(0 ==  strcmp(pdp_type,"IP"))) && (!strcmp(local_gateway, "")))
                    {
                        get_gateway(&gw_ndis);
                        RLOGD("gw_ndis  [%s]", gw_ndis);
                        strcpy(local_gateway, gw_ndis);
                        free(gw_ndis);
                        gw_ndis = NULL;
                        property_set("net.usb0.gw", local_gateway);
                    }

                    property_get("net.usb0.local-ip", local_ip, "");
                    property_get("net.usb0.dns1", local_pdns, "");
                    property_get("net.usb0.dns2", local_sdns, "");
                    property_get("net.usb0.gw", local_gateway, "");

                    RLOGD("local_pdns:%s",local_pdns);
                    RLOGD("local_sdns:%s",local_sdns);
                    RLOGD("local_ip:%s",local_ip);
                    RLOGD("local_gateway:%s",local_gateway);
                }
                if((!strcmp(local_ip, "")) || (!strcmp(local_ip, "0.0.0.0")))

                {
                    RLOGD("NDIS link is up but no local IP is assigned. Will retry %d times after %d seconds", \
                            retry, POLL_NDIS_SYSFS_SECONDS);
                }
                else
                {
                    RLOGD("NDIS link is up with local IP address %s", local_ip);
                    *response_local_ip = local_ip;
                    break;
                }
            }        
           else
            {
                RLOGD("NDIS link status in %s is %s. Will retry %d times", \
                        NDIS_OPERSTATE_PATH, buffer, retry);
            }
        }
        else
        {
            RLOGD("Can not detect NDIS state in %s. Will retry %d times after %d seconds", \
                    NDIS_OPERSTATE_PATH, retry-1, POLL_NDIS_SYSFS_SECONDS);
        }
        sleep(POLL_NDIS_SYSFS_SECONDS-1);
    
        }while(--retry);        

    if(retry == 0)
    {
        goto ndis_error;
    }

    at_response_free(p_response);
    return SUCCESS;
error:
    at_response_free(p_response);
    return ERROR;
ndis_error:
    at_response_free(p_response);
    return NDIS_ERROR;

}


void Get_NetProperties()
{
    RLOGD("***********Enter %s**********", __FUNCTION__);
    static char local_ip[PROPERTY_VALUE_MAX]={0};
    static char local_pdns[PROPERTY_VALUE_MAX]={0};
    static char local_sdns[PROPERTY_VALUE_MAX]={0};
    char gw[PROPERTY_VALUE_MAX]={0};

    if(cus_netifName_flag)
    {
        property_get(cus_local_ip, local_ip, "");
        property_get(cus_dns1, local_pdns, "");
        property_get(cus_dns2, local_sdns, "");
        property_get(cus_gw, gw, "");
    }
    else if (GHT_MA510_GL == mode_flag || eth1_interface == 1)
    {
        property_get("net.eth1.local-ip", local_ip, "");
        property_get("net.eth1.dns1", local_pdns, "");
        property_get("net.eth1.dns2", local_sdns, "");
        property_get("net.eth1.gw", gw, "");
    }
    else
    {
        property_get("net.usb0.local-ip", local_ip, "");
        property_get("net.usb0.dns1", local_pdns, "");
        property_get("net.usb0.dns2", local_sdns, "");
        property_get("net.usb0.gw", gw, "");
    }
    
    RLOGD("local_ip:%s",local_ip);
    RLOGD("local_pdns:%s",local_pdns);
    RLOGD("local_sdns:%s",local_sdns);
    RLOGD("gw:%s", gw);

    RLOGD("***********Leave %s**********", __FUNCTION__);
}

/**
 * called by requestSetupDataCall
 *
 * return 0 for success
 * return 1 for error;
 * return 2 for ppp_error;
 */
static int setupDataCallECMMode(char**response_local_ip,const char* apn,const char* auth_type,const char* username,const  char* password,const char* pdp_type)
{
#define SUCCESS 0
#define ERROR 1
#define NDIS_ERROR 2
    int fd;
    int ret = 0;
    int i = 0;
    int j = 0;
    int n = 1;
    char bufsrc[100]={0};
    char *bufdest;

    char buffer[20];
    char exit_code[PROPERTY_VALUE_MAX]={0};
    static char local_ip[PROPERTY_VALUE_MAX]={0};
    static char local_pdns[PROPERTY_VALUE_MAX]={0};
    static char local_sdns[PROPERTY_VALUE_MAX]={0};
    int retry = POLL_NDIS_SYSFS_SECONDS;
    int ready_for_connect = 0;
    int try_connect_numbers = 0;
    char apntype[PROPERTY_VALUE_MAX];
    ATResponse *p_response = NULL;
    int err = 0;
    char *cmd = NULL;

    int active=-1;
    char *line,*if_name;
    int network_type = 0;
    RIL_IPv6 ril_IPv6;

    RLOGD("******** Enter setupDataCallECMMode ********");

    if(mode_flag == GHT_L716)
    {
        asprintf(&cmd, "/system/bin/ip route del default dev %s", cus_netifName);
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

        asprintf(&cmd, "/system/bin/busybox ifconfig %s down", cus_netifName);
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

        ifc_init();
        ifc_up(cus_netifName);
        ifc_close();
    }
    network_type = odm_get_current_network_type();
    g_apn_pdptype = odm_get_pdptype(pdp_type);

#if 0
    asprintf(&cmd, "AT+GTRNDIS=0,%d", cus_cid);
    err = at_send_command_timeout(cmd,  &p_response, 30000);
    free(cmd);
    if (err < 0 || p_response->success == 0)
        RLOGD("No call,can not release data call");
#endif

    err = at_send_command_singleline("AT+GTRNDIS?", "+GTRNDIS:", &p_response);
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        at_tok_start(&line);
        at_tok_nextint(&line,&active);
        if (active == 1)
        {
            at_response_free(p_response);
            asprintf(&cmd, "AT+GTRNDIS=0,%d", cus_cid);
            err = at_send_command_timeout(cmd,  &p_response, 30000);
            free(cmd);
            if (err < 0 || p_response->success == 0)
                goto error;
        }
    }
    at_response_free(p_response);
    p_response = NULL;

    RLOGD("%s: ECM_NetifName:%s", __FUNCTION__, cus_netifName);

    if (0 == network_type)
    {
        RLOGD("No service,can not setup data call");
        goto error;
    }

    if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
    {
        if((username != NULL) && (password != NULL))
        {
            if (mode_flag < GHT_NL668)
            {
                asprintf(&cmd, "AT^PPPCFG=\"%s\",\"%s\"", username, password);
                err = at_send_command(cmd, NULL);
                free(cmd);
            }
        }
    }

    if((username != NULL) && (password != NULL))
    {
        if ((0 != strlen(username)) || (0 != strlen(password)))
        {
            if (mode_flag < GHT_NL668)
            {
                asprintf(&cmd, "AT$QCPDPP=1,%s,\"%s\",\"%s\"", auth_type, password, username);
            }
            else
            {
                asprintf(&cmd, "AT+MGAUTH=1,%s,\"%s\",\"%s\"",auth_type,username,password);
            }
            err = at_send_command(cmd, NULL);
            free(cmd);
        }
    }

    do {
        if(6 == network_type || 7 ==network_type || 13 ==network_type)
        {

            asprintf(&cmd, "AT+NETCFG=1,2,\"%s\",\"%s\",\"%s\",\"%s\",\"PAP_CHAP\"",apn,pdp_type,username,password);

            err = at_send_command(cmd, NULL);
            free(cmd);

            asprintf(&cmd, "AT+GTRNDIS=1,%d", cus_cid);
            err = at_send_command_timeout(cmd,&p_response,ODM_RMNET_CALL_TIME_OUT);
            free(cmd);
            if (err < 0 || p_response->success == 0)
            {
                goto error;
            }
        }
        else
        {
            getSetAPN(cus_cid, pdp_type, apn);

            asprintf(&cmd, "AT+GTRNDIS=1,%d", cus_cid);
            err = at_send_command_timeout(cmd,&p_response,ODM_RMNET_CALL_TIME_OUT);
            free(cmd);
            if (err < 0 || p_response->success == 0)
            {
                goto error;
            }
        }
        break;
    }while(--retry);

    if (retry == 0)
    {
        RLOGD("open ndis_fd fail!");
        goto error;
    }

    if(cus_netifName_flag)
    {
        ECM_NetifName = strdup(cus_netifName);
        ECM_local_ip  = strdup(cus_local_ip);
        ECM_dns1      = strdup(cus_dns1);
        ECM_dns2      = strdup(cus_dns2);
        ECM_operstate = strdup(cus_operstate);
    }
    else if (GHT_MA510_GL == mode_flag || eth1_interface == 1)
    {
        ECM_NetifName = strdup("eth1");
        ECM_local_ip  = strdup("net.eth1.local-ip");
        ECM_dns1      = strdup("net.eth1.dns1");
        ECM_dns2      = strdup("net.eth1.dns2");
        ECM_operstate = strdup(ECM_OPERSTATE_PATH);
    }
    else
    {
        ECM_NetifName = strdup("usb0");
        ECM_local_ip  = strdup("net.usb0.local-ip");
        ECM_dns1      = strdup("net.usb0.dns1");
        ECM_dns2      = strdup("net.usb0.dns2");
        ECM_operstate = strdup(NDIS_OPERSTATE_PATH);
    }

    asprintf(&cmd, "busybox ifconfig %s up", ECM_NetifName);
    RLOGD("%s",cmd);
    system(cmd);
    free(cmd);

#ifdef ODM_ARM64
#if 0
#if defined GHT_FEATURE_ANDROID7X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
/*

            asprintf(&cmd, "echo 1 > proc/sys/net/ipv4/ip_forward");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);

            asprintf(&cmd, "/system/bin/ip route add default via 192.168.0.1");
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);

            asprintf(&cmd, "/system/bin/ip rule add from all lookup main pref 1");   //Use this command only on 64-bit systems
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);
*/
#endif
#endif

    if(mode_flag == GHT_L716){
                asprintf(&cmd, "echo 1 > proc/sys/net/ipv4/ip_forward");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);

                asprintf(&cmd, "/system/bin/ip route add default via 192.168.0.1");
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);

                asprintf(&cmd, "/system/bin/ip rule add from all lookup main pref 1");   //Use this command only on 64-bit systems
                RLOGD("%s",cmd);
                system(cmd);
                free(cmd);
    }

    ret = fibo_bring_up_interface_do_dhcp(ECM_NetifName);
    if(ret)
    {
        RLOGE("Get DHCP info error.");
        //goto error;
    }

    ret = fibo_get_ip(ECM_NetifName, bufsrc);
    if(ret)
    {
        RLOGE("Get IP address error.");
        //goto error;
    }

    property_set(ECM_local_ip, bufsrc);

#else     //ARM32
    if (GHT_MA510_GL == mode_flag)
    {
        asprintf(&cmd, "netcfg eth1 dhcp");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

        asprintf(&cmd, "ifconfig eth1 > /data/ODM_IP");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

        fd = open("/data/ODM_IP", O_RDONLY);
        ret = read(fd, bufsrc, sizeof(bufsrc));
        close(fd);

        bufdest = strtok(bufsrc, " ");
        bufdest = strtok(NULL, " ");
        bufdest = strtok(NULL, " ");

        property_set("net.eth1.local-ip", bufdest);
    }
    else
    {
        asprintf(&cmd, "netcfg usb0 dhcp");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

        asprintf(&cmd, "ifconfig usb0 > /data/ODM_IP");
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

        fd = open("/data/ODM_IP", O_RDONLY);
        ret = read(fd, bufsrc, sizeof(bufsrc));
        close(fd);

        bufdest = strtok(bufsrc, " ");
        bufdest = strtok(NULL, " ");
        bufdest = strtok(NULL, " ");

        property_set("net.usb0.local-ip", bufdest);
    }
#endif //End: #ifdef ODM_ARM64

    if (PDP_IPV4 != g_apn_pdptype)
    {
        if (6 == network_type || 7 ==network_type || 13 ==network_type)
        {
            RLOGD("Not support 3GPP2");
        }
        else
        {
            ret = getIPV6Info(&ril_IPv6);
            if(ret)
            {
                RLOGD("getIPV6Info error!");
                goto error;
            }

            RLOGD("RIL IPV6 ipv6addr: [%s]",ril_IPv6.ipv6addr);
            RLOGD("RIL IPV6 ipv6gateway: [%s]",ril_IPv6.ipv6gateway);
            RLOGD("RIL IPV6 ipv6dns1: [%s]",ril_IPv6.ipv6dns1);
            RLOGD("RIL IPV6 ipv6dns2: [%s]",ril_IPv6.ipv6dns2);
            //Get_NetProperties();
            setIPv6(ril_IPv6);
        }
    }
    else
    {
        at_send_command_singleline("AT+GTRNDIS?", "+GTRNDIS:", NULL);
    }

    do
    {
        // Waitting for dhcpcd sucessfully

        fd = open(ECM_operstate, O_RDONLY);

        RLOGD("interface:%s",ECM_NetifName);

        if (fd >= 0)
        {
            RLOGD("open ecm_operstate_path ok");
            buffer[0] = 0;
            read(fd, buffer, sizeof(buffer));
            close(fd);
            if(!strncmp(buffer, "up", strlen("up")) || !strncmp(buffer, "unknown", strlen("unknown")))
            {
                local_ip[0] = 0;

                property_get(ECM_local_ip, local_ip, "");
                property_get(ECM_dns1, local_pdns, "");
                property_get(ECM_dns2, local_sdns, "");

                RLOGD("local_ip:%s",local_ip);
                RLOGD("local_pdns:%s",local_pdns);
                RLOGD("local_sdns:%s",local_sdns);

                if(GHT_MC919 == mode_flag)
                {
                    RLOGD("Manually add an sdns for MC919.");
                    property_set(ECM_dns2, "8.8.8.8");
                }

                if((!strcmp(local_ip, "")) || (!strcmp(local_ip, "0.0.0.0")) || (!strcmp(local_ip, "0:0:0:0"))  )
                {
                    RLOGD("ECM link is up but no local IP is assigned. Will retry %d times after %d seconds", \
                            retry, POLL_NDIS_SYSFS_SECONDS);
                }
                else
                {
                    RLOGD("ECM link is up with local IP address %s", local_ip);
                    *response_local_ip = local_ip;
                    break;
                }

            }
            else
            {
                RLOGD("ECM link status in /sys/class/net/%s/operstate is %s. Will retry %d times",ECM_NetifName, buffer, retry);
            }
        }
        else
        {
            RLOGD("Can not detect ECM state in/sys/class/net/%s/operstate. Will retry %d times after %d seconds",ECM_NetifName, retry-1, POLL_NDIS_SYSFS_SECONDS);
        }
        sleep(POLL_NDIS_SYSFS_SECONDS-1);
    }while(--retry);

    if(retry == 0)
    {
        goto ecm_error;
    }

    fibocom_pingflag = 1;     //Data dialing succeeded. Ping can begin!

    at_response_free(p_response);
    return SUCCESS;
error:
    at_response_free(p_response);
    return ERROR;
ecm_error:
    at_response_free(p_response);
    return NDIS_ERROR;
}

void get_cgdcont0()
{
    RLOGD("*********Enter %s***********", __FUNCTION__);
    char cgdcont0_char[PROPERTY_VALUE_MAX]  = {0};
    int ret;

    //0: Do not set APN for cid0
    //1: Set the APN for cid0
    ret = property_get("ril.fibocom.cgdcont0", cgdcont0_char, "");

    if(ret > MAX_CGDCONT0_PROPERTY_LENGTH)
    {
        RLOGD("[%s,%d]The length of the property:ril.fibocom.cgdcont0 is too long:%d, %d characters maximum allowed.", __FUNCTION__, __LINE__, ret, MAX_CGDCONT0_PROPERTY_LENGTH);
    }
    else if(ret > 0)
    {
        RLOGD("[%s,%d]get ril.fibocom.cgdcont0:%s, ret:%d", __FUNCTION__, __LINE__, cgdcont0_char, ret);
        cus_cgdcont0 = atoi(cgdcont0_char);
        if(cus_cgdcont0 == NEED_CGDCONT0_YES || cus_cgdcont0 == NEED_CGDCONT0_NO)
        {
            RLOGD("[%s,%d]cus_cgdcont0:%d", __FUNCTION__, __LINE__, cus_cgdcont0);
        }
        else
        {
            RLOGD("[%s,%d]cgdcont0:%d is expected to range from %d to %d", __FUNCTION__, __LINE__, cus_cgdcont0, NEED_CGDCONT0_NO, NEED_CGDCONT0_YES);
            cus_cgdcont0 = 0;
        }

    }
    else
    {
        RLOGD("[%s,%d]ril.fibocom.cgdcont0 property not set, ret:%d", __FUNCTION__, __LINE__, ret);
    }

    RLOGD("*********Leave %s***********", __FUNCTION__);

}


void get_Current_Apn(int target_cid, char *out_pdp_type, char *out_apn_name, char *out_ip_addr)
{
    ATResponse *p_response = NULL;
    ATLine *p_cur;
    int err;
    int n = 0;
    char *out;
    char *line;
    int cid;

    err = at_send_command_multiline ("AT+CGDCONT?", "+CGDCONT:", &p_response);
    if (err != 0 || p_response->success == 0) {
        RLOGD("%s,%d,err[%d]", __FUNCTION__,__LINE__,err);
        goto error;
    }

    for(p_cur = p_response->p_intermediates; p_cur !=NULL; p_cur = p_cur->p_next)
    {
        line = p_cur->line;

        //RLOGD("line:%s", line);
        err = at_tok_start(&line);
        if (err < 0)
            goto error;

        err = at_tok_nextint(&line, &cid);
        if (err < 0)
            goto error;

        if(cid != target_cid)
        {
            continue;
        }
        else
        {
            // apn type
            err = at_tok_nextstr(&line, &out);
            if (err < 0)
                goto error;
            if(out_pdp_type != NULL)
            {
                strcpy(out_pdp_type, out);
            }

            //apn name
            err = at_tok_nextstr(&line, &out);
            if (err < 0)
                goto error;
            if(out_apn_name != NULL)
            {
                strcpy(out_apn_name, out);
            }

            //ip address
            err = at_tok_nextstr(&line, &out);
            if (err < 0)
                goto error;
            if(out_ip_addr != NULL)
            {
                strcpy(out_ip_addr, out);
                RLOGD("[%s,%d]AT+CGDCONT: out:%s out_ip_addr:%s", __FUNCTION__, __LINE__, out, out_ip_addr);
            }

            break;
        }
    }

error:
    at_response_free(p_response);
    p_response = NULL;
    return;
}

int APNInfoChange(char *New_Pdp_Type, char *New_APN_Name, char *Old_PDP_type, char *Old_APN_Name)
{
    int ret = false;

    if(New_Pdp_Type == NULL && New_APN_Name == NULL)
    {
        RLOGD("New_Pdp_Type and New_APN_Name are empty, so the upper layer does not want to change the APN information");
        return ret;
    }

    RLOGD("[%s,%d]Old_PDP_type:%s, New_Pdp_Type:%s", __FUNCTION__, __LINE__, Old_PDP_type, New_Pdp_Type);
    RLOGD("[%s,%d]Old_APN_Name:%s, New_APN_Name:%s", __FUNCTION__, __LINE__, Old_APN_Name, New_APN_Name);

    if((0 != strcmp(Old_PDP_type, New_Pdp_Type)) || (0 != strcmp(Old_APN_Name, New_APN_Name)))
    {
        if(0 != strcmp(Old_PDP_type, New_Pdp_Type))
        {
            RLOGD("[%s,%d]pdp_type has been changed", __FUNCTION__, __LINE__);
        }

        if(0 != strcmp(Old_APN_Name, New_APN_Name))
        {
            RLOGD("[%s,%d]apn_name has been changed", __FUNCTION__, __LINE__);
        }

        ret = true;
    }

    return ret;
}

void getSetAPN(int cid, char *pdp_type, char *apn)
{
    int err;
    char *cmd = NULL;

    //Before setting the APN, obtain the current APN
    get_Current_Apn(cid, Cur_Pdp_Type, Cur_APN_Name, NULL);
    RLOGD("Current PDP_type:%s, Current APN_Name:%s, get cid:%d", Cur_Pdp_Type, Cur_APN_Name, cid);

    err = APNInfoChange(pdp_type, apn, Cur_Pdp_Type, Cur_APN_Name);
    RLOGD("APNInfoChange err:%d", err);
    
    if (err)            //We need to update the APN information
    {
        asprintf(&cmd, "AT+CGDCONT=%d,\"%s\",\"%s\"", cid, pdp_type, apn);
        at_send_command(cmd, NULL);
        free(cmd);

        strncpy(Cur_Pdp_Type,pdp_type,strlen(pdp_type));
        strncpy(Cur_APN_Name,apn,strlen(apn));
        g_apn_pdptype = odm_get_pdptype(Cur_Pdp_Type);

#if 0
        if (!(GHT_FG621 == mode_flag))
        {
            onDeactiveDataCallList();
            at_send_command("AT+CFUN=4", NULL);
            at_send_command("AT+CFUN=1", NULL);
        }
#endif
    }
}

void requestSetInitialAttachAPN(void *data, size_t datalen __unused, RIL_Token t)
{
    RLOGD("%s E", __FUNCTION__);
    /* compatibility code android-5.1 l710/h3x/l8x tangsh 2016.9.21 e */
    const char *apn =NULL;
    const char *user = NULL;
    const char *password = NULL;
    char *cmd = NULL;
    const char *pdp_type = NULL;
    const char *auth_type = NULL; //added by lisf 20190201
    int err = 0;

    apn = ((const char **)data)[0];
    pdp_type = ((const char **)data)[1];
    auth_type = ((const char **)data)[2]; // added by lisf 20190201
    user = ((const char **)data)[3];
    password = ((const char **)data)[4];
    RLOGD("[%s] apn:%s, pdp_type:%s", __FUNCTION__, apn, pdp_type);
    //RLOGD("debug : auth_type:%s, user:%s, password:%s",auth_type,user,password);

    if((apn != NULL) && (pdp_type!= NULL))
    {
        if(cus_cgdcont0 == NEED_CGDCONT0_YES)
        {
            char *cmd0 = NULL;

            asprintf(&cmd0, "AT+CGDCONT=0,\"%s\",\"%s\"", pdp_type, apn);
            at_send_command(cmd0, NULL);
            free(cmd0);
        }
        RLOGD("[%s] cur_oper:%d, g_cops_lte:%d", __FUNCTION__, cur_oper, g_cops_lte);

        getSetAPN(cus_cid, pdp_type, apn);
    }
    else
    {
        RLOGD("!!!apn, pdp_type parameters may be null Pointers");
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    //RLOGD("auth_type= '%s'(%d), username= '%s', password= '%s'",auth_type, auth_type, user,password);
    if(auth_type == NULL)
    {   // 0  Authentication protocol is not used (NONE)
        asprintf(&cmd, "AT+MGAUTH=1,0");
        at_send_command(cmd, NULL);
        free(cmd);
    }
    else if((user!= NULL) && (password!= NULL))
    {
        asprintf(&cmd, "AT+MGAUTH=1,%d,\"%s\",\"%s\"", auth_type, user, password);
        at_send_command(cmd, NULL);
        free(cmd);
    }
    else
    {
        RLOGD("!!!user,password  parameters may be null Pointers");
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

int get_Current_Usbmode()
{
    int err, responsenet;
    ATResponse *p_response;
    char *line, usbmode_str[8] = {0};

    err = at_send_command_singleline("AT+GTUSBMODE?", "+GTUSBMODE:", &p_response);

    if (err < 0 || p_response->success == 0)
    {
        RLOGD("The module does not support this command");
        goto error;
    }
    else
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0)
        {
            goto error;
        }
        err = at_tok_nextint(&line, &responsenet);
        if (err < 0)
        {
            goto error;
        }
    }

    sprintf(usbmode_str, "%d", responsenet);
    property_set(PROPERTY_CURRENT_USBMODE, usbmode_str);
    return responsenet;

error:
    return RET_FAIL;
}

int setUsbmode(int usbmode)
{
    int ret;
    char cmd[100] = {0}, usbmode_str[8] = {0};
    ATResponse *p_response;

    sprintf(cmd, "AT+GTUSBMODE=%d", usbmode);

    ret = at_send_command_timeout(cmd, &p_response, ATSEND_TIMEOUT_MSEC);
    if (ret < 0 || p_response->success == FALSE)
    {
        RLOGD("An error occurred while executing GTUSBMODE command!");
        return RET_FAIL;
    }
    else
    {
        //MC919 automatically restarts, so skip this step
        if(GHT_MC919 != mode_flag)
        {
            sleep(1);
            at_send_command_timeout("AT+CFUN=15", NULL, ATSEND_TIMEOUT_MSEC);
        }

        sprintf(usbmode_str, "%d", usbmode);
        property_set(PROPERTY_CURRENT_USBMODE, usbmode_str);
        return RET_SUCCESS;
    }

}

void getSetUsbmode()
{
    ENTER_FUNC;
    int cur_usbmode = 0, ret;
    char cmd[100] = {0};
    ATResponse *p_response;

    cur_usbmode = get_Current_Usbmode();
    if(RET_FAIL ==cur_usbmode)
    {
        RLOGE("This module does not support GTUSBMODE command!");
        return;
    }

    get_Cus_Usbmode();  //Gets the USBMODE specified by the customer
    RLOGD("current usbmode:%d, cus_usbmode:%d", cur_usbmode, cus_usbmode);

    if(NO_CUS_USBMODE == cus_usbmode)
    {
        if(dialmode == DIAL_RAS_MOD)
        {
            if(mode_flag == GHT_NL668)
            {
                if(cur_usbmode != 17 && cur_usbmode != 18)
                {
                    setUsbmode(17);
                }
            }
            else if(mode_flag == GHT_MC919)
            {
                if(cur_usbmode != 72)
                {
                    setUsbmode(72);
                }
            }
            else if(mode_flag == GHT_MC66x)
            {
                if(cur_usbmode != 73)
                {
                    setUsbmode(73);
                }
            }
        }
        else if (DIAL_ECM_MOD == dialmode)
        {
            if(mode_flag == GHT_L610)
            {
                if(cur_usbmode != 32)
                {
                    setUsbmode(32);
                }
            }
            else if(mode_flag == GHT_FG650)
            {
                //The 38 or 39 of the FG650 corresponds to RNDIS, which is not available on Android
                if(cur_usbmode == 39 || cur_usbmode == 38)
                {
                    setUsbmode(37);
                }
            }
            else if(mode_flag == GHT_MC919)
            {
                if(cur_usbmode != 70)
                {
                    setUsbmode(70);
                }
            }
            else if(mode_flag == GHT_NL668)
            {
                if(cur_usbmode != 18)
                {
                    setUsbmode(18);
                }
            }
            else if(mode_flag == GHT_MC66x)
            {
                if(cur_usbmode != 74)
                {
                    setUsbmode(74);
                }
            }
        }
    }
    else if(cur_usbmode != cus_usbmode)    //cus_usbmode != 0 && cur_usbmode != cus_usbmode
    {
        setUsbmode(cus_usbmode);
    }
    else  //cus_usbmode is non-zero, but is the same as the current USBMODE, so you don't need to change it
    {
        RLOGD("Do not change USBMODE");
    }

    LEAVE_FUNC;
    return ;
}

void get_Cus_Usbmode()
{
    RLOGD("*********Enter %s***********", __FUNCTION__);
    char usbmode_char[PROPERTY_VALUE_MAX]  = {0};
    int ret;

    //get netif name by proprity specified by user.
    ret = property_get("ril.fibocom.usbmode", usbmode_char, "");

    if(ret > MAX_USBMODE_PROPERTY_LENGTH)
    {
        RLOGD("[%s,%d]The length of the property:ril.fibocom.usbmode is too long:%d, %d characters maximum allowed.", __FUNCTION__, __LINE__, ret, MAX_USBMODE_PROPERTY_LENGTH);
    }
    else if(ret > 0)
    {
        RLOGD("[%s,%d]get ril.fibocom.usbmode:%s, ret:%d", __FUNCTION__, __LINE__, usbmode_char, ret);
        cus_usbmode = atoi(usbmode_char);
        if(cus_usbmode >= MIN_USBMODE_NUM && cus_usbmode <= MAX_USBMODE_NUM)
        {
            RLOGD("[%s,%d]cus_usbmode:%d", __FUNCTION__, __LINE__, cus_usbmode);
        }
        else
        {
            RLOGD("[%s,%d]usbmode:%d is expected to range from %d to %d", __FUNCTION__, __LINE__, cus_usbmode, MIN_USBMODE_NUM, MAX_USBMODE_NUM);
            cus_usbmode = NO_CUS_USBMODE;
        }

    }
    else
    {
        RLOGD("[%s,%d]ril.fibocom.usbmode property not set, ret:%d", __FUNCTION__, __LINE__, ret);
    }

    RLOGD("*********Leave %s***********", __FUNCTION__);
}

void getNetifName()
{
    RLOGD("*********Enter %s***********", __FUNCTION__);

    //get netif name by proprity specified by user.
    cus_netifName_flag = property_get("ril.fibocom.NetifName", cus_netifName, "");

    if(cus_netifName_flag > 100)
    {
        RLOGD("[%s,%d]The length of the property:%d is too long, 100 characters maximum allowed.", __FUNCTION__, __LINE__, cus_netifName_flag);
    }
    else if(cus_netifName_flag > 0)
    {
        RLOGD("[%s,%d]get ril.fibocom.NetifName:%s, ret:%d", __FUNCTION__, __LINE__, cus_netifName, cus_netifName_flag);

        //get final name of IFNAME gw, IP, dns and so on...
        sprintf(cus_gw, "net.%s.gw", cus_netifName);
        sprintf(cus_local_ip, "net.%s.local-ip", cus_netifName);
        sprintf(cus_dns1, "net.%s.dns1", cus_netifName);
        sprintf(cus_dns2, "net.%s.dns2", cus_netifName);
        sprintf(cus_operstate, "/sys/class/net/%s/operstate", cus_netifName);

        RLOGD("[%s,%d]cus_gw:%s", __FUNCTION__, __LINE__, cus_gw);
        RLOGD("[%s,%d]cus_local_ip:%s", __FUNCTION__, __LINE__, cus_local_ip);
        RLOGD("[%s,%d]cus_dns1:%s", __FUNCTION__, __LINE__, cus_dns1);
        RLOGD("[%s,%d]cus_dns2:%s", __FUNCTION__, __LINE__, cus_dns2);
        RLOGD("[%s,%d]cus_operstate:%s", __FUNCTION__, __LINE__, cus_operstate);
    }
    else
    {
        RLOGD("[%s,%d]ril.fibocom.NetifName property not set, ret:%d", __FUNCTION__, __LINE__, cus_netifName_flag);
    }

    RLOGD("*********Leave %s***********", __FUNCTION__);

}

void get_cid()
{
    RLOGD("*********Enter %s***********", __FUNCTION__);
    char cid_char[PROPERTY_VALUE_MAX]  = {0};
    int ret;

    //get netif name by proprity specified by user.
    ret = property_get("ril.fibocom.cid", cid_char, "");

    if(ret > MAX_CID_PROPERTY_LENGTH)
    {
        RLOGD("[%s,%d]The length of the property:ril.fibocom.cid is too long:%d, %d characters maximum allowed.", __FUNCTION__, __LINE__, ret, MAX_CID_PROPERTY_LENGTH);
    }
    else if(ret > 0)
    {
        RLOGD("[%s,%d]get ril.fibocom.cid:%s, ret:%d", __FUNCTION__, __LINE__, cid_char, ret);
        cus_cid = atoi(cid_char);
        if(cus_cid >= MIN_CID_NUM && cus_cid <= MAX_CID_NUM)
        {
            RLOGD("[%s,%d]cus_cid:%d", __FUNCTION__, __LINE__, cus_cid);
        }
        else
        {
            RLOGD("[%s,%d]cid:%d is expected to range from %d to %d", __FUNCTION__, __LINE__, cus_cid, MIN_CID_NUM, MAX_CID_NUM);
            cus_cid = 1;
        }

    }
    else
    {
        RLOGD("[%s,%d]ril.fibocom.cid property not set, ret:%d", __FUNCTION__, __LINE__, ret);
    }

    RLOGD("*********Leave %s***********", __FUNCTION__);

}

void requestSetupDataCall(void *data, size_t datalen, RIL_Token t)
{
    const char *apn;

    //add by gaopjing test at+ecm begin

    const char *pdp_type =NULL;
    const char *username =NULL;
    const char *password =NULL;
    const char *auth_type =NULL;
    int err;
    int setup_data_call_result = 0;

    ATResponse *p_response = NULL;
    int response = 0;
    int responsenet=0;
    char *line;

   
    RLOGD("******** SHUT UP SELINUX ********");
    char *cmd = NULL;
    asprintf(&cmd, "setenforce 0");
    RLOGD("%s",cmd);
    system(cmd); 
    free(cmd);
    RLOGD("******** Enter requestSetupDataCall ********");
    apn = ((const char **)data)[2];
    username = ((const char **)data)[3];
    password = ((const char **)data)[4];
    auth_type = ((const char **)data)[5];

    if (datalen > 6 * sizeof(char *))
    {
        pdp_type = ((const char **)data)[6];
    }
    else
    {
        pdp_type = "IP";
    }

#ifndef SIGNAL_MODEM
    setup_data_call_result = setupDataCallDefault(apn);
    if(setup_data_call_result == 1)
    {
        goto error;
    }
#else

    char*response_local_ip[16];
    if(dialmode == DIAL_RAS_MOD)
    {
        if(pppd)
        {
            RLOGD("Stop existing PPPd before activating PDP");
            at_send_command("ATH", NULL);
            property_set("ctl.stop", SERVICE_PPPD_GPRS);
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }
            pppd = 0;
        }

        //add by zhengjianrong for MA510 RIL BEGIN
        if(mode_flag == GHT_M910_GL || mode_flag == GHT_MA510_GL){
        //add by zhengjianrong for MA510 RIL END
            setup_data_call_result = setupDataCallRASModeM910(response_local_ip,apn,auth_type,username,password,pdp_type);
        }
        else{
            setup_data_call_result = setupDataCallRASMode(response_local_ip,apn,auth_type,username,password,pdp_type);
        }
    }
    else if(dialmode == DIAL_NDIS_MOD)
    {
        setup_data_call_result = setupDataCallNDISMode(response_local_ip,apn,auth_type,username,password,pdp_type);
    }
	//added for NL678-E-00
    else if(dialmode == DIAL_ECM_MOD)
    {
        setup_data_call_result = setupDataCallECMMode(response_local_ip,apn,auth_type,username,password,pdp_type);
        RLOGD("setupDataCallECMMode ret:%d%s",setup_data_call_result, setup_data_call_result == 0? "":"(failure)");
    }

    if(setup_data_call_result ==1)
    {
        goto error;
    }
    else if(setup_data_call_result == 2)
    {
        goto ppp_ndis_error;
    }
#endif

    requestOrSendDataCallList(&t);
    return;

ppp_ndis_error:
    /* PDP activated successfully, but PPP connection can't be setup. So deactivate PDP context */
    /* If PPPd is already launched, stop it */
    if(dialmode == DIAL_RAS_MOD)
    {
        if(pppd)
        {
            at_send_command("ATH", NULL);
            property_set("ctl.stop", SERVICE_PPPD_GPRS);
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }
            pppd = 0;
        }
    }
    else if(dialmode == DIAL_NDIS_MOD)
    {
        /*begin:modified "AT$QCRMCALL=0,1" timeout 45s by lisf 20190418 for mantis 0019714*/
       // err = at_send_command("AT$QCRMCALL=0,1", NULL);	
        err = at_send_command_timeout("AT$QCRMCALL=0,1",NULL, ATSEND_TIMEOUT_MSEC*4+5000);
       /*end:modified "AT$QCRMCALL=0,1" timeout 45s by lisf 20190418 for mantis 0019714*/
        if(ndis_fd > 0)
        {
            close(ndis_fd);
            ndis_fd = -1;
        }
	}
    else if(dialmode == DIAL_ECM_MOD)
    {
        asprintf(&cmd, "AT+GTRNDIS=0,%d", cus_cid);
        at_send_command_timeout(cmd, NULL, 30000);
        free(cmd);
    }
    // fall through
error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

void requestDeactivateDataCall(void *data, size_t datalen __unused, RIL_Token t)
{
    int err;
    char *cmd = NULL;

    if(dialmode == DIAL_RAS_MOD)
    {
        char * cid;

        ATResponse *p_response =NULL;
        cid =((char **)data)[0];
        if(pppd)
        {
	    gPid_pppd_died = get_pid("pppd");
           RLOGD("Stop existing PPPd, pid [%d]", gPid_pppd_died);
            err = at_send_command("ATH", NULL);
            err = property_set("ctl.stop", SERVICE_PPPD_GPRS);
		/*begin: added for NL678-E ppp dial by lisf 20190111*/
		if(mode_flag  == GHT_NL678_E)
	      {
	      		ril_kill_pppd(0); 
        	}
		/*end: added for NL678-E ppp dial by lisf 20190111*/
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }
            if (err < 0)
            {
                RLOGD("Can not stop PPPd");
                goto error;
            }
            pppd = 0;
        }
        asprintf(&cmd, "AT+CGACT=0,%s", cid);
        err =at_send_command(cmd, &p_response);

        at_response_free(p_response);
        free(cmd);
        cmd = NULL;
    }
    else if(dialmode == DIAL_NDIS_MOD)
    {
        /*begin:modified "AT$QCRMCALL=0,1" timeout 45s by lisf 20190418 for mantis 0019714*/
      //  err = at_send_command("AT$QCRMCALL=0,1", NULL);
        err = at_send_command_timeout("AT$QCRMCALL=0,1",NULL, ATSEND_TIMEOUT_MSEC*4+5000);
        /*end:modified "AT$QCRMCALL=0,1" timeout 45s by lisf 20190418 for mantis 0019714*/
        if (err < 0)
        {
            RLOGD("Can not down the ndis link");
            goto error;
        }
    }
    else if(dialmode == DIAL_ECM_MOD)
    {

        asprintf(&cmd, "AT+GTRNDIS=0,%d", cus_cid);
        err = at_send_command_timeout(cmd, NULL, 30000);
        free(cmd);
        if (err < 0)
        {
            RLOGD("Can not down the ECM link");
            goto error;
        }

        if(ANDROID_8 == Ght_Android_Version)
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 8 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            if(GHT_FG650 == mode_flag)
            {
                setRadioState(RADIO_STATE_OFF);
                at_send_command("AT+CFUN=4", NULL);
                at_send_command("AT+CFUN=1", NULL);
                RLOGD("the module need to redial again!!!");
            }
        }

        #if 0
        #if defined GHT_FEATURE_ANDROID8X
        if(GHT_FG650 == mode_flag)
        {
             setRadioState(RADIO_STATE_OFF);
             at_send_command("AT+CFUN=4", NULL);
             at_send_command("AT+CFUN=1", NULL);
             RLOGD("the module need to redial again!!!");
        }
        #endif
        #endif

        RLOGD("%s: ECM_NetifName:%s", __FUNCTION__, ECM_NetifName);
        if(mode_flag == GHT_L716)
        {
            asprintf(&cmd, "/system/bin/ip route del default dev %s", ECM_NetifName);
            RLOGD("%s",cmd);
            system(cmd);
            free(cmd);
        }

        asprintf(&cmd, "/system/bin/busybox ifconfig %s down", ECM_NetifName);
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);

    }

    fibocom_pingflag = 0;

    //bug41351,2020-02-24
   // RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED, NULL, 0); //added for debug 20181122
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);

    return;

error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);

}


void requestGetPreferredNetworkType(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    int response = 0;
    int responsenet=0;
    char *line;
	
    if(mode_flag < GHT_NL668)
    {
        err = at_send_command_singleline("AT+MODODR?", "+MODODR:", &p_response);
        if (err < 0 || p_response->success == 0)
        {
            goto error;
        }
    }
    else if (((mode_flag >= GHT_NL668) && (mode_flag <= GHT_NL678_E)) ||(mode_flag == GHT_FG650)||(mode_flag == GHT_L716))//modified support for NL668 NORMAL by lisf 20190318
    {
        err = at_send_command_singleline("AT+GTRAT?", "+GTRAT:", &p_response);
        if (err < 0 || p_response->success == 0)
        {
            goto error;
        }	
    }
    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0)
    {
        goto error;
    }
    err = at_tok_nextint(&line, &responsenet);
    if (err < 0)
    {
        goto error;
    } 
    if(mode_flag < GHT_NL668)
    {
    switch(responsenet)
    {
        case 1:
            response = PREF_NET_TYPE_WCDMA;
            break;
        case 2:
            response = PREF_NET_TYPE_LTE_GSM_WCDMA;
            break;
        case 3:
            response = PREF_NET_TYPE_GSM_ONLY;
            break;
        case 4:
            response = PREF_NET_TYPE_GSM_WCDMA;
            break;
        case 5:
            response = PREF_NET_TYPE_LTE_ONLY;
            break;
        case 6:
            response = PREF_NET_TYPE_WCDMA;
            break;
        case 7:
            response = PREF_NET_TYPE_WCDMA;
            break;
        case 8:
            response = PREF_NET_TYPE_CDMA_ONLY;
            break;
        case 9:
            response = PREF_NET_TYPE_CDMA_EVDO_AUTO;
            break;
        case 10:
            response = PREF_NET_TYPE_EVDO_ONLY;
            break;
        default:
            goto error;
            break;
        }
     }
	 else if(((mode_flag >= GHT_NL668) && (mode_flag <= GHT_NL678_E)) ||(mode_flag == GHT_FG650)||(mode_flag == GHT_L716))//modified support for NL668 NORMAL by lisf 20190318
	 {
        switch(responsenet)
        {
         case 0:        /*GSM*/
             response = PREF_NET_TYPE_GSM_ONLY;
             break;
         case 1:        /*GSM/UMTS*/
             response = PREF_NET_TYPE_GSM_WCDMA;
             break;
         case 2:        /*UMTS*/
             response = PREF_NET_TYPE_WCDMA;
             break;
         case 3:        /*LTE*/
             response = PREF_NET_TYPE_LTE_ONLY;
             break;
         case 4:        /*LTE/UMTS*/
             response = PREF_NET_TYPE_LTE_WCDMA;
             break;
         case 5:        /*LTE/GSM*/
             response = PREF_NET_TYPE_LTE_GSM_WCDMA;
             break;
         case 6:        /*LTE/UMTS/GSM*/
             response = PREF_NET_TYPE_LTE_GSM_WCDMA;
             break;
         case 7:        /*TD-SCDMA*/
             response = PREF_NET_TYPE_WCDMA;
             break;
         case 8:        /*eMTC*/
         case 9:        /*NB-IoT*/
             response = PREF_NET_TYPE_LTE_ONLY;
             break;
         case 10:       /*Automatic*/
             response = PREF_NET_TYPE_LTE_GSM_WCDMA;
             break;
         case 11:       /*CDMA*/
             response = PREF_NET_TYPE_CDMA_ONLY;
             break;
         case 12:       /*CDMA/EVDO*/
             response = PREF_NET_TYPE_CDMA_EVDO_AUTO;
             break;
         case 13:       /*EVDO*/
             response = PREF_NET_TYPE_EVDO_ONLY;
             break;/* 
         case 14:
            response = PREF_NET_TYPE_NR_RAN;
            break;
        case 15:
            response = PREF_NET_TYPE_NR_RAN_WCDMA;
            break;
        case 16:
            response = PREF_NET_TYPE_NR_RAN_LTE;
            break;
        case 20:
            response = PREF_NET_TYPE_NR_RAN_LTE_WCDMA;
            break;  */ //modify stephen
         default:
             goto error;
             break;
         }
    
    }

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void networkSkipWhiteSpace(char **p_cur)
{
    if (*p_cur == NULL) return;

    while (**p_cur != '\0' && isspace(**p_cur)) {
        (*p_cur)++;
    }
}


int getPreferredNetworkType(char *old_str_mode)
{
    int err=0;
    int mode = 3;
    char *line;
    ATResponse *p_response = NULL;
	//added for NL678-E-00
    if (mode_flag < GHT_NL668)
    {
	    err = at_send_command_singleline("AT+MODODR?", "+MODODR:", &p_response);
	    if (err < 0|| p_response->success == 0)
	      goto  error;
	}
	else if((mode_flag <= GHT_NL678_E && mode_flag >= GHT_NL668) || (mode_flag == GHT_FG650)|| (mode_flag == GHT_L716))//modified support for NL668 NORMAL by lisf 20190318 add L716 by gr 20220831
	{
		err = at_send_command_singleline("AT+GTRAT?", "+GTRAT:", &p_response);
		if (err < 0|| p_response->success == 0)
			goto error;
	}

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0)
      goto  error;

    
    networkSkipWhiteSpace(&line);
    strncpy(old_str_mode, line, strlen(line));
    err = at_tok_nextint(&line, &mode);
    if (err < 0)
      goto error;

    at_response_free(p_response);
    return mode;
    
    error:
        at_response_free(p_response);
        return 0;
}

void requestSetPreferredNetworkType(void *data, size_t datalen __unused, RIL_Token t)
{

    int err = 0;
    int setmode = 0,mode = 0;
    char *cmd = NULL;
    char *str_mode = NULL;
    setmode = ((int *)data)[0];
    RLOGD("requestSetPreferredNetworkType setmode=%d",setmode);

    if(0 == Net_3G_Support_Flag)
    {
        //The project generally only supports 4G and 3G networks. If 3G is not supported, it means 4G ONLY
        if(GHT_L610 == mode_flag || GHT_MC66x == mode_flag)
        {
            RLOGD("The project only supports 4G networks, so change setmode to 11");
            setmode = 11;
        }
    }

    if(mode_flag < GHT_NL668)
    {
       switch(setmode)
       {
    /* BEGIN: Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
        case 22:  /* TD-SCDMA/LTE/GSM/WCDMA, CDMA, and EvDo */
        case 12:    /* LTE/WCDMA */
    /* END:   Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
        case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
        case 8:     /* LTE, CDMA and EvDo */
        case 9:     /* LTE, GSM/WCDMA */
            mode = 2;
            break;
        case 6:     /* EvDo only */
        case 2:     /* WCDMA  */
        case 0:     /* GSM/WCDMA (WCDMA preferred) */
        case 3:     /* GSM/WCDMA (auto mode, according to PRL) */
        case 4:     /* CDMA and EvDo (auto mode, according to PRL) */
        case 7:     /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
            {
                if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                {
                    mode = 9;
                }
                else if(ODM_CM_OPERATOR == cur_oper)
                {
                    mode = 6;
                }
                else if(ODM_CU_OPERATOR == cur_oper)
                {
                    mode = 1;
                }
            }
            break;
        case 1:    /* GSM only */
        case 5:    /* CDMA only */
            {
                if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                {
                    mode = 8;
                }
                else if(ODM_CM_OPERATOR == cur_oper)
                {
                    mode = 3;
                }
                else if(ODM_CU_OPERATOR == cur_oper)
                {
                    mode = 3;
                }
                else
                {
                    mode =2;
                }
            }
            break;
        case 11:    /* LTE only */
            mode = 5;
            break;
	/* BEGIN: Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
	#if 0
	case 18:  /* TD-SCDMA, GSM/WCDMA */
	     mode =4;
	     break;
	 #endif
	/* END:   Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
        default:
            mode = 2;
            break;
    }
	 }
     /*begin:added support for NL668 NORMAL by lisf 20190318*/
       else if((mode_flag <= GHT_MDM_NORMAL) && (mode_flag >= GHT_NL668))
       {
           switch(setmode)
	    {
	        case 22:  /* TD-SCDMA/LTE/GSM/WCDMA, CDMA, and EvDo */
	        case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
	        case 9:     /* LTE, GSM/WCDMA */
	        case 12:    /* LTE/WCDMA */
	        case 8:     /* LTE, CDMA and EvDo */
                    mode = 10;
	            break;
	        case 0:     /* GSM/WCDMA (WCDMA preferred) */
	        case 3:     /* GSM/WCDMA (auto mode, according to PRL) */
	        case 7:     /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
	        case 21:    /*TD-SCDMA,EvDo,CDMA,GSM/WCDMA*/
	        case 18:    /* TD-SCDMA, GSM/WCDMA */
	        case 16:    /* TD-SCDMA and GSM */
                if(ODM_CU_OPERATOR == cur_oper)
                {
                    /* BEGIN: Added by guorui, 2022/08/01  */
                    str_mode = "2";
                    /* END: Added by guorui, 2022/08/01  */
                }
                else if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                {
                    mode = 12;
                }
                else
                {
                    mode = 1;
                }
                break;
            case 6:     /* EvDo only */
                mode = 13;
                break;
            case 2:     /* WCDMA  */
            case 14:    /* TD-SCDMA and WCDMA */
                mode = 2;
                break;
            case 4:     /* CDMA and EvDo (auto mode, according to PRL) */
                mode = 12;
                break;
            case 19:    /* TD-SCDMA, WCDMA and LTE */
            case 15:    /* TD-SCDMA and LTE */
                mode = 4;
                break;
            case 13:    /* TD-SCDMA only */
                mode = 7;
                break;
            case 17:    /* TD-SCDMA,GSM and LTE */
            case 20:    /* TD-SCDMA, GSM/WCDMA and LTE */
                mode = 6;
                break;
            /* BEGIN: Added by guorui, 2022/08/01  */
            case 1:    /* GSM only */
                if(ODM_CM_OPERATOR == cur_oper)
                {
                    str_mode = "0";
                }
                else if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                {
                    mode = 11;
                }
                else
                {
                    mode = 0;
                }
                break;
            case 5:    /* CDMA only */
                mode = 11;
                break;
            case 11:    /* LTE only */
                mode = 3;
                break;
            default:
                mode = 10;
                break;
        }
       }
     else if(mode_flag  == GHT_L716)
     {
        switch(setmode)
        {
            case 22:  /* TD-SCDMA/LTE/GSM/WCDMA, CDMA, and EvDo */
            case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
            case 9:     /* LTE, GSM/WCDMA */
            case 12:    /* LTE/WCDMA */
            case 8:     /* LTE, CDMA and EvDo */
                    mode = 10;
                break;
            case 0:     /* GSM/WCDMA (WCDMA preferred) */
            case 3:     /* GSM/WCDMA (auto mode, according to PRL) */
            case 7:     /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
            case 21:    /*TD-SCDMA,EvDo,CDMA,GSM/WCDMA*/
            case 18:    /* TD-SCDMA, GSM/WCDMA */
            case 16:    /* TD-SCDMA and GSM */
                if(ODM_CU_OPERATOR == cur_oper)
                {
                    str_mode = "2";
                }
                else if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                {
                    mode = 12;
                }
                else
                {
                    mode = 1;
                }
                break;
            case 6:     /* EvDo only */
                mode = 13;
                break;
            case 2:     /* WCDMA  */
            case 14:    /* TD-SCDMA and WCDMA */
                mode = 2;
                break;
            case 4:     /* CDMA and EvDo (auto mode, according to PRL) */
                mode = 12;
                break;
            case 19:    /* TD-SCDMA, WCDMA and LTE */
            case 15:    /* TD-SCDMA and LTE */
                mode = 4;
                break;
            case 13:    /* TD-SCDMA only */
                mode = 7;
                break;
            case 17:    /* TD-SCDMA,GSM and LTE */
            case 20:    /* TD-SCDMA, GSM/WCDMA and LTE */
                mode = 6;
                break;
            case 1:    /* GSM only */
                if(ODM_CM_OPERATOR == cur_oper)
                {
                    str_mode = "0";
                }
                else if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                {
    /* END: Added by guorui, 2022/08/01 */
                    mode = 11;
                }
                else
                {
                    mode = 0;
                }
                break;
            case 5:    /* CDMA only */
                mode = 11;
                break;
            case 11:    /* LTE only */
                mode = 3;
                break;
            default:
                mode = 10;
                break;
        }
       }
       /*end:added support for NL668 NORMAL by lisf 20190318*/
     else if(mode_flag  == GHT_L610)  //NOTE: MC669 and MC919 do not support this branch!
     {
	    switch(setmode)
	    {
	    /* BEGIN: Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
	        case 22:  /* TD-SCDMA/LTE/GSM/WCDMA, CDMA, and EvDo */
	        case 12:    /* LTE/WCDMA */
	    /* END:   Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
	        case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
	        case 8:     /* LTE, CDMA and EvDo */
	        case 9:     /* LTE, GSM/WCDMA */
	            mode = 10;
	            break;
	        case 1:    /* GSM only */
	        case 5:    /* CDMA only */
	            mode = 0;
	            break;
	        case 11:    /* LTE only */
	            mode = 3;
	            break;
	        default:
	            mode = 10;
	            break;
	    }
	 }
	 else if(mode_flag  == GHT_FG621 )
	 {
	    switch(setmode)
	    {
	    /* BEGIN: Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
	        case 22:  /* TD-SCDMA/LTE/GSM/WCDMA, CDMA, and EvDo */
	        case 12:    /* LTE/WCDMA */
	    /* END:   Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
	        case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
	        case 8:     /* LTE, CDMA and EvDo */
	        case 9:     /* LTE, GSM/WCDMA */
	            mode = 10;
	            break;
	        case 2:     /* WCDMA  */
	        case 14:    /* TD-SCDMA and WCDMA */
	            mode = 2;
	            break;
	        case 19:    /* TD-SCDMA, WCDMA and LTE */
	        case 15:    /* TD-SCDMA and LTE */
	            mode = 4;
	            break;
	        case 11:    /* LTE only */
	            mode = 3;
	            break;
	        default:
	            mode = 10;
	            break;
	    }
	 }
        else if(mode_flag == GHT_FG650)
        {

            RLOGD("GHT_FG650[%s,%d]setmode=[%d]",__FUNCTION__, __LINE__, setmode);
            switch(setmode)
            {
                case 28: /*NETWORK_MODE_NR_LTE_WCDMA*/
                    str_mode = "20,6,3";
                    break;
				case 10:  /* LTE, CDMA, EvDo, GSM/WCDMA */
				case 8:   /* LTE, CDMA and EvDo */
				case 20:  /* TD-SCDMA,GSM/WCDMA and LTE*/
                case 19:  /* TD-SCDMA,WCDMA and LTE*/
                case 17:  /* TD-SCDMA,GSM and LTE*/
				case 15:  /* TD-SCDMA and LTE*/
                case 12:  /* LTE/WCDMA */
                      str_mode = "4,3";
                      break;
                case 11:  /* LTE only */
//                      mode = 3;
                      str_mode = "3";
                      break;
                case 21:  /* TD-SCDMA,GSM/WCDMA, CDMA, and EvDo */
                case 18:  /* TD-SCDMA,GSM/WCDMA*/
                case 14:  /* TD-SCDMA and WCDMA*/
                case 7:   /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
                case 3:   /* GSM/WCDMA  (auto mode, according to PRL) */
                case 2:   /* WCDMA  */
                case 0:   /* GSM/WCDMA (WCDMA preferred) */
                case 16:  /* TD-SCDMA and GSM*/   
                case 13:  /* TD-SCDMA only*/
                case 6:   /* EvDo only */
                case 5:   /* CDMA only */
                case 4:   /* CDMA and EvDo (auto mode, according to PRL) */
                      RLOGD("GHT_FG650 cur_oper:[%d]", cur_oper);
                      //FM650 only supports Unicom 3G network
                      if(ODM_CU_OPERATOR == cur_oper)
                      {
//                          mode = 2;
                          str_mode = "2";
                      }
                      else
                      {
//                          mode = 20;
                          str_mode = "20,6,3";
                      }
                      break;
                default:
//                      mode = 20;
                      str_mode = "20,6,3";
                      break;
            }
        }
	 else if(mode_flag  == GHT_NL678_E)
	 {
	    switch(setmode)
	    {
	    /* BEGIN: Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
	        case 22:  /* TD-SCDMA/LTE/GSM/WCDMA, CDMA, and EvDo */
	        case 12:    /* LTE/WCDMA */
	    /* END:   Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
	        case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
	        case 8:     /* LTE, CDMA and EvDo */
	        case 9:     /* LTE, GSM/WCDMA */
	            mode = 10;
	            break;
	        case 6:     /* EvDo only */
	        case 2:     /* WCDMA  */
	        case 0:     /* GSM/WCDMA (WCDMA preferred) */
	        case 3:     /* GSM/WCDMA (auto mode, according to PRL) */
	        case 4:     /* CDMA and EvDo (auto mode, according to PRL) */
	        case 7:     /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
	            {
	                if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
	                {
	                    mode = 12;
	                }
	                else if(ODM_CM_OPERATOR == cur_oper)
	                {
	                    mode = 2;
	                }
	                else if(ODM_CU_OPERATOR == cur_oper)
	                {
	                    mode = 2;
	                }
	            }
	            break;
	        case 1:    /* GSM only */
	        case 5:    /* CDMA only */
	            {
	                if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
	                {
	                    mode = 11;
	                }
	                else if(ODM_CM_OPERATOR == cur_oper)
	                {
	                    mode = 2;
	                }
	                else if(ODM_CU_OPERATOR == cur_oper)
	                {
	                    mode = 2;
	                }
	                else
	                {
	                    mode =10;
	                }
	            }
	            break;
	        case 11:    /* LTE only */
	            mode = 3;
	            break;
	        default:    /* GSM only */
	            mode = 10;
	            break;
	    }
	 }
     else if(GHT_H330S == mode_flag){
         RLOGD("GHT_H330S[%s,%d]setmode=[%d]",__FUNCTION__, __LINE__, setmode);
         switch(setmode)
         {
         case 1:    /* GSM only */
            mode = 0;
            break;
         default:
            mode = 2;
            break;
         }

/*         if(ODM_CM_OPERATOR == cur_oper)
             mode = 0;
         else if(ODM_CU_OPERATOR == cur_oper)
             mode = 2;
         else if(ODM_CT_OPERATOR_3G == cur_oper || ODM_CT_OPERATOR_4G == cur_oper)
         {
             RLOGD("error : The H330S does not support telecom cards");
             goto error;
         }
         else
         {
             RLOGD("error : Unknown SIM card");    //This code should never be executed
             goto error;
         }*/
    }
    else
    {
        RLOGD("Unknown module, cannot set preferred network");
        goto error;
    }

    char old_str_mode[100] = {0};
    int NetworkType;
    ATResponse *outResponse;

    NetworkType = getPreferredNetworkType(old_str_mode);
    RLOGD("debug: NetworkType:%d, old_str_mode:%s, str_mode:%s",NetworkType, old_str_mode,str_mode);
    if((GHT_FG650 == mode_flag && strcmp(old_str_mode,str_mode)) || (GHT_FG650 != mode_flag && mode != NetworkType))
    {
        RLOGD("requestSetPreferredNetworkType setmode=%d, mode=%d, str_mode=%s",setmode, mode, str_mode);
        if(mode_flag < GHT_NL668)
        {
            asprintf(&cmd,"AT+MODODR=%d",mode);
        }
        /* BEGIN: Added by guorui, 2022/08/01  */
        else if(((mode_flag <= GHT_MDM_NORMAL) && (mode_flag >= GHT_NL668)) || (mode_flag == GHT_L716))
        {
            if(str_mode != NULL){
                asprintf(&cmd, "AT+GTRAT=%s", str_mode);
            }
            else
            {
                asprintf(&cmd,"AT+GTRAT=%d",mode);
            }
        }
        else if(((mode_flag >= GHT_L610) && (mode_flag <= GHT_NL678_E))  || (GHT_H330S == mode_flag))//modified support for NL668 NORMAL by lisf 20190318
        {
        /* END: Added by guorui, 2022/08/01  */
            asprintf(&cmd,"AT+GTRAT=%d",mode);
        }
        else if(mode_flag == GHT_FG650)
        {
            asprintf(&cmd, "AT+GTRAT=%s", str_mode);
        }
        err = at_send_command(cmd, &outResponse);
        free(cmd);
        cmd = NULL;

        /* BEGIN: Added by eric.li, 2019/2/19   PN:free more mem on time  */
        if (err < 0 )
        {
            goto error;
        }
        /* END:   Added by eric.li, 2019/2/19   PN:free more mem on time  */

        /*BEGIN: Added by wujiabao in 2022/05/27, only when the GTRAT command is successfully executed, the data_call is deactivated*/
        if(true == outResponse->success)
        /*END:   Added by wujiabao in 2022/05/27, only when the GTRAT command is successfully executed, the data_call is deactivated*/
        {
            /*begin:added by lisf for switch cdma & evdo*/
            if(((mode_flag >= GHT_NL668) && (mode_flag <= GHT_NL678_E))||mode_flag == GHT_L716)
            {
                if(mode ==12 || 11 ==mode)
                {
                    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED, NULL, 0);
                    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse( RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED, NULL, 0);
                }
            }
            onDeactiveDataCallList();
            /*end:added by lisf for switch cdma & evdo*/
        }
    }

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;
error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

void requestSetNetworkSelectionManual(void *data, size_t datalen __unused, RIL_Token t)
{
    const char *operator = NULL;
    char *cmd = NULL;
    int err = 0;
    ATResponse *p_response = NULL;

    operator = (const char *)data;
    // <!--[ODM]lindong@2017.11.24 for manual select network
    RLOGD("[%s,%d]operator[%p]",__FUNCTION__, __LINE__, operator);
    if(NULL == operator)
    {
        goto error;
    }
    RLOGD("[%s,%d],operator[%s]",__FUNCTION__, __LINE__, operator);
    // --!>
    asprintf(&cmd, "AT+COPS=1,2,\"%s\" ", operator);

/* BEGIN: Modified by eric.li, 2018/11/5   PN:fix bug 11301 that at+cops timeout on NL668-AM */
    //err = at_send_command(cmd, &p_response);
    err = at_send_command_timeout(cmd, &p_response, TIME_OUT_COPS );//wait long timeout by trento
/* END:   Modified by eric.li, 2018/11/5   PN:fix bug 11301 that at+cops timeout on NL668-AM */
    free(cmd);
    if (err < 0 || p_response->success == 0)
    {
        // err = at_send_command("AT+COPS=0", NULL);
        // if(err < 0)
// <!--added by wangmengying@2017.12.13 for register network failed still need to send cops=0
        g_SetNetworkSelectionManual = 1;
// end-->
        goto error;
    }

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);

    return;
error:
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    sleep(1);
    onDeactiveDataCallList();
}

void requestNeighboringCellIds(void * data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    char *line, *p;
    int commas;
    int skip;
    int i;
    int count = 3;
    int lac = 0,cid = 0;
    int ber;
    int rssi;

    RIL_NeighboringCell **pp_cellIds;
    RIL_NeighboringCell *p_cellIds;

    pp_cellIds = (RIL_NeighboringCell **)alloca(sizeof(RIL_NeighboringCell *));
    p_cellIds = (RIL_NeighboringCell *)alloca(sizeof(RIL_NeighboringCell));
    pp_cellIds[0]=p_cellIds;

    err = 1;
    for (i=0; i<4 && err != 0; i++)
        err = at_send_command_singleline("AT+CREG?", "+CREG:", &p_response);

    if (err < 0 || p_response->success == 0 ) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;
    /* Ok you have to be careful  here
     * The solicited version of the CREG response is
     * +CREG: n, stat, [lac, cid]
     * and the unsolicited version is
     * +CREG: stat, [lac, cid]
     * The <n> parameter is basically "is unsolicited creg on?"
     * which it should always be
     *
     * Now we should normally get the solicited version here,
     * but the unsolicited version could have snuck in
     * so we have to handle both
     *
     * Also since the LAC and CID are only reported when registered,
     * we can have 1, 2, 3, or 4 arguments here
     *
     * finally, a +CGREG: answer may have a fifth value that corresponds
     * to the network type, as in;
     *
     *   +CGREG: n, stat [,lac, cid [,networkType]]
     */

    /* count number of commas */
    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }
    switch (commas) 
    {
        case 0: /* +CREG: <stat> */
        case 1: /* +CREG: <n>, <stat> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            break;
            //goto error;
        case 2: /* +CREG: <stat>, <lac>, <cid> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &lac);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &cid);
            if (err < 0) goto error;
            break;
        case 3: /* +CREG: <n>, <stat>, <lac>, <cid> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &lac);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &cid);
            if (err < 0) goto error;
            break;
        case 4: /* +CGREG: <n>, <stat>, <lac>, <cid>, <networkType> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &lac);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &cid);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &skip);
            if (err < 0) goto error;
            count = 4;
            break;
        default:
            goto error;
    }

    RLOGD("request neighboring cellID : lac : %x, cid : %x", lac, cid);
    at_response_free(p_response);

    err = at_send_command_singleline("AT+CSQ", "+CSQ:", &p_response);

     if (err < 0 || p_response->success == 0) {
         goto error;
     }

     line = p_response->p_intermediates->line;

     err = at_tok_start(&line);
     if (err < 0) goto error;

    err = at_tok_nextint(&line, &rssi);
      if (err < 0) goto error;

    err = at_tok_nextint(&line, &ber);
      if (err < 0) goto error;

    p_cellIds[0].cid = (char*) alloca(16);
    sprintf(p_cellIds[0].cid, "%04x%04x", lac & 0xFFFF, cid & 0xFFFF );
    p_cellIds[0].rssi = rssi;

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, pp_cellIds, sizeof(pp_cellIds));
    at_response_free(p_response);
    p_response = NULL;
    return;

error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    if (p_response)
    {
        at_response_free(p_response);
    }
    return ;
}

void requestGetCellInfoList(void * data __unused, size_t datalen __unused, RIL_Token t)
{
    int err,i = 0;
    ATResponse *atResponse = NULL;
    char *line;
    int resp[15]={0};  //mode,type,<MCC>,<MNC>,<LAC>,<CI>,<scrambling_code>....
    int ber = 99;
    int sig_strength = 99;
    int rsrp = 0;
    int rsrq = 0;
#define CELL_NUM 20              //We expect to store data for up to 19 neighboring cells
    //RLOGE("requestGetCellInfoList:");

    RIL_CellInfo *p_cellInfo;
    int cellInfo_len = sizeof(RIL_CellInfo);

    if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        cellInfo_len = sizeof(RIL_CellInfo_v12);
    }
    p_cellInfo = (RIL_CellInfo *)malloc(CELL_NUM * sizeof(RIL_CellInfo) + 128);
    RLOGD("version_check sizeof(RIL_CellInfo):%d, sizeof(RIL_CellInfo_v12):%d", sizeof(RIL_CellInfo), sizeof(RIL_CellInfo_v12));

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
    RLOGD("RIL_CellInfo_v12");
    RIL_CellInfo_v12 p_cellInfo[CELL_NUM];
#else
    RLOGD("not RIL_CellInfo_v12");
    RIL_CellInfo p_cellInfo[CELL_NUM];
//    p_cellInfo = (RIL_CellInfo *)alloca(sizeof(RIL_CellInfo));
#endif
#endif

    err = at_send_command_singleline("AT+CSQ", "+CSQ:", &atResponse);

    if (err < 0 || atResponse->success == 0)
    {
        RLOGD("at_send_command_singleline(AT+CSQ) return err[%d]", err);
        goto error;
    }
    line = atResponse->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &sig_strength);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &ber);
    if (err < 0) goto error;

    at_response_free(atResponse);
    atResponse = NULL;

    err = at_send_command_multiline_timeout("AT+GTCCINFO?","", 2 * ATSEND_TIMEOUT_MSEC, &atResponse);

    if (err < 0 || atResponse->success == 0)
    {
        RLOGD("requestGetCellInfoList: at_send_command_singleline(AT+CELLINFO?) return err[%d]", err);
        goto error;
    }
    else
    {
    ATLine *p_cur;
    int CurretService = 0;

    for (p_cur = atResponse->p_intermediates
            ; p_cur != NULL && i < CELL_NUM
            ; p_cur = p_cur->p_next)
    {
        char *line = p_cur->line;

        if (!at_tok_hasmore(&line))
        {
            RLOGD("That`s all.");
            continue;
        }
        if(!(strncmp(line,"GSM service cell:",strlen("GSM service cell:"))) ||
            !(strncmp(line,"UMTS service cell:",strlen("UMTS service cell:"))) ||
            !(strncmp(line,"LTE service cell:",strlen("LTE service cell:"))) ||
            !(strncmp(line,"CDMA service cell:",strlen("CDMA service cell:"))) ||
            !(strncmp(line,"EVDO service cell:",strlen("EVDO service cell:"))) ||
            !(strncmp(line,"eMTC service cell:",strlen("eMTC service cell:"))) ||
            !(strncmp(line,"NB-IoT service cell:",strlen("NB-IoT service cell:"))))
        {
            RLOGD("[%d]service cell:%s",__LINE__,line);
            CurretService = 1;
            p_cur = p_cur->p_next;
            line = p_cur->line;
            RLOGD("[%d]cell:%s",__LINE__,line);
            err = at_tok_nextint(&line, &resp[0]); //IsServiceCell
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[1]);///rat
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[2]);//MCC
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[3]);//MNC
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &resp[4]);//LAC   //tac
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &resp[5]);//CID
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &resp[6]);//LTE:earfcn;GSM:arfcn;UMTS:uarfcn
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &resp[7]);//LTE:physicalcellId;GSM:basic;UMTS:psc
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[8]);//band
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[9]);//bandwidth
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[10]);//rssnr_value
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[11]);//rxlev
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[12]);//rsrp
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &resp[13]);//rsrq
            if (err < 0) goto error;
            
            rsrp = resp[12];
            rsrq = resp[13];
            
            rsrp = (140 - rsrp);
            rsrq = (rsrq / 2 -3);
switch(resp[1]){
        //GSM
        case 1:
            RLOGE("GTCCINFO GSM:MCC=%d , MNC=%d , LAC=%d , CID=%d , SCRAM_CODE=%d...",resp[2],resp[3],resp[4],resp[5],resp[6]);
            RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d , SCRAM_CODE1=%d...",g_mcc,g_mnc,g_lac,g_cid,resp[6]);
            p_cellInfo[0].cellInfoType = RIL_CELL_INFO_TYPE_GSM;
            p_cellInfo[0].registered = 1;
            p_cellInfo[0].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
            p_cellInfo[0].timeStamp = 0;
            p_cellInfo[0].CellInfo.gsm.cellIdentityGsm.mcc = ((g_mcc!=0xffff)?g_mcc:resp[2]);  //MCC
            p_cellInfo[0].CellInfo.gsm.cellIdentityGsm.mnc = ((g_mnc!=0xffff)?g_mnc:resp[3]);  //MNC
            p_cellInfo[0].CellInfo.gsm.cellIdentityGsm.lac = ((g_lac!=0xffff)?g_lac:resp[4]);  //LAC
            p_cellInfo[0].CellInfo.gsm.cellIdentityGsm.cid = ((g_cid!=0xffff)?g_cid:resp[5]);  //CID

            if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                ((RIL_CellInfo_v12 *)p_cellInfo)[0].CellInfo.gsm.cellIdentityGsm.arfcn = resp[6];    //arfcn
                ((RIL_CellInfo_v12 *)p_cellInfo)[0].CellInfo.gsm.cellIdentityGsm.bsic = resp[7];     //basic
            }
#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
            p_cellInfo[0].CellInfo.gsm.cellIdentityGsm.arfcn = resp[6];    //arfcn
            p_cellInfo[0].CellInfo.gsm.cellIdentityGsm.bsic = resp[7];     //basic
#endif
#endif
            p_cellInfo[0].CellInfo.gsm.signalStrengthGsm.signalStrength = sig_strength;
            p_cellInfo[0].CellInfo.gsm.signalStrengthGsm.bitErrorRate = ber;

            if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                ((RIL_CellInfo_v12 *)p_cellInfo)[0].CellInfo.gsm.signalStrengthGsm.timingAdvance = INT_MAX;  //0xffff
            }

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
            p_cellInfo[0].CellInfo.gsm.signalStrengthGsm.timingAdvance = INT_MAX;  //0xffff
#endif
#endif

            break;
        //WCDMA
        case 2:
            RLOGE("GTCCINFO WCDMA:MCC=%d , MNC=%d , LAC=%d , CID=%d , SCRAM_CODE=%d...",resp[2],resp[3],resp[4],resp[5],resp[6]);
            RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d , SCRAM_CODE1=%d...",g_mcc,g_mnc,g_lac,g_cid,resp[6]);
            p_cellInfo[0].cellInfoType = RIL_CELL_INFO_TYPE_WCDMA;
            p_cellInfo[0].registered = 1;
            p_cellInfo[0].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
            p_cellInfo[0].timeStamp = 0;
            p_cellInfo[0].CellInfo.wcdma.cellIdentityWcdma.mcc = ((g_mcc!=0xffff)?g_mcc:resp[2]);  //MCC
            p_cellInfo[0].CellInfo.wcdma.cellIdentityWcdma.mnc = ((g_mnc!=0xffff)?g_mnc:resp[3]);  //MNC
            p_cellInfo[0].CellInfo.wcdma.cellIdentityWcdma.lac = ((g_lac!=0xffff)?g_lac:resp[4]);  //LAC
            p_cellInfo[0].CellInfo.wcdma.cellIdentityWcdma.cid = ((g_cid!=0xffff)?g_cid:resp[5]);  //CID
            p_cellInfo[0].CellInfo.wcdma.cellIdentityWcdma.psc = resp[7];

            if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                ((RIL_CellInfo_v12 *)p_cellInfo)[0].CellInfo.wcdma.cellIdentityWcdma.uarfcn = resp[6];
            }

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
            p_cellInfo[0].CellInfo.wcdma.cellIdentityWcdma.uarfcn = resp[6];
#endif
#endif

            p_cellInfo[0].CellInfo.wcdma.signalStrengthWcdma.signalStrength = sig_strength;
            p_cellInfo[0].CellInfo.wcdma.signalStrengthWcdma.bitErrorRate = ber;
            break;
//#ifndef GHT_FEATURE_ANDROID4X
        //TDSCDMA
        case 3:
            if(Ght_Android_Version != ANDROID_4)
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d != 4 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                RLOGE("GTCCINFO TDSCDMA:MCC=%d , MNC=%d , LAC=%d , CID=%d , SCRAM_CODE=%d...",resp[2],resp[3],resp[4],resp[5],resp[6]);
                RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d , SCRAM_CODE1=%d...",g_mcc,g_mnc,g_lac,g_cid,resp[6]);
                p_cellInfo[0].cellInfoType = RIL_CELL_INFO_TYPE_TD_SCDMA;
                p_cellInfo[0].registered = 1;
                p_cellInfo[0].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
                p_cellInfo[0].timeStamp = 0;
                p_cellInfo[0].CellInfo.tdscdma.cellIdentityTdscdma.mcc = ((g_mcc!=0xffff)?g_mcc:resp[2]);  //MCC
                p_cellInfo[0].CellInfo.tdscdma.cellIdentityTdscdma.mnc = ((g_mnc!=0xffff)?g_mnc:resp[3]);  //MNC
                p_cellInfo[0].CellInfo.tdscdma.cellIdentityTdscdma.lac = ((g_lac!=0xffff)?g_lac:resp[4]);  //LAC
                p_cellInfo[0].CellInfo.tdscdma.cellIdentityTdscdma.cid = ((g_cid!=0xffff)?g_cid:resp[5]);  //CID
                p_cellInfo[0].CellInfo.tdscdma.signalStrengthTdscdma.rscp = sig_strength;
                break;
            }
//#endif
        //LTE/NB-IoT/eMTC
        case 4:
        case 5:
        case 6:
            RLOGE("GTCCINFO LTE:MCC=%d , MNC=%d , CID=%d ...",resp[2],resp[3],resp[4]);
            RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d ...",g_mcc,g_mnc,g_lac,g_cid);
            p_cellInfo[0].cellInfoType = RIL_CELL_INFO_TYPE_LTE;
            p_cellInfo[0].registered = 1;
            p_cellInfo[0].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
            p_cellInfo[0].timeStamp = 0;
            p_cellInfo[0].CellInfo.lte.cellIdentityLte.mcc = ((g_mcc!=0xffff)?g_mcc:resp[2]);  //MCC
            p_cellInfo[0].CellInfo.lte.cellIdentityLte.mnc = ((g_mnc!=0xffff)?g_mnc:resp[3]);  //MNC
            p_cellInfo[0].CellInfo.lte.cellIdentityLte.tac = resp[4];  //tac
            p_cellInfo[0].CellInfo.lte.cellIdentityLte.ci = ((g_cid!=0xffff)?g_cid:resp[5]);  //CID

            if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                ((RIL_CellInfo_v12 *)p_cellInfo)[0].CellInfo.lte.cellIdentityLte.earfcn = resp[6];  //earfcn
            }

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
            p_cellInfo[0].CellInfo.lte.cellIdentityLte.earfcn = resp[6];  //earfcn
#endif
#endif
            p_cellInfo[0].CellInfo.lte.cellIdentityLte.pci = ((g_pci!=0xffff)?g_pci:resp[7]);  //pci


            p_cellInfo[0].CellInfo.lte.signalStrengthLte.signalStrength = sig_strength;
            p_cellInfo[0].CellInfo.lte.signalStrengthLte.rsrp = rsrp;    //rsrp
            p_cellInfo[0].CellInfo.lte.signalStrengthLte.rsrq = rsrq;    //rsrq
            p_cellInfo[0].CellInfo.lte.signalStrengthLte.rssnr = resp[10];   //rssnr_value      //INT_MAX or 0?
            p_cellInfo[0].CellInfo.lte.signalStrengthLte.cqi=INT_MAX;         //INT_MAX or 0 ?
            p_cellInfo[0].CellInfo.lte.signalStrengthLte.timingAdvance = INT_MAX;   //INT_MAX or 0 ?

            break;
        //CDMA,EVDO
        case 7:
        case 8:
            RLOGE("GTCCINFO CDMA:MCC=%d , MNC=%d , LAC=%d , CID=%d , SCRAM_CODE=%d...",resp[2],resp[3],resp[4],resp[5],resp[6]);
            RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d , SCRAM_CODE1=%d...",g_mcc,g_mnc,g_lac,g_cid,resp[6]);
            p_cellInfo[0].cellInfoType = RIL_CELL_INFO_TYPE_CDMA;
            p_cellInfo[0].registered = 1;
            p_cellInfo[0].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
            p_cellInfo[0].timeStamp = 0;
            p_cellInfo[0].CellInfo.cdma.cellIdentityCdma.networkId = resp[3];
            p_cellInfo[0].CellInfo.cdma.cellIdentityCdma.systemId = resp[2];
            p_cellInfo[0].CellInfo.cdma.cellIdentityCdma.basestationId = resp[4];
            p_cellInfo[0].CellInfo.cdma.cellIdentityCdma.longitude = resp[9];
            p_cellInfo[0].CellInfo.cdma.cellIdentityCdma.latitude = resp[10];
            if (7 == resp[1])
            {
                p_cellInfo[0].CellInfo.cdma.signalStrengthCdma.dbm = sig_strength;
                p_cellInfo[0].CellInfo.cdma.signalStrengthCdma.ecio = ber;
            }
            else
            {
                p_cellInfo[0].CellInfo.cdma.signalStrengthEvdo.dbm = sig_strength;
                p_cellInfo[0].CellInfo.cdma.signalStrengthEvdo.ecio = ber;
            }
            break;
        default:
            RLOGE("GTCCINFO type not defined..");
            break;
        }
        i++;

            continue;
        }
        else if(!(strncmp(line,"GSM neighbor cell:",strlen("GSM neighbor cell:"))) ||
            !(strncmp(line,"UMTS neighbor cell:",strlen("UMTS neighbor cell:"))) ||
            !(strncmp(line,"LTE neighbor cell:",strlen("LTE neighbor cell:"))) ||
            !(strncmp(line,"CDMA neighbor cell:",strlen("CDMA neighbor cell:"))) ||
            !(strncmp(line,"EVDO neighbor cell:",strlen("EVDO neighbor cell:"))) ||
            !(strncmp(line,"eMTC neighbor cell:",strlen("eMTC neighbor cell:"))) ||
            !(strncmp(line,"NB-IoT neighbor cell:",strlen("NB-IoT neighbor cell:")))||
            !(strncmp(line,"NB-IoT neighbor cell:",strlen("NB-IoT neighbor cell:")))||
            !(strncmp(line,"+GTCCINFO:",strlen("+GTCCINFO:"))) ||
            !(strncmp(line,"+CREG:",strlen("+CREG:"))) ||
            !(strncmp(line,"+CGREG:",strlen("+CREG:"))) ||
            !(strncmp(line,"+CEREG:",strlen("+CREG:"))))
            {
                RLOGD("[%d]useless Line:%s",__LINE__,line);
                continue;
            }

                line = p_cur->line;
                RLOGD("[%d]neighbor cell:%s",__LINE__,line);
                err = at_tok_nextint(&line, &resp[0]); //IsServiceCell
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[1]);///rat
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[2]);//MCC
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[3]);//MNC
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[4]);//LAC   //tac
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[5]);//CID
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[6]);//LTE:earfcn;GSM:arfcn;UMTS:uarfcn
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[7]);//LTE:physicalcellId;GSM:basic;UMTS:psc
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[8]);//bandwidth;GSM:c1
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[9]);//rxlev;GSM:c2
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[10]);//rsrp;GSM:c31
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[11]);//rsrq;GSM:c32
                if (err < 0) goto error;
                        
                rsrp = resp[10];
                rsrq = resp[11];
                        
                rsrp = (140 - rsrp);
                rsrq = (rsrq / 2 -3);
switch(resp[1])
            {
                //GSM
                case 1:
                        RLOGE("GTCCINFO:MCC=%d , MNC=%d , LAC=%d , CID=%d , SCRAM_CODE=%d...",resp[2],resp[3],resp[4],resp[5],resp[6]);
                        RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d , SCRAM_CODE1=%d...",g_mcc,g_mnc,g_lac,g_cid,resp[6]);
                        p_cellInfo[i].cellInfoType = RIL_CELL_INFO_TYPE_GSM;
                        p_cellInfo[i].registered = 1;
                        p_cellInfo[i].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
                        p_cellInfo[i].timeStamp = 0;
                        p_cellInfo[i].CellInfo.gsm.cellIdentityGsm.mcc = ((g_mcc!=0xffff)?g_mcc:resp[2]);  //MCC
                        p_cellInfo[i].CellInfo.gsm.cellIdentityGsm.mnc = ((g_mnc!=0xffff)?g_mnc:resp[3]);  //MNC
                        p_cellInfo[i].CellInfo.gsm.cellIdentityGsm.lac = ((g_lac!=0xffff)?g_lac:resp[4]);  //LAC
                        p_cellInfo[i].CellInfo.gsm.cellIdentityGsm.cid = ((g_cid!=0xffff)?g_cid:resp[5]);  //CID

                        if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
                        {
                            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                            ((RIL_CellInfo_v12 *)p_cellInfo)[i].CellInfo.gsm.cellIdentityGsm.arfcn = resp[6];    //arfcn
                            ((RIL_CellInfo_v12 *)p_cellInfo)[i].CellInfo.gsm.cellIdentityGsm.bsic = resp[7];     //basic
                        }

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
                        p_cellInfo[i].CellInfo.gsm.cellIdentityGsm.arfcn = resp[6];    //arfcn
                        p_cellInfo[i].CellInfo.gsm.cellIdentityGsm.bsic = resp[7];     //basic
#endif
#endif
                        p_cellInfo[i].CellInfo.gsm.signalStrengthGsm.signalStrength = sig_strength;
                        p_cellInfo[i].CellInfo.gsm.signalStrengthGsm.bitErrorRate = ber;
                        if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
                        {
                            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                            ((RIL_CellInfo_v12 *)p_cellInfo)[i].CellInfo.gsm.signalStrengthGsm.timingAdvance = INT_MAX;  //0xffff
                        }

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
                        p_cellInfo[i].CellInfo.gsm.signalStrengthGsm.timingAdvance = INT_MAX;  //0xffff
#endif
#endif
                        break;
                //WCDMA
                case 2:
                        RLOGE("GTCCINFO:MCC=%d , MNC=%d , LAC=%d , CID=%d , SCRAM_CODE=%d...",resp[2],resp[3],resp[4],resp[5],resp[6]);
                        RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d , SCRAM_CODE1=%d...",g_mcc,g_mnc,g_lac,g_cid,resp[6]);
                        p_cellInfo[i].cellInfoType = RIL_CELL_INFO_TYPE_WCDMA;
                        p_cellInfo[i].registered = 1;
                        p_cellInfo[i].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
                        p_cellInfo[i].timeStamp = 0;
                        p_cellInfo[i].CellInfo.wcdma.cellIdentityWcdma.mcc = ((g_mcc!=0xffff)?g_mcc:resp[2]);  //MCC
                        p_cellInfo[i].CellInfo.wcdma.cellIdentityWcdma.mnc = ((g_mnc!=0xffff)?g_mnc:resp[3]);  //MNC
                        p_cellInfo[i].CellInfo.wcdma.cellIdentityWcdma.lac = ((g_lac!=0xffff)?g_lac:resp[4]);  //LAC
                        p_cellInfo[i].CellInfo.wcdma.cellIdentityWcdma.cid = ((g_cid!=0xffff)?g_cid:resp[5]);  //CID
                        p_cellInfo[i].CellInfo.wcdma.cellIdentityWcdma.psc = resp[7];

                        if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
                        {
                            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                            ((RIL_CellInfo_v12 *)p_cellInfo)[i].CellInfo.wcdma.cellIdentityWcdma.uarfcn = resp[6];
                        }

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
                        p_cellInfo[i].CellInfo.wcdma.cellIdentityWcdma.uarfcn = resp[6];
#endif
#endif
                        p_cellInfo[i].CellInfo.wcdma.signalStrengthWcdma.signalStrength = sig_strength;
                        p_cellInfo[i].CellInfo.wcdma.signalStrengthWcdma.bitErrorRate = ber;
                        break;
//#ifndef GHT_FEATURE_ANDROID4X
                //TDSCDMA
                case 3:
                    if(Ght_Android_Version != ANDROID_4)
                    {
                        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d != 4 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                        RLOGE("GTCCINFO:MCC=%d , MNC=%d , LAC=%d , CID=%d , SCRAM_CODE=%d...",resp[2],resp[3],resp[4],resp[5],resp[6]);
                        RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d , SCRAM_CODE1=%d...",g_mcc,g_mnc,g_lac,g_cid,resp[6]);
                        p_cellInfo[i].cellInfoType = RIL_CELL_INFO_TYPE_TD_SCDMA;
                        p_cellInfo[i].registered = 1;
                        p_cellInfo[i].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
                        p_cellInfo[i].timeStamp = 0;
                        p_cellInfo[i].CellInfo.tdscdma.cellIdentityTdscdma.mcc = ((g_mcc!=0xffff)?g_mcc:resp[2]);  //MCC
                        p_cellInfo[i].CellInfo.tdscdma.cellIdentityTdscdma.mnc = ((g_mnc!=0xffff)?g_mnc:resp[3]);  //MNC
                        p_cellInfo[i].CellInfo.tdscdma.cellIdentityTdscdma.lac = ((g_lac!=0xffff)?g_lac:resp[4]);  //LAC
                        p_cellInfo[i].CellInfo.tdscdma.cellIdentityTdscdma.cid = ((g_cid!=0xffff)?g_cid:resp[5]);  //CID
                        p_cellInfo[i].CellInfo.tdscdma.signalStrengthTdscdma.rscp = sig_strength;
                        break;
                    }
//#endif
                    //LTE/NB-IoT/eMTC
                case 4:
                case 5:
                case 6:
                        RLOGE("GTCCINFO neighbor cell:MCC=%d , MNC=%d , CID=%d ...",resp[2],resp[3],resp[4]);
//                        RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d ...",g_mcc,g_mnc,g_lac,g_cid);
                        p_cellInfo[i].cellInfoType = RIL_CELL_INFO_TYPE_LTE;
                        p_cellInfo[i].registered = 0;
                        p_cellInfo[i].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
                        p_cellInfo[i].timeStamp = 0;
                        p_cellInfo[i].CellInfo.lte.cellIdentityLte.mcc = ((g_mcc!=0xffff)?g_mcc:resp[2]);  //MCC
                        p_cellInfo[i].CellInfo.lte.cellIdentityLte.mnc = ((g_mnc!=0xffff)?g_mnc:resp[3]);  //MNC
                        p_cellInfo[i].CellInfo.lte.cellIdentityLte.tac = resp[4];  //tac
                        p_cellInfo[i].CellInfo.lte.cellIdentityLte.ci = ((g_cid!=0xffff)?g_cid:resp[5]);  //CID

                        if(ANDROID_10 == Ght_Android_Version || ANDROID_7 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
                        {
                            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                            ((RIL_CellInfo_v12 *)p_cellInfo)[i].CellInfo.lte.cellIdentityLte.earfcn = resp[6];  //earfcn
                        }

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X
                        p_cellInfo[i].CellInfo.lte.cellIdentityLte.earfcn = resp[6];  //earfcn
#endif
#endif
                        p_cellInfo[i].CellInfo.lte.cellIdentityLte.pci = ((g_pci!=0xffff)?g_pci:resp[7]);  //pci
            
            
//                        p_cellInfo[i].CellInfo.lte.signalStrengthLte.signalStrength = sig_strength;
                        p_cellInfo[i].CellInfo.lte.signalStrengthLte.rsrp = rsrp;    //rsrp
                        p_cellInfo[i].CellInfo.lte.signalStrengthLte.rsrq = rsrq;    //rsrq
                        p_cellInfo[i].CellInfo.lte.signalStrengthLte.rssnr = INT_MAX;   //rssnr_value      //INT_MAX or 0?
                        p_cellInfo[i].CellInfo.lte.signalStrengthLte.cqi=INT_MAX;         //INT_MAX or 0 ?
                        p_cellInfo[i].CellInfo.lte.signalStrengthLte.timingAdvance = INT_MAX;   //INT_MAX or 0 ?

                        break;
                    //CDMA,EVDO
                    case 7:
                    case 8:
                        RLOGE("GTCCINFO:MCC=%d , MNC=%d , LAC=%d , CID=%d , SCRAM_CODE=%d...",resp[2],resp[3],resp[4],resp[5],resp[6]);
                        RLOGE("GTCCINFO from cops cgreg:MCC1=%d , MNC1=%d , LAC1=%d , CID1=%d , SCRAM_CODE1=%d...",g_mcc,g_mnc,g_lac,g_cid,resp[6]);
                        p_cellInfo[i].cellInfoType = RIL_CELL_INFO_TYPE_CDMA;
                        p_cellInfo[i].registered = 1;
                        p_cellInfo[i].timeStampType = RIL_TIMESTAMP_TYPE_JAVA_RIL;
                        p_cellInfo[i].timeStamp = 0;
                        p_cellInfo[i].CellInfo.cdma.cellIdentityCdma.networkId = resp[3];
                        p_cellInfo[i].CellInfo.cdma.cellIdentityCdma.systemId = resp[2];
                        p_cellInfo[i].CellInfo.cdma.cellIdentityCdma.basestationId = resp[4];
                        p_cellInfo[i].CellInfo.cdma.cellIdentityCdma.longitude = resp[9];
                        p_cellInfo[i].CellInfo.cdma.cellIdentityCdma.latitude = resp[10];
                        if (7 == resp[1])
                        {
                            p_cellInfo[i].CellInfo.cdma.signalStrengthCdma.dbm = sig_strength;
                            p_cellInfo[i].CellInfo.cdma.signalStrengthCdma.ecio = ber;
                        }
                        else
                        {
                            p_cellInfo[i].CellInfo.cdma.signalStrengthEvdo.dbm = sig_strength;
                            p_cellInfo[i].CellInfo.cdma.signalStrengthEvdo.ecio = ber;
                        }
                        break;
                    default:
                        RLOGE("GTCCINFO type not defined..");
                        break;
                    }
                    i++;
    }
    if(CurretService != 1)  goto error;
    }

    RLOGD("Current cell number:%d", i);
    if(i == CELL_NUM)
    {
        RLOGE("Note that RIL can currently only fetch the first %d cells!", CELL_NUM);
    }


    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, p_cellInfo, i * cellInfo_len);
    int k = 0;
    for(k ; k < i ; k++)
    {
        RLOGD("cellInfo[%d]:cellinfoType:%d,registered:%d,timeStampType:%d,timestamp:%d,mcc:%d,mnc:%d,ci:%x,pci:%x,tac:%x,signalStrength:%d,rsrp:%d,rsrq:%d,rssnr:%d,cqi:%x,timeAdvance:%x",k,\
               p_cellInfo[k].cellInfoType, p_cellInfo[k].registered, p_cellInfo[k].timeStampType, p_cellInfo[k].timeStamp, p_cellInfo[k].CellInfo.lte.cellIdentityLte.mcc, p_cellInfo[k].CellInfo.lte.cellIdentityLte.mnc,\
               p_cellInfo[k].CellInfo.lte.cellIdentityLte.ci, p_cellInfo[k].CellInfo.lte.cellIdentityLte.pci, p_cellInfo[k].CellInfo.lte.cellIdentityLte.tac, \
               p_cellInfo[k].CellInfo.lte.signalStrengthLte.signalStrength, p_cellInfo[k].CellInfo.lte.signalStrengthLte.rsrp, p_cellInfo[k].CellInfo.lte.signalStrengthLte.rsrq, p_cellInfo[k].CellInfo.lte.signalStrengthLte.rssnr,\
               p_cellInfo[k].CellInfo.lte.signalStrengthLte.cqi, p_cellInfo[k].CellInfo.lte.signalStrengthLte.timingAdvance);
        if(ANDROID_7 == Ght_Android_Version || ANDROID_10 == Ght_Android_Version || ANDROID_11 == Ght_Android_Version)
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d ==7 or == 10 or == 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            RLOGD("cellInfo[%d]: earfcn:%d", k, ((RIL_CellInfo_v12 *)p_cellInfo)[k].CellInfo.lte.cellIdentityLte.earfcn);
        }
    }

#if 0
#if defined GHT_FEATURE_ANDROID10X || defined GHT_FEATURE_ANDROID7X

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, p_cellInfo, i * sizeof(RIL_CellInfo_v12));
    int k = 0;
    for(k ; k < i ; k++)
    {
        RLOGD("cellInfo[%d]:cellinfoType:%d,registered:%d,timeStampType:%d,timestamp:%d,mcc:%d,mnc:%d,ci:%x,pci:%x,tac:%x,earfcn:%d,signalStrength:%d,rsrp:%d,rsrq:%d,rssnr:%d,cqi:%x,timeAdvance:%x",k,\
               p_cellInfo[k].cellInfoType,p_cellInfo[k].registered,p_cellInfo[k].timeStampType,p_cellInfo[k].timeStamp,p_cellInfo[k].CellInfo.lte.cellIdentityLte.mcc,p_cellInfo[k].CellInfo.lte.cellIdentityLte.mnc,\
               p_cellInfo[k].CellInfo.lte.cellIdentityLte.ci,p_cellInfo[k].CellInfo.lte.cellIdentityLte.pci,p_cellInfo[k].CellInfo.lte.cellIdentityLte.tac,p_cellInfo[k].CellInfo.lte.cellIdentityLte.earfcn,\
               p_cellInfo[k].CellInfo.lte.signalStrengthLte.signalStrength,p_cellInfo[k].CellInfo.lte.signalStrengthLte.rsrp,p_cellInfo[k].CellInfo.lte.signalStrengthLte.rsrq,p_cellInfo[k].CellInfo.lte.signalStrengthLte.rssnr,\
               p_cellInfo[k].CellInfo.lte.signalStrengthLte.cqi,p_cellInfo[k].CellInfo.lte.signalStrengthLte.timingAdvance);

    }
#else
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, p_cellInfo, i * sizeof(RIL_CellInfo));
    RLOGD("CellInfo:cellinfoType:%d,registered:%d,timeStamp:%d",p_cellInfo->cellInfoType,p_cellInfo->registered,p_cellInfo->timeStamp);
#endif
#endif

    at_response_free(atResponse);
//    free(p_cellInfo);
    RLOGE("requestGetCellInfoList: Done.");
    return;

error:
    RLOGE("requestGetCellInfoList, err = %d", err);
    RLOGE("GTCCINFO:resp[0]=%d, resp[1]=%d, MCC=%d, MNC=%d, LAC=%d, CID=%d, SCRAM_CODE=%d...",resp[0], resp[1], resp[2],resp[3],resp[4],resp[5],resp[6]);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);

    if (atResponse)
    {
        at_response_free(atResponse);
    }
    return ;

}


void requestSetNetworkSelectionAutomatic(RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    int mode;
    char *line = NULL;

    RLOGD("[%s] entered\r\n",__func__);

// <!--added by wangmengying@2017.12.13 for register network failed still need to send cops=0
    if (g_SetNetworkSelectionManual == 1)
    {
        at_send_command_timeout("AT+COPS=0",NULL, TIME_OUT_COPS);
        g_SetNetworkSelectionManual = 0;
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    }
// end-->

// <!--added by wangmengying@2017.12.13 for cops=0 need to send only mode == 1
    err = at_send_command_singleline("AT+COPS?", "+COPS:", &p_response);

    if (err < 0 || p_response->success == 0)
    {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0)
    {
        goto error;
    }

    err = at_tok_nextint(&line, &mode);
    if (err < 0)
    {
        goto error;
    }
    RLOGD("[%s] mode[%d]\r\n",__func__,mode);

    if(1 == mode)
// end-->
    {
// <!--added by wangmengying@2017.12.13 for  cops=0 need long timeout
        at_send_command_timeout("AT+COPS=0",NULL, TIME_OUT_COPS);
// end-->
    }
    at_response_free(p_response);
    //onDeactiveDataCallList();
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;
error:
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    return;
}

/* added by  nodecom aron begin */
void requestSetLocationUpdates(void * data, size_t datalen __unused, RIL_Token t)
{
    /**
     * "data" is int *
     * ((int *)data)[0] is == 1 for updates enabled (+CREG=2)
     * ((int *)data)[0] is == 0 for updates disabled (+CREG=1)
     */
    int err;
    if( ((int *)data)[0] == 1 )
    {
        err = at_send_command("AT+CREG=2",NULL);
    }
    else if(((int *)data)[0] == 0)
    {
        err = at_send_command("AT+CREG=1",NULL);
    }
    else
    {
        goto error;
    }
    if (err < 0)
        goto error;

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    return;
}
void requestScreenState(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    /*
       if ((((int *)data)[0]) == 1)
       {
    //Screen on
    //at_send_command("AT+SIGNALIND=1", NULL);
    at_send_command("AT+NWTYPEIND=1", NULL);
    at_send_command("AT+PSDIALIND=1", NULL);
    }
    else
    {
    //Screen off
    //at_send_command("AT+SIGNALIND=0", NULL);
    at_send_command("AT+NWTYPEIND=0", NULL);
    at_send_command("AT+PSDIALIND=0", NULL);
    }
    */
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}
/* added by  nodecom aron end */


/*add by fibo replace syscall call for ndis dial 20181208*/
int fibo_bring_up_interface_do_dhcp(const char * iname)
{
    int retry = DHCP_MAX_RETRY_NUM;
    int ret = 0;

    do
    {
        RLOGD("%s init", __FUNCTION__);
        ifc_init();
        ifc_up(iname);
        ret = do_dhcp(iname);
        ifc_close();
        RLOGD("%s ret = %d, retry = %d", __FUNCTION__, ret, retry);
    }while (ret && retry--);

    if(ret == -1 && retry == 0)
    {
        RLOGE("We tried %d times, but did not get DHCP information!", DHCP_MAX_RETRY_NUM);
        return RET_FAIL;
    }

    return RET_SUCCESS;
}

int fibo_get_ip(const char *interface, char *ip)
{
#define ETH_ALEN 6
    //ENTER_FUNC;
    int sock, err, i;
    char hwaddr[ETH_ALEN] = {0};
    struct sockaddr_in sin;
    struct ifreq ifr;
    if(interface == NULL || strlen(interface) == 0
    || ip == NULL ){
        RLOGD("fibo %s \r\n","please input interface");
    return -1;
    }
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == -1)
    {
        RLOGD("fibo %s\r\n","socket");
        return -1;
    }
    strncpy(ifr.ifr_name,interface,IFNAMSIZ);
    ifr.ifr_name[IFNAMSIZ - 1] = 0;

    err = ioctl(sock, SIOCGIFADDR, &ifr);
    if (err < 0)
    {
        RLOGD("fibo getip ioctl failure! err:%d, %s", err, strerror(err));
        strncpy(ip,DEFAULTIP,sizeof(DEFAULTIP));
        close(sock);
        return -1;
    }

    memcpy(&sin, &ifr.ifr_addr, sizeof(sin));
    strncpy(ip,inet_ntoa(sin.sin_addr),strlen(inet_ntoa(sin.sin_addr)));
    RLOGD( "fibo get ip %s, if_name:%s, strlen(ifr.ifr_name):%d", inet_ntoa(sin.sin_addr), ifr.ifr_name == NULL?"NULL":ifr.ifr_name, strlen(ifr.ifr_name));

    if (ioctl(sock, SIOCGIFHWADDR, &ifr) < 0) {
        RLOGD("%s: get hwaddr error!", __FUNCTION__);
        return -1;
    }
    memcpy(hwaddr, ifr.ifr_hwaddr.sa_data, ETH_ALEN);

    for(i = 0 ; i < ETH_ALEN; i++)
    {
        RLOGD("%s: get hwaddr[%d]:%02x", __FUNCTION__, i, hwaddr[i]);
    }

    close(sock);
    return 0;
}
/*add end by fibo 20181208*/
void *ndis_main_loop()
{
    int ret = 0;
    for(;;)
    {
        if(ret  == 0) //é»å¡çº¿ç¨
        {
            pthread_mutex_lock(&s_ndismutex);
            ret = pthread_cond_wait(&s_ndiscond, &s_ndismutex);
            pthread_mutex_unlock(&s_ndismutex);
        }
       
        ret =  fibo_bring_up_interface_do_dhcp("usb0");  

        sleep(1);
    }
    return ((void *)0);
}

/*Begin: Deleted by wujiabao in 2022/07/20, because we did not need it*/
#if 0
static int getPreferredNetworkTypeM910()
{
    int err=0;
    int mode = 2;
    char *line;
    ATResponse *p_response = NULL;

    if(mode_flag == GHT_757S)
    {
       err = at_send_command_singleline("AT+MODODR?", "+MODODR:", &p_response); 
    }
    else
    {
        err = at_send_command_singleline("AT+GTRAT?", "+GTRAT:", &p_response);
    }
    if (err < 0|| p_response->success == 0)
      goto done;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0)
      goto done;

    err = at_tok_nextint(&line, &mode);
    if (err < 0)
      goto done;
done:
    at_response_free(p_response);
    return mode;
}
/*
*  return   0 GSM Network;
*           1 NB Network
*/
static int isNBPreferredNetwork(void)
{
    int ret = 0;
    int err = 0;
    ATResponse *p_response = NULL;
    int response = 0;
    char *line;
    char *presponse =NULL;

    isNBCard = 0;
    sleep(3);
    err = at_send_command_singleline("AT+COPS?", "+COPS:", &p_response);
    if (err < 0 || p_response->success == 0)
    {
        goto error;
    }
    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0)goto error;
    RLOGD("isNBPreferredNetwork line :[%s]",line);
    err = at_tok_nextint(&line, &response);
    if (err < 0)goto error;
    RLOGD("isNBPreferredNetwork line1 :[%s] response :[%d]",line,response);
    err = at_tok_nextint(&line, &response);
    if (err < 0)goto error;
    RLOGD("isNBPreferredNetwork line2 :[%s] response :[%d]",line,response);
    err = at_tok_nextstr(&line, &(presponse));
    if (err < 0) goto error;
    RLOGD("isNBPreferredNetwork line3 :[%s] presponse :[%s]",line,presponse);
    err = at_tok_nextint(&line, &response);
    if (err < 0) goto error;
    RLOGD("isNBPreferredNetwork line4 :[%s] response :[%d]",line,response);
    
    ret = 1;
    isNBCard = 1;
    at_response_free(p_response);
    return ret;
error:
    at_response_free(p_response);
    return ret;
}

static int trySet4GNBPreferred(void)
{
    int ret = 1;
    int err = 0;
    ATResponse *p_response = NULL;

    err = at_send_command("AT+GTRAT=9",&p_response);
    if (err < 0 || p_response->success == 0){
        ret = 0;
    }
    RLOGD("networkTrySet4GNBPreferred err[%d] p_response :[%d]",err,p_response->success);
    return ret;
}

void requestSetPreferredNetworkType_M910(void *data, size_t datalen __unused, RIL_Token t)
{
    int err = 0;
    int tryNBPreferredSet=0;
    int isNBNetwork= 0;
    ATResponse *p_response = NULL;
    int setmode = 0,mode = 0;
    char *cmd = NULL;
    setmode = ((int *)data)[0];

    if(mode_flag == GHT_757S)
    {
        switch(setmode)
        {
           /* BEGIN: Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
               case 22:  /* TD-SCDMA/LTE/GSM/WCDMA, CDMA, and EvDo */
               case 12:    /* LTE/WCDMA */
           /* END:   Added by eric.li, 2018/10/17   PN:add support for android7 to handle prefered network */
               case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
               case 8:     /* LTE, CDMA and EvDo */
               case 9:     /* LTE, GSM/WCDMA */
                   mode = 2;
                   break;
               case 6:     /* EvDo only */
               case 2:     /* WCDMA  */
               case 0:     /* GSM/WCDMA (WCDMA preferred) */
               case 3:     /* GSM/WCDMA (auto mode, according to PRL) */
               case 4:     /* CDMA and EvDo (auto mode, according to PRL) */
               case 7:     /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
                   {
                       if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                       {
                           mode = 9;
                       }
                       else if(ODM_CM_OPERATOR == cur_oper)
                       {
                           mode = 6;
                       }
                       else if(ODM_CU_OPERATOR == cur_oper)
                       {
                           mode = 1;
                       }
                   }
                   break;
               case 1:    /* GSM only */
               case 5:    /* CDMA only */
                   {
                       if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                       {
                           mode = 8;
                       }
                       else if(ODM_CM_OPERATOR == cur_oper)
                       {
                           mode = 3;
                       }
                       else if(ODM_CU_OPERATOR == cur_oper)
                       {
                           mode = 3;
                       }
                       else
                       {
                           mode =2;
                       }
                   }
                   break;
               case 11:    /* LTE only */
                   mode = 5;
                   break;

               default:
                   mode = 2;
                   break;
       }
    }
    else if(mode_flag == GHT_M910_GL)
    {
        switch(setmode)
        {
            case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
            case 8:     /* LTE, CDMA and EvDo */
                mode = 10;
                break;
            case 9:     /* LTE, GSM/WCDMA */
                /*fix me how to different NB card from usim card*/
                tryNBPreferredSet = trySet4GNBPreferred();
                isNBNetwork = isNBPreferredNetwork();
                if(tryNBPreferredSet && isNBNetwork){
                        mode = 9;
                }
                else{
                    if((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper)){
                        mode = 3;
                    }
                    else{
                        mode = 0;
                    }
                }
                break;
            case 6:     /* EvDo only */
                mode = 13;
                break;
            case 2:     /* WCDMA  */
                mode = 2;
                break;
            case 0:     /* GSM/WCDMA (WCDMA preferred) */
            case 3:     /* GSM/WCDMA (auto mode, according to PRL) */
                if((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                {
                    mode = 3;
                }
                else
                {
                    mode = 0;
                }
                break;
            case 4:     /* CDMA and EvDo (auto mode, according to PRL) */
                mode = 12;
                break;
            case 7:     /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
                {
                    if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                    {
                        mode = 13;
                    }
                    else if(ODM_CM_OPERATOR == cur_oper)
                    {
                        mode = 7;
                    }
                    else if(ODM_CU_OPERATOR == cur_oper)
                    {
                        mode = 2;
                    }
                }
                break;
            case 1:    /* GSM only */
                mode = 0;
                break;
            case 5:    /* CDMA only */
                mode = 11;
                break;
            case 11:    /* LTE only */
                mode = 3;
                break;
            default:
                mode = 10;
                break;
        }
    }
    // <!--[ODM]wangmengying@2019.10.31 bug33035,switch RAT
    else
    {
        switch(setmode)
        {
            case 10:    /* LTE, CDMA, EvDo, GSM/WCDMA */
            case 8:     /* LTE, CDMA and EvDo */
            case 9:     /* LTE, GSM/WCDMA */
                mode = 10;
                break;
            case 0:     /* GSM/WCDMA (WCDMA preferred) */
            case 3:     /* GSM/WCDMA (auto mode, according to PRL) */
            case 1:    /* GSM only */
            case 7:     /* GSM/WCDMA, CDMA, and EvDo (auto mode, according to PRL) */
                mode = 0;
                break;
            case 11:    /* LTE only */
                mode = 3;
                break;
            default:
                mode = 10;
                break;
        }
    }
    // end-->
    if(mode != getPreferredNetworkTypeM910())
    {
        RLOGD("requestSetPreferredNetworkType setmode=%d, mode=%d",setmode, mode);
        // <!--[ODM]wangmengying@2019.10.31 bug29134,2G switch 4G, need to disconnect ppp first
        if (GHT_MA510_GL == mode_flag)
        {
            onDeactiveDataCallList();
        }
        // end-->

        if(mode_flag == GHT_757S)
        {
            asprintf(&cmd,"AT+MODODR=%d",mode);
        }
        else
        {
            asprintf(&cmd,"AT+GTRAT=%d",mode);
        }
        err = at_send_command(cmd,&p_response);
        free(cmd);
        onDeactiveDataCallList();
        if (err < 0 || p_response->success == 0)
        {
            goto error;
        }
    }

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, sizeof(int));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);

}

void requestGetPreferredNetworkTypeM910(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    int response = 0;
    int responsenet=0;
    char *line;

    if(mode_flag == GHT_757S)
    {
        err = at_send_command_singleline("AT+MODODR?", "+MODODR:", &p_response);
    }
    else
    {
        err = at_send_command_singleline("AT+GTRAT?", "+GTRAT:", &p_response); 
    }
   
    if (err < 0 || p_response->success == 0)
    {
        goto error;
    }
    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0)
    {
        goto error;
    }
    err = at_tok_nextint(&line, &responsenet);
    if (err < 0)
    {
        goto error;
    }
    switch(responsenet)
    {
        case 0:        /*GSM*/
            response = PREF_NET_TYPE_GSM_ONLY;
            break;
        case 1:        /*GSM/UMTS*/
            response = PREF_NET_TYPE_GSM_WCDMA;
            break;
        case 2:        /*UMTS*/
            response = PREF_NET_TYPE_WCDMA;
            break; 
        case 3:        /*LTE*/
            response = PREF_NET_TYPE_LTE_ONLY;
            break;
        case 4:        /*LTE/UMTS*/
            response = PREF_NET_TYPE_LTE_WCDMA;
            break;
        case 5:        /*LTE/GSM*/
            response = PREF_NET_TYPE_LTE_GSM_WCDMA;
            break;
        case 6:        /*LTE/UMTS/GSM*/
            response = PREF_NET_TYPE_LTE_GSM_WCDMA;
            break;
        case 7:        /*TD-SCDMA*/
            response = PREF_NET_TYPE_WCDMA;
            break;
        case 8:        /*eMTC*/
        case 9:        /*NB-IoT*/ 
            response = PREF_NET_TYPE_LTE_ONLY;
            break;
        case 10:       /*Automatic*/
            response = PREF_NET_TYPE_LTE_CMDA_EVDO_GSM_WCDMA;
            break;
        case 11:       /*CDMA*/
            response = PREF_NET_TYPE_CDMA_ONLY;
            break;
        case 12:       /*CDMA/EVDO*/
            response = PREF_NET_TYPE_CDMA_EVDO_AUTO;
            break;
        case 13:       /*EVDO*/
            response = PREF_NET_TYPE_EVDO_ONLY;
            break;
        default:
            goto error;
            break;
    }
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);

}

void requestRegistrationStateM910(int request, void *data __unused,size_t datalen __unused, RIL_Token t)
{
    int err;
    int *registration = NULL;
    char **responseStr = NULL;
    ATResponse *p_response = NULL;
    const char *cmd;
    const char *prefix;
    char *line;
    int j, numElements = 0;
    int count = 3;
    int type = 0;
    int startfrom;

    if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE) {
        if ((g_cops_lte == 7)||(g_cops_lte == 12)||(g_cops_lte == 11))
        {
            cmd = "AT+CEREG?";
            prefix = "+CEREG:";
        }
        //add by zhengjianrong for MA510 Ril begin
        else if((g_cops_lte == 9) && (mode_flag == GHT_MA510_GL))
        {
            cmd = "AT+CEREG?";
            prefix = "+CEREG:";
        }
        //add by zhengjianrong for MA510 Ril end
        else if((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
        {
            cmd = "AT+CGREG?";
            prefix = "+CGREG:";
        }
        else
        {
            cmd = "AT+CREG?";
            prefix = "+CREG:";
        }
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        numElements = 15;
#else
        numElements = 4;
#endif
    } 
    else if (request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
        if ((g_cops_lte == 7)||(g_cops_lte == 12)||(g_cops_lte == 11))
        {
            cmd = "AT+CEREG?";
            prefix = "+CEREG:";
        }
        //add by zhengjianrong for MA510 Ril begin
        else if((g_cops_lte == 9) && (mode_flag == GHT_MA510_GL))
        {
            cmd = "AT+CEREG?";
            prefix = "+CEREG:";
        }
        //add by zhengjianrong for MA510 Ril end
        else
        {
            if (mode_flag == GHT_MA510_GL)
            {
                cmd = "AT+CREG?";
                prefix = "+CREG:";
            }
            else
            {
                cmd = "AT+CGREG?";
                prefix = "+CGREG:";
            }
        }
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        numElements = 6;
#else
        numElements = 4;
#endif
    } else {
        assert(0);
        goto error;
    }

    err = at_send_command_singleline(cmd, prefix, &p_response);

    if ((err != 0) || (p_response->success == 0) ) goto error;

    line = p_response->p_intermediates->line;

    if (parseRegistrationState(line, &type, &count, &registration)) goto error;

    responseStr = malloc(numElements * sizeof(char *));
    if (!responseStr) goto error;
    memset(responseStr, 0, numElements * sizeof(char *));
    /**
     * The first '4' bytes for both registration states remain the same.
     * But if the request is 'DATA_REGISTRATION_STATE',
     * the 5th and 6th byte(s) are optional.
     */
    startfrom = 0;
    asprintf(&responseStr[1], "%x", registration[1]);
    asprintf(&responseStr[2], "%x", registration[2]);
    if (count > 3) {
        switch(registration[3])
        {
             /* AT response */
             // 0 GSM 
             // 2 UTRAN 
             // 3 GSM w/EGPRS 
             // 4 UTRAN w/HSDPA 
             // 5 UTRAN w/HSUPA 
             // 6 UTRAN w/HSDPA and HSUPA 
             case 0:
                 registration[3] = RADIO_TECH_GPRS;
                 break;
             case 1:
                 registration[3] = RADIO_TECH_GPRS;
                 break;
             case 2:
                 registration[3] = RADIO_TECH_UMTS;
                 break;
             case 3:
                 registration[3] = RADIO_TECH_EDGE;
                 break;
             case 4:
                 registration[3] = RADIO_TECH_HSDPA;
                 break;
             case 5:
                 registration[3] = RADIO_TECH_HSUPA;
                 break;
             case 6:
                 registration[3] = RADIO_TECH_HSPA;
                 break;
             case 7:
             case 9:
             case 12:
             // <!--added by wangmengying@2018.8.28 for add EMTC networktype
             case 11:
             // end--!>
                 registration[3] = RADIO_TECH_LTE;

                 break;
             case 8:
                 registration[3] = RADIO_TECH_HSPAP;
             default:
                 registration[3] = RADIO_TECH_UNKNOWN;
                 break;
        }
       asprintf(&responseStr[3], "%d", registration[3]);
       RLOGD("registration[3] == %d\r\n",registration[3]);
    }
    if (request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
    {
        if (registration[0] == 6)
        {
            registration[0] = 1;
            RLOGD("registration[0] ==  %d \r\n",registration[0] );
        }
    }
    asprintf(&responseStr[0], "%d", registration[0]);
    RLOGD("registration[0] == %d\r\n",registration[0]);
    free(registration);
    registration = NULL;
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    if(request == RIL_REQUEST_DATA_REGISTRATION_STATE) {
        asprintf(&responseStr[4],"%d", 0);
        asprintf(&responseStr[5],"%d",1);
    }
    else if(request == RIL_REQUEST_VOICE_REGISTRATION_STATE)
    {
         for(j = 4 ; j < numElements;j++)
         {
            asprintf(&responseStr[j],"%d", 0);
         }
    }
#else
    for (j = startfrom; j < numElements; j++)
    {
        if (!responseStr[j])
        {
            //RLOGD("[%s,%d],j[%d]\r",__FUNCTION__, __LINE__, j);
            //goto error;
            asprintf(&responseStr[j],"%d", 0);
        }
    }
#endif
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, numElements*sizeof(responseStr));
    for (j = 0; j < numElements; j++ ) {
        free(responseStr[j]);
        responseStr[j] = NULL;
    }
    free(responseStr);
    responseStr = NULL;
    at_response_free(p_response);
    return;

error:
    if (responseStr) {
        for (j = 0; j < numElements; j++) {
            free(responseStr[j]);
            responseStr[j] = NULL;
        }
        free(responseStr);
        responseStr = NULL;
    }
    RLOGD("RequestRegistrationState must never return an error when radio is on");
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);

}

static int parseRegistrationStateM910(char *str, int *type __unused, int *items, int **response)
{
    int err;
    char *line = str, *p;
    int *resp = NULL;
    int skip;
    int count = 3;
    int commas;

    RLOGD("parseRegistrationState. Parsing: %s",str);
    err = at_tok_start(&line);
    if (err < 0) goto error;

    /* Ok you have to be careful here
     * The solicited version of the CREG response is
     * +CREG: n, stat, [lac, cid]
     * and the unsolicited version is
     * +CREG: stat, [lac, cid]
     * The <n> parameter is basically "is unsolicited creg on?"
     * which it should always be
     *
     * Now we should normally get the solicited version here,
     * but the unsolicited version could have snuck in
     * so we have to handle both
     *
     * Also since the LAC and CID are only reported when registered,
     * we can have 1, 2, 3, or 4 arguments here
     *
     * finally, a +CGREG: answer may have a fifth value that corresponds
     * to the network type, as in;
     *
     *   +CGREG: n, stat [,lac, cid [,networkType]]
     */
    /* count number of commas */
    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }
    RLOGD("parseRegistrationState. commas: %d",commas);
    resp = (int *)calloc(commas + 1, sizeof(int));
    if (!resp) goto error;
    switch (commas) {
        case 0: /* +CREG: <stat> */
            err = at_tok_nextint(&line, &resp[0]);
            if (err < 0) goto error;
            resp[1] = -1;
            resp[2] = -1;
            break;
            
            case 1: /* +CREG: <n>, <stat> */
                err = at_tok_nextint(&line, &skip);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                resp[1] = -1;
                resp[2] = -1;
                if (err < 0) goto error;
                break;
                
            case 2: /* +CREG: <stat>, <lac>, <cid> */
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[1]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[2]);
                if (err < 0) goto error;
                break;
            case 3: /* +CREG: <n>, <stat>, <lac>, <cid> */
                err = at_tok_nextint(&line, &skip);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[1]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[2]);
                if (err < 0) goto error;
                break;
            /* special case for CGREG, there is a fourth parameter
             * that is the network type (unknown/gprs/edge/umts)
             */
            case 4: /* +CGREG: <n>, <stat>, <lac>, <cid>, <networkType> */
            //case 5: /* +CGREG: <n>, <stat>, <lac>, <cid>, <networkType> */
                err = at_tok_nextint(&line, &skip);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[1]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[2]);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[3]);
                if (err < 0) goto error;
                count = 4;
                break;
            case 5: /* +CEREG: <n>, <stat>, <lac>, <mmd>, <cid>, <networkType> */
                err = at_tok_nextint(&line, &skip);
                if (err < 0) goto error;
                err = at_tok_nextint(&line, &resp[0]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[1]);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &skip);
                if (err < 0) goto error;
                err = at_tok_nexthexint(&line, &resp[2]);
                if (err < 0) goto error;
//#ifdef GHT_FEATURE_ANDROID8X
                err = at_tok_nexthexint(&line, &resp[3]);
                if (err < 0) goto error;
//#else
//                err = at_tok_nextint(&line, &resp[3]);
//                if (err < 0) goto error;
//#endif
                count = 4;
                
                RLOGD("resp[] == %d, %d, %d, %d",resp[0], resp[1], resp[2], resp[3]);
                break;
            default:
                goto error;
            }
    if (response)
        *response = resp;
    if (items)
        *items = commas + 1;
    return 0;
error:
    free(resp);
    return -1;
}

int odm_get_current_network_type_m910()
{
    int err;
    int response = 0;
    const char *cmd;
    const char *prefix;
    char *line;
    int *registration = NULL;
    int count = 0;
    int type = 0;
    ATResponse *p_response = NULL;

// <!--added by wangmengying@2018.8.28 for add EMTC networktype
    if ((g_cops_lte == 7)||(g_cops_lte == 12)||(g_cops_lte == 11))
// end--!>
    {
        cmd = "AT+CEREG?";
        prefix = "+CEREG:";
    }
    //add by zhengjianrong for MA510 Ril begin
    else if((g_cops_lte == 9) && (mode_flag == GHT_MA510_GL))
    {
        cmd = "AT+CEREG?";
        prefix = "+CEREG:";
    }
    //add by zhengjianrong for MA510 Ril end
    else
    {
        if (mode_flag == GHT_MA510_GL)
        {
            cmd = "AT+CREG?";
            prefix = "+CREG:";
        }
        else
        {
            cmd = "AT+CGREG?";
            prefix = "+CGREG:";
        }
    }
    err = at_send_command_singleline(cmd, prefix, &p_response);

    if ((err != 0) || (p_response->success == 0) ) goto error;

    line = p_response->p_intermediates->line;

    if (parseRegistrationStateM910(line, &type, &count, &registration)) goto error;

    if (NULL == registration)
    {
        goto error;
    }

    if(count > 3){
        switch(registration[3])
        {
             /* AT response */
             // 0 GSM 
             // 2 UTRAN 
             // 3 GSM w/EGPRS 
             // 4 UTRAN w/HSDPA 
             // 5 UTRAN w/HSUPA 
             // 6 UTRAN w/HSDPA and HSUPA 
             case 0:
                 response = RADIO_TECH_GPRS;
                 break;
             case 1:
                 response = RADIO_TECH_GPRS;
                 break;
             case 2:
                 response = RADIO_TECH_UMTS;
                 break;
             case 3:
                 response = RADIO_TECH_EDGE;
                 break;
             case 4:
                 response = RADIO_TECH_HSDPA;
                 break;
             case 5:
                 response = RADIO_TECH_HSUPA;
                 break;
             case 6:
                 response = RADIO_TECH_HSPA;
                 break;
             case 7:
             case 9:
             case 12:
             // <!--added by wangmengying@2018.8.28 for add EMTC networktype
             case 11:
             // end--!>
                 response = RADIO_TECH_LTE;

                 break;
             case 8:
                 response = RADIO_TECH_HSPAP;
             default:
                 response = RADIO_TECH_UNKNOWN;
                 break;
        }
    }
    free(registration);
    registration = NULL;
    at_response_free(p_response);
    
    RLOGD("network type %d",response);
    return response;

error:
    at_response_free(p_response);
    return 0;
}

//<!--added by wangmengying@2019.11.26 for fix bug34926 MA510 query network registration status
int odm_get_current_network_type_ma510()
{
    int err;
    int response = 0;
    char *line;
    int registration[4] = {0};
    ATResponse *p_response = NULL;

    err = at_send_command_singleline("AT+COPS?", "+COPS:", &p_response);
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &registration[0]);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &registration[1]);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &registration[2]);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &registration[3]);

        switch(registration[3])
        {
             /* AT response */
             // 0 GSM
             // 2 UTRAN
             // 3 GSM w/EGPRS
             // 4 UTRAN w/HSDPA
             // 5 UTRAN w/HSUPA
             // 6 UTRAN w/HSDPA and HSUPA
             case 0:
                 response = RADIO_TECH_GPRS;
                 break;
             case 1:
                 response = RADIO_TECH_GPRS;
                 break;
             case 2:
                 response = RADIO_TECH_UMTS;
                 break;
             case 3:
                 response = RADIO_TECH_EDGE;
                 break;
             case 4:
                 response = RADIO_TECH_HSDPA;
                 break;
             case 5:
                 response = RADIO_TECH_HSUPA;
                 break;
             case 6:
                 response = RADIO_TECH_HSPA;
                 break;
             case 7:
             case 9:
                 response = RADIO_TECH_LTE;
                 break;
             default:
                 response = RADIO_TECH_UNKNOWN;
                 break;
        }
    }
    at_response_free(p_response);

    RLOGD("network type %d",response);
    return response;

error:
    at_response_free(p_response);
    return 0;
}
//end--!>

static int setupDataCallRASModeM910(char**response_local_ip,const char* apn,const char* auth_type,const char* username,const  char* password,const char* pdp_type)
{
#define SUCCESS 0
#define ERROR 1
#define PPP_ERROR 2
    int fd;
    char buffer[20];
    char exit_code[PROPERTY_VALUE_MAX]={0};
    static char local_ip[PROPERTY_VALUE_MAX]={0};
    static char local_pdns[PROPERTY_VALUE_MAX]={0};
    static char local_sdns[PROPERTY_VALUE_MAX]={0};
    int retry = POLL_PPP_SYSFS_RETRY;
    char apntype[PROPERTY_VALUE_MAX];
    ATResponse *p_response = NULL;
    int err = 0;
    char*cmd;
    int network_type = 0;
    char datachannel[PROPERTY_VALUE_MAX]={0};

    property_get("ril.datachannel",datachannel,"");
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    ril_kill_pppd(0);      
#else    
    RLOGD("******** Enter setupDataCallRASMode ********");
//<!--added by wangmengying@2018.8.22 for avoid ppp dial
    asprintf(&cmd, "busybox pkill /system/bin/pppd");
    RLOGD("setupDataCallRASMode :%s",cmd);
    system(cmd);
    free(cmd);
// end--!>
#endif
    err = at_send_command("ATH", NULL);
    property_set("ctl.stop", SERVICE_PPPD_GPRS);
    //sleep(3);

    if(isNBCard){
        RLOGD("do nothing NB Card do not need apn settins");
        asprintf(&cmd, "AT+CGDCONT=%d,\"ip\"", cus_cid);
        err = at_send_command(cmd, NULL);
        free(cmd);
    }
    else{
        asprintf(&cmd, "AT+CGDCONT=%d,\"%s\",\"%s\",,0,0", cus_cid, pdp_type, apn);
        err = at_send_command(cmd, NULL);
        free(cmd);
    }
 
    if (ODM_CT_OPERATOR_3G == cur_oper)
    {

        asprintf(&cmd, "AT^PPPCFG=\"%s\",\"%s\"", username, password);
        err = at_send_command(cmd, NULL);
        free(cmd);
    }
    if((username != NULL ) && ( password != NULL))
    {
        if((username != NULL) && (password != NULL))
        {
            asprintf(&cmd, "AT$QCPDPP=1,%s,\"%s\",\"%s\"", auth_type, password, username);
            err = at_send_command(cmd, NULL);
            free(cmd);
        }
        property_set("net.ppp0.user", username);
        property_set("net.ppp0.password", password);
    }
    // Start data on PDP context 1
    //err = at_send_command("ATD*99***1#", &p_response);
    RLOGD("@@setupDataCallRASMode DATA CALL DEBUG1 script_type %d",script_type);
    // Setup PPP connection after PDP Context activated successfully
    // The ppp service name is specified in /init.rc
    property_set(PROPERTY_PPPD_EXIT_CODE, "");
    if(0 == script_type)
    {
        do {
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }
            //ppp_fd = open(datachannel, O_RDWR);
            ppp_fd = open(datachannel, O_RDWR | O_NONBLOCK | O_NOCTTY);
            RLOGD("setupDataCallRASMode: ppp_fd=%d errno:[%d]", ppp_fd,errno);
            if (ppp_fd > 0)
            {
                struct termios ios;
                tcgetattr(ppp_fd, &ios);
                ios.c_lflag = 0;
                ios.c_oflag &= (~ONLCR);
                ios.c_iflag &= (~(ICRNL | INLCR));
                ios.c_iflag |= (IGNCR | IXOFF);
                ios.c_cc[VTIME] = 10;
                ios.c_cc[VMIN] = 0;
                tcsetattr(ppp_fd, TCSANOW, &ios);
                tcflush(ppp_fd, TCIOFLUSH);

                if (GHT_MA510_GL == mode_flag)
                {
                    network_type = odm_get_current_network_type_ma510();
                }
                else
                {
                    network_type = odm_get_current_network_type_m910();
                }
                if(!network_type)
                {
                    RLOGD("No service,can not setup data call");
                    if(ppp_fd > 0)
                    {
                        close(ppp_fd);
                        ppp_fd = -1;
                    }
                    goto error;
                }
                else if(6 == network_type||7 == network_type || 13 == network_type)
                {
                    err = at_send_command_dial(ppp_fd, "ATD#777");
                }
                else
                {
                    err = at_send_command_dial(ppp_fd, "ATD*99#");
                    err = dial_at_modem(ppp_fd);
                }
                if (err < 0 || err == 1)
                {
                    RLOGD("send dial command failed!");
                    close(ppp_fd);
                    sleep(1);
                    continue;
                }
                break;
            }
            else
            {
                close(ppp_fd);
                ppp_fd = -1;
                RLOGD("retry %d after %d seconds", retry, POLL_PPP_SYSFS_SECONDS);
                sleep(POLL_PPP_SYSFS_SECONDS);
            }
        }while(--retry);

        if ((ppp_fd < 0) && (retry == 0))
        {
            close(ppp_fd);
            ppp_fd = -1;
            RLOGD("open ppp_fd fail!");
            goto error;
        }
        if(!network_type)
        {
            RLOGD("No service,can not setup data call");
            if(ppp_fd > 0)
            {
                close(ppp_fd);
                ppp_fd = -1;
            }
            goto error;
        }
        else if(6 == network_type||7 == network_type || 13 == network_type)
        {
            sleep(1);
            if (0 == strcmp(auth_type,"1"))
            {
                asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns debug ipcp-accept-local ipcp-accept-remote defaultroute -chap",datachannel,username,password);
            }
            else
            {
                asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns debug ipcp-accept-local ipcp-accept-remote defaultroute",datachannel,username,password);
            }
        }
        else
        {
            sleep(1);
            if((username != NULL) && (password != NULL))
            {
              asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts user %s password %s usepeerdns debug ipcp-accept-local ipcp-accept-remote defaultroute",datachannel,username,password);
            }
            else
            {
              asprintf(&cmd, "/system/bin/pppd %s 115200 nocrtscts usepeerdns debug ipcp-accept-local ipcp-accept-remote defaultroute",datachannel);
            }
        }
        RLOGD("%s",cmd);
        system(cmd);
        free(cmd);
        gPid_pppd_live = get_pid("pppd");
        if (gPid_pppd_died  == gPid_pppd_live){
            RLOGD("!!!!!!!!!!!pppd call failed as kill pppd failed, gPid_pppd_died[%d]", gPid_pppd_died);
        }
        else{
            RLOGD(" gPid_pppd_died[%d], gPid_pppd_live[%d]", gPid_pppd_died, gPid_pppd_live);
        }
    }
    
    // <!--modified by wangyi@2018.07.14 for optimizing RIL function modules
    // set 'pppd' flag here, ppp main loop will detect PPP OperState in parallel with Dial procedure, it risk and no point.
    // move the setting after retrieving IP address seems better.
    //pppd = 1;
    // end-->
    sleep(3);
    retry = 3;

    // Wait for PPP interface ready
    do
    {
        // Check whether PPPD exit abnormally
        property_get(PROPERTY_PPPD_EXIT_CODE, exit_code, "");
        if(strcmp(exit_code, "") != 0)
        {
            RLOGD("PPPd exit with code %s", exit_code);
            retry = 0;
            break;
        }

        fd  = open(PPP_OPERSTATE_PATH, O_RDONLY);
        if (fd >= 0)
        {
            memset(buffer,0,sizeof(buffer));
            read(fd, buffer, sizeof(buffer));       
            close(fd);
            if(!strncmp(buffer, "up", strlen("up")) || !strncmp(buffer, "unknown", strlen("unknown")))
            {
                // Should already get local IP address from PPP link after IPCP negotation
                // system property net.ppp0.local-ip is created by PPPD in "ip-up" script
                local_ip[0] = 0;

                property_get("net.ppp0.local-ip", local_ip, "");
                property_get("net.ppp0.dns1", local_pdns, "");
                property_get("net.ppp0.dns2", local_sdns, "");
                RLOGD("local_pdns:%s",local_pdns);
                RLOGD("local_sdns:%s",local_sdns);
                RLOGD("local_ip:%s",local_ip);


                if ((!strcmp(apntype, "mms")))
                {
                    if((!strcmp(local_ip, "")))
                    {
                        RLOGD("PPP link is up but no local IP is assigned. Will retry %d times after %d seconds", \
                                retry, POLL_PPP_SYSFS_SECONDS);
                    }
                    else
                    {
                        RLOGD("PPP link is up with local IP address %s", local_ip);
                        // other info like dns will be passed to framework via property (set in ip-up script)
                        //response[2] = local_ip;
                        *response_local_ip = local_ip;
                        // now we think PPPd is ready
                        break;
                    }
                }
                else
                {
                    if((!strcmp(local_ip, "")) || (!strcmp(local_ip, "0.0.0.0")))

                        //end-->
                    {
                        RLOGD("PPP link is up but no local IP is assigned. Will retry %d times after %d seconds", \
                                retry, POLL_PPP_SYSFS_SECONDS);
                    }
                    else
                    {
                        RLOGD("PPP link is up with local IP address %s", local_ip);
                        // other info like dns will be passed to framework via property (set in ip-up script)
                        //response[2] = local_ip;
                        *response_local_ip = local_ip;
                        // now we think PPPd is ready
                        break;
                    }
                }

            }
            else
            {
                RLOGD("PPP link status in %s is %s. Will retry %d times", \
                        PPP_OPERSTATE_PATH, buffer, retry);
            }
        }
        else
        {
            RLOGD("Can not detect PPP state in %s. Will retry %d times after %d seconds", \
                    PPP_OPERSTATE_PATH, retry-1, POLL_PPP_SYSFS_SECONDS);
        }
        sleep(POLL_PPP_SYSFS_SECONDS-1);
    }while (--retry);

    
    // <!--modified by wangyi@2018.07.14 for optimizing RIL function modules
    // no matter IP address abtain successfully or fail, set pppd flag, thread protect is not necessary
    pppd = 1;
    // end-->

    if(retry == 0)
    {
        goto ppp_error;
    }

    close(ppp_fd);
    ppp_fd = -1;

    at_response_free(p_response);
    return SUCCESS;
error:
    close(ppp_fd);
    ppp_fd = -1;
    at_response_free(p_response);
    return ERROR;
ppp_error:
    close(ppp_fd);
    ppp_fd = -1;
    at_response_free(p_response);
    return PPP_ERROR;

}

void requestSetInitialAttachAPNM910(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestOperatorM910(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    int i;
    int skip;
    ATLine *p_cur;
    char *response[3];
    int network_debounce_time = 20;
#if 1 //fibocom
    __requestOperator_restart:
#endif
    memset(response, 0, sizeof(response));

    ATResponse *p_response = NULL;

    err = at_send_command_multiline(
            "AT+COPS=3,0;+COPS?;+COPS=3,1;+COPS?;+COPS=3,2;+COPS?",
            "+COPS:", &p_response);

    /* we expect 3 lines here:
     * +COPS: 0,0,"T - Mobile"
     * +COPS: 0,1,"TMO"
     * +COPS: 0,2,"310170"
     */

    if ( err < 0 || p_response->success == 0) goto error;

    for (i = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL
            ; p_cur = p_cur->p_next, i++
        )
    {
        char *line = p_cur->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &skip);
        if (err < 0) goto error;

        // If we're unregistered, we may just get
        // a "+COPS: 0" response
        if (!at_tok_hasmore(&line))
        {
            response[i] = NULL;
            g_cops_lte = -1;
            continue;
        }

        err = at_tok_nextint(&line, &skip);
        if (err < 0) goto error;

        // a "+COPS: 0, n" response is also possible
        if (!at_tok_hasmore(&line))
        {
            response[i] = NULL;
            g_cops_lte = -1;
            continue;
        }

        err = at_tok_nextstr(&line, &(response[i]));
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &g_cops_lte);
        if (err < 0) goto error;
    }

    if (i != 3)
    {
        /* expect 3 lines exactly */
        goto error;
        g_cops_lte = -1;
    }

    RLOGD("requestOperator:[%s,%s,%s]",response[0],response[1],response[2]);
#if 1
    if(!response[0] && !response[1] && !response[2] && (network_debounce_time > 0)){
        sleep(1);
        network_debounce_time--;
        at_response_free(p_response);
        goto __requestOperator_restart;
    }
    network_debounce_time = 0;
#endif
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
    at_response_free(p_response);

    return;
error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}
#else
static int getPreferredNetworkTypeM910()
{
    return 0;
}
/*
*  return   0 GSM Network;
*           1 NB Network
*/
static int isNBPreferredNetwork(void)
{
    return 0;
}

static int trySet4GNBPreferred(void)
{
    return 0;
}

void requestSetPreferredNetworkType_M910(void *data, size_t datalen __unused, RIL_Token t)
{
}

void requestGetPreferredNetworkTypeM910(void *data __unused, size_t datalen __unused, RIL_Token t)
{
}

void requestRegistrationStateM910(int request, void *data __unused,size_t datalen __unused, RIL_Token t)
{
}

static int parseRegistrationStateM910(char *str, int *type __unused, int *items, int **response)
{
    return 0;
}

int odm_get_current_network_type_m910()
{
    return 0;
}

//<!--added by wangmengying@2019.11.26 for fix bug34926 MA510 query network registration status
int odm_get_current_network_type_ma510()
{
    return 0;
}
//end--!>

static int setupDataCallRASModeM910(char**response_local_ip,const char* apn,const char* auth_type,const char* username,const  char* password,const char* pdp_type)
{
    return 0;
}

void requestSetInitialAttachAPNM910(void *data __unused, size_t datalen __unused, RIL_Token t)
{

}

void requestOperatorM910(void *data __unused, size_t datalen __unused, RIL_Token t)
{
}

#endif
/*End: Deleted by wujiabao in 2022/07/20, because we did not need it*/
