/*************************************************************************
    Copyright (C)2015-2017 Fibocom Wireless Inc. All rights reserved
     File Name: pingtimer.c
     Author: LiuQiFeng
     Mail: liuqf@fibocom.com
     Created Time: Thu 25 Jan 2018 09:29:46 PM
     History:
     Date        Author       Comment:
     --------------------------------------------------------------------
                 LiuQiFeng
 ************************************************************************/

#include<stdio.h>
#include<errno.h>
#include "fibo_ping.h"

int go_ping()
{
        int i = 0;
        while(i < ping_retry)
        {
                pid_t pid;
                if ((pid = vfork()) < 0)
                {
                        RLOGD("vfork error");
                        exit(1);
                }
                else if (pid == 0)
                {
                        if ( execlp("ping", "ping", ping_args , ping_url, (char*)0) < 0)
                        {
                                RLOGD("execlp error\n");
                                exit(1);
                        }
                }

                int stat;
                waitpid(pid, &stat, 0);

                if (stat == 0)
                {
                        return 0;
                }
                sleep(3);
                i++;
        }
        return -1;
}

static char *get_from_shell(char *shell_cmd)
{
    FILE *fstream=NULL;
    char buff[1024];
    static char cmd[1024];
    int i = 0;
    int j = 0;
    memset(buff,0,sizeof(buff));
    memset(cmd,0,sizeof(cmd));

    if(NULL==(fstream=popen(shell_cmd,"r")))
    {
        RLOGD("execute command failed: %s",strerror(errno));
        return NULL;
    }

    if(NULL!=fgets(buff, sizeof(buff), fstream))
    {
        // printf("%s",buff);
    }
    else
    {
        pclose(fstream);
        return NULL;
    }

    pclose(fstream);
    for (i = 0; i <= strlen(buff); i++)
    {
        if ('\n' == buff[i])
        {
            break;
        }
        else
        {
            if ('\t' == buff[i])
            {
                return cmd;
            }
            cmd[j] = buff[i];
            j++;
        }
    }
    return cmd;
}

void g_on_timer(int sig)
{
    int ret ;
    char *date = NULL;
    char *cmd = NULL;

    date = get_from_shell("date +%Y_%m_%d_%H_%M_%S");
    RLOGD("[fibo_ping] try to ping %s...", ping_url);
    ret = go_ping();
    if (ret == 0)
    {
        fibocom_pingcounter = 0;
        RLOGD("[fibo_ping] ping %s success! date:%s, and set counter to 0!", ping_url, date);
    }
    else if (ret == -1)
    {
        //TODO: Added commands for querying information about CPIN, COPS, CSQ, CGDCONT, and GTRNDIS
        fibocom_pingcounter ++;
        RLOGD("[fibo_ping] ping %s failed! date:%s, failure_counter:%d/%d", ping_url, date, fibocom_pingcounter, RESTART_THRESHOLD);
        if (fibocom_pingcounter == RESTART_THRESHOLD)
        {
            #if 1
            RLOGD("[fibo_ping] The number of failures has reached %d. The module will be restarted!", RESTART_THRESHOLD);

            at_send_command("AT+CFUN=15", NULL);
            fibocom_pingflag = 0;
            fibocom_pingcounter = 0;

            #else
            asprintf(&cmd, "echo \"%s\" >> /data/pingfile", date);
            fibocom_pingcounter = 0;
            system("/system/bin/reboot");
            system(cmd);
            free(cmd);
            #endif
        }
        else
        {
            #if 0
            system("/system/bin/svc data disable");
            asprintf(&cmd, "echo \"%s\"+%d >> /data/pingfile", date,fibocom_pingcounter);
            system(cmd);
            free(cmd);
            RLOGD("[%d] fibocom_data disable\r\n",__func__);
            #endif
        }
    }
    return;
}

void get_ping_args()
{
    int ret;
    char *ping_str = NULL;

    ping_str = (char *)malloc(sizeof(char) * KEYVALLEN);
    ret = getProfileString("PING", "PINGARGS", ping_str, "-c 1 -W 10 -s 4");

    if(!strncmp(ping_str, "ping", strlen("ping")))
    {
        RLOGD("ping_str start with 'ping', so remove 'ping'!");
        ping_str += 4;
    }
    l_trim(ping_args, ping_str);

    ret = getProfileString("PING", "PINGURL", ping_url, "www.fibocom.com");

    RLOGD("ping_args:%s", ping_args);
    RLOGD("ping_url:%s",  ping_url);
}

void pingLoop()
{
    RLOGD("[%s,%d] E", __FUNCTION__, __LINE__);
    static int round = 0;

    ping_retry    = getProfileInt32("PING", "PINGRETRY", 1);
    ping_interval = getProfileInt32("PING", "PINGINTERVAL", 60);
    RLOGD("[%s,%d] ping_interval:%d, ping_retry:%d", __FUNCTION__, __LINE__, ping_interval, ping_retry);

    get_ping_args();

    for(;;)
    {
        RLOGD("[fibo_ping] [%s,%d] fibocom_pingflag:%d", __FUNCTION__, __LINE__, fibocom_pingflag);
        if(fibocom_pingflag)
        {
            RLOGD("[fibo_ping] Round %d", round++);
            g_on_timer(0);
        }

        sleep(ping_interval);
    }

    RLOGD("[%s,%d] X", __FUNCTION__, __LINE__);
}

void fibocom_start_timer()
{
    if (fibocom_pingflag == 0)
    {
        signal(SIGALRM, g_on_timer);
#if 0
        g_tmval.it_value.tv_sec = TIMER10*60;
#else
        g_tmval.it_value.tv_sec = TIMER5*30;
#endif
        g_tmval.it_value.tv_usec = 0;
        g_tmval.it_interval = g_tmval.it_value;
        setitimer(ITIMER_REAL, &g_tmval, NULL);
        fibocom_pingflag = 1;
        RLOGD("%s: start first timer after fiveMinutes will reboot ended[%d]####",__func__,fibocom_pingflag);
    }
}

void fibocom_new_timer(int tv_sec)
{
    g_tmval.it_value.tv_sec = tv_sec*60;
    g_tmval.it_value.tv_usec = 0;
    g_tmval.it_interval = g_tmval.it_value;
    setitimer(ITIMER_REAL, &g_tmval, NULL);
    fibocom_pingflag = 0;
    fibocom_pingcounter = 0;
    RLOGD("%s: create a new timer!####",__func__);
}

void fibocom_stop_timer()
{
    g_tmval.it_value.tv_sec = 0;
    g_tmval.it_value.tv_usec = 0;
    g_tmval.it_interval = g_tmval.it_value;
    setitimer(ITIMER_REAL, &g_tmval, NULL);
    fibocom_pingflag = 0;
    fibocom_pingcounter = 0;
    RLOGD("%s: stop all timers[%d]####",__func__,fibocom_pingflag);
}
