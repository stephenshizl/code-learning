/******************************************************************************
  Copyright (C), 2019, Shenzhen G&T Industrial Development Co., Ltd

  File:      other_function.c

  Author:  Fibocom-diego
  Version: 1.0
  Date:  2019.04

  Description:   otherfunction APIs

** History:
**Author (core ID)                Date          Number     Description of Changes
**-----------------------------------------------------------------------------
** NODECOM-Aron                30-10-2018         **   init version 
** FIBOCOM-diego               10-01-2019         **   add requestDeviceIdentity support Androdi8.1
** FIBOCOM-diego               15-04-2019         **   modify requestBasebandVersion support M910/757S devices
** -----------------------------------------------------------------------------
******************************************************************************/

#include <telephony/ril.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <alloca.h>
#include "atchannel.h"
#include "at_tok.h"
#include "misc.h"
#include <getopt.h>
#include <sys/socket.h>
#include <cutils/sockets.h>
#include <cutils/properties.h>
#include <termios.h>

#include "ril_common.h"
#include "other_function.h"

#define LOG_TAG GHT_RIL
#include <utils/Log.h>


extern int cur_oper;

//<!---Start:Modified by Wujiabao in 2022/04/29, and change the initial value to GHT_L610
product_model mode_flag = GHT_L610;
//-----End:Modified by Wujiabao in 2022/04/29, and change the initial value to GHT_L610--->

int if_get_mode_flag = 0;               //added by wujiabao to check if get mode flag
extern int odm_get_current_network_type();

/* BEGIN: Added by abby.wang, 2018/12/22 fix bug14209,bug13844 USSD has no return for a long time */
extern unsigned int ussd_pending_index;
extern const struct timeval ussd_timeout_timeval;

/*Delete the Spaces on the left*/
char *l_trim(char *szOutput, const char *szInput)
{
    assert(szInput != NULL);
    assert(szOutput != NULL);
    assert(szOutput != szInput);
    for   (NULL; *szInput != '\0' && isspace(*szInput); ++szInput)
    {
        ;
    }
    return strcpy(szOutput, szInput);
}

/*Delete the Spaces on the right*/
char *r_trim(char *szOutput, const char *szInput)
{
    char *p = NULL;
    assert(szOutput != NULL);
    assert(szOutput != szInput);
    strcpy(szOutput, szInput);
    for(p = szOutput + strlen(szOutput) - 1; p >= szOutput && isspace(*p); --p)
    {
        ;
    }
    *(++p) = '\0';
    return szOutput;
}

/*Delete the left and right Spaces*/
char *a_trim(char *szOutput, const char *szInput)
{
    char *p = NULL;
    assert(szInput != NULL);
    assert(szOutput != NULL);
    l_trim(szOutput, szInput);
    for   (p = szOutput + strlen(szOutput) - 1; p >= szOutput && isspace(*p); --p)
    {
        ;
    }
    *(++p) = '\0';
    return szOutput;
}

int getProfileString(char *AppName, char *KeyName, char *KeyVal, char *DefaultVal)
{
    char appname[32], keyname[32];
    char *buf, *c;
    char buf_i[KEYVALLEN], buf_o[KEYVALLEN];
    FILE *fp;
    int found = 0; /* 1 AppName 2 KeyName */

    strcpy(KeyVal, DefaultVal);
    if( (fp = fopen( PROFILE_PATH, "r" )) == NULL )
    {
        RLOGE("GHT_PROFILE: openfile %s error: %s", PROFILE_PATH, strerror(errno));
        return (RET_FAIL);
    }
    fseek( fp, 0, SEEK_SET );

    if (!AppName || !KeyName)
    {
        RLOGE("GHT_PROFILE: AppName = \"%s\" or KeyName = \"%s\" is NULL!", AppName == NULL?"NULL":AppName, KeyName == NULL?"NULL":KeyName);
        return RET_FAIL;
    }
    memset( appname, 0, sizeof(appname) );
    sprintf( appname, "[%s]", AppName );

    while( !feof(fp) && fgets( buf_i, KEYVALLEN - 1, fp ) != NULL )
    {
        l_trim(buf_o, buf_i);
        //RLOGD("[%s,%d] buf_o:%s", __FUNCTION__, __LINE__, buf_o);
        if( strlen(buf_o) <= 0 )
        {
            //RLOGD("[%s,%d] strlen(buf_o) <= 0, continue...", __FUNCTION__, __LINE__);
            continue;
        }
        buf = NULL;
        buf = buf_o;

        if( found == 0 )
        {
            //RLOGD("[%s,%d] found is 0", __FUNCTION__, __LINE__);
            if( buf[0] != '[' )
            {
                //RLOGD("[%s,%d] buf[0] is:%c not '[', continue...", __FUNCTION__, __LINE__, buf[0]);
                continue;
            }
            else if ( strncmp(buf, appname, strlen(appname)) == 0 )
            {
                //RLOGD("[%s,%d] buf:%s, found appname!", __FUNCTION__, __LINE__, buf);
                found = 1;
                continue;
            }
            else
            {
                RLOGD("buf:%s, buf[0] is '[', but not match appname:%s, strlen(appname):%d", buf, appname, strlen(appname));
            }

        }
        else if( found == 1 )
        {
            //RLOGD("[%s,%d] found is 1", __FUNCTION__, __LINE__);
            if( buf[0] == '#' || buf[0] == ';' )
            {
                //RLOGD("[%s,%d] buf[0](%c) is '#' or ';', continue...", __FUNCTION__, __LINE__, buf[0]);
                continue;
            }
            else if ( buf[0] == '[' )     //No content in this app
            {
                //RLOGD("[%s,%d] buf[0](%c) is '[', break!", __FUNCTION__, __LINE__, buf[0]);
                break;
            }
            else
            {
                //RLOGD("[%s,%d] buf:%s", __FUNCTION__, __LINE__, buf);
                if( (c = (char *)strchr(buf, '=')) == NULL )
                {
                    //RLOGD("[%s,%d] found '=', continue...", __FUNCTION__, __LINE__);
                    continue;
                }
                memset( keyname, 0, sizeof(keyname) );

                sscanf( buf, "%[^=|^ |^\t]", keyname );
                //RLOGD("[%s,%d] keyname in file:%s", __FUNCTION__, __LINE__, keyname);

                if( strcmp(keyname, KeyName) == 0 )
                {
                    //RLOGD("[%s,%d] keyname match successfully!", __FUNCTION__, __LINE__);

                    sscanf( ++c, "%[^\n]", KeyVal );
                    char *KeyVal_o = (char *)malloc(strlen(KeyVal) + 1);
                    if(KeyVal_o != NULL)
                    {
                        memset(KeyVal_o, 0, sizeof(*KeyVal_o));
                        a_trim(KeyVal_o, KeyVal);
                        //RLOGD("[%s,%d] get KeyVal_o:%s", __FUNCTION__, __LINE__, KeyVal_o);

                        if(KeyVal_o && strlen(KeyVal_o) > 0)
                        {
                            //RLOGD("[%s,%d] strcpy KeyVal_o to KeyVal!", __FUNCTION__, __LINE__);
                            strcpy(KeyVal, KeyVal_o);
                        }
                        free(KeyVal_o);
                        KeyVal_o = NULL;
                    }
                    found = 2;
                    break;
                }
                else
                {
                    //RLOGD("[%s,%d] keyname not match!", __FUNCTION__, __LINE__);
                    continue;
                }
            }
        }
    }

    fclose( fp );
    if( found == 2 )
    {
        RLOGD("GHT_PROFILE: Found [%s]%s = %s !", AppName, KeyName, KeyVal);
        return (RET_SUCCESS);
    }
    else
    {
        RLOGE("GHT_PROFILE: Search for [%s]%s failed!, found_ret:%d", AppName, KeyName, found);
        return (RET_FAIL);
    }
}


bool getProfileBool(char *AppName, char *KeyName, bool DefaultVal) {
    char KeyVal[32] = {0};
    int ret = getProfileString(AppName, KeyName, KeyVal, "");
    int len = strlen(KeyVal);

    if (len == 1) {
        char ch = KeyVal[0];
        if (ch == '0' || ch == 'n') {
            return false;
        } else if (ch == '1' || ch == 'y') {
            return true;
        }
    } else if (len > 1) {
        if (!strcmp(KeyVal, "no") || !strcmp(KeyVal, "false") || !strcmp(KeyVal, "off")) {
            return false;
        } else if (!strcmp(KeyVal, "yes") || !strcmp(KeyVal, "true") || !strcmp(KeyVal, "on")) {
            return true;
        }
    }

    return DefaultVal;
}

// Convert string profiles to int (default if fails); return default value if out of bounds
static intmax_t getProfileImax(char *AppName, char *KeyName, intmax_t lower_bound, intmax_t upper_bound,
                                  intmax_t default_value) {
    if (!AppName || !KeyName) {
        return default_value;
    }

    intmax_t result = default_value;
    char buf[KEYVALLEN] = {'\0'};
    char *end = NULL;

    getProfileString(AppName, KeyName, buf, "");
    int len = strlen(buf);
    if (len > 0) {
        int tmp = errno;
        errno = 0;

        // Infer base automatically
        result = strtoimax(buf, &end, /*base*/ 0);
        if ((result == INTMAX_MIN || result == INTMAX_MAX) && errno == ERANGE) {
            // Over or underflow
            result = default_value;
            RLOGD("[%s]%s = %s: overflow!", AppName, KeyName, buf);
            //ALOGV("%s(%s,%" PRIdMAX ") - overflow", __FUNCTION__, KeyName, default_value);
        } else if (result < lower_bound || result > upper_bound) {
            // Out of range of requested bounds
            result = default_value;
            RLOGD("[%s]%s = %s: out of range!", AppName, KeyName, buf);
            //ALOGV("%s(%s,%" PRIdMAX ") - out of range", __FUNCTION__, KeyName, default_value);
        } else if (end == buf) {
            // Numeric conversion failed
            result = default_value;
            RLOGD("[%s]%s = %s: numeric conversion failed!", AppName, KeyName, buf);
            //ALOGV("%s(%s,%" PRIdMAX ") - numeric conversion failed", __FUNCTION__, KeyName,
                  //default_value);
        }

        errno = tmp;
    }

    return result;
}

int64_t getProfileInt64(char *AppName, char *KeyName, int64_t default_value) {
    return (int64_t)getProfileImax(AppName, KeyName, INT64_MIN, INT64_MAX, default_value);
}

int32_t getProfileInt32(char *AppName, char *KeyName, int32_t default_value) {
    return (int32_t)getProfileImax(AppName, KeyName, INT32_MIN, INT32_MAX, default_value);
}


//Add this feature later
#if 0
// Convert string property to int (default if fails); return default value if out of bounds
static intmax_t property_get_imax(const char *key, intmax_t lower_bound, intmax_t upper_bound,
                                  intmax_t default_value) {
    if (!key) {
        return default_value;
    }

    intmax_t result = default_value;
    char buf[PROPERTY_VALUE_MAX] = {'\0'};
    char *end = NULL;

    int len = property_get(key, buf, "");
    if (len > 0) {
        int tmp = errno;
        errno = 0;

        // Infer base automatically
        result = strtoimax(buf, &end, /*base*/ 0);
        if ((result == INTMAX_MIN || result == INTMAX_MAX) && errno == ERANGE) {
            // Over or underflow
            result = default_value;
            ALOGV("%s(%s,%" PRIdMAX ") - overflow", __FUNCTION__, key, default_value);
        } else if (result < lower_bound || result > upper_bound) {
            // Out of range of requested bounds
            result = default_value;
            ALOGV("%s(%s,%" PRIdMAX ") - out of range", __FUNCTION__, key, default_value);
        } else if (end == buf) {
            // Numeric conversion failed
            result = default_value;
            ALOGV("%s(%s,%" PRIdMAX ") - numeric conversion failed", __FUNCTION__, key,
                  default_value);
        }

        errno = tmp;
    }

    return result;
}

int64_t property_get_int64(const char *key, int64_t default_value) {
    return (int64_t)property_get_imax(key, INT64_MIN, INT64_MAX, default_value);
}

int32_t property_get_int32(const char *key, int32_t default_value) {
    return (int32_t)property_get_imax(key, INT32_MIN, INT32_MAX, default_value);
}
#endif

static void onUssdResponse(char *mode) {
    char *response[2];
    response[0] = mode;

    switch (mode[0] - '0') {
        case 2:
            response[1] = "USSD terminated by network";
        break;
        case 3:
            response[1] = "Other local client has responded";
        break;
        case 4:
            response[1] = "Operation not supported";
        break;
        case 5:
        default:
            response[1] = "Network time out";
        break;
    }
    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_ON_USSD, response, sizeof(response[0]) + sizeof(response[1]));
}

static void onUssdTimedCallback(void *param) {
    if (ussd_pending_index != *((unsigned int *) param))
        return;
    at_send_command("AT+CUSD=2", NULL); //cancel
    onUssdResponse("5");
}

static char* getModelId()
{
    ATResponse *p_response = NULL;
    int err = 0;
    char *line;
    char *response = NULL;
    char *res = NULL;

    err = at_send_command_singleline("AT+CGMM?","+CGMM:",&p_response);
    if(err<0 || p_response->success == 0)
    {
        RLOGE("[%s] at_send_command_singleline error",__FUNCTION__);
        goto error;
    }
    else
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if(err){
            RLOGE("[%s] at_tok_start error",__FUNCTION__);
            goto error;
        }
        err = at_tok_nextstr(&line, &response);
        if(err){
            RLOGE("[%s] at_tok_nextstr error",__FUNCTION__);
            goto error;
        }
    }
    RLOGD("[%s] Model ID:[%s]",__FUNCTION__,response);
    /*
     *duplicate a string  Memory for the new string is obtained with malloc,
     *and can be freed with free
     */
    res = strdup(response);
error:
    at_response_free(p_response);
    return res;
}

/**
 * RIL_REQUEST_SEND_USSD
 *
 * Send a USSD message
 *
 * If a USSD session already exists, the message should be sent in the
 * context of that session. Otherwise, a new session should be created.
 *
 * The network reply should be reported via RIL_UNSOL_ON_USSD
 *
 * Only one USSD session may exist at a time, and the session is assumed
 * to exist until:
 *   a) The android system invokes RIL_REQUEST_CANCEL_USSD
 *   b) The implementation sends a RIL_UNSOL_ON_USSD with a type code
 *      of "0" (USSD-Notify/no further action) or "2" (session terminated)
 *
 * "data" is a const char * containing the USSD request in UTF-8 format
 * "response" is NULL
 *
 * Valid errors:
 *  SUCCESS
 *  RADIO_NOT_AVAILABLE
 *  FDN_CHECK_FAILURE
 *  GENERIC_FAILURE
 *
 * See also: RIL_REQUEST_CANCEL_USSD, RIL_UNSOL_ON_USSD
 */
void  requestSendUSSD(void *data, size_t datalen __unused, RIL_Token t)
{
    ATResponse   *p_response = NULL;
    int err;
    char *cmd = NULL;
    const char *ussdRequest;
    int mode = 0;

#ifdef CUSD_USE_UCS2_MODE
    int i = 0;
    char ucs2[100];
    ussdRequest = (char *)(data);
    while (ussdRequest[i]) {
        sprintf(ucs2+i*4, "%04X", ussdRequest[i]);
        i++;
    }
    data = ucs2;
#endif
    ussdRequest = (char *)(data);
    mode = 1;

    asprintf(&cmd,"AT+CUSD=%d,\"%s\"",mode,ussdRequest);
    err = at_send_command(cmd,&p_response);
    if(err != 0 || p_response == NULL || p_response->success == 0)
    {
        goto error;
    }

#if 1 
    ussd_pending_index++;
    RIL_requestTimedCallback(onUssdTimedCallback, (void *)(&ussd_pending_index), &ussd_timeout_timeval);
#endif
    if(NULL != cmd)
    {
        free(cmd);
        cmd = NULL;
    }
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;
error:
    RLOGD("[Abby]ERROR: %s failed",__func__);
    if(NULL != cmd)
    {
        free(cmd);
        cmd = NULL;
    }
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}
/* END: Added by abby.wang, 2018/12/22 fix bug14209,bug13844 USSD has no return for a long time */

void requestCancelUSSD(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err = 0;

    ussd_pending_index++;

    err = at_send_command_numeric("AT+CUSD=2", &p_response);

    if (err < 0 || p_response->success == 0)
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS,
                p_response->p_intermediates->line, sizeof(char *));
    }
    at_response_free(p_response);

}

void requestOemHookStrings(void *data, size_t datalen, RIL_Token t)
{
    int i;
    const char ** cur;

    RLOGD("got OEM_HOOK_STRINGS: 0x%8p %lu", data, (long)datalen);

    for (i = (datalen / sizeof (char *)), cur = (const char **)data ;
            i > 0 ; cur++, i --)
    {
        RLOGD("> '%s'", *cur);
    }

    // echo back strings
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, data, datalen);
}

int eth1_interface = 0;

void InitFlags()
{
    eth1_interface      = 0;
    Voice_Support_Flag  = 1;
    GTRAT_Support_Flag  = 1;
    Net_3G_Support_Flag = 1;
}

static void setModeType_new(char *str)
{
    RLOGD("*********enter [%s]:GHT_%s*********",__FUNCTION__, str == NULL? "NULL":str);

    if(str == NULL)
    {
        goto error;
    }

    //If only a module is replaced, you need to initialize the Flags left by the previous module.
    InitFlags();

    if((!strncmp(str,"L610",4)) || (!strncmp(str,"MC615",5)))
    {
        mode_flag = GHT_L610;
        if(!strncmp(str,"MC615",5))
        {
            RLOGD("GHT [GHT_MC615]");
        }
        else
        {
            RLOGD("GHT [GHT_L610]");
        }
    }
    else if(!strncmp(str,"FG650",5) || !strncmp(str,"FM650",5))
    {
        mode_flag = GHT_FG650;
        RLOGD("GHT [GHT_FG650]");
    }
    else if(!strncmp(str,"FG621",5))
    {
        mode_flag = GHT_FG621;
        RLOGD("GHT [GHT_FG621]");
    }
    else if(!strncmp(str,"NL668",5) || !strncmp(str,"MC116",5) )
    {
        mode_flag = GHT_NL668;
        RLOGD("GHT [GHT_NL668]");
    }
    /* BEGIN: Added by guorui, 2022/08/01  */
    else if(!strncmp(str,"L716",4) )
    {
        mode_flag = GHT_L716;
        RLOGD("GHT [GHT_L716]");
    }
    /* END: Added by guorui, 2022/08/01  */
    else if(!strncmp(str,"H330S",5))
    {
        mode_flag = GHT_H330S;
        RLOGD("GHT [GHT_H330S]");
    }
    else if(!strncmp(str,"MC919",5))
    {
        mode_flag = GHT_MC919;
        RLOGD("GHT [GHT_MC919]");
    }
    else if((!strncmp(str,"MC661",5)) || (!strncmp(str,"MC669",5)) || (!strncmp(str,"MC665",5)))
    {
        mode_flag = GHT_MC66x;
        RLOGD("GHT [GHT_MC66x]");
    }
    else{
        goto error;
    }

    //Check whether the module uses "eth1" network card for ECM dialing.
    if(!strncmp(str, "L610-CN-62", strlen("L610-CN-62"))
     ||!strncmp(str, "MC615", strlen("MC615"))
     ||!strncmp(str, "MC669-CN", strlen("MC669-CN"))
     ||!strncmp(str, "MC665-CN", strlen("MC665-CN"))
     ||!strncmp(str, "MC661-CN", strlen("MC661-CN"))
     ||!strncmp(str, "MC919", strlen("MC919")))
    {
        RLOGD("this module use eth1 Netif!");
        eth1_interface = 1;
    }

    //Check whether the module supports dialing.
    if(!strncmp(str, "MC669-CN", strlen("MC669-CN"))
      ||!strncmp(str, "MC665-CN", strlen("MC665-CN"))
      ||!strncmp(str, "MC661-CN", strlen("MC661-CN")))
    {
        RLOGD("This module does not support voice, GTRAT and 3G networks!");
        Voice_Support_Flag   = 0;
        GTRAT_Support_Flag   = 0;
        Net_3G_Support_Flag  = 0;
    }

    if(!strncmp(str, "MC615-CN", strlen("MC615-CN")))
    {
        //MC615-CN project only supports 4G network and does not support AT+GTRAT=10 command
        Net_3G_Support_Flag  = 0;
    }

    return;

error:
    //<!-- Start: Modified by Wujiabao in 2022/04/21, Change the default module model from GHT_MDM_NORMAL to GHT_L610,
    //because up to now, we are only doing modules related to L610
    mode_flag = GHT_L610;
    RLOGD("GHT [The module is unrecognized and we default it to be GHT_L610]");
    //End----!>

    return;
}


static void setModeType(char *str)
{
    RLOGD("[setModeType] version is %s",str);
    char *model_id = NULL;
    if (0 == strncmp(str,"NL650",5))
    {
        mode_flag = GHT_NL650;
    }
    else if(0 == strncmp(str,"NL660",5))
    {
        mode_flag = GHT_NL660;
        RLOGD("GHT [GHT_NL660]");
    }
    else if (0 == strncmp(str,"19006.1000.00.01.71",19) \
        || !strncmp(str,"19006.1000.00.01.72",19) \
        || !strncmp(str,"19006.1000.00.01.74",19) \
        || !strncmp(str,"19006.1000.33.01.71",19) \
        || !strncmp(str,"19006.1000.00.02.04",19) \
        || !strncmp(str,"19006.1000.00.02.10",19) )
    {
        mode_flag = GHT_NL668;
        RLOGD("GHT [GHT_NL668_CN_XX]");
    }
    else if(0 ==strncmp(str,"19006.1000.00.02.77",19) \
        || !strncmp(str,"19006.1000.00.02.79",19) )
    {
        mode_flag = GHT_NL668_AM;
        RLOGD("GHT [GHT_NL668_AM]");
    }
    else if(0 ==strncmp(str,"19006.1000.00.01.73",19) )
    {
        mode_flag = GHT_NL668_EAU;
        RLOGD("GHT [GHT_NL668_EAU]");
    }
    //added for NL678-E-00
    else if(!strncmp(str,"19208.1000.00.01.01",19)\
    || !strncmp(str,"19208.1000.00.02.01",19))
    {
        mode_flag = GHT_NL678_E;
        RLOGD("GHT [GHT_NL678_E]");
    }
    else if((!strncmp(str,"19006.1000.00.01.76",19)) \
        || (!strncmp(str,"19006.1000.00.01.78",19)))
    {
        mode_flag = GHT_NL668_EU;
        RLOGD("GHT [GHT_NL668_EU]");
    }
    else if((!strncmp(str,"19100.3000.00.11.01",19)))
    {
        mode_flag = GHT_757S;
        RLOGD("GHT [GHT_757S]");
    }
    else if((!strncmp(str,"69100.1000.00.02.61",19)) \
        || (!strncmp(str,"69100.1000.01.02.61",19)))
    {
        mode_flag = GHT_M910_GL;
        RLOGD("GHT [GHT_M910_GL]");
    }
    //add by zhengjianrong for MA510 RIL BEGIN
    else if((!strncmp(str,"69400.1000.00.00.00",19)))
    {
        mode_flag = GHT_MA510_GL;
        RLOGD("GHT [GHT_MA510_GL]");
    }
    //add by zhengjianrong for MA510 RIL END
    else if((!strncmp(str,"16000.1000.00.03.01",19)) \
        || (!strncmp(str,"16000.1000.00.04.01",19)) \
        || (!strncmp(str,"16000.1000.00.05.01",19)) \
        || (!strncmp(str,"16000.1000.00.05.08",19)) \
        || (!strncmp(str,"16000.1000.00.05.10",19)) \
        || (!strncmp(str,"16000.1000.00.02.01",19)))
    {
        mode_flag = GHT_L610;
        RLOGD("GHT [GHT_L610_XX]");
    }
    else if(!strncmp(str,"16121.1000.00.01.01",19))
    {
        mode_flag = GHT_FG621;
        RLOGD("GHT [GHT_FG621_XX]");
    }
     else if(!strncmp(str,"86100.1000.00",13))
    {
        mode_flag = GHT_FG650;
        RLOGD("GHT [GHT_FG650_XX]");
    }
    else
    {
        RLOGD(" getModelId Enter ");
        model_id = getModelId();
        setModeType_new(model_id);
    }
    get_Properties();

    RLOGD("[%s] ====== Leave ",__FUNCTION__);

}

void get_Properties()
{
    //Specifies the name of the net interface to use at SETUP_DATA_CALL
    getNetifName();

    //Specifies which cid to use for data dialing
    get_cid();

    //Specifies whether to set the APN of cid0
    get_cgdcont0();

    //Gets and sets the USBMODE, if necessary
    getSetUsbmode();

}

static char* getBasebandVersion()
{
    ATResponse *p_response = NULL;
    int err = 0;
    char *line = NULL;
    char *response = NULL;
    char *res = NULL;

    if(ANDROID_8 == Ght_Android_Version)
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 8 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        sleep(2);
        at_send_command("ATE0", NULL);
    }

#if 0
#if defined GHT_FEATURE_ANDROID8X
    sleep(2);
    at_send_command("ATE0", NULL);
#endif
#endif

    err = at_send_command_singleline("AT+CGMR?","+CGMR:",&p_response);
    if(err<0 || p_response->success == 0)
    {
        RLOGE("[%s] at_send_command_singleline error",__FUNCTION__);
        goto error;
    }
    else
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if(err){
            RLOGE("[%s] at_tok_start error",__FUNCTION__);
            goto error;
        }
        err = at_tok_nextstr(&line, &response);
        if(err){
            RLOGE("[%s] at_tok_nextstr error",__FUNCTION__);
            goto error;
        }
    }
    RLOGD("[%s] basebandverison:[%s]",__FUNCTION__,response);
    /*
     *duplicate a string  Memory for the new string is obtained with malloc,
     *and can be freed with free
     */
    res = strdup(response);

error:
    at_response_free(p_response);
    return res;
}
void requestBasebandVersion(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    char *response = NULL;

    RLOGD("[%s] ====== Enter ",__FUNCTION__);
    response = getBasebandVersion();
    if(response == NULL)
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(char *));
        setModeType(response);
		if_get_mode_flag = 1;
        free(response);
    }

    
    return;
}

static int loadCommand(char *cmd,char *prefix,int request)
{
    int err = 0;
    int network_type = 0;

    switch (mode_flag)
    {
        case GHT_NL650:
        case GHT_NL660:
            if(request == 0){
                network_type = odm_get_current_network_type();
                if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
                {
                    if(14 == network_type)
                    {
                        strcpy(cmd,"AT+LCTSN=0,7");
                        strcpy(prefix,"+LCTSN:");
                    }
                    else
                    {
                        strcpy(cmd,"AT+LCTSN=0,9");
                        strcpy(prefix,"+LCTSN:");
                    }
                }
                else
                {
                    strcpy(cmd,"AT+LCTSN=0,7");
                    strcpy(prefix,"+LCTSN:");
                }
            }
            else if(request == 1){
                    strcpy(cmd,"AT+LCTSN=0,7");
                    strcpy(prefix,"+LCTSN:");
            }
            else{
                RLOGE("[%s] unsupport request ",__FUNCTION__);
                err = -1;
            }
            break;
        case GHT_NL668:
        case GHT_NL668_EAU:
        case GHT_NL668_EU:
        case GHT_NL668_AM:
        case GHT_757S:
        case GHT_M910_GL:
        // <!--wangmengying@2019.7.26 for solve 7.x GET_IMEI return ERROR
        case GHT_MA510_GL:
        // end-->
        case GHT_NL678_E:
        case GHT_MDM_NORMAL:
        case GHT_L610:
        case GHT_MC919:
        case GHT_MC66x:
        case GHT_FG621:
        case GHT_FG650:
        case GHT_H330S:
        case GHT_L716:
                if(request == 0){
                    strcpy(cmd,"AT+CGSN?");
                    strcpy(prefix,"+CGSN:");
                }
                else if(request == 1){
                    strcpy(cmd,"AT+CGSN=2");
                    strcpy(prefix,"+CGSN:");
                }
                else{
                    RLOGE("[%s] unsupport request ",__FUNCTION__);
                    err = -1;
                }
            break;
        default:
            err = -1;
            RLOGE("[%s] unsupport mode flag ",__FUNCTION__);
            break;
    }
    return err;
}

static char *getIMEI()
{
    ATResponse *p_response = NULL;
    int err = 0;
    char *line;
    char *res = NULL;
    char *responsenet = NULL;
    char *cmd = NULL;
    char *prefix = NULL;
    char cmdbuf[15] = {0};
    char prebuf[15] = {0};
    int requestImei = 0;

    err = loadCommand(cmdbuf,prebuf,requestImei);
    if(err){
       RLOGE("[%s] loadCommand error",__FUNCTION__);
       goto done;
    }
    asprintf( &cmd, "%s",cmdbuf);
    asprintf( &prefix, "%s",prebuf);

    RLOGD("[%s] cmd: [%s]",__FUNCTION__,cmd);
    RLOGD("[%s] prefix: [%s]",__FUNCTION__,prefix);

    err = at_send_command_singleline(cmd,prefix, &p_response);
    if (err < 0 || p_response->success == 0){
       RLOGE("[%s] at_send_command_singleline err",__FUNCTION__);
       goto done;
    }

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if(err){
       RLOGE("[%s] at_tok_start err",__FUNCTION__);
       goto done;
    }
    err = at_tok_nextstr(&line, &responsenet);
    if(err){
       RLOGE("[%s] at_tok_nextstr err",__FUNCTION__);
       goto done;
    }
    RLOGD("[%s] imei: %s",__FUNCTION__,responsenet);
    res = strdup(responsenet);  //duplicate a string

done:
    at_response_free(p_response);
    return res;
}
void requestGetIMEI(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    char *response = NULL;

    RLOGD("[%s] ====== Enter ",__FUNCTION__);
    
    response = getIMEI();
    if(response == NULL)
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS,response, sizeof(char *));
        free(response);
    }
    RLOGD("[%s] ====== Leave ",__FUNCTION__);
    return;
}

static char *getIMEISV()
{
    ATResponse *p_response = NULL;
    int err = 0;
    char *line;
    char *res = NULL;
    char *responsenet = NULL;
    char *cmd = NULL;
    char *prefix = NULL;
    char cmdbuf[15] = {0};
    char prebuf[15] = {0};
    int requestImeisv = 1;

    err = loadCommand(cmdbuf,prebuf,requestImeisv);
    if(err){
       RLOGE("[%s] loadCommand error",__FUNCTION__);
       goto done;
    }
    asprintf( &cmd, "%s",cmdbuf);
    asprintf( &prefix, "%s",prebuf);

    RLOGD("[%s] cmd: [%s]",__FUNCTION__,cmd);
    RLOGD("[%s] prefix: [%s]",__FUNCTION__,prefix);

    err = at_send_command_singleline(cmd,prefix, &p_response);
    if (err < 0 || p_response->success == 0){
       RLOGE("[%s] at_send_command_singleline err",__FUNCTION__);
       goto done;
    }

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if(err){
       RLOGE("[%s] at_tok_start err",__FUNCTION__);
       goto done;
    }
    err = at_tok_nextstr(&line, &responsenet);
    if(err){
       RLOGE("[%s] at_tok_nextstr err",__FUNCTION__);
       goto done;
    }
    RLOGD("[%s] imei: %s",__FUNCTION__,responsenet);
    res = strdup(responsenet);  //duplicate a string

done:
    at_response_free(p_response);
    return res;
}

void requestGetIMEISV(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    char imeisv_str[3];
    int len = 0;
    char *strIMEI = NULL;

    RLOGD("[%s] ====== Enter ",__FUNCTION__);
    strIMEI = getIMEISV();
    len = strlen(strIMEI);
    
    if((strIMEI == NULL) || (len < 2))
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else
    {
        imeisv_str[0] = strIMEI[len-2];
        imeisv_str[1] = strIMEI[len-1];
        imeisv_str[2] = 0;
        RLOGD("requestGetIMEISV imeisv [%s]", imeisv_str);
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS,imeisv_str, sizeof(char *));
        free(strIMEI);
    }
    RLOGD("[%s] ====== Leave ",__FUNCTION__);
    return; 
}

static void setOperator(char *src)
{
    if(src == NULL){
        RLOGE("[%s] parameter error",__FUNCTION__);
        goto done;
    }
    if(-1 == cur_oper)
    {
        *(src+5) = '\0';
        if((0 == strcmp(src,"46003")) || (0 == strcmp(src,"20404")))
        {
            cur_oper = ODM_CT_OPERATOR_3G;
        }
        else if(0 == strcmp(src,"46011"))
        {
            cur_oper = ODM_CT_OPERATOR_4G;
        }
        else if((0 == strcmp(src,"46000")) || (0 == strcmp(src,"46002")) ||
                (0 == strcmp(src,"46007")) || (0 == strcmp(src,"46004")) ||
				(0 == strcmp(src,"46008")))
        {
            cur_oper = ODM_CM_OPERATOR;
        }
        else if((0 == strcmp(src,"46001"))||(0 == strcmp(src,"46006")) ||
		        (0 == strcmp(src,"46009")))
        {
            cur_oper = ODM_CU_OPERATOR;
        }
        else
        {
            RLOGE("Fibocom unkonw mcc and mnc,line = %s\r",src);
            cur_oper = ODM_CM_OPERATOR;
        }
    }

done:
    RLOGD("[%s]  cur_oper :[%d]",__FUNCTION__,cur_oper);
    return;
}

static char * getIMSI()
{
    ATResponse *p_response = NULL;
    int err = 0;
    char *line;
    char *res = NULL;
    char *response = NULL;
    int nRetry = 10;
	int get_imsi_flag = 0;

    do
    {
        err = at_send_command_singleline("AT+QCIMI?","+QCIMI:",&p_response);
        if (err < 0 || p_response->success == 0){
            RLOGE("[%s] at_send_command_singleline QCIMI error",__FUNCTION__);
            //err = at_send_command_singleline("AT+CIMI?","+CIMI:", &p_response);
            err = at_send_command_singleline_timeout("AT+CIMI?", "+CIMI", NUMERIC_AT_TIMEOUT_MSEC, &p_response);
            if (err < 0 || p_response->success == 0){
                RLOGE("[%s] at_send_command_singleline CIMI error",__FUNCTION__);
            }
            else{
                RLOGD("[%s] at_send_command_singleline CIMI sucess",__FUNCTION__);
				get_imsi_flag = 1;
                break;
            }
        }
        else{
            RLOGD("[%s] at_send_command_singleline QCIMI sucess",__FUNCTION__);
			get_imsi_flag = 1;
            break;
        }
        sleep(1);
    }while(nRetry--);

	if(get_imsi_flag == 0)
		goto done;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if(err){
        RLOGE("[%s] at_tok_start err",__FUNCTION__);
        goto done;
    }
    err = at_tok_nextstr(&line, &response);
    if(err)
    {
        RLOGE("[%s] at_tok_nextstr err",__FUNCTION__);
        goto done; 
    }

    RLOGD("[%s] getIMSI :%s",__FUNCTION__,response);

    /*
     *duplicate a string  Memory for the new string is obtained with malloc, 
     *and can be freed with free
     */
    res = strdup(response);  
done:
    at_response_free(p_response);
    return res;    
}
void requestGetIMSI(void *data __unused, size_t datalen __unused, RIL_Token t)
{

    char *response = NULL;

    RLOGD("[%s] ====== Enter ",__FUNCTION__);
    
    response = getIMSI();
    if (response == NULL)
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else
    {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS,response, sizeof(char *));
        setOperator(response);
        free(response);
    }
    RLOGD("[%s] ====== Leave ",__FUNCTION__);
    return;
}

/* added by nodecom begin */
void requestQueryClip(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    /**
     * Queries the status of the CLIP supplementary service
     *
     * (for MMI code "*#30#")
     *
     * "data" is NULL
     * "response" is an int *
     * (int *)response)[0] is 1 for "CLIP provisioned"
     *                           and 0 for "CLIP not provisioned"
     *                           and 2 for "unknown, e.g. no network etc"
     */

    int err;
    int* response[1];

    ATResponse *p_response = NULL;
    char *line;

    err = at_send_command_singleline("AT+CLIP?","+CLIP:",&p_response);
    if(err < 0 ||p_response->success == 0)
        goto error;
    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if(err < 0)
        goto error;
    err = at_tok_nextint(&line,response[0]);
    if(err < 0)
        goto error;

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t,RIL_E_SUCCESS, response, sizeof(response));
    at_response_free(p_response);
    return;

error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t,RIL_E_GENERIC_FAILURE,NULL,0);
    at_response_free(p_response);

}

/* added by nodecom end */

//#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
/*Begin: Wujiabao changed it to '#if 1' in 2022/07/20*/
#if 1
/*End:   Wujiabao changed it to '#if 1' in 2022/07/20*/
void requestDeviceIdentity(void *data __unused,size_t datalen __unused,  RIL_Token t)
{
    int err;
    int i;
    char * response[4];
    
    ATResponse *p_response = NULL;
    char *line;
    ATLine *p_cur;

    response[2] = "888";
    response[3] = "777";

    err = at_send_command_multiline("AT+CGSN=1;+CGSN=2","+CGSN:", &p_response);
	
    /* we expect 2 lines here:
     * +CGSN: 866857030583674
     * +CGSN: 8668570305836726
     */
    if ( err < 0 || p_response->success == 0) goto error;

    //line = p_response->p_intermediates->line;
    //RLOGD("requestDeviceIdentity get mesagge = %s ",line);
    
    for (i = 0, p_cur = p_response->p_intermediates; 
        p_cur != NULL; 
        p_cur = p_cur->p_next, i++)
    {
          line = p_cur->line;
          RLOGD("requestDeviceIdentity get line = %s ",line);
          err = at_tok_start(&line);
          if (err < 0) goto error;
          
          RLOGD("requestDeviceIdentity get line1 = %s ",line);
          err = at_tok_nextstr(&line, &(response[i]));
    }
        
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t,RIL_E_SUCCESS, response, sizeof(response));
    at_response_free(p_response);
    return;

    
error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t,RIL_E_GENERIC_FAILURE,NULL,0);  
    at_response_free(p_response);
}
#endif
