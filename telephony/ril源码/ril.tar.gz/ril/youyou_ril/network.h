#ifndef _NETWORK_H_
#define _NETWORK_H_

#define NO_SCRIPT

//<!---Used by ril.fibocom.cid property
#define MAX_CID_PROPERTY_LENGTH 1
#define MIN_CID_NUM 1
#define MAX_CID_NUM 7
//-----Used by ril.fibocom.cid property--!>

//<!---Used by ril.fibocom.cgdcont0 property
#define MAX_CGDCONT0_PROPERTY_LENGTH 1
#define NEED_CGDCONT0_YES 1
#define NEED_CGDCONT0_NO  0
//-----Used by ril.fibocom.cgdcont0 property--!>

//<!-----Used by ril.fibocom.usbmode property
#define MAX_USBMODE_PROPERTY_LENGTH 2
#define MIN_USBMODE_NUM 31
#define MAX_USBMODE_NUM 75
#define NO_CUS_USBMODE  0
//-----!>

#define DEFAULT_PDNS "8.8.8.8"
#define DEFAULT_SDNS "8.8.4.4"

#define DHCP_MAX_RETRY_NUM 1

extern int fibocom_pingflag;

void onDataCallListChanged(void *param);

void requestDataCallList(void *data, size_t datalen, RIL_Token t);

void requestQueryNetworkSelectionMode(void *data, size_t datalen, RIL_Token t);

void requestQueryAvailableNetworks(void *data, size_t datalen, RIL_Token t);

void requestSignalStrength(void *data, size_t datalen, RIL_Token t);

void requestSignalStrength_Generic(void *data, size_t datalen, RIL_Token t);

void requestRegistrationState(int request, void *data,size_t datalen, RIL_Token t);

void OnRadioQuerryMdmNormalRegistration(int request, void *data,size_t datalen, RIL_Token t);

void requestOperator(void *data, size_t datalen, RIL_Token t);

void requestOperator_Generic(void *data, size_t datalen, RIL_Token t);

void requestSetupDataCall(void *data, size_t datalen, RIL_Token t);

void requestDeactivateDataCall(void *data, size_t datalen, RIL_Token t);

void requestGetPreferredNetworkType(void *data, size_t datalen, RIL_Token t);

void requestSetPreferredNetworkType(void *data, size_t datalen, RIL_Token t);

void requestSetNetworkSelectionManual(void *data, size_t datalen, RIL_Token t);

void requestNeighboringCellIds(void * data, size_t datalen, RIL_Token t);

void requestGetCellInfoList(void * data, size_t datalen, RIL_Token t);

void requestSetNetworkSelectionAutomatic(RIL_Token t);

/* added by  nodecom aron begin */
void requestSetLocationUpdates(void * data, size_t datalen, RIL_Token t);
void requestScreenState(void *data, size_t datalen, RIL_Token t);
/* added by  nodecom aron end */

void onDeactiveDataCallList() ;

void OnResumeLTENetwork();
//added by lisf for debug 20181210
int get_pid(char *name);
void ril_kill_pppd(int flag);

void requestSetPreferredNetworkType_M910(void *data, size_t datalen, RIL_Token t);
void requestRegistrationStateM910(int request, void *data,size_t datalen, RIL_Token t);
void requestSetInitialAttachAPNM910(void *data, size_t datalen, RIL_Token t);
void requestGetPreferredNetworkTypeM910(void *data, size_t datalen, RIL_Token t);
void requestOperatorM910(void *data, size_t datalen, RIL_Token t);
static int setupDataCallRASModeM910(char**response_local_ip,const char* apn,const char* auth_type,const char* username,const  char* password,const char* pdp_type);

int odm_get_current_network_type_m910();
//<!--added by wangmengying@2019.11.26 for fix bug34926 MA510 query network registration status
int odm_get_current_network_type_ma510();
// end--!>

void get_cid();
void Get_NetProperties();
void get_cgdcont0();
void get_Cus_Usbmode();
void getSetAPN(int, char*, char*);
void odm_fix_gw(char *gw);



#endif /*_NETWORK_H_*/

