/******************************************************************************
  Copyright (C), 2019, Shenzhen G&T Industrial Development Co., Ltd

  File:      sim.c

  Author:  Fibocom-diego
  Version: 1.0
  Date:  2019.04

  Description:   sims APIs

** History:
**Author (core ID)                Date          Number     Description of Changes
**-----------------------------------------------------------------------------
** NODECOM-Aron                30-10-2018         **   init version 
** FIBOCOM-diego               15-04-2019         **   add requestSIM_IO_M910 support M910/757S devices
** -----------------------------------------------------------------------------
******************************************************************************/
#include <telephony/ril.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <alloca.h>
#include "atchannel.h"
#include "at_tok.h"
#include "misc.h"
#include <getopt.h>
#include <sys/socket.h>
#include <cutils/sockets.h>
#include <cutils/properties.h>
#include <termios.h>

#include "ril_common.h"
#include "sim.h"
#include "network.h"
#define LOG_TAG GHT_RIL
#include <utils/Log.h>

extern int cur_oper;
extern product_model mode_flag;
static struct timeval TIMEVAL_DELAYINIT = {0,0}; // will be set according to property value

extern void setRadioState(RIL_RadioState newState);
extern SIM_Status getSIMStatus();
extern SIM_Status gSimStatus;
#if 1 //usim -> sim
typedef struct __TLV {
    unsigned char tag;
    unsigned char len;
    unsigned char data[0];
} TLV;

static int hexCharToInt(char c) {
    if (c >= '0' && c <= '9') return (c - '0');
    if (c >= 'A' && c <= 'F') return (c - 'A' + 10);
    if (c >= 'a' && c <= 'f') return (c - 'a' + 10);
    return 0;
}

static int hexStringToBytes(const char * s, unsigned char *d) {
    int sz, i;

    if (!s || !strlen(s))
        return 0;

    sz = strlen(s) / 2;

    for (i = 0; i < sz ; i++) {
        d[i] = (unsigned char) ((hexCharToInt(s[i*2 + 0]) << 4) | hexCharToInt(s[i*2 + 1]));
    }

    return sz;
}

static TLV * getTLV(const unsigned char *d, unsigned char tag) {
     TLV *tlv = (TLV *)d;
     int sz = tlv->len;

     tlv++; //skip head

     while (sz) {
        if (tlv->tag != tag) {
            tlv = (TLV *)(((char *)tlv) + sizeof(TLV) + tlv->len);
            sz -= sizeof(TLV) + tlv->len;
        } else {
        #if 0
            int i;
            printf("{%02x, %02x, ", tlv->tag, tlv->len);
            for (i = 0; i < tlv->len; i++)
                printf("%02x, ", tlv->data[i]);
            printf("}\n");
        #endif
            return tlv;
        }
    }
    return NULL;
}

//frameworks\base\telephony\java\com\android\internal\telephony\IccFileHandler.java
//from TS 11.11 9.1 or elsewhere
const int EF_ICCID  = 0x2fe2;
const int COMMAND_READ_BINARY = 0xb0;     //176
const int COMMAND_UPDATE_BINARY = 0xd6;   //214
const int COMMAND_READ_RECORD = 0xb2;     //178
const int COMMAND_UPDATE_RECORD = 0xdc;   //220
const int COMMAND_SEEK = 0xa2;
const int COMMAND_GET_RESPONSE = 0xc0;
        
//***** types of files  TS 11.11 9.3
static const int EF_TYPE_TRANSPARENT = 0;
static const int EF_TYPE_LINEAR_FIXED = 1;
static const int EF_TYPE_CYCLIC = 3;

//***** types of files  TS 11.11 9.3
const int TYPE_RFU = 0;
const int TYPE_MF  = 1;
const int TYPE_DF  = 2;
const int TYPE_EF  = 4;

// Byte order received in response to COMMAND_GET_RESPONSE
// Refer TS 51.011 Section 9.2.1
const int RESPONSE_DATA_RFU_1 = 0;
const int RESPONSE_DATA_RFU_2 = 1;

const int RESPONSE_DATA_FILE_SIZE_1 = 2;
const int RESPONSE_DATA_FILE_SIZE_2 = 3;

const int RESPONSE_DATA_FILE_ID_1 = 4;
const int RESPONSE_DATA_FILE_ID_2 = 5;
const int RESPONSE_DATA_FILE_TYPE = 6;
const int RESPONSE_DATA_RFU_3 = 7;
const int RESPONSE_DATA_ACCESS_CONDITION_1 = 8;
const int RESPONSE_DATA_ACCESS_CONDITION_2 = 9;
const int RESPONSE_DATA_ACCESS_CONDITION_3 = 10;
const int RESPONSE_DATA_FILE_STATUS = 11;
const int RESPONSE_DATA_LENGTH = 12;
const int RESPONSE_DATA_STRUCTURE = 13;
const int RESPONSE_DATA_RECORD_LENGTH = 14;

void usim2sim(RIL_SIM_IO_Response *psr) {
    int sz;
    int i;
    unsigned char usim_data[1024];
    unsigned char sim_data[15] = {0};
    static char new_response[31];
    TLV * tlv;
    const char bytesToHexString[] = "0123456789abcdef";

    if (!psr->simResponse)
        return;

    if (!strlen(psr->simResponse)) {
        psr->simResponse = NULL;
        return;
    }

    if (strlen(psr->simResponse) < 4)
        return;

    sz = hexStringToBytes(psr->simResponse, usim_data);

    if (usim_data[0] != 0x62) {
       RLOGD("CRSM: not usim");
        return;
    }

    if (usim_data[1] != (sz - 2)) {
        RLOGD("CRSM: error usim len");

    }

    tlv = getTLV(usim_data, 0x80);
    if (tlv) {
        RLOGD("CRSM: FILE_SIZE %02X%02X", tlv->data[0], tlv->data[1]);
        sim_data[RESPONSE_DATA_FILE_SIZE_1] = tlv->data[0];
        sim_data[RESPONSE_DATA_FILE_SIZE_2] = tlv->data[1];
    }

    tlv = getTLV(usim_data, 0x83);
    if (tlv) {
        RLOGD("CRSM: FILE_ID %02X%02X", tlv->data[0], tlv->data[1]);
        sim_data[RESPONSE_DATA_FILE_ID_1] = tlv->data[0];
        sim_data[RESPONSE_DATA_FILE_ID_2] = tlv->data[1];
    }

    tlv = getTLV(usim_data, 0x82);
    if (tlv) {
        int filetype = (tlv->data[0] >> 3) & 0x7;
        int efstruct = (tlv->data[0] >> 0) & 0x7;
        RLOGD("CRSM: len: %d, %02x %02x %02x %02x %02x", tlv->len, tlv->data[0], tlv->data[1], tlv->data[2], tlv->data[3], tlv->data[4]);

        //File type:
        if ((filetype == 0) || (filetype == 1)) {
            RLOGD("CRSM: FILE_TYPE_EF");
            sim_data[RESPONSE_DATA_FILE_TYPE] = TYPE_EF;
        } else if ((filetype == 7) && (efstruct == 0)) {
            RLOGD("CRSM: TYPE_DF");
            sim_data[RESPONSE_DATA_FILE_TYPE] = TYPE_DF;
        } else {
            RLOGD("CRSM: TYPE_RFU");
            sim_data[RESPONSE_DATA_FILE_TYPE] = TYPE_RFU;
        }

        //EF struct
        if (efstruct == 1) {
            RLOGD("CRSM: EF_TYPE_TRANSPARENT");
            sim_data[RESPONSE_DATA_STRUCTURE] = EF_TYPE_TRANSPARENT;
        } else if (efstruct == 2) {
            RLOGD("CRSM: EF_TYPE_LINEAR_FIXED");
            sim_data[RESPONSE_DATA_STRUCTURE] = EF_TYPE_LINEAR_FIXED;
        } else if (efstruct == 3) {
            RLOGD("CRSM: EF_TYPE_CYCLIC");
            sim_data[RESPONSE_DATA_STRUCTURE] = EF_TYPE_CYCLIC;
         } else {
            RLOGD("CRSM: EF_TYPE_UNKNOWN");
         }

        if ((efstruct == 2) || (efstruct == 3)) {
            if (tlv->len == 5) {
                sim_data[RESPONSE_DATA_RECORD_LENGTH] = ((tlv->data[2] << 8) + tlv->data[3]) & 0xFF;
               RLOGD("CRSM: RESPONSE_DATA_RECORD_LENGTH %d", sim_data[RESPONSE_DATA_RECORD_LENGTH]);
            } else {
                RLOGD("CRSM: must contain Record length and Number of records");
            }
        }
    }

    for (i = 0; i < 15; i++) {
        new_response[i*2 + 0] =  bytesToHexString[0x0f & (sim_data[i] >> 4)];
        new_response[i*2 + 1] =  bytesToHexString[0x0f & sim_data[i]];
    }
    new_response[30] = '\0';

    psr->simResponse = new_response;

//see telephony\src\java\com\android\internal\telephony\uicc\IccIoResult.java
#if 0
    /**
     * true if this operation was successful
     * See GSM 11.11 Section 9.4
     * (the fun stuff is absent in 51.011)
     */
    public boolean success() {
        return sw1 == 0x90 || sw1 == 0x91 || sw1 == 0x9e || sw1 == 0x9f;
    }
#endif
    if (psr->sw1 == 0x90 || psr->sw1 == 0x91 || psr->sw1 == 0x9e || psr->sw1 == 0x9f)
        ;
    else
        psr->sw1 = 0x90;

    return;
}
#endif
extern int odm_get_current_network_type();
/* BEGIN: Added by eric.li, 2018/10/14   PN:add for sim io parse */
#if 1
#define RIL_SIMRECORDTYPE_UNKNOWN       (0x00000000)
#define RIL_SIMRECORDTYPE_TRANSPARENT   (0x00000001)
#define RIL_SIMRECORDTYPE_CYCLIC        (0x00000002)
#define RIL_SIMRECORDTYPE_LINEAR        (0x00000003)
#define RIL_SIMRECORDTYPE_MASTER        (0x00000004)
#define RIL_SIMRECORDTYPE_DEDICATED     (0x00000005)

typedef struct
{
    unsigned char m_bTag;
    int  m_uLen;
    unsigned char* m_pbValue;
    int m_uTotalSize;
}BerTlv;

struct sUSIMGetResponse
{
    int dwRecordType;
    //UINT32 dwItemCount;
    int dwTotalSize;
    int dwRecordSize;
};

unsigned char PrintStringNullTerminate(char* pszOut, int cbOut, char* pszFormat, ... )
{
    unsigned char fRet = true;
    int iWritten;

    //RIL_LOG_VERBOSE("PrintStringNullTerminate() - Enter\r\n");

    va_list args;
    va_start(args, pszFormat);

    iWritten = vsnprintf(pszOut, cbOut, pszFormat, args);

    if (0 > iWritten)
    {
        fRet = false;
        pszOut[0] = '\0';
    }
    else if ((int)iWritten >= cbOut)
    {
        fRet = false;
        pszOut[cbOut - 1] = '\0';
    }

    va_end(args);

    //RIL_LOG_VERBOSE("PrintStringNullTerminate() - Exit\r\n");
    return fRet;
}


static unsigned char Parse(unsigned char* pRawData, int cbSize, BerTlv * pBerTlv)
{
    if (2 > cbSize) {
        // Not enough data for a TLV.
        return false;
    }

    // Tag at index 0.
    unsigned char bTag = pRawData[0];
    if (0x00 == bTag ||
        0xFF == bTag)
    {
        // Invalid Tag
        return false;
    }

    // Encoded length starts at index 1
    unsigned char bValuePos = 0;
    int uLen = 0;

    if (0x80 == (0x80 & pRawData[1])) {
        unsigned char bLenBytes = 0x7F & pRawData[1];

        if (1 < bLenBytes ||
            3 > cbSize) {
            // Currently only support 1 extra length byte
            return false;
        }

        uLen = pRawData[2];
        bValuePos = 3;
    }
     else {
        uLen = pRawData[1];
        bValuePos = 2;
    }

    // Verify there is enough data available for the value
    if (uLen + bValuePos > cbSize) {
        return false;
    }

    // Verify length and value size are consistent.
    if (cbSize - bValuePos < uLen) {
        // Try and recover using the minimum value.
        uLen = cbSize - bValuePos;
    }

    pBerTlv->m_bTag = bTag;
    pBerTlv->m_uLen = uLen;
    pBerTlv->m_pbValue = pRawData + bValuePos;
    pBerTlv->m_uTotalSize = uLen + bValuePos;

    return true;
}


static unsigned char ParseUSIMRecordStatus(unsigned char* sResponse, int cbResponse, struct sUSIMGetResponse* sUSIM)
{
    RLOGD("ParseUSIMRecordStatus - ENTER\r\n");

    unsigned char bRet = false;

    unsigned char FCP_TAG = 0x62;
    unsigned char FILE_SIZE_TAG = 0x80;
    unsigned char FILE_DESCRIPTOR_TAG = 0x82;
    unsigned char FILE_ID_TAG = 0x83;
    int MASTER_FILE_ID = 0x3F00;
    int dwRecordType = 0;
    int dwItemCount = 0;
    int dwRecordSize = 0;
    int dwTotalSize = 0;
    BerTlv tlvFileDescriptor = {0};
    BerTlv tlvFcp = {0};
                // Retrieve the file size.
    BerTlv tlvCurrent = {0};
                        // Next data object should be File ID.

    unsigned char* pbFcpData = NULL;
    int cbFcpDataSize = 0;
    int cbDataUsed = 0;
    unsigned char* pbFileDescData = NULL;
    int cbFileDescDataSize = 0;

    unsigned char fIsDf = false;
    unsigned char bEfStructure = 0;

    if (NULL == sResponse ||
        0 == cbResponse ||
        NULL == sUSIM)
    {
        RLOGD("ParseUSIMRecordStatus - Input parameters\r\n");
        goto Error;
    }

    // Need at least 2 bytes for response data FCP (file control parameters)
    if (2 > cbResponse)
    {
       RLOGD("ParseUSIMRecordStatus - Need at least 2 bytes for response data\r\n");
        goto Error;
    }

    // Validate this response is a 3GPP 102 221 SELECT response.
    Parse(sResponse, cbResponse, &tlvFcp);
    if (FCP_TAG != tlvFcp.m_bTag)
    {
        RLOGD("ParseUSIMRecordStatus - First tag is not FCP.  Tag=[0x%02X]\r\n",
                tlvFcp.m_bTag);
        goto Error;
    }

    if (cbResponse != tlvFcp.m_uTotalSize)
    {
        RLOGD("ParseUSIMRecordStatus -"
                " cbResponse=[%d] not equal to total size=[%d]\r\n",
                cbResponse, tlvFcp.m_uTotalSize);
        goto Error;
    }
    pbFcpData = tlvFcp.m_pbValue;
    cbFcpDataSize = tlvFcp.m_uLen;

    // Retrieve the File Descriptor data object
    Parse(pbFcpData, cbFcpDataSize,&tlvFileDescriptor);
    if (FILE_DESCRIPTOR_TAG != tlvFileDescriptor.m_bTag)
    {
        RLOGD("ParseUSIMRecordStatus -"
                " File descriptor tag is not FCP.  Tag=[0x%02X]\r\n", tlvFileDescriptor.m_bTag);
        goto Error;
    }

    cbDataUsed = tlvFileDescriptor.m_uTotalSize;
    if (cbDataUsed > cbFcpDataSize)
    {
        RLOGD("ParseUSIMRecordStatus -"
                " cbDataUsed=[%d] is greater than cbFcpDataSize=[%d]\r\n",
                cbDataUsed, cbFcpDataSize);
        goto Error;
    }

    pbFileDescData = tlvFileDescriptor.m_pbValue;
    cbFileDescDataSize = tlvFileDescriptor.m_uLen;
    // File descriptors should only be 2 or 5 bytes long.
    if((2 != cbFileDescDataSize) && (5 != cbFileDescDataSize))
    {
        RLOGD("ParseUSIMRecordStatus -"
                " File descriptor can only be 2 or 5 bytes.  cbFileDescDataSize=[%d]\r\n",
                cbFileDescDataSize);
        goto Error;

    }
    if (2 > cbFileDescDataSize)
    {
        RLOGD("ParseUSIMRecordStatus -"
                " File descriptor less than 2 bytes.  cbFileDescDataSize=[%d]\r\n",
                cbFileDescDataSize);
        goto Error;
    }

    fIsDf = (0x38 == (0x38 & pbFileDescData[0]));
    bEfStructure = (0x07 & pbFileDescData[0]);


    RLOGD("ParseUSIMRecordStatus: fIsDf = %u , bEfStructure = %u \r\n",fIsDf, bEfStructure);

    if (fIsDf)
    {
        dwRecordType = RIL_SIMRECORDTYPE_DEDICATED;
    }
    // or it is an EF or MF.
    else
    {
        switch (bEfStructure)
        {
            // Transparent
            case 0x01:
                dwRecordType = RIL_SIMRECORDTYPE_TRANSPARENT;
                break;

            // Linear Fixed
            case 0x02:
                dwRecordType = RIL_SIMRECORDTYPE_LINEAR;
                break;

            // Cyclic
            case 0x06:
                dwRecordType = RIL_SIMRECORDTYPE_CYCLIC;
                break;

           default:
                break;
        }

        if (RIL_SIMRECORDTYPE_LINEAR == dwRecordType ||
            RIL_SIMRECORDTYPE_CYCLIC == dwRecordType)
        {
            // Need at least 5 bytes
            if (5 > cbFileDescDataSize)
            {
                RLOGD("ParseUSIMRecordStatus -"
                        " File descriptor less than 5 bytes.  cbFileDescDataSize=[%d]\r\n",
                        cbFileDescDataSize);
                goto Error;
            }

            dwItemCount = pbFileDescData[4];
            dwRecordSize = (pbFileDescData[2] << 4) + (pbFileDescData[3]);

            // Skip checking of consistency with the File Size data object to
            // save time.
            dwTotalSize = dwItemCount * dwRecordSize;
        }
        else if(RIL_SIMRECORDTYPE_TRANSPARENT == dwRecordType)
        {
            while (cbFcpDataSize > cbDataUsed)
            {
                if (!Parse(
                    pbFcpData + cbDataUsed,
                    cbFcpDataSize - cbDataUsed,&tlvCurrent))
                {
                    RLOGD("ParseUSIMRecordStatus - Couldn't parse TRANSPARENT\r\n");
                    goto Error;
                }

                cbDataUsed += tlvCurrent.m_uTotalSize;

                if (FILE_SIZE_TAG == tlvCurrent.m_bTag)
                {
                    unsigned char* pbFileSize = NULL;

                    if (2 > tlvCurrent.m_uLen)
                    {
                        RLOGD("ParseUSIMRecordStatus -"
                                " TRANSPARENT length must be at least 2\r\n");
                        goto Error;
                    }

                    pbFileSize = tlvCurrent.m_pbValue;

                    dwTotalSize = (pbFileSize[0] << 4) + pbFileSize[1];

                    // Size found. Leave loop
                    break;
                }
            }
        }
    }

    // if record type has not been resolved, check for Master file.
    if (RIL_SIMRECORDTYPE_UNKNOWN == dwRecordType)
    {
        unsigned char* pbFileId = NULL;
        int uFileId = 0;
        BerTlv tlvFileId = {0};

        // Next data object should be File ID.
        Parse(
            pbFcpData + cbFcpDataSize,
            cbFcpDataSize - cbDataUsed, &tlvFileId);

        if (FILE_ID_TAG != tlvFileId.m_bTag)
        {
            RLOGD("ParseUSIMRecordStatus - UNKNOWN tag not equal to FILE_ID_TAG\r\n");
            goto Error;
        }

        if (2 != tlvFileId.m_uLen)
        {
            RLOGD("ParseUSIMRecordStatus - UNKNOWN length not equal to 2\r\n");
            goto Error;
        }

        pbFileId = tlvFileId.m_pbValue;
        uFileId = (pbFileId[0] << 4) + pbFileId[1];

        if (MASTER_FILE_ID != uFileId)
        {
            RLOGD("ParseUSIMRecordStatus -"
                    " UNKNOWN file ID not equal to MASTER_FILE_ID\r\n");
            goto Error;
        }

        dwRecordType = RIL_SIMRECORDTYPE_MASTER;
    }

    sUSIM->dwRecordType = dwRecordType;
    sUSIM->dwTotalSize = dwTotalSize;
    sUSIM->dwRecordSize = dwRecordSize;

    bRet = true;
Error:

    RLOGD("ParseUSIMRecordStatus - EXIT = [%d]\r\n", bRet);
    return bRet;
}   


static  unsigned char SemiByteCharsToByte(char chHigh, char chLow)
{
    unsigned char bRet;

    if ('0' <= chHigh && '9' >= chHigh)
    {
        bRet = (chHigh - '0') << 4;
    }
    else
    {
        bRet = (0x0a + chHigh - 'A') << 4;
    }

    if ('0' <= chLow && '9' >= chLow)
    {
        bRet |= (chLow - '0');
    }
    else
    {
        bRet |= (0x0a + chLow - 'A');
    }
    return bRet;
}

static unsigned char GSMHexToGSM(char* sIn, int cbIn, unsigned char* sOut,
                            int cbOut, int* rcbUsed)
{
    char* pchIn = sIn;
    char* pchInEnd = sIn + cbIn;
    unsigned char* pchOut = sOut;
    unsigned char* pchOutEnd = sOut + cbOut;
    unsigned char fRet = false;

    while (pchIn < pchInEnd - 1 && pchOut < pchOutEnd)
    {
        *pchOut++ = SemiByteCharsToByte(*pchIn, *(pchIn + 1));
        pchIn += 2;
    }

    *rcbUsed = pchOut - sOut;
    fRet = true;
    return fRet;
}

static unsigned char CopyStringNullTerminate(char* pszOut, char* pszIn, int cbOut)
{
    unsigned char fRet = true;
    int cbIn = 0;

    //RIL_LOG_VERBOSE("CopyStringNullTerminate() - Enter\r\n");

    if ((NULL != pszIn) && (NULL != pszOut))
    {
        cbIn = strlen(pszIn);

        strncpy(pszOut, pszIn, cbOut);

        //  Klokworks fix here
        pszOut[cbOut - 1] = '\0';
        //  End Klokworks fix

        if (cbOut <= cbIn)
        {
            fRet = false;
        }
    }

    //RIL_LOG_VERBOSE("CopyStringNullTerminate() - Exit\r\n");

    return fRet;
}

static long ParseSimIo(char *line, int command, RIL_SIM_IO_Response *pResponse)
{
     RLOGD("ParseSimIo() - Enter\r\n");

    long res = RIL_E_GENERIC_FAILURE;
    char* pszRsp = NULL;
    int err = 0;

    int  uiSW1 = 0;
    int  uiSW2 = 0;
    char* szResponseString = NULL;
    int  cbResponseString = 0;
    char m_szNewLine[3];
    
    CopyStringNullTerminate(m_szNewLine, "\r\n", sizeof(m_szNewLine));

    err = at_tok_start(&line);
    if (err < 0) goto Error;

    err = at_tok_nextint(&line, &uiSW1);
    if (err < 0) goto Error;

    err = at_tok_nextint(&line, &uiSW2);
    if (err < 0) goto Error;

    if (at_tok_hasmore(&line)) {
        err = at_tok_nextstr(&line, &pszRsp);
        if (err < 0) goto Error;
    }

    RLOGD("ParseSimIo() - Extracted SW1 = %u and SW2 = %u\r\n", uiSW1, uiSW2);

   // Parse <response>
   // NOTE: we take ownership of allocated szResponseString
   RLOGD("ParseSimIo():pszRsp:%s\r\n",pszRsp);

   if(NULL == pszRsp)
   {
       RLOGD("ParseSimIo:pszRsp == NULL !!!\r\n");
       goto Error;
   }
   
   cbResponseString = strlen(pszRsp) + 1;
   szResponseString = (char*)malloc(cbResponseString);

    if (NULL == szResponseString)
    {
        RLOGE("ParseSimIo()+++3\r\n");
        goto Error;
    }

    memset(szResponseString, 0, cbResponseString);
    strncpy(szResponseString, pszRsp, cbResponseString);

    RLOGD("ParseSimIo() -"
                    " Extracted data string: \"%s\" (%u chars including NULL)\r\n",
                   szResponseString, cbResponseString);
    if (0 != (cbResponseString - 1) % 2)
    {
       RLOGD("ParseSimIo() : String was not a multiple of 2.\r\n");
       goto Error;
    }

    if ((192 == command) && ('6' == szResponseString[0]) && ('2' == szResponseString[1]))
    {
            //  USIM GET_RESPONSE response
       // RIL_LOG_INFO("CTE_XMM6260::ParseSimIo() - USIM GET_RESPONSE\r\n");
        char szTemp[5] = {0};
        struct sUSIMGetResponse sUSIM;
        memset(&sUSIM, 0, sizeof(struct sUSIMGetResponse));

            //  Need to convert the response string from ascii to binary.
        
        int cbNewString = (cbResponseString-1)/2;
        unsigned char *sNewString = (unsigned char*)malloc(cbNewString);
        
        if (NULL == sNewString)
        {
           // RIL_LOG_CRITICAL("CTE_XMM6260::ParseSimIo() - Cannot create new string!\r\n");
            goto Error;
        }
        memset(sNewString, 0, cbNewString);

        int cbUsed = 0;
        if (!GSMHexToGSM(szResponseString, cbResponseString, sNewString, cbNewString, &cbUsed))
        {
            RLOGD("CTE_XMM6260::ParseSimIo() -"
                   " Cannot cconvert szResponseString to GSMHex.\r\n");
            free(sNewString);
            sNewString = NULL;
            cbNewString = 0;
            goto Error;
        }

        //  OK, now parse!
        if (!ParseUSIMRecordStatus((unsigned char*)sNewString, cbNewString, &sUSIM))
        {
            //RIL_LOG_CRITICAL("CTE_XMM6260::ParseSimIo() - Cannot parse USIM record status\r\n");
            free(sNewString);
            sNewString = NULL;
            cbNewString = 0;
            goto Error;
        }


        free(sNewString);
        sNewString = NULL;
        cbNewString = 0;

        RLOGD("ParseSimIo() - sUSIM.dwRecordType=[0x%04X]\r\n",
                sUSIM.dwRecordType);
        RLOGD("ParseSimIo() - sUSIM.dwTotalSize=[0x%04X]\r\n",
                sUSIM.dwTotalSize);
        RLOGD("ParseSimIo() - sUSIM.dwRecordSize=[0x%04X]\r\n",
                sUSIM.dwRecordSize);

        //  Delete old original response.  Create new "fake" response.
        free(szResponseString);
        szResponseString = NULL;
        cbResponseString = 0;

        //  Java layers as of Froyo (Nov 1/2010) only use:
        //  Total size (0-based bytes 2 and 3), File type (0-based byte 6),
        //  Data structure (0-based byte 13), Data record length (0-based byte 14)
        cbResponseString = 31;  //  15 bytes + NULL
        szResponseString = (char*)malloc(cbResponseString);
        if (NULL == szResponseString)
        {
           RLOGE("CTE_XMM6260::ParseSimIo() -"
                    " Cannot create new szResponsestring!\r\n");
            free(sNewString);
            sNewString = NULL;
            goto Error;
        }
        if (!CopyStringNullTerminate(szResponseString,
                "000000000000000000000000000000", cbResponseString))
        {
            RLOGD("CTE_XMM6260::ParseSimIo() -"
                    " Cannot CopyStringNullTerminate szResponsestring!\r\n");
            free(sNewString);
            sNewString = NULL;
            goto Error;
        }

        //  Extract info, put into new response string
        if (!PrintStringNullTerminate(szTemp, 5, "%04X", sUSIM.dwTotalSize))
        {
            RLOGE("CTE_XMM6260::ParseSimIo() -"
                    " Cannot PrintStringNullTerminate sUSIM.dwTotalSize!\r\n");
            free(sNewString);
            sNewString = NULL;
            goto Error;
        }
        memcpy(&szResponseString[4], szTemp, 4);

        if (!PrintStringNullTerminate(szTemp, 3, "%02X", sUSIM.dwRecordSize))
        {
           RLOGD("CTE_XMM6260::ParseSimIo() -"
                    " Cannot PrintStringNullTerminate sUSIM.dwRecordSize!\r\n");
            free(sNewString);
            sNewString = NULL;
            goto Error;
        }
        memcpy(&szResponseString[28], szTemp, 2);

        if (RIL_SIMRECORDTYPE_UNKNOWN == sUSIM.dwRecordType)
        {
            //  bad parse.
            RLOGD("CTE_XMM6260::ParseSimIo() -"
                    " sUSIM.dwRecordType is unknown!\r\n");
            free(sNewString);
            sNewString = NULL;
            goto Error;
        }


        if (RIL_SIMRECORDTYPE_MASTER == sUSIM.dwRecordType)
        {
            szResponseString[13] = '1';
        }
        else if (RIL_SIMRECORDTYPE_DEDICATED == sUSIM.dwRecordType)
        {
            szResponseString[13] = '2';
        }
        else
        {
            //  elementary file
            szResponseString[13] = '4';

            if (RIL_SIMRECORDTYPE_TRANSPARENT == sUSIM.dwRecordType)
            {
                szResponseString[27] = '0';
            }
            else if (RIL_SIMRECORDTYPE_LINEAR == sUSIM.dwRecordType)
            {
                szResponseString[27] = '1';
            }
            else if (RIL_SIMRECORDTYPE_CYCLIC == sUSIM.dwRecordType)
            {
                szResponseString[27] = '3';
            }
        }

        //  ok we're done.  print.
        RLOGD("ParseSimIo() - new USIM response=[%s]\r\n",
                szResponseString);

    }

    // Allocate memory for the response struct PLUS a buffer for the response string
    // The char* in the RIL_SIM_IO_Response will point to the buffer allocated directly after the
    // RIL_SIM_IO_Response, When the RIL_SIM_IO_Response is deleted, the corresponding response
    // string will be freed as well.
    //pResponse = (RIL_SIM_IO_Response*)malloc(sizeof(RIL_SIM_IO_Response) + cbResponseString + 1);
    pResponse->simResponse = (char *)malloc(cbResponseString + 1);
    if (NULL == pResponse->simResponse)
    {
        RLOGD("CTE_XMM6260::ParseSimIo() -"
                " Could not allocate memory for a RIL_SIM_IO_Response struct.\r\n");
        goto Error;
    }
    
    memset(pResponse->simResponse, 0, cbResponseString + 1);
    pResponse->sw1 = uiSW1;
    pResponse->sw2 = uiSW2;

    if (NULL == szResponseString)
    {
        free(pResponse->simResponse);
        pResponse->simResponse = NULL;
    }
    else
    {
        if (!CopyStringNullTerminate(pResponse->simResponse, szResponseString, cbResponseString))
        {
           RLOGE("CTE_XMM6260::ParseSimIo() -"
                    " Cannot CopyStringNullTerminate szResponseString\r\n");
            goto Error;
        }

        // Ensure NULL termination!
        pResponse->simResponse[cbResponseString] = '\0';
    }

    res = RIL_E_SUCCESS;

Error:
    if (RIL_E_SUCCESS != res)
    {
        free(pResponse->simResponse);
        pResponse->simResponse = NULL;
    }

    free(szResponseString);
    szResponseString = NULL;

   RLOGD("CTE_XMM6260::ParseSimIo() - Exit\r\n");
    return res;
}
#endif
/* END:   Added by eric.li, 2018/10/14   PN:add for sim io parse */



void  requestSIM_IO(void *data, size_t datalen __unused, RIL_Token t)
{
    ATResponse *p_response = NULL;
    RIL_SIM_IO_Response sr;
    int err;
    char *cmd = NULL;
    RIL_SIM_IO_v6 *p_args;
    char *line;
    unsigned int i = 0;
    ATResponse *qccid_response = NULL;
    char iccid_low = 0;
    int command =0;
    memset(&sr, 0, sizeof(sr));

    p_args = (RIL_SIM_IO_v6 *)data;
    command = p_args->command;

    if (p_args->command == COMMAND_GET_RESPONSE) {
        p_args->p3 = 0;
    }

    if((mode_flag  == GHT_FG621) ||(mode_flag == GHT_FG650) || (mode_flag == GHT_L610) || (GHT_MC919 == mode_flag) || (GHT_MC66x == mode_flag))
    {
        if (p_args->data == NULL) 
        {
                    asprintf(&cmd, "AT+CRSM=%d,%d,%d,%d,%d",
                    p_args->command, p_args->fileid,
                    p_args->p1, p_args->p2, p_args->p3);
        }
        else
        {
                    asprintf(&cmd, "AT+CRSM=%d,%d,%d,%d,%d,\"%s\"",
                    p_args->command, p_args->fileid,
                    p_args->p1, p_args->p2, p_args->p3, p_args->data);
        }
    }
    else
    {
        
        if (p_args->data == NULL) {
				RLOGD("stephen p_args->data == NULL to AT+CRSM");
                asprintf(&cmd, "AT+CRSM=%d,%d,%d,%d,%d,,\"%s\"",
                            p_args->command, p_args->fileid,
                            p_args->p1, p_args->p2, p_args->p3, p_args->path);
            }
            else
            {
				RLOGD("stephen p_args->data not NULL to AT+CRSM");
                asprintf(&cmd, "AT+CRSM=%d,%d,%d,%d,%d,\"%s\",\"%s\"",
                            p_args->command, p_args->fileid,
                            p_args->p1, p_args->p2, p_args->p3, p_args->data, p_args->path);
            }
    }
    
    err = at_send_command_singleline(cmd, "+CRSM:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(sr.sw1));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(sr.sw2));
    if (err < 0) goto error;

    if (at_tok_hasmore(&line)) {
        err = at_tok_nextstr(&line, &(sr.simResponse));
        if (err < 0) goto error;
    }


//see telephony\src\java\com\android\internal\telephony\uicc\IccFileHandler.java handleMessage() -> case EVENT_GET_BINARY_SIZE_DONE:
    if (p_args->command == COMMAND_GET_RESPONSE)
    {
		RLOGD("stephen p_args->command == COMMAND_GET_RESPONSE to usim2sim");
        usim2sim(&sr);
    }


    RLOGD("[%s]: RIL_SIM_IO_Response Complete sr.sw1=%d, sr.sw2=%d, sr.simResponse=%s",
        __func__, sr.sw1, sr.sw2, sr.simResponse);

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        if(!sr.sw1 && !sr.sw2)
        {
            goto error;
        }
    }

#if 0
/*SIM_IO request: Abnormal handling of telecom card data reading, lisf 20181207*/
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
   if(!sr.sw1 && !sr.sw2)
  {
        goto error;
   }
#endif
#endif

    if (p_args->fileid == EF_ICCID && sr.simResponse == NULL)
        goto error;
    
    RIL_onRequestComplete(t, RIL_E_SUCCESS, &sr, sizeof(sr));
    at_response_free(p_response);
    free(cmd);

    return;
error:
    if (p_args->fileid == EF_ICCID) {
        sr.sw1 = 144;
        sr.sw2 = 0;
        sr.simResponse = NULL;
        if (p_args->command == COMMAND_GET_RESPONSE) {
            sr.simResponse = "0000000a2fe2040000000000000000";
        } else if (p_args->command == COMMAND_READ_BINARY) {
#define TELCOMM_DUMMY_ICCID "98681031098310024233"
            err = at_send_command_singleline("AT+CCID?", "+CCID: ", &qccid_response);
            if (err < 0 || qccid_response == NULL || qccid_response->success == 0) {
                sr.simResponse = TELCOMM_DUMMY_ICCID;
            } else {
            line = qccid_response->p_intermediates->line;
            if (0 == at_tok_start(&line) && 0 == at_tok_nextstr(&line, &sr.simResponse)) {
                for (i = 0; i < strlen(sr.simResponse); i+=2) {
                    if ((strlen(sr.simResponse) - 1) < (i+1)) {
                        sr.simResponse = TELCOMM_DUMMY_ICCID;
                    } else {
                        iccid_low = sr.simResponse[i];
                        sr.simResponse[i] = sr.simResponse[i+1];
                        sr.simResponse[i+1] = iccid_low;
                    }
                }
            } else {
                sr.simResponse = TELCOMM_DUMMY_ICCID;
            }
            }
        }
        if (sr.simResponse != NULL) {
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &sr, sizeof(sr));
            at_response_free(p_response);
            free(cmd);
            if (NULL != qccid_response) {
                at_response_free(qccid_response);
                qccid_response = NULL;
            }
            return;
        }
    }
    RLOGD("%s error\n", __func__);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    free(cmd);
    if (NULL != qccid_response) {
        at_response_free(qccid_response);
    }
}

/* BEGIN: Added by eric.li, 2018/12/26   PN:function check facility */
static int odm_check_facility_cmd(char *facility_string)
{
    ATResponse   *p_response = NULL;
    char *line;
    char *cmd = NULL;
    int  response = -1;
    int err;

    if (NULL == facility_string)
    {
        RLOGD("facility_string is NULL");
        goto error;	
    }

    asprintf(&cmd, "AT+CLCK=\"%s\",2", facility_string);

    err = at_send_command_singleline(cmd, "+CLCK:", &p_response);

    if (NULL != cmd)
    {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0)
    {
        goto error;
    }
    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0)
    {
        goto error;
    }

    err = at_tok_nextint(&line, &response);
    if (err < 0)
    {
        goto error;
    }

    at_response_free(p_response);
    RLOGD("odm_check_clck_cmd response[%d]", response);
    return response;

    error:
    RLOGD("odm_check_clck_cmd err happened!!!!!!");
    at_response_free(p_response);
    return -1;
}
/* END:   Added by eric.li, 2018/12/26   PN:function check facility */
//duanshitao add for sim pin and puk 20101122

void  requestQueryFacilityLock(void*  data, size_t  datalen __unused, RIL_Token  t)
{
    int  response;
    char *facility_string = NULL;
    char *facility_password = NULL;
    char *facility_class = NULL;

    assert (datalen >=  (3 * sizeof(char **)));

    facility_string   = ((char **)data)[0];
    facility_password = ((char **)data)[1];
    facility_class    = ((char **)data)[2];
/*begin:modified by lisf 20181116 for check sim lock status*/

	RLOGD("%s facility_string[%s];facility_password[%s]facility_class[%s] ", __FUNCTION__,facility_string, facility_password, facility_class);

    if (strcmp("SC", facility_string) == 0)
    {
        switch (gSimStatus)
        {
            case    SIM_READY: /* SIM_READY means the radio state is RADIO_STATE_SIM_READY */
                response =0;
                break;

            case    SIM_PIN:
            case    SIM_PUK:
            case    SIM_NETWORK_PERSONALIZATION:
                response = 1;
                break;

            case   SIM_ABSENT :
            case    SIM_NOT_READY :	   
                default :
                response = -1; 
                break;
        }
        
        if (0 == response)
        {
            //need check if CLCK locked.
            //instead using AT+CLCK="SC",2 directly to check, as this AT cmd always block too much time leading timeout to reset modem
            response = odm_check_facility_cmd(facility_string);				
        }
        RLOGD("%s getSIMStatus response [%d],   gSimStatus:%d(%s)", __FUNCTION__, response, gSimStatus, simStatusToString(gSimStatus));
        if((0 == response) || (1 == response))
        {
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
            return;
        }
        else
        {
            // response equal -1, unsol RIL_E_GENERIC_FAILURE for now;
            goto error;
        }
        /*end:modified by lisf 20181116 for check sim lock status*/
    }
    else
    {
    	response = odm_check_facility_cmd(facility_string);
    	RLOGD("other facility_string[%s] response[%d]", facility_string, response);
    	if (-1 == response)
    		goto error;

		RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
		return;
	}

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    return;
}

void  requestSetFacilityLock(void*  data, size_t  datalen __unused, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    ATResponse     *pin_response =NULL;
    int           err;
    char*         cmd = NULL;
    char pin = 0;
    int rc=0;
    int response[2];
    char *nettypeline;

    char *facility_string = NULL;
    char *facility_mode = NULL;
    char *facility_password = NULL;

    /*begin:added by lisf 20181121*/
    int network_type = 0;
    network_type = odm_get_current_network_type();
    /*end:added by lisf 20181121*/
    assert(datalen >= (4 * sizeof(char **)));

    facility_string = ((char **) data)[0];
    facility_mode = ((char **) data)[1];
    facility_password = ((char **) data)[2];

    if (strcmp("SC", facility_string) == 0)
    {
        pin = 1;
    }

/*begin:modified by lisf 20181121*/
	if(6 == network_type || 7 ==network_type || 13 ==network_type)
/*end:modified by lisf 20181121*/
    {
        asprintf(&cmd, "AT+QCLCK=\"%s\",%s,\"%s\"", facility_string, facility_mode, facility_password);
    }
    else
    {
        asprintf(&cmd, "AT+CLCK=\"%s\",%s,\"%s\"", facility_string, facility_mode, facility_password);
    }

    err = at_send_command(cmd, &p_response);

    if (err < 0 || p_response->success == 0)
    {
        if (pin == 1)
        {
            //<!--[ODM]wangmengying@2019.07.31 modify PIN related AT
            if (GHT_NL668 <= mode_flag)
            // end-->
            {
                rc = at_send_command_singleline("AT+TPIN?","+TPIN:",&pin_response);
            }
            else
            {
                rc = at_send_command_singleline("AT+PINPUK=?", "+PINPUK:",&pin_response);
            }

            if (rc < 0 || pin_response->success == 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error;
            }

            nettypeline = pin_response->p_intermediates->line;
            rc = at_tok_start(&nettypeline);
            if (rc < 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error;
            }

            rc= at_tok_nextint(&nettypeline, &(response[0]));
            if (rc < 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error;
            }
        }

        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &response[0], sizeof(int));
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &response[0], sizeof(int *));
        }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &response[0], sizeof(int));
#else
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &response[0], sizeof(int *));
#endif
#endif
    }
    else
    {
        if (pin == 1)
        {
            response[0]=3;

            if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                RIL_onRequestComplete(t, RIL_E_SUCCESS, &response[0], sizeof(int));
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                RIL_onRequestComplete(t, RIL_E_SUCCESS, &response[0], sizeof(int *));
            }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &response[0], sizeof(int));
#else

            RIL_onRequestComplete(t, RIL_E_SUCCESS, &response[0], sizeof(int *));
#endif
#endif
        }
    }

error:
    at_response_free(p_response);
    at_response_free(pin_response);
}

//void  requestEnterSimPin(void*  data, size_t  datalen, RIL_Token  t)
void  requestEnterSimPin(int request, void*  data, size_t  datalen __unused, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    ATResponse   *pin_response = NULL;
    int           err;
    int           num_retries = -1;
    char*         cmd = NULL;
    const char**  strings = (const char**)data;
    int response[2];
    int rc=0;
    char *nettypeline = NULL;
    int count = 0;

    //printf(&cmd, "AT+CPIN=%s", strings[0]);
    if (( datalen == sizeof(char*)) || !strings[1] || !strings[1][0])
    {
    // <!--added by wangmengying@2020.2.12 fix bug40734,AT+CPIN="xxxx"
        asprintf(&cmd, "AT+CPIN=\"%s\"", strings[0]);
    // end--!>
    }
    else
    {
        asprintf(&cmd, "AT+CPIN=\"%s\",\"%s\"", strings[0], strings[1]);
    }

    err = at_send_command(cmd, &p_response);
    RLOGD("EnterSimPin return err = %d, p_response->success = %d", err, p_response->success);
    free(cmd);
    cmd =NULL;

    //<!--[ODM]wangmengying@2019.07.31 modify PIN related AT
    if (GHT_NL668 <= mode_flag )
    // end-->
    {
        if (err < 0 || p_response->success == 0)
        {
            rc = at_send_command_singleline("AT+TPIN?","+TPIN:",&pin_response);

            if (rc < 0 || pin_response->success == 0)
            {
                goto error1;
            }
            nettypeline = pin_response->p_intermediates->line;
            rc = at_tok_start(&nettypeline);
            if (rc < 0)
            {
                goto error1;
            }

            rc = at_tok_nextint(&nettypeline, &num_retries);
            if (rc < 0)
            {
                goto error_668;
            }

            if (request == RIL_REQUEST_ENTER_SIM_PUK)
            {
                err = at_tok_nextint(&nettypeline, &num_retries);
                RLOGD("response[%d] = %d\n",count,num_retries);
                if (err < 0) goto error_668;
                RLOGD("refresh response[%d] [%d] = %d\n",request,count,num_retries);
            }

            goto error_668;
        }
        else
        {
            /* Got OK, return success. */

            num_retries = 1;

            if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                RIL_onRequestComplete(t, RIL_E_SUCCESS, &num_retries, sizeof(int));
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                RIL_onRequestComplete(t, RIL_E_SUCCESS, &num_retries, sizeof(int *));
            }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &num_retries, sizeof(int));
#else
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &num_retries, sizeof(int *));
#endif
#endif
            sleep(1);
            /* Make sure we get notifications for network registeration
               of both voice and data now */
            at_send_command("AT+CREG=2", NULL);
            at_send_command("AT+CGREG=2", NULL);
            at_send_command("AT+CEREG=2", NULL);

            /* Notify that SIM is ready */
            setRadioState(RADIO_STATE_SIM_READY);
        // <!--added by wangmengying@2020.3.11 fix bug42831,unlock SIM pin and update SIM status
            RIL_onUnsolicitedResponse( RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED,NULL, 0);
        // end-->
        }
        return;
    }
    else
    {
        if (err < 0 || p_response->success == 0)
        {
            rc = at_send_command_singleline("AT+PINPUK=?", "+PINPUK:",&pin_response);
            if (rc < 0 || pin_response->success == 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error_660;
            }
            nettypeline = pin_response->p_intermediates->line;
            rc = at_tok_start(&nettypeline);
            if (rc < 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error_660;
            }

            rc = at_tok_nextint(&nettypeline, &(response[0]));
            if (rc < 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error_660;
            }

            RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &response[0], sizeof(int *));
        }
        else
        {
            response[0]=3;
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &response[0], sizeof(int *));
            TIMEVAL_DELAYINIT.tv_sec = 5;
            RIL_requestTimedCallback(initializeCallback, NULL, &TIMEVAL_DELAYINIT);
        }
    }

error1:
    at_response_free(p_response);
    num_retries = 1;
error_668:

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &num_retries, sizeof(int));
    }
    else
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &num_retries, sizeof(int *));
    }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &num_retries, sizeof(int));
#else
    RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &num_retries, sizeof(int *));
#endif
#endif
error_660:
    at_response_free(p_response);
    at_response_free(pin_response);
}

#if 0
void  requestEnterSimPuk(void*  data, size_t  datalen, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char*         cmd = NULL;
    const char**  strings = (const char**)data;
    int response[2];
    char *nettypeline,*nettypestr;
    int    rc;
    //    ARLOGD("Sim puk = %s, Sim pin = %s", strings[0], strings[1]);
    datalen;
    asprintf(&cmd, "AT+CPIN=\"%s\",\"%s\"", strings[0], strings[1]);

    err = at_send_command(cmd, &p_response);

    if (err < 0 || p_response->success == 0)
    {
        rc = at_send_command_singleline("AT+PINPUK=?", "+PINPUK:",&p_response);

        if (rc < 0 || p_response->success == 0)
        {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
            goto error;
        }
        nettypeline = p_response->p_intermediates->line;
        rc = at_tok_start(&nettypeline);
        if (rc < 0)
        {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
            goto error;
        }

        rc = at_tok_nextint(&nettypeline,  &(response[0]));
        if (rc <0)
        {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
            goto error;
        }
        rc = at_tok_nextint(&nettypeline,  &(response[1]));
        if (rc <0)
        {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
            goto error;
        }

        RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &response[1], sizeof(int *));
    }
    else
    {
        response[1]=10;
        RIL_onRequestComplete(t, RIL_E_SUCCESS, &response[1], sizeof(int *));
        TIMEVAL_DELAYINIT.tv_sec = 5;
        RIL_requestTimedCallback(initializeCallback, NULL, &TIMEVAL_DELAYINIT);
    }

error:
    at_response_free(p_response);
}
#endif

//void  requestChangeSimPin(void*  data, size_t  datalen, RIL_Token  t)
void  requestChangeSimPin(int request, void*  data, size_t  datalen __unused, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char*         cmd = NULL;
    const char**  strings = (const char**)data;;
    int response[2];
    int rc;
    char *nettypeline = NULL;
    int num_retries = -1;
    int count = 0;

    asprintf(&cmd, "AT+CPWD=\"SC\",\"%s\",\"%s\"", strings[0], strings[1]);

    err = at_send_command(cmd, &p_response);
    free(cmd);
    cmd = NULL;

    //<!--[ODM]wangmengying@2019.07.31 modify PIN related AT
    if (GHT_NL668 <= mode_flag)
    // end-->
    {
        if (err < 0 || p_response->success == 0)
        {
            at_response_free(p_response);
            rc = at_send_command_singleline("AT+TPIN?","+TPIN:",&p_response);

            if (rc < 0 || p_response->success == 0)
            {
                goto error1;
            }
            nettypeline = p_response->p_intermediates->line;
            rc = at_tok_start(&nettypeline);
            if (rc < 0)
            {
                goto error1;
            }

            rc = at_tok_nextint(&nettypeline, &num_retries);
            if (rc < 0)
            {
                goto error_668;
            }

            if (request == RIL_REQUEST_ENTER_SIM_PUK)
            {
                err = at_tok_nextint(&nettypeline, &num_retries);
                RLOGD("response[%d] = %d\n",count,num_retries);
                if (err < 0) goto error_668;
                RLOGD("refresh response[%d] [%d] = %d\n",request,count,num_retries);
            }

            goto error_668;
        }
        else
        {
            num_retries = 1;
            if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
            {
                RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                RIL_onRequestComplete(t, RIL_E_SUCCESS, &num_retries, sizeof(int));
            }
            else
            {
                RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                RIL_onRequestComplete(t, RIL_E_SUCCESS, &num_retries, sizeof(int *));
            }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &num_retries, sizeof(int));
#else
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &num_retries, sizeof(int *));
#endif
#endif
            /* Make sure we get notifications for network registeration
               of both voice and data now */
            at_send_command("AT+CREG=2", NULL);
            at_send_command("AT+CGREG=2", NULL);
            at_send_command("AT+CEREG=2", NULL);

            /* Notify that SIM is ready */
            setRadioState(RADIO_STATE_SIM_READY);
        }
        at_response_free(p_response);
		return;
    }
    else
    {
        if (err < 0 || p_response->success == 0)
        {
            at_response_free(p_response);
            rc = at_send_command_singleline("AT+PINPUK=?", "+PINPUK:",&p_response);
            if (rc < 0 || p_response->success == 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error_660;
            }
            nettypeline = p_response->p_intermediates->line;
            rc = at_tok_start(&nettypeline);
            if (rc < 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error_660;
            }
            rc = at_tok_nextint(&nettypeline, &(response[0]));
            if (rc < 0)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                goto error_660;
            }
            RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &response[0], sizeof(int *));
        }
        else
        {
            response[0]=3;
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &response[0], sizeof(int *));
        }
    }

error1:
    at_response_free(p_response);
    num_retries = 1;
error_668:
    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &num_retries, sizeof(int));
    }
    else
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &num_retries, sizeof(int *));
    }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &num_retries, sizeof(int));
#else
    RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &num_retries, sizeof(int *));
#endif
#endif
error_660:
    at_response_free(p_response);
}
//duanshitao add for sim pin and puk 20101122 end

#if 0
void  requestSIM_IO_M910(void *data, size_t datalen __unused, RIL_Token t)
{
    ATResponse *p_response = NULL;
    RIL_SIM_IO_Response sr;
    int err;
    char *cmd = NULL;
    RIL_SIM_IO_v6 *p_args;
    char *line;
    unsigned long i = 0;
    ATResponse *qccid_response = NULL;
    char iccid_low = 0;

    memset(&sr, 0, sizeof(sr));

    p_args = (RIL_SIM_IO_v6 *)data;

    /* FIXME handle pin2 */
#if 1 //fibocom
    if (p_args->command == COMMAND_GET_RESPONSE) {
        p_args->p3 = 0;
    }
#endif

    if (p_args->data == NULL) {
        //RLOGD("[%s]: p_args->data is NULL", __func__);
        asprintf(&cmd, "AT+CRSM=%d,%d,%d,%d,%d",
                    p_args->command, p_args->fileid,
                    p_args->p1, p_args->p2, p_args->p3);
    }
    else
    {
        asprintf(&cmd, "AT+CRSM=%d,%d,%d,%d,%d,\"%s\"",
                    p_args->command, p_args->fileid,
                    p_args->p1, p_args->p2, p_args->p3, p_args->data);
    }

    err = at_send_command_singleline(cmd, "+CRSM:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(sr.sw1));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(sr.sw2));
    if (err < 0) goto error;

    if (at_tok_hasmore(&line)) {
        err = at_tok_nextstr(&line, &(sr.simResponse));
        if (err < 0) goto error;
    }

#if 1 //fibocom
//see telephony\src\java\com\android\internal\telephony\uicc\IccFileHandler.java handleMessage() -> case EVENT_GET_BINARY_SIZE_DONE:
    if (p_args->command == COMMAND_GET_RESPONSE)
        usim2sim(&sr);
#endif

    /*RLOGD("[%s]: RIL_SIM_IO_Response Complete sr.sw1=%d, sr.sw2=%d, sr.simResponse=%s",
        __func__, sr.sw1, sr.sw2, sr.simResponse);*/

#ifdef QUECTEL_REPORT_SIGNAL_STRENGTH
    if ((p_args->fileid == EF_ICCID) && (p_args->command == COMMAND_READ_BINARY)) {
        requestSignalStrength(NULL, 0, NULL);
    }
#endif

    if (p_args->fileid == EF_ICCID && sr.simResponse == NULL)
        goto error;
    
    RIL_onRequestComplete(t, RIL_E_SUCCESS, &sr, sizeof(sr));
    at_response_free(p_response);
    free(cmd);

    return;
error:
    if (p_args->fileid == EF_ICCID) {
        sr.sw1 = 144;
        sr.sw2 = 0;
        sr.simResponse = NULL;
        if (p_args->command == COMMAND_GET_RESPONSE) {
            sr.simResponse = "0000000a2fe2040000000000000000";
        } else if (p_args->command == COMMAND_READ_BINARY) {
#define TELCOMM_DUMMY_ICCID "98681031098310024233"
			err = at_send_command_singleline("AT+CCID?", "+CCID: ", &qccid_response);
            if (err < 0 || qccid_response == NULL || qccid_response->success == 0) {
                sr.simResponse = TELCOMM_DUMMY_ICCID;
            } else {
            line = qccid_response->p_intermediates->line;
            if (0 == at_tok_start(&line) && 0 == at_tok_nextstr(&line, &sr.simResponse)) {
                for (i = 0; i < strlen(sr.simResponse); i+=2) {
                    if ((strlen(sr.simResponse) - 1) < (i+1)) {
                        //RLOGD("[%s:%d] array out of index, invalid iccid length.\n", __func__, __LINE__);
                        sr.simResponse = TELCOMM_DUMMY_ICCID;
                    } else {
                        iccid_low = sr.simResponse[i];
                        sr.simResponse[i] = sr.simResponse[i+1];
                        sr.simResponse[i+1] = iccid_low;
                    }
                }
            } else {
                //RLOGD("[%s:%d] at_tok_start or at_tok_nextstr failed.\n", __func__, __LINE__);
                sr.simResponse = TELCOMM_DUMMY_ICCID;
            }
            }
        }
        if (sr.simResponse != NULL) {
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &sr, sizeof(sr));
            at_response_free(p_response);
            free(cmd);
            if (NULL != qccid_response) {
                at_response_free(qccid_response);
                qccid_response = NULL;
            }
            return;
        }
    }
    RLOGD("%s error\n", __func__);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    free(cmd);
    if (NULL != qccid_response) {
        at_response_free(qccid_response);
    }
}
#else
void  requestSIM_IO_M910(void *data, size_t datalen __unused, RIL_Token t)
{
}
#endif