/******************************************************************************
  Copyright (C), 2019, Shenzhen G&T Industrial Development Co., Ltd

  File:      getdevinof.c

  Author:  Fibocom-diego
  Version: 1.0
  Date:  2019.04

  Description:   getdevinfo APIs

** History:
**Author (core ID)                Date          Number     Description of Changes
**-----------------------------------------------------------------------------
** NODECOM-Aron                30-10-2018         **   init version getdevinfo detect_usb_device
** FIBOCOM-diego               14-04-2019         **   add General Function getUsbPortInfo
** -----------------------------------------------------------------------------
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <fcntl.h>

#define LOG_TAG GHT_RIL
#include <utils/Log.h>

#include<sys/types.h>
#include <unistd.h>
#include <ril_common.h>

#include "getdevinfo.h"
#include <sys/stat.h>
#include <cutils/properties.h>

#define TTY_NAME "ttyUSB"
#define SYS_USB_ROOT_DIR "/sys/bus/usb/devices/"
#define IDPRODUCT_FILE "idProduct"
#define AL_PID 0x1001
//added for NL678
#define AL_PID_NL678 0x0104
//added for NL678-E-00
//add by zhengjianrong for MA510 Ril begin
#define AL_PID_MA510 0x0106
//add by zhengjianrong for MA510 Ril end
#define AL_PID_L610 0x4d10

#define AL_PID_FG621 0x0a04

extern product_model mode_flag;
static int readfile(char *pathname, char* buffer,  int size);
static int getfirstinterfacename(char*dir,char*ifname);
static int readinterfaceinfo(char *pathname,char *class, char *subclass, char *protocol);
static int reversefind(const char *str, char ch);
static int get_net_mode();
static int get_channels(char *atchannel, char *datachannel);
static int get_devinfo(char *dir,char *vid);
extern int detect_usb_device(char *atchannel, char *datachannel);

char interface_name[256];


struct interfaceinfo
{
    char ifclass[4];
    char ifsubclass[4];
    char ifprotocol[4];
};

struct deviceinfo
{
    char vid[6];
    char pid[6];
    char atchannel[15];
    char datachannel[15];
    int mode;
};

//<!-- build 32/64 by caogang@20171025
struct deviceinfo deviceinfotable[]=
{
    {"1508", "1001", "/dev/ttyUSB1", "/dev/ttyUSB2", 0},
  //added for NL678		
    {"2cb7", "0104", "/dev/ttyUSB1", "/dev/ttyUSB2", 0},		
//    {NULL, NULL, NULL, NULL, 0}
    {"\0", "\0", "\0", "\0", 0}
};

//struct deviceinfo mydevinfo = {0};
struct deviceinfo mydevinfo = {"\0", "\0", "\0", "\0", 0};
//end -->

static int readfile(char *pathname, char* buffer, int size)
{
    int fd;
    int count=0;

    if(buffer==NULL)
    {
        return 0;
    }
    if(pathname==NULL)
        return 0;
    if((fd=open(pathname,O_RDONLY))==-1)
    {
        return 0;
    }
    count=read(fd,buffer,size);
    close(fd);
    return 1;
}

static int getfirstinterfacename(char*dir, char*ifname)
{
    DIR* dp=NULL;
    struct dirent *filename;
    char subdir[10];
    int index;

    dp = opendir(dir);
    if(dp == NULL)
    {
        RLOGD("Opendir %s failed!", dir);
        return 0;
    }
    index = reversefind(dir, '/');
    memcpy(subdir, dir+index+1, strlen(dir)-index);
    //RLOGD("subdir = %s\n", subdir);

    while((filename=readdir(dp))!=NULL)
    {
        //RLOGD("filename:%s\n",filename->d_name);
        if(strstr(filename->d_name, subdir) != NULL)
        {
            memcpy(ifname, filename->d_name, strlen(filename->d_name)+1);
            return 1;
        }
    }
    return 0;
}

static int readinterfaceinfo(char *pathname,char *class, char *subclass, char *protocol)
{
    char filename[256];
    char tmp[20];

    memset(filename, 0, 256);
    strcat(filename, pathname);
    strcat(filename, "/bInterfaceClass");
    readfile(filename, tmp, 2);
    tmp[2] = 0;
    memcpy(class, tmp, 3);

    memset(filename, 0, 256);
    strcat(filename, pathname);
    strcat(filename, "/bInterfaceSubClass");
    readfile(filename, tmp, 2);
    tmp[2] = 0;
    memcpy(subclass, tmp, 3);

    memset(filename, 0, 256);
    strcat(filename, pathname);
    strcat(filename, "/bInterfaceProtocol");
    readfile(filename, tmp, 2);
    tmp[2] = 0;
    memcpy(protocol, tmp, 3);

    return 0;
}

static int reversefind(const char *str, char ch)
{
    int i, len;

    len = strlen(str);
    for(i=len-1; i>=0; i--)
    {
        if(str[i] == ch)
        {
            return i;
        }
    }

    return -1;
}

int getdevinfors(char *vid, char *pid, char *atchannel, char *datachannel, int *mode)
{
    char dir[] = "/sys/bus/usb/devices";
    int ret;
    vid;
    *mode = 0;
    //modify for NL678
    if (mode_flag <GHT_NL678_E)
    {
    	   sprintf(pid, "1001");
    }
    else if(mode_flag == GHT_NL678_E)
    {
     	   sprintf(pid, "0104");
    }
    detect_usb_device(atchannel,datachannel);

    return 1;
}

int detect_usb_device(char *atchannel, char *datachannel)
{
    DIR *dp=NULL,*dp2=NULL,*dp3=NULL;
    int fd;
    struct dirent *root_entry;
    struct dirent *sec_entry;
    struct dirent *third_entry;
    char buf[256];
    char tty_at_name[16];
    char tty_modem_name[16];
    char cur_atchannel[15];
    char cur_datachannel[15];
    int tty_number;
    int product_id = 0;
    char *current_dir_ptr = NULL;
    char current_dir[128];

    dp = opendir(SYS_USB_ROOT_DIR);
    if(!dp)
    {
        RLOGD("open sys dir fail");
        return 0;
    }
    chdir(SYS_USB_ROOT_DIR);
    current_dir_ptr = getcwd(current_dir,128);
    while((root_entry = readdir(dp)) != NULL)
    {
        if((strcmp(".",root_entry->d_name) == 0) ||
                (strcmp("..",root_entry->d_name) == 0))
        {
            continue;
        }
        chdir(root_entry->d_name);
        if(access(IDPRODUCT_FILE,F_OK) == 0)
        {
            fd = open(IDPRODUCT_FILE,O_RDONLY);
            memset(buf,0,sizeof(buf));
            read(fd,buf,4);
            close(fd);
            product_id = strtol(buf,NULL,16);
            RLOGD("Read result:buf->%s,product_id=0x%04x",buf,product_id);
            if(AL_PID == product_id || product_id == AL_PID_NL678 || product_id == AL_PID_MA510 
                    || product_id == AL_PID_L610 || product_id == AL_PID_FG621)
            {
                sprintf(tty_at_name,"%s:1.2",root_entry->d_name);
                sprintf(tty_modem_name,"%s:1.1",root_entry->d_name);
                chdir(tty_at_name);
                current_dir_ptr = getcwd(current_dir,128);
                dp2 = opendir(current_dir);
                if(!dp2)
                {
                    RLOGD("open sys dir fail");
                    if(dp)
                        closedir(dp);
                    return 0;
                }
                while((sec_entry = readdir(dp2)) != NULL)
                {
                    if(strncmp(sec_entry->d_name,TTY_NAME,6) == 0)
                    {
                        memcpy(cur_atchannel,sec_entry->d_name,14);
                        sprintf(atchannel,"/dev/%s",cur_atchannel);
                    }
                }
                chdir(SYS_USB_ROOT_DIR);
                chdir(root_entry->d_name);
                chdir(tty_modem_name);
                current_dir_ptr = getcwd(current_dir,128);
                dp3 = opendir(current_dir);
                if(!dp3)
                {
                    RLOGD("open sys dir fail");
                    if(dp)
                        closedir(dp);
                    if(dp2)
                        closedir(dp2);
                    return 0;
                }
                while((third_entry = readdir(dp3)) != NULL)
                {
                    if(strncmp(third_entry->d_name,TTY_NAME,6) == 0)
                    {
                        memcpy(cur_datachannel,third_entry->d_name,14);
                        sprintf(datachannel,"/dev/%s",cur_datachannel);
                    }
                }

            }
            else
            {
                //added for NL678-E-00
                if (mode_flag <GHT_NL678_E)
   		 {
               RLOGD("pid is not 0x1001");
              }
		 else if(mode_flag == GHT_NL678_E)
		 {
		       RLOGD("pid is not 0x0104");
		 }
		 else if(mode_flag == GHT_MA510_GL)
		 {
		       RLOGD("pid is not 0x0106");
		 }
                chdir(SYS_USB_ROOT_DIR);
                continue;
            }
        }
        chdir(SYS_USB_ROOT_DIR);
    }
    if(dp)
        closedir(dp);
    if(dp2)
        closedir(dp2);
    if(dp3)
        closedir(dp3);
    RLOGD("atchannel=%s,datachannel=%s",atchannel,datachannel);
    return 1;

}


/*
 *  diego add for fuctions campaticability M910
 *
 */
static const struct fibo_module_info * fibo_get_module_info(char *idVendor, char *idProduct){
    unsigned int i;

    for (i = 0; i < ARRAY_SIZE(fibo_module_info_table); i++){
        if (!strncasecmp(fibo_module_info_table[i].idVendor, idVendor, USBID_LEN) \
            && !strncasecmp(fibo_module_info_table[i].idProduct, idProduct, USBID_LEN))
        {
            return &fibo_module_info_table[i];
        }
    }
    return NULL;
}

static int fibo_get_usb_device_info(struct fibo_usb_device_info *device_info)
{
    int fd;
    int ret = -1;
    DIR *pDir = NULL;
    struct dirent *ent;
    struct stat statbuf;
    const char *dir = "/sys/bus/usb/devices";
    char filename[MAX_PATH] ={0};
    struct fibo_usb_device_info usb_device_info;
    struct fibo_module_info *module_info = NULL;

    if ((pDir = opendir(dir)) == NULL){
        RLOGE("Cannot open directory:%s/", dir);
        goto done;
    }

    memset(&usb_device_info,0,sizeof(struct fibo_usb_device_info));

    while((ent = readdir(pDir)) != NULL){
        sprintf(filename, "%s/%s",dir,ent->d_name);
        //RLOGD("fibo_get_usb_device_info file path:%s ",filename);
        lstat(filename, &statbuf);
        if (S_ISLNK(statbuf.st_mode)) {
            char idVendor[USBID_LEN+1] = {0};
            char idProduct[USBID_LEN+1] = {0};

            sprintf(filename, "%s/%s/idVendor", dir, ent->d_name);
            //RLOGD("fibo_get_usb_device_info idVendor file path:%s ",filename);
            fd = open(filename, O_RDONLY);
            if (fd > 0) {
                read(fd, idVendor, USBID_LEN);
                //RLOGD("found idVendor in : %s  idVendor : %s",filename,idVendor);
                close(fd);
            }
            sprintf(filename, "%s/%s/idProduct", dir, ent->d_name);
            //RLOGD("fibo_get_usb_device_info idProduct file path:%s ",filename);
            fd = open(filename, O_RDONLY);
            if (fd > 0) {
                read(fd, idProduct, USBID_LEN);
                //RLOGD("found idProduct in : %s  idProduct : %s",filename,idProduct);
                close(fd);
            }
            module_info = fibo_get_module_info(idVendor,idProduct);
            if(module_info == NULL){
                continue;
            }
            ret = 0;
            RLOGD("find fibocom module idVendor:[%s] idProduct:[%s]",idVendor,idProduct);
            usb_device_info.module_info = module_info;
            snprintf(usb_device_info.usbdevice_pah, sizeof(usb_device_info.usbdevice_pah), "%s/%s", dir, ent->d_name);
            RLOGD("usb_device_info.usbdevice_path:[%s]",usb_device_info.usbdevice_pah);
            memcpy(device_info, &usb_device_info, sizeof(struct fibo_usb_device_info));

            break;        //The program exits the loop as soon as it finds our module
        }
    }

done:
    closedir(pDir);
    return ret;
}

static int fibo_find_ttyname(int usb_interface, const char *usbdevice_pah, char *out_ttyname, char *ttyname)
{
    int ret = -1, current_usbmode;
    DIR *pDir;
    struct dirent* ent = NULL;
    char dir[MAX_PATH]={0};
    char property_name[PROPERTY_VALUE_MAX]  = {0};
    char property_value[PROPERTY_VALUE_MAX] = {0};
    char *property_tty = NULL, *property_usbmode = NULL, *s = NULL;
    char target_dir[MAX_PATH] = {"/dev/"};

    snprintf(property_name, sizeof(property_name), "ril.fibocom.%s", ttyname);
    ret = property_get(property_name, property_value, "");
    if(ret > 0)
    {
        RLOGD("[%s,%d] get ttyname from property %s: %s", __FUNCTION__, __LINE__, property_name, property_value);

        s = property_value;
        property_tty = strsep(&s, ",");
        if(property_tty != NULL)
        {
            RLOGD("[%s,%d]property_tty:%s", __FUNCTION__, __LINE__, property_tty);
        }
        else
        {
            RLOGD("property_tty is NULL");
        }

        property_usbmode = strsep(&s, ",");
        if(property_usbmode != NULL)
        {
            RLOGD("[%s,%d]property_usbmode:%s", __FUNCTION__, __LINE__, property_usbmode);
            current_usbmode = property_get_int32(PROPERTY_CURRENT_USBMODE, 0);
            RLOGD("[%s,%d]current_usbmode:%d", __FUNCTION__, __LINE__, current_usbmode);
            if(atoi(property_usbmode) != current_usbmode)
            {
                goto USB_INTERFACE;      //If the expected USBMODE is not equal to the current USBMODE, the property is ignored
            }
        }
        else
        {
            RLOGD("property_usbmode is NULL");
        }

        strncat(target_dir, property_tty, MAX_TTYNAME_LEN);

        ret = access(target_dir, F_OK);
        if(RET_SUCCESS == ret)
        {
            RLOGD("Path %s exists, success!!!", target_dir);
            strcpy(out_ttyname, property_tty);
            goto done;
        }
        else
        {
            RLOGD("Path %s does not exist: %s", target_dir, strerror(ret));
        }
    }
    else
    {
        RLOGD("Property %s not set, so try to get ttyname via USB.", property_name);
    }

USB_INTERFACE:
    ret = -1;

    if(usb_interface < 0) {
        goto done;
    }

    snprintf(dir, sizeof(dir), "%s:1.%d", usbdevice_pah, usb_interface);

    if((pDir = opendir(dir)) == NULL){
        RLOGE("Cannot open directory:%s/", dir);
        ret = -2;
        goto done;
    }

    while((ent = readdir(pDir)) != NULL){
        if (strncmp(ent->d_name, "tty", 3) == 0) {
            RLOGD("find %s/%s", dir, ent->d_name);
            strcpy(out_ttyname, ent->d_name);
            ret = 0;//sucesss
            break;
        }
    }

    closedir(pDir);
done:
    return ret;
}
static void installDriver(char *vid,char *pid)
{
    char *cmd;
    if (access("/sys/bus/usb-serial/drivers/option1/new_id", W_OK) == 0) {
        RLOGD("find usb serial option driver, but do not cantain fibocom vid&pid");
        asprintf(&cmd, "echo %s %s > /sys/bus/usb-serial/drivers/option1/new_id",vid,pid);
        system(cmd);
        free(cmd);
        sleep(1); //wait usb driver load  
    }
    else {
        RLOGE("can not find usb serial option driver");
    }
}
static int fibo_find_port(USBPortDevice *portDevice)
{
    int ret = 0;
    struct fibo_usb_device_info usb_device_info;
    struct fibo_module_info *module_info = NULL;
    USBPortDevice device;
    char prefix[] = "/dev/";

    memset(&usb_device_info,0,sizeof(struct fibo_usb_device_info));
    memset(&device,0,sizeof(USBPortDevice));

    ret = fibo_get_usb_device_info(&usb_device_info);
    if(ret){
        goto done;
    }
    else{
        //ensure option driver match
        if (access("/dev/ttyUSB0", R_OK)){
           installDriver(usb_device_info.module_info->idVendor,usb_device_info.module_info->idProduct);
        }
        else{
           RLOGD("usb serial option driver match success");
        }
    }

    module_info = (struct fibo_module_info *)usb_device_info.module_info;

    ret = fibo_find_ttyname(module_info->diag_inf,usb_device_info.usbdevice_pah,usb_device_info.ttyDM, TTYNAME_DIAG);
    if(ret)
    {
        RLOGD("Failed to find %s, it is recommended to specify it via the ril.fibocom.%s property", TTYNAME_DIAG, TTYNAME_DIAG);
        goto done;
    }

    ret = fibo_find_ttyname(module_info->modem_inf,usb_device_info.usbdevice_pah,usb_device_info.ttyModem, TTYNAME_MODEM);
    if(ret)
    {
        RLOGD("Failed to find %s, it is recommended to specify it via the ril.fibocom.%s property", TTYNAME_MODEM, TTYNAME_MODEM);
        goto done;
    }

    ret = fibo_find_ttyname(module_info->at_inf,usb_device_info.usbdevice_pah,usb_device_info.ttyAT, TTYNAME_AT);
    if(ret)
    {
        RLOGD("Failed to find %s, it is recommended to specify it via the ril.fibocom.%s property", TTYNAME_AT, TTYNAME_AT);
        goto done;
    }


    RLOGD("ttyDiag  = [%s]", usb_device_info.ttyDM);
    RLOGD("ttyModem = [%s]", usb_device_info.ttyModem);
    RLOGD("ttyAT    = [%s]", usb_device_info.ttyAT);

    strcpy(device.diagchannel,prefix);
    strcpy(device.atchannel,prefix);
    strcpy(device.datachannel,prefix);
    strncat(device.diagchannel,usb_device_info.ttyDM,strlen(usb_device_info.ttyDM));
    strncat(device.atchannel,usb_device_info.ttyAT,strlen(usb_device_info.ttyAT));
    strncat(device.datachannel,usb_device_info.ttyModem,strlen(usb_device_info.ttyModem));

    memcpy(portDevice,&device,sizeof(USBPortDevice));
done:
    return ret;
}

int getUsbPortInfo(USBPortDevice *usbPortDevice)
{
    int ret = 0;
    USBPortDevice portDevice;

    memset(&portDevice,0,sizeof(portDevice));
    ret = fibo_find_port(&portDevice);
    if(ret){
        RLOGE("getUsbPortInfo error errnum:[%d]",ret);
        goto done;
    }

    strcpy(usbPortDevice->atchannel, portDevice.atchannel);
    strcpy(usbPortDevice->datachannel, portDevice.datachannel);
    strcpy(usbPortDevice->diagchannel, portDevice.diagchannel);

    RLOGD("getUsbPortInfo diagchannel   :[%s]",usbPortDevice->diagchannel);
    RLOGD("getUsbPortInfo atchannel   :[%s]",usbPortDevice->atchannel);
    RLOGD("getUsbPortInfo datachannel :[%s]",usbPortDevice->datachannel);

done:
    return ret;
}
