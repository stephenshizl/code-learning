
/*
 *  sms.h
 *  
 *
 *  Created by fupeilong on 1/22/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */
 
/*when who why modified*/

#ifndef SMS_H
#define SMS_H 1
#endif


/*added by nodecom  for adding sms_send_report begin */
typedef enum
{
    SMS_GENERAL = 0, 
    SMS_SEND_REPORT = 1,
    SMS_BROADCAST = 2
} SMS_Type;

/*added by nodecom  for adding sms_send_report end */
/*  request functions
 *
 */

// <!--added by wangmengying@2018.8.1 for recives SMS
void receiveSMS(void *param);
// end--!>

void requestWriteSmsToSim(void *data, size_t datalen, RIL_Token t);

void requestSendSMS(void *data, size_t datalen, RIL_Token t);

void requestSMSAcknowledge(void *data, size_t datalen, RIL_Token t);

void requestDeleteSmsOnSim(void *data, size_t datalen, RIL_Token t);

#if 1
/* added by nodecom begin */

void requestGsmGetBroadcastSMSConfig(void *data, size_t datalen, RIL_Token t);

void requestGsmSetBroadcastSMSConfig(void *data, size_t datalen, RIL_Token t);

void requestGsmSMSBroadcastActivation(void *data, size_t datalen, RIL_Token t);

void requestGetSMSCAddress(void *data, size_t datalen, RIL_Token t);
 
void requestSetSMSCAddress(void *data, size_t datalen, RIL_Token t);

void requestReportSMSMemoryStatus(void *data, size_t datalen, RIL_Token t);

/* added by nodecom end */
#endif
/* * 
 * functions called when AT command comes up  
 *
 */
void onNewSmsNotification(char *line);

/* BEGIN: Added by eric.li, 2019/1/11   PN:add support for send more message */
void requestSendSMSExpectMore(void *data, size_t datalen, RIL_Token t);
/* END:   Added by eric.li, 2019/1/11   PN:add support for send more message */

