#ifndef _RIL_COMMON_H_
#define _RIL_COMMON_H_

#include <telephony/ril.h>
#include "sim.h"

#define GHT_RIL "GHT_RIL"
#define GHT_AT  "GHT_AT"

#define PROPERTY_CURRENT_USBMODE "persist.ril.current_usbmode"
#define PROFILE_PATH "/system/etc/ght_ril_config.ini"

//<---!added by Wujiabao in 2022/2/28:Add global variables that indicate whether certain functionality is supported or not
extern int Voice_Support_Flag;
extern int GTRAT_Support_Flag;
extern int Net_3G_Support_Flag;
//!---->

#define ENTER_FUNC RLOGD("********Enter %s********", __FUNCTION__)
#define LEAVE_FUNC RLOGD("********Leave %s********", __FUNCTION__)
#define PRINT_FUNC_LINE RLOGD("[%s,%d]", __FUNCTION__, __LINE__)

#define SCNd32 "d"
#define PRId32 "d"
#define SIM_CMD_MAX_SIZE 50
#define SW1_RSP_SUCCESS 0x90
#define SW1_RSP_SEND_COMMANDS 0x91
#define SW2_RSP_SUCCESS 0x00
#define SW2_RSP_RESET_MODEM 0x0B

#define RET_FAIL -1
#define RET_SUCCESS 0

#define TRUE  1
#define FALSE 0

#define CHECK_DNS_AVAILABLE(x) (x != NULL && strcmp(x, "0.0.0.0") && strlen(x)?true:false)

#ifdef USE_TI_COMMANDS

// Enable a workaround
// 1) Make incoming call, do not answer
// 2) Hangup remote end
// Expected: call should disappear from CLCC line
// Actual: Call shows as "ACTIVE" before disappearing
#define WORKAROUND_ERRONEOUS_ANSWER 1

// Some varients of the TI stack do not support the +CGEV unsolicited
// response. However, they seem to send an unsolicited +CME ERROR: 150
#define WORKAROUND_FAKE_CGEV 1
#endif

#define ODM_CM_OPERATOR 0
#define ODM_CT_OPERATOR_3G 1
#define ODM_CT_OPERATOR_4G 2
#define ODM_CU_OPERATOR 3

#define Kernel_Version "4.4.36"      //Android6.x

//#ifdef RIL_SHLIB
 struct RIL_Env *s_rilenv;
typedef enum
{
    INVALIDE_MOD = -1,
    DIAL_RAS_MOD   = 0,
    DIAL_ECM_MOD   = 1,
    DIAL_NDIS_MOD  = 2,
    DIAL_MAX_MOD
} dial_mode;

typedef enum
{
    GHT_NL650,
    GHT_NL660,
    GHT_NL668,/*added by eric.li, mean NL668-CN*/
    /* BEGIN: Added by eric.li, 2018/10/18   PN:add support for android7 to handle prefered network */
    GHT_NL668_AM,
    GHT_NL668_EAU,
    /* END:   Added by eric.li, 2018/10/18   PN:add support for android7 to handle prefered network */
    GHT_NL668_EU,
    GHT_NL668_JP,
    GHT_NL668_LA,
    GHT_MDM_NORMAL,  //For special product models, add modem_flags after GHT_MDM_NORMAL please.
    GHT_L610,
    GHT_MC919,       //Add a new model because the MC919 and L610 are quite different
    GHT_MC66x,
    GHT_FG621,
    GHT_NL678_E,
    /*diego add for campalibility M910 devices begin*/
    GHT_M910_GL,
    GHT_757S,
    /*diego add for campalibility M910 devices end*/
    //add by zhengjianrong for MA510 begin
    GHT_MA510_GL,
    GHT_FG650,
    //add by zhengjianrong for MA510 end
    GHT_H330S,
    GHT_L716
} product_model;
//added by lisf for android8 20181208

#if 0
typedef enum
{
    RADIO_STATE_SIM_NOT_READY = 2, 
    RADIO_STATE_SIM_LOCKED_OR_ABSENT = 3,
    RADIO_STATE_SIM_READY = 4,
    RADIO_STATE_RUIM_NOT_READY = 5,  
    RADIO_STATE_RUIM_READY = 6, 
    RADIO_STATE_RUIM_LOCKED_OR_ABSENT = 7,
    RADIO_STATE_NV_NOT_READY = 8, 
    RADIO_STATE_NV_READY = 9, 
}RIL_RadioState;    
#endif
//Register network priority by "+GTRANT" command 20181119
typedef enum {    
	PREF_NET_TYPE_GSM                = 0, /* GSM only */    
		PREF_NET_TYPE_GSM_UMTS                 = 1, /* GSM /UMTS */   
		PREF_NET_TYPE_UMTS                    = 2, /* UMTS only  */    
		PREF_NET_TYPE_LTE           = 3, /* LTE only */    
		PREF_NET_TYPE_LTE_UMTS           = 4, /* LTE and UMTS */    
		PREF_NET_TYPE_LTE_GSM                = 5, /*LTE and GSM*/    
		PREF_NET_TYPE_LTE_UMTS_GSM                = 6, /* LTE/UMTS/GSM */    
		PREF_NET_TYPE_TD_SCDMA = 7, /* TD-SCDMA */    
		PREF_NET_TYPE_EMTC            = 8, /* EMTC */    
		PREF_NET_TYPE_NB_IOT       = 9, /* NBIOT*/    
		PREF_NET_TYPE_AUTOMATIC  = 10, /* Automic */    
		PREF_NET_TYPE_CDMA                 = 11, /* CDMA only */    
		PREF_NET_TYPE_CDMA_EVDO                = 12 , /*CDMA and EVDO */    
		PREF_NET_TYPE_EVDO                  =13     /*EVDO*/
} RIL_PreferredNetType;
#define RIL_onRequestComplete(t, e, response, responselen) s_rilenv->OnRequestComplete(t,e, response, responselen)
#define RIL_onUnsolicitedResponse(a,b,c) s_rilenv->OnUnsolicitedResponse(a,b,c)
#define RIL_requestTimedCallback(a,b,c) s_rilenv->RequestTimedCallback(a,b,c)
//#endif

void initializeCallback(void *param);

typedef struct{
    int rssi;
    int ber;
    int rscp;
    int rsrp;
    int rsrq;
}CSQInfo;
int getCSQInfo(CSQInfo *csqInfo);

/*Begin: Deleted by wujiabao in 2022/07/20, because we did not need it*/
#if 0
typedef struct{
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        RIL_SignalStrength_v10 signalStrength;
#else
        RIL_SignalStrength_v6 signalStrength;
#endif
}RIL_SignalStrength;
#endif
/*End:   Deleted by wujiabao in 2022/07/20, because we did not need it*/

typedef struct{
    int mode;
    int format;
    char *oper;
    int Act;
}COPSInfo;

typedef enum{
    ANDROID_MIN = 4,
    ANDROID_4 = 4,
    ANDROID_5,
    ANDROID_6,
    ANDROID_7,
    ANDROID_8,
    ANDROID_9,
    ANDROID_10,
    ANDROID_11,
    ANDROID_MAX = 11,
}Android_Version;

extern Android_Version Ght_Android_Version;

int getCOPSInfo(COPSInfo *copsInfo);
void getNetifName();
const char *simStatusToString(SIM_Status s);

#endif /*_RIL_COMMON_H_*/
