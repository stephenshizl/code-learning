﻿/******************************************************************************
  Copyright (C), 2019, Shenzhen G&T Industrial Development Co., Ltd

  File:      voice.c

  Author:  Fibocom-diego
  Version: 1.0
  Date:  2019.04

  Description:   voices APIs

** History:
**Author (core ID)                Date          Number     Description of Changes
**-----------------------------------------------------------------------------
** NODECOM-Aron                30-10-2018         **   init version 
** FIBOCOM-diego               10-01-2019         **   add requestDeviceIdentity support Androdi8.1
** FIBOCOM-diego               15-04-2019         **   modify requestGetCurrentCalls return fake value for M910
** -----------------------------------------------------------------------------
******************************************************************************/
#include <telephony/ril.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <alloca.h>
#include "atchannel.h"
#include "at_tok.h"
#include "misc.h"
#include <getopt.h>
#include <sys/socket.h>
#include <cutils/sockets.h>
#include <cutils/properties.h>
#include <termios.h>

#include "ril_common.h"
#include "voice.h"

#define LOG_TAG GHT_RIL
#include <utils/Log.h>

//<!--[ODM][CLCC] gaoyunlai 20150506 modified for can not get the status of call when another hang up in call.
#define POLL_CALL_STATE
//end-->

// <!--added by wangmengying@2018.8.1 for Call Waiting and Call Forwarding
#define TIME_OUT_CGACT 151000
// end--!>

static const struct timeval TIMEVAL_CALLSTATEPOLL = {0,500000};
extern int cur_oper;
int voice_handover_flag = 0;
//added for NL678-E-00
extern product_model mode_flag;
extern int odm_get_current_network_type();
extern char *get_network_type();
extern void OnResumeLTENetwork();

RIL_Call *current_calls;
int current_call_counts;

/*called by callFromCLCCLine()*/
static int clccStateToRILState(int state, RIL_CallState *p_state)
{
    switch(state)
    {
        case 0:
            *p_state = RIL_CALL_ACTIVE;
            return 0;
        case 1:
            *p_state = RIL_CALL_HOLDING;
            return 0;
        case 2:
            *p_state = RIL_CALL_DIALING;
            return 0;
        case 3:
            *p_state = RIL_CALL_ALERTING;
            return 0;
        case 4:
            *p_state = RIL_CALL_INCOMING;
            return 0;
        case 5:
            *p_state = RIL_CALL_WAITING;
            return 0;
        default:
            return -1;
    }
}

/**
 * Note: directly modified line and has *p_call point directly into
 * modified line
 * called by requestGetCurrentCalls()
 */
static int callFromCLCCLine(char *line, RIL_Call *p_call)
{
    //+CLCC: 1,0,2,0,0,\"+18005551212\",145
    //     index,isMT,state,mode,isMpty(,number,TOA)?

    int err;
    int state;
    int mode;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(p_call->index));
    if (err < 0) goto error;
    err = at_tok_nextbool(&line, &(p_call->isMT));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &state);
    if (err < 0) goto error;

    err = clccStateToRILState(state, &(p_call->state));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &mode);
    if (err < 0) goto error;

    p_call->isVoice = (mode == 0);

    err = at_tok_nextbool(&line, &(p_call->isMpty));
    if (err < 0) goto error;

    if (at_tok_hasmore(&line))
    {
        err = at_tok_nextstr(&line, &(p_call->number));
        /* tolerate null here */
        if (err < 0)
            return 0;
        // Some lame implementations return strings
        // like "NOT AVAILABLE" in the CLCC line
        if (p_call->number != NULL
                && 0 == strspn(p_call->number, "+0123456789"))
        {
            p_call->number = NULL;
        }
        err = at_tok_nextint(&line, &p_call->toa);
        if (err < 0) goto error;
    }
    return 0;

error:
    RLOGD("invalid CLCC line\n");
    return -1;
}


/*called by requestGetCurrentCalls()*/
static void sendCallStateChanged(void *param __unused)
{
    RIL_onUnsolicitedResponse (
            RIL_UNSOL_RESPONSE_CALL_STATE_CHANGED,
            NULL, 0);
}

void requestGetCurrentCalls(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    ATResponse *p_response;
    ATLine *p_cur;
    int countCalls;
    int countValidCalls;
    RIL_Call *p_calls;
    RIL_Call **pp_calls;
    int i;
    int needRepoll = 0;

#ifdef WORKAROUND_ERRONEOUS_ANSWER
    int prevIncomingOrWaitingLine;

    prevIncomingOrWaitingLine = s_incomingOrWaitingLine;
    s_incomingOrWaitingLine = -1;
#endif /*WORKAROUND_ERRONEOUS_ANSWER*/

    //fake clcc response for 910 NB-iOT
    if(mode_flag == GHT_M910_GL)
    {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
        return;
    }
    err = at_send_command_multiline ("AT+CLCC", "+CLCC:", &p_response);

    if (err != 0 || p_response->success == 0)
    {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        at_response_free(p_response);
        return;
    }

    /* count the calls */
    for (countCalls = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL; p_cur = p_cur->p_next)
    {
        countCalls++;
    }

    /* yes, there's an array of pointers and then an array of structures */

    pp_calls = (RIL_Call **)alloca(countCalls * sizeof(RIL_Call *));
    p_calls = (RIL_Call *)alloca(countCalls * sizeof(RIL_Call));
    memset (p_calls, 0, countCalls * sizeof(RIL_Call));

    current_calls = (RIL_Call *)alloca(countCalls * sizeof(RIL_Call));
    memset (current_calls, 0, countCalls * sizeof(RIL_Call));

    /* init the pointer array */
    for(i = 0; i < countCalls ; i++)
    {
        pp_calls[i] = &(p_calls[i]);
    }
    for (countValidCalls = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL; p_cur = p_cur->p_next)
    {

        err = callFromCLCCLine(p_cur->line, p_calls + countValidCalls);
        if (err != 0)
        {
            // <!--[ODM]wangmengying@2019.9.11 bug29133,stat is 6(released),should reply error
            //continue;
            break;
            // end-->
        }

        //isDataAllowed=flase when use 4G SIM card
        RLOGD("requestGetCurrentCalls p_calls[%d].isVoice=%d",
                countValidCalls, p_calls[countValidCalls].isVoice );
        if(p_calls[countValidCalls].isVoice == false)
        {
            continue;
        }

        current_calls[countValidCalls].index = p_calls[countValidCalls].index;
        current_calls[countValidCalls].state = p_calls[countValidCalls].state;

#ifdef WORKAROUND_ERRONEOUS_ANSWER
        if (p_calls[countValidCalls].state == RIL_CALL_INCOMING
                || p_calls[countValidCalls].state == RIL_CALL_WAITING
           )
        {
            s_incomingOrWaitingLine = p_calls[countValidCalls].index;
        }
#endif /*WORKAROUND_ERRONEOUS_ANSWER*/

        if (p_calls[countValidCalls].state != RIL_CALL_ACTIVE
                && p_calls[countValidCalls].state != RIL_CALL_HOLDING)
        {
            needRepoll = 1;
        }

        countValidCalls++;
    }

    // <!--[ODM]wangmengying@2019.9.11 bug29133,stat is 6(released),should reply error
    if (err != 0)
    {
        RLOGD("[%s,%d],err is [%d].\r",__FUNCTION__, __LINE__, err);
        goto error;
    }
    //end-->

    current_call_counts = countValidCalls;
#ifdef WORKAROUND_ERRONEOUS_ANSWER
    // Basically:
    // A call was incoming or waiting
    // Now it's marked as active
    // But we never answered it
    //
    // This is probably a bug, and the call will probably
    // disappear from the call list in the next poll
    if (prevIncomingOrWaitingLine >= 0
            && s_incomingOrWaitingLine < 0
            && s_expectAnswer == 0
       )
    {
        for (i = 0; i < countValidCalls ; i++)
        {

            if (p_calls[i].index == prevIncomingOrWaitingLine
                    && p_calls[i].state == RIL_CALL_ACTIVE
                    && s_repollCallsCount < REPOLL_CALLS_COUNT_MAX
               )
            {
                RLOGD(
                        "Hit WORKAROUND_ERRONOUS_ANSWER case."
                        " Repoll count: %d\n", s_repollCallsCount);
                s_repollCallsCount++;
                goto error;
            }
        }
    }

    s_expectAnswer = 0;
    s_repollCallsCount = 0;
#endif /*WORKAROUND_ERRONEOUS_ANSWER*/

    RIL_onRequestComplete(t, RIL_E_SUCCESS, pp_calls,
            countValidCalls * sizeof (RIL_Call *));

    at_response_free(p_response);

#ifdef POLL_CALL_STATE
    if (countValidCalls)    // We don't seem to get a "NO CARRIER" message from
        // smd, so we're forced to poll until the call ends.
#else
        if (needRepoll)
#endif
        {
            RIL_requestTimedCallback (sendCallStateChanged, NULL, &TIMEVAL_CALLSTATEPOLL);
        }

    return;
error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}


void requestDial(void *data, size_t datalen __unused, RIL_Token t)
{
    RIL_Dial *p_dial;
    char *cmd;
    const char *clir;
    int ret;
    int send_retry = 0;
    p_dial = (RIL_Dial *)data;
    /*begin:added by lisf 20181121*/
    int network_type = 0;
    network_type = odm_get_current_network_type();
    /*end:added by lisf 20181121*/
    switch (p_dial->clir)
    {
        case 1:
            clir = "I";
            break;  /*invocation*/
        case 2:
            clir = "i";
            break;  /*suppression*/
        default:
        case 0:
            clir = "";
            break;   /*subscription default*/
    }
    RLOGD("voice dial begin");
    //asprintf(&cmd, "ATD%s%s;", p_dial->address, clir);
	// <!--added by wangmengying@2020.2.21 fix bug41287,use CT card,modify dial AT command
    if (((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper)) && (mode_flag < GHT_NL668))
	// end-->
    {
        if (strcmp(get_network_type(),"SRLTE") != 0)
        {
/*begin:modified by lisf 20181121*/
            if(14 == network_type)
/*end:modified by lisf 20181121*/
            {
                at_send_command("AT+MODODR=8",NULL);
                voice_handover_flag =1 ; //added by lisf 20190315

/*begin:modified by lisf 20181121*/
                while(6 != network_type
                        && 7!= network_type
                        && 13!= network_type
                        && 10> send_retry)
 /*end:modified by lisf 20181121*/
                {
                    network_type = odm_get_current_network_type();
                    sleep(1);
                    send_retry++;
                    RLOGD("send_retry = %d",send_retry);
                }
            }
        }
        sleep(3);
        asprintf(&cmd, "AT+CDV%s%s;", p_dial->address, clir);
    }
    else
    {
        asprintf(&cmd, "ATD%s%s;", p_dial->address, clir);
    }
    ret = at_send_command(cmd, NULL);

    free(cmd);

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void  requestGetMute(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int response = 0;
    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response,sizeof(response));
}

// <!--added by wangmengying@2018.8.1 for DTMF
void requestDTMFStart(void *data, size_t datalen __unused, RIL_Token t)
{
    char c = ((char *)data)[0];
    char *cmd = NULL;
    //modified for NL678-E-00
    if((mode_flag <=  GHT_NL678_E) || (mode_flag == GHT_MA510_GL) || (mode_flag == GHT_FG650))
    {
    	    asprintf(&cmd, "AT+VTS=\"%c\"", c);
    }
    at_send_command(cmd, NULL);
    free(cmd);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestDTMFStop(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;

    /* Send a command to cancel the DTMF tone*/
    err = at_send_command("AT",NULL);
    if (err != 0)
        goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RLOGE("ERROR: requestDtmfStop failed");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

void requestDTMF(void *data, size_t datalen __unused, RIL_Token t)
{
    char c = ((char *)data)[0];
    char *cmd = NULL;

    //modified for NL678-E-00
    if((mode_flag <=  GHT_NL678_E) || (mode_flag == GHT_MA510_GL))
    {
    	    asprintf(&cmd, "AT+VTS=\"%c\"", c);
    }

    at_send_command(cmd, NULL);
    free(cmd);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);

}
// end--!>

void requestSeparateConnection(void *data, size_t datalen __unused, RIL_Token t)
{
    char  cmd[12];
    int   party = ((int*)data)[0];

    // Make sure that party is in a valid range.
    // (Note: The Telephony middle layer imposes a range of 1 to 7.
    // It's sufficient for us to just make sure it's single digit.)
    if (party > 0 && party < 10)
    {
        sprintf(cmd, "AT+CHLD=2%d", party);
        at_send_command(cmd, NULL);
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    }
    else
    {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
}

void requestUDUB(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    /* user determined user busy */
    /* sometimes used: ATH */
    at_send_command("ATH", NULL);
    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestConference(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    // 3GPP 22.030 6.5.5
    // "Adds a held call to the conversation"
    at_send_command("AT+CHLD=3", NULL);
    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestAnswer(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    at_send_command("ATA", NULL);
#ifdef WORKAROUND_ERRONEOUS_ANSWER
    s_expectAnswer = 1;
#endif  /* WORKAROUND_ERRONEOUS_ANSWER */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestSwitchWaitingOrHoldingAndActive(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    // 3GPP 22.030 6.5.5
    // "Places all active calls (if any exist) on hold and accepts
    //  the other (held or waiting) call."
    at_send_command("AT+CHLD=2", NULL);

#ifdef WORKAROUND_ERRONEOUS_ANSWER
    s_expectAnswer = 1;
#endif /* WORKAROUND_ERRONEOUS_ANSWER */

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestHangupForegroundResumeBackground(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    // 3GPP 22.030 6.5.5
    // "Releases all active calls (if any exist) and accepts
    //  the other (held or waiting) call."
    //at_send_command("AT+CHLD=1", NULL);
    //at_send_command("AT+CHUP", NULL);
	// <!--added by wangmengying@2020.2.21 fix bug41335,bug41239,use CT card,modify hangup AT command
    if(((ODM_CT_OPERATOR_3G == cur_oper) || (ODM_CT_OPERATOR_4G == cur_oper)) && (mode_flag < GHT_NL668))
	// end-->
    {
        at_send_command("AT+CHV", NULL);
        if(1 == voice_handover_flag)
        {
            OnResumeLTENetwork();
            voice_handover_flag = 0;
        }
    }
    else
    {
        at_send_command("AT+CHUP", NULL);//modified by nodecom
    }

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestHangupWaitingOrBackground(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    // 3GPP 22.030 6.5.5
    // "Releases all held calls or sets User Determined User Busy
    //  (UDUB) for a waiting call."
    //at_send_command("AT+CHLD=0", NULL);
    //at_send_command("AT+CHUP", NULL);
	// <!--added by wangmengying@2020.2.21 fix bug41335,bug41239,use CT card,modify hangup AT command
    if(((ODM_CT_OPERATOR_3G == cur_oper) || (ODM_CT_OPERATOR_4G == cur_oper)) && (mode_flag < GHT_NL668))
	// end-->
    {
        at_send_command("AT+CHV", NULL);
    }
    else
    {
        at_send_command("AT+CHUP", NULL);//modified by nodecom
    }

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestHangup(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int *p_line;
    int ret;
    char *cmd = NULL;
    p_line = (int *)data;
    int i;

    // 3GPP 22.030 6.5.5
    // "Releases a specific active call X"
    for (i = 0; i < current_call_counts; i++) {
        if (current_calls[i].index == p_line[0]) {
            if (current_calls[i].state == RIL_CALL_ACTIVE
                || current_calls[i].state == RIL_CALL_HOLDING) {
                // <!--[ODM]wangmengying@2019.9.11 bug29472,MA510-GL-xx not support Call Related Supplementary Services Command(CHLD).
                if (GHT_MA510_GL == mode_flag)
                {
                    asprintf(&cmd, "AT+CHUP");
                }
                else
                {
                    asprintf(&cmd, "AT+CHLD=1%d", p_line[0]);
                }
                // end-->
            } else {
                asprintf(&cmd, "AT+CHUP");
            }
            break;
        }
    }
    if (cmd == NULL) {
        asprintf(&cmd, "AT+CHUP");
    }

    //ret = at_send_command(cmd, NULL);
	// <!--added by wangmengying@2020.2.21 fix bug41335,bug41239,use CT card,modify hangup AT command
    if(((ODM_CT_OPERATOR_3G == cur_oper) || (ODM_CT_OPERATOR_4G == cur_oper)) && (mode_flag < GHT_NL668))
	// end-->
    {
        ret = at_send_command("AT+CHV", NULL);
    }
    else
    {
        //ret = at_send_command("AT+CHUP", NULL);//modified by nodecom
        ret = at_send_command(cmd, NULL);
    }

    //#endif
	if (cmd != NULL) {
		free(cmd);
	}
    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

// <!--added by wangmengying@2018.8.1 for Call Waiting
void  requestGetClir(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    /** Gets current CLIR status
     * "data" is NULL
     * "response" is int *
     * ((int *)data)[0] is "n" parameter from TS 27.007 7.7
     * ((int *)data)[1] is "m" parameter from TS 27.007 7.7
     */
    int err = 0;
    int response[2] ={0};
    ATResponse *p_response;
    char* line = NULL;

	/* BEGIN: Added by eric.li, 2018/12/22   PN:modify for issue of query cmd AT+CLIR? that  timeout in 10 seconds  */
	RLOGD("[%s,%d],requestGetClir Timeout is [%d]ms.\r",__FUNCTION__, __LINE__, QUERY_NETWORK_TIMEOUT);
	err = at_send_command_singleline_timeout("AT+CLIR?","+CLIR:",QUERY_NETWORK_TIMEOUT,&p_response);
	/* END:   Added by eric.li, 2018/12/22   PN:modify for issue of query cmd AT+CLIR? that  timeout in 10 seconds  */
	
    if (err < 0 || p_response->success == 0)
        goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0)
        goto error;

    err = at_tok_nextint(&line, &response[0]);
    if (err < 0)
        goto error;

    err = at_tok_nextint(&line, &response[1]);
    if (err < 0)
        goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    return;
}

void  requestSetClir(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    /**
     * "data" is int *
     * ((int *)data)[0] is "n" parameter from TS 27.007 7.7
     *
     * "response" is NULL
     */
    int err = 0;
    char *cmd = NULL;

    asprintf(&cmd, "AT+CLIR=%d", ((int *)data)[0]);

    err = at_send_command(cmd,NULL);
    if (err < 0)
        goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    free(cmd);
    return;

error:
    free(cmd);
    RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, NULL, 0);
}

void requestQueryCallWaiting(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    /**
     * "data" is const int *
     * ((const int *)data)[0] is the TS 27.007 service class to query.
     * "response" is a const int *
     * ((const int *)response)[0] is 0 for "disabled" and 1 for "enabled"
     *
     * If ((const int *)response)[0] is = 1, then ((const int *)response)[1]
     * must follow, with the TS 27.007 service class bit vector of services
     * for which call waiting is enabled.
     *
     * For example, if ((const int *)response)[0]  is 1 and
     * ((const int *)response)[1] is 3, then call waiting is enabled for data
     * and voice and disabled for everything else
     */
    int err;
    int response[2] = {0};
    char *line = NULL;
    ATResponse *p_response = NULL;
    ATLine *p_cur = NULL;
    int status = 0;
    int service = 0;

    err = at_send_command_singleline_timeout("AT+CCWA=1,2", "+CCWA:", QUERY_NETWORK_TIMEOUT, &p_response);
    if (err < 0 || p_response->success == 0)
        goto error;

    for (p_cur = p_response->p_intermediates; p_cur != NULL;p_cur = p_cur->p_next)
    {
        line = p_cur->line;
        status = 0;
        service = 0;

        err = at_tok_start(&line);
        if (err < 0)
            goto error;

        err = at_tok_nextint(&line, &status);
        if (err < 0)
            goto error;

        if (at_tok_hasmore(&line))
        {
            err = at_tok_nextint(&line, &service);
            if (err < 0) goto error;
        }

        (response[0]) = status;
        if(1 == status) {
            (response[1]) = (response[1]) | service;
        }
    };

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
    at_response_free(p_response);
    return;

error:
    RLOGD("******** requestQueryCallWaiting is failed ********");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

void requestSetCallWaiting(void *data, size_t datalen, RIL_Token t)
{
    /**
     * "data" is const int *
     * ((const int *)data)[0] is 0 for "disabled" and 1 for "enabled"
     * ((const int *)data)[1] is the TS 27.007 service class bit vector of
     *                           services to modify
     * "response" is NULL
     */
    ATResponse *p_response = NULL;
    int err = 0;
    char*cmd = NULL;
    int enable, service_class;

    if((datalen < 2)||(data == NULL)) goto error;

    enable = ((int *)data)[0];
    service_class = ((int *)data)[1];

    /* no class */
    if(0 == service_class)
    {
        asprintf(&cmd, "AT+CCWA=0,%d", enable);
    }
    else
    {
        asprintf(&cmd, "AT+CCWA=0,%d,%d", enable, service_class);
    }
    err = at_send_command_timeout(cmd,&p_response,TIME_OUT_CGACT); //wait long timeout
    if (err < 0 || p_response->success == 0)
        goto error;

    RIL_onRequestComplete(t,RIL_E_SUCCESS,NULL,0);
    at_response_free(p_response);
    free(cmd);
    return ;

error:
    free(cmd);
    RIL_onRequestComplete(t,RIL_E_GENERIC_FAILURE,NULL,0);
    at_response_free(p_response);
}
// end--!>

// <!--added by wangmengying@2018.8.1 for Call Forwarding Number and Conditions
void requestSetCallForward(void *data, RIL_Token t)
{
    int err = 0;
    char *cmd;
    RIL_CallForwardInfo *info = NULL;
    ATResponse *atResponse = NULL;

    info = ((RIL_CallForwardInfo *) data);

    if(data == NULL)
        goto error;
    RLOGD("info->reason[%d] info->status[%d] info->number[%s]",info->reason,info->status,info->number);
//added for info->number == NULL, return error 20181217;
    if(info->number==NULL)
    {
        goto error;
    }
	
    if(0 == info->status)
    {
        asprintf(&cmd,"AT+CCFC = %d,%d",info->reason, info->status);
    }
    else
    {
        if('+' == info->number[0])
        {
            info->toa = 145;
        }
        else
        {
            info->toa = 129;
        }
        if ( 0 == info->serviceClass ) {
            asprintf(&cmd,"AT+CCFC = %d,%d,\"%s\",%d",
                    info->reason, info->status,
                    info->number, info->toa);
        } else {
            asprintf(&cmd,"AT+CCFC = %d,%d,\"%s\",%d,%d",
                    info->reason, info->status,
                    info->number, info->toa, info->serviceClass);
        }
    }

    err = at_send_command_timeout(cmd,&atResponse,TIME_OUT_CGACT); //wait long timeout
    free(cmd);
    if (err < 0 || atResponse->success == 0)
        goto error;
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(atResponse);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(atResponse);
}

void requestQueryCallForwardStatus(void *data, RIL_Token t)
{
    int err = 0;
    int i = 0;
    int n = 0;
    int tmp = 0;
    ATResponse *atResponse = NULL;
    ATLine *p_cur;
    RIL_CallForwardInfo **responses = NULL;
    char *tmp_char = NULL;
    RIL_CallForwardInfo *info = NULL;
    info = ((RIL_CallForwardInfo *) data);

    char *cmd = NULL;

    asprintf(&cmd, "AT+CCFC=%d,2", info->reason);

    err = at_send_command_singleline_timeout(cmd, "+CCFC:", QUERY_NETWORK_TIMEOUT, &atResponse);
    free(cmd);

    if (err < 0 || atResponse->success == 0)
        goto error;

    for (p_cur = atResponse->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next)
        n++;

    responses = (RIL_CallForwardInfo **) alloca(n * sizeof(RIL_CallForwardInfo *));

    for (i = 0; i < n; i++) {
        responses[i] = (RIL_CallForwardInfo*)alloca(sizeof(RIL_CallForwardInfo));
        responses[i]->status = 0;
        responses[i]->reason = 0;
        responses[i]->serviceClass = 0;
        responses[i]->toa = 0;
        responses[i]->number = (char*)"";
        responses[i]->timeSeconds = 0;
    }

    for (i = 0,p_cur = atResponse->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next, i++) {
        char *line = p_cur->line;

        err = at_tok_start(&line);
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &(responses[i]->status));
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &(responses[i]->serviceClass));
        if (err < 0) goto error;

        if(!at_tok_hasmore(&line)) continue;

        err = at_tok_nextstr(&line, &(responses[i]->number));
        //if (err < 0) goto error;

        if(!at_tok_hasmore(&line)) continue;

        err = at_tok_nextint(&line, &(responses[i]->toa));
        //if (err < 0) goto error;

        if(!at_tok_hasmore(&line)) continue;
        //at_tok_nextint(&line,&tmp);
        at_tok_nextstr(&line, &tmp_char);

        if(!at_tok_hasmore(&line)) continue;
        at_tok_nextint(&line,&tmp);

        if(!at_tok_hasmore(&line)) continue;
        err = at_tok_nextint(&line, &(responses[i]->timeSeconds));
        //if (err < 0) goto error;

    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, responses, n*sizeof(RIL_CallForwardInfo **));
    at_response_free(atResponse);

    return;

error:
    at_response_free(atResponse);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}
// end--!>
