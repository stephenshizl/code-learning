/* //device/system/reference-ril/reference-ril.c
 **
 ** Copyright 2006, The Android Open Source Project
 **
 ** Licensed under the Apache License, Version 2.0 (the "License");
 ** you may not use this file except in compliance with the License.
 ** You may obtain a copy of the License at
 **
 **     http://www.apache.org/licenses/LICENSE-2.0
 **
 ** Unless required by applicable law or agreed to in writing, software
 ** distributed under the License is distributed on an "AS IS" BASIS,
 ** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 ** See the License for the specific language governing permissions and
 ** limitations under the License.
 */

/*
 ** NODECOM reference-ril 1.0.0 is base version for wcdma ,added by NODECOM-Aron 2010.9.29
 */
/*when who why modified*/
/*
 *2010.11.30 modified by Aron
 added sim pin and puk request and modified the request of Baseband Version
 2011.10.21 Aron modified the version to 1.1.1 for modify of mms and Baseband Version
 */

#include <telephony/ril.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <alloca.h>
#include "atchannel.h"
#include "at_tok.h"
#include "misc.h"
#include <getopt.h>
#include <sys/socket.h>
#include <cutils/sockets.h>
#include <cutils/properties.h>
#include <termios.h>
#include <ctype.h>
#include "ril_common.h"
#include "sim.h"
#include "voice.h"
#include "network.h"
#include "sms.h"
#include "other_function.h"
#include "getdevinfo.h"
//added by NODECOM-Aron end

#define LOG_TAG GHT_RIL
#include <utils/Log.h>

#define MAX_AT_RESPONSE 0x1000

/* property to control the delay (in seconds) to initialize RIL */
#define RIL_DELAY_TIME "gsm.ril.delay"

//add by gaojing to resolve product question begin

#define V35_Normal_Version_to_open_CREG 1

#define V35_Product_Version_to_Close_CREG 1

//add by gaojing to resolve product question end

/*add by NODECOM-Aron for version control 2010.9.29*/
/*modified by NODECOM-Aron for sim pin and puk request 2010.11.30*/

/*add by eric.li to define version for 32/64 arm arch start*/
#ifndef  ODM_ARM64
#define REFERENCE_RIL_VERSION  "Fibocom_RIL_V9X.01.21"
#else
#define REFERENCE_RIL_VERSION  "Fibocom_RIL_V9X.01.21"
#endif
/*add by eric.li to define version for 32/64 arm arch end*/

#define PPP_OPERSTATE_PATH "/sys/class/net/ppp0/operstate"

// <!--[ODM][ril]pulong@2015.8.24 added for CT operator
int cur_oper = -1;
// end-->
////int devmode = -1;

dial_mode dialmode = DIAL_RAS_MOD;

extern int handover_flag;
extern int voice_handover_flag;
extern int s_fd;
extern int  ppp_fd ;
extern int if_get_mode_flag;

extern char s_ATBuffer[MAX_AT_RESPONSE+1];
extern char *s_ATBufferCur;
//added for NL678-E-00
extern product_model mode_flag;
#if (RIL_VERSION != 7)
extern void requestSetInitialAttachAPN(void *data, size_t datalen, RIL_Token t);
#endif

static void onUnsolicited (const char *s, const char *sms_pdu);

static void onRequest (int request, void *data, size_t datalen, RIL_Token t);
static RIL_RadioState currentState();
static int onSupports (int requestCode);
static void onCancel (RIL_Token t);
static const char *getVersion();
static const char *getKernelVersion();
static int isRadioOn();
SIM_Status getSIMStatus();
static int getCardStatus(RIL_CardStatus_v6 **pp_card_status);
static void freeCardStatus(RIL_CardStatus_v6 *p_card_status);

static void pollSIMState (void *param);
void setRadioState(RIL_RadioState newState);
//static void onDataCallListChanged(void *param);

int start_ppp_check_pthread();

//diego add for ndis thread
int start_ndis_do_dhcp_pthread();
extern void *ndis_main_loop();
pthread_t s_tid_ndisloop;
//diego add end 

/* BEGIN: Added by abby.wang, 2018/12/22 fix bug14209,bug13844 USSD has no return for a long time */
#define CUSD_USE_UCS2_MODE
unsigned int ussd_pending_index = 0;
const struct timeval ussd_timeout_timeval = {30,0}; //seconds
/* END: Added by abby.wang, 2018/12/22 fix bug14209,bug13844 USSD has no return for a long time */
/* BEGIN: Added by eric.li, 2018/12/25   PN:gSimstatus to trace sim status */
SIM_Status gSimStatus = SIM_ABSENT;
/* END:   Added by eric.li, 2018/12/25   PN:gSimstatus to trace sim status */
/* BEGIN: Added by eric.li, 2019/1/10   PN:0014627 android5 cannot enter sim init with property */
int gSimPostInitFlag = 0;
/* END:   Added by eric.li, 2019/1/10   PN:0014627 android5 cannot enter sim init with property */
extern int detect_usb_device(char *atchannel, char *datachannel);

extern int qualcomm_diag_reset();


// <!--[ODM]wangmengying@2019.8.16 [SN-20190608001]Customized AT commands
//extern void initReserveAtCommand();
void initReserveAtCommand();
// end-->

extern const char * requestToString(int request);
extern const char * radioStateToString(RIL_RadioState s);
extern void pingLoop();


/*** Static Variables ***/
static RIL_RadioFunctions s_callbacks =
{
    RIL_VERSION,
    onRequest,
    currentState,
    onSupports,
    onCancel,
    getVersion
};

static RIL_RadioState sState = RADIO_STATE_UNAVAILABLE;

static pthread_mutex_t s_state_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t s_state_cond = PTHREAD_COND_INITIALIZER;

static int s_port = -1;
static const char * s_device_path = NULL;
#ifdef HAVE_DATA_DEVICE
static const char * s_data_device_path = NULL;
#endif
static const char * s_diag_device_path = NULL;
static int          s_device_socket = 0;

char atchannel[15] = {0};
char datachannel[15] = {0};

char cur_atchannel[15] = {0};
char cur_datachannel[15] = {0};

int script_type = 0;

/* trigger change to this with s_state_cond */
static int s_closed = 0;

//static int sFD;     /* file desc of AT channel */
//static char sATBuffer[MAX_AT_RESPONSE+1];
//static char *sATBufferCur = NULL;

static const struct timeval TIMEVAL_SIMPOLL = {1,0};

//static const struct timeval TIMEVAL_0 = {0,0};
static struct timeval TIMEVAL_DELAYINIT = {0,0}; // will be set according to property value

#ifdef WORKAROUND_ERRONEOUS_ANSWER
// Max number of times we'll try to repoll when we think
// we have a AT+CLCC race condition
#define REPOLL_CALLS_COUNT_MAX 4

// Line index that was incoming or waiting at last poll, or -1 for none
static int s_incomingOrWaitingLine = -1;
// Number of times we've asked for a repoll of AT+CLCC
static int s_repollCallsCount = 0;
// Should we expect a call to be answered in the next CLCC?
static int s_expectAnswer = 0;
#endif /* WORKAROUND_ERRONEOUS_ANSWER */

/* added by NODECOM-Aron for SMS begin */
extern int sms_type;
/* added by NODECOM-Aron for SMS end */
extern int pppd;

extern int odm_get_current_network_type();
/* BEGIN: Added by eric.li, 2018/12/22   PN:sovle issue cannot receive sms and so on issue in case  onSimReady can not be called  with probability  */
static void odm_post_sim_init(void)
{
    at_send_command_singleline("AT+CSMS=0", "+CSMS:", NULL);

//<!--modified by wujiabao for mantis bug:FG621 cannot receive long SMS on Android7,9
    if(mode_flag == GHT_FG621)
		at_send_command("AT+CPMS=\"SM\",\"SM\",\"SM\"", NULL);
	else
        at_send_command("AT+CPMS=\"ME\",\"ME\",\"ME\"", NULL);
//end !-->

    if(GHT_H330S == mode_flag)
        at_send_command("AT+CNMI=3,1,0,0,0", NULL);
    else
        at_send_command("AT+CNMI=2,1,2,2,0", NULL);

    if(ANDROID_7 == Ght_Android_Version)
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 7 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        if(mode_flag == GHT_FG621)
            at_send_command("AT+CNMI=2,2,2,2,1", NULL);
    }

#if 0
#if defined GHT_FEATURE_ANDROID7X
    if(mode_flag == GHT_FG621)
		at_send_command("AT+CNMI=2,2,2,2,1", NULL);
#endif
#endif

    /* BEGIN: Added by eric.li, 2019/1/21   PN:solve onRequest done before initial callback */
    gSimPostInitFlag = 1;
    /* END:   Added by eric.li, 2019/1/21   PN:solve onRequest done before initial callback */

}
/* END:   Added by eric.li, 2018/12/22   PN:sovle issue cannot receive sms and so on issue in case  onSimReady can not be called  with probability  */
/*begin:modified by lisf 20181201 for RIL8*/	
//#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
/*Begin: Wujiabao changed it to '#if 1' in 2022/07/20*/
#if 1
/*End:   Wujiabao changed it to '#if 1' in 2022/07/20*/
static void requestGetHardwareConfig(void *data __unused, size_t datalen __unused, RIL_Token t)
{
   // TODO - hook this up with real query/info from radio.

   RIL_HardwareConfig hwCfg;
   hwCfg.type = -1;

   RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &hwCfg, sizeof(hwCfg));
}
#endif
/*end:modified by lisf 20181201 for RIL8*/	
/* BEGIN: Added by eric.li, 2018/10/17   PN:support RIL_REQUEST_GET_RADIO_CAPABILITY */
#if (RIL_VERSION > 9 )
static void setRadioCap(int *rat)
{
    RLOGD("[%s] DEBUG mode flag :[%d]",__FUNCTION__,mode_flag);
    if (GHT_NL668 == mode_flag) {
        *rat = (RAF_GPRS | RAF_EDGE | RAF_UMTS | RAF_1xRTT | RAF_EVDO_A | RAF_HSDPA| RAF_HSUPA|RAF_HSPA | RAF_EHRPD | RAF_LTE | RAF_HSPAP | RAF_GSM | RAF_TD_SCDMA);
    } 
    else if (GHT_NL668_AM == mode_flag){
        *rat = RAF_UMTS | RAF_HSDPA| RAF_HSUPA|RAF_HSPA | RAF_LTE | RAF_HSPAP;
    } 
    else if ( (GHT_NL668_EAU == mode_flag) || (GHT_NL668_EU == mode_flag)){
       /*Begin add NL668-EAU Capablility by lisf 20181112*/
       *rat = RAF_GPRS | RAF_EDGE | RAF_UMTS | RAF_HSDPA| RAF_HSUPA | RAF_HSPA | RAF_LTE | RAF_HSPAP | RAF_GSM;
        /*End add NL668-EAU Capablility by lisf 20181112*/
    }
    /*begin:added NL678-E-00 radio Capablility by lisf 20181120*/
    else if(GHT_NL678_E == mode_flag){
#if (RIL_VERSION >= 12 )
        {
            *rat = RAF_UMTS | RAF_HSDPA| RAF_HSUPA | RAF_HSPA | RAF_LTE  | RAF_HSPAP | RAF_LTE_CA;
        }
#else 
        {
            *rat = RAF_UMTS | RAF_HSDPA| RAF_HSUPA | RAF_HSPA | RAF_LTE  | RAF_HSPAP;
        }
#endif
    }
    /*end:added NL678-E-00 radio Capablility by lisf 20181120*/
    /*begin:added support for NL668 NORMAL by lisf 20190318*/
    else if(GHT_MDM_NORMAL == mode_flag){
        *rat = RAF_GPRS | RAF_EDGE|RAF_UMTS | RAF_HSDPA| RAF_HSUPA | RAF_HSPA | RAF_LTE  | RAF_HSPAP | RAF_GSM;
    }
    /*end:added support  for NL668 NORMAL by lisf 20190318*/
    //add by zhengjianrong for MA510 RIL BEGIN
    else if (GHT_M910_GL == mode_flag || GHT_757S == mode_flag || mode_flag == GHT_MA510_GL){
    //add by zhengjianrong for MA510 RIL END
        *rat = (RAF_GPRS | RAF_EDGE | RAF_UMTS | RAF_1xRTT | RAF_EVDO_A | RAF_HSDPA| RAF_HSUPA|RAF_HSPA | RAF_EHRPD | RAF_LTE | RAF_HSPAP | RAF_GSM | RAF_TD_SCDMA);
    } 
    else if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag){
        *rat = (RAF_GPRS | RAF_EDGE | RAF_LTE | RAF_GSM);
    }
    else if (GHT_FG621 == mode_flag){
        *rat = (RAF_UMTS | RAF_HSDPA| RAF_HSUPA|RAF_HSPA | RAF_LTE | RAF_HSPAP);
    }
     else if (GHT_FG650 == mode_flag){
        *rat = (RAF_UMTS | RAF_HSDPA| RAF_HSUPA|RAF_HSPA | RAF_LTE | RAF_HSPAP | RAF_NR_LTE);
    }
    else{
        *rat = RAF_GPRS | RAF_EDGE|RAF_UMTS | RAF_HSDPA| RAF_HSUPA | RAF_HSPA | RAF_LTE  | RAF_HSPAP | RAF_GSM;
    }
}
static int getRadioCap()
{
    int err = 0;
    int rat = 0;
    char *line = NULL;
    ATResponse *p_response = NULL;
    
    err = at_send_command_singleline("AT+GTRADIOCAP=0", "+GTRADIOCAP", &p_response);
    if (err < 0 || p_response->success == 0){
        RLOGE("[%s] at_send_command_singleline err",__FUNCTION__);
        goto error;
    }
    line=p_response->p_intermediates->line;
    err = at_tok_start(&(line));
    if (err < 0 ){
        RLOGE("[%s] at_tok_start err",__FUNCTION__);
        goto error;
    }
    err = at_tok_nexthexint(&line, &rat);
    if (err < 0 ){
        RLOGE("[%s] at_tok_nexthexint err",__FUNCTION__);
        goto error;
    }
    err = rat;
    RLOGD("[%s] RadioCapability:[%d]",__FUNCTION__,rat);
error:
    at_response_free(p_response);
    return err;
}
static int setRadioCapablility(RIL_RadioCapability *response)
{
    int err = 0;

    if(response == NULL){
        err = -1;
        RLOGE("[%s] parameter error",__FUNCTION__);
        goto error;
    }
    response->version = RIL_RADIO_CAPABILITY_VERSION;
    response->session = 0;
    response->phase = RC_PHASE_FINISH;

    err = getRadioCap();
    if(err > 0){
        response->rat = err;
    }
    else{
        setRadioCap(&response->rat);
    }
    RLOGD("[%s] get radioaccessfamily,rat[%d]",__FUNCTION__,response->rat);
error:
    return err;
}
static void requestGetRadioCapablility(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err = -1;
    RIL_RadioCapability response;

    RLOGD("[%s] ====== Enter ",__FUNCTION__);

    memset(&response,0,sizeof(RIL_RadioCapability));
    err = setRadioCapablility(&response);
    if(err){
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else{
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(RIL_RadioCapability));
    }
    RLOGD("[%s] ====== Leave ",__FUNCTION__);
    return;
}
#endif
/* END:   Added by eric.li, 2018/10/17   PN:support RIL_REQUEST_GET_RADIO_CAPABILITY */

static const char *getKernelVersion()
{
    char *cmd;
    int fd = 0;
    int ret = 0;
    static  char bufsrc[100]={0};

    asprintf(&cmd, "uname -r > /data/ODM_KERNEL_VERSION");
    RLOGD("%s",cmd);
    system(cmd);
    free(cmd);

    fd = open("/data/ODM_KERNEL_VERSION", O_RDONLY);
    ret = read(fd, bufsrc, sizeof(bufsrc));

    RLOGD("ODM_KERNEL_VERSION :: %s",bufsrc);
    property_set("odm.kernel.version", bufsrc);

    return bufsrc;
}

static void *ppp_main_loop()
{
    int fd;
    char buffer[20];
    unsigned int count = 3;

    for(;;)
    {
        if(pppd == 1)
        {
        /*begin:modified for ppp dial retry count by lisf 20181224*/
            //count = 5;
            if (GHT_L610 == mode_flag || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
            {
                count = 15;
            }
            else
            {
                count = 5;
            }

	/*end:modified for ppp dial retry count by lisf 20181224*/
            do
            {
                fd  = open(PPP_OPERSTATE_PATH, O_RDONLY);
                if (fd >= 0)
                {
                    buffer[0] = 0;
			memset(buffer,0,sizeof(buffer)); //added by lisf for debug 20181219
                    read(fd, buffer, sizeof(buffer));
                    close(fd);
		      RLOGD("ppp_main_loop:%s",buffer);
                    if(!strncmp(buffer, "up", strlen("up")) || !strncmp(buffer, "unknown", strlen("unknown")))
                    {
                          /*begin:modified for ppp dial retry count by lisf 20181224*/
                          char local_ip[PROPERTY_VALUE_MAX]={0};
                		property_get("net.ppp0.local-ip", local_ip, "");
			      if(!((!strcmp(local_ip, "")) || (!strcmp(local_ip, "0.0.0.0"))))
			      {
					  RLOGD("ppp has already connected ,local ip :%s\n",local_ip);
					  count = 5;
					  break;
			      }
				/*end:modified for ppp dial retry count by lisf 20181224*/
                    }
                    else
                    {
                        RLOGD("ppp_main_loop:PPP link status is %s. Will retry %d times after %d seconds",buffer, count, 2);
                    }
                }
                else
                {
                    RLOGD("ppp_main_loop:Can not detect PPP state. Will retry %d times after %d seconds",count, 2);
                }
                sleep(2);
            } while (--count);
            //remove for ril reponse to framework may be messy code

            if(0 == count && pppd == 1)

            {
                    RLOGD("ppp get state timeout!\n");
                    onDeactiveDataCallList();
            }
        }
        sleep(4);
    }
    return ((void *)0);
}


void readSMS()
{
    int location = 0;
    int err;
    ATResponse *p_response = NULL;
    ATLine *p_cur;
    /*begin:added by lisf 20181121*/
    int network_type = 0;
    network_type = odm_get_current_network_type();
    /*end:added by lisf 20181121*/
    if ((ODM_CT_OPERATOR_3G == cur_oper) ||(ODM_CT_OPERATOR_4G == cur_oper))
    {
/*begin:modified by lisf 20181121*/
	if(6 == network_type || 7 ==network_type || 13 ==network_type)
/*end:modified by lisf 20181121*/
        {
            err = at_send_command_multiline("AT^HCMGL=0","^HCMGL:",&p_response);

            for (p_cur = p_response->p_intermediates; p_cur != NULL;
                    p_cur = p_cur->p_next)
            {
                char *line = p_cur->line;
                RLOGD("read SMS line=%s",line);
                err = at_tok_start(&line);
                if(err < 0)
                {
                    RLOGD("start fail");
                    continue;
                }
                RLOGD("read SMS start line=%s",line);
                err = at_tok_nextint(&line, &location);
                if(err < 0)
                {
                    RLOGD("nextint fail");
                    continue;
                }
                RLOGD("read SMS location=%d",location);

                RIL_requestTimedCallback (receiveSMS, ( void* )(long)location, NULL );
            }
        }
        else
        {
            err = at_send_command_multiline("AT+CMGL=0","+CMGL:",&p_response);

            for (p_cur = p_response->p_intermediates; p_cur != NULL;
                    p_cur = p_cur->p_next)
            {
                char *line = p_cur->line;
                RLOGD("read SMS CMGL line=%s",line);
                err = at_tok_start(&line);
                if(err < 0)
                {
                    continue;
                }
                RLOGD("read SMS CMGL start line=%s",line);
                err = at_tok_nextint(&line, &location);
                if(err < 0)
                {
                    continue;
                }
                RLOGD("read SMS CMGL location=%d",location);

                RIL_requestTimedCallback ( receiveSMS, ( void* )(long)location, NULL );
            }
        }
    }
    else
    {
        err = at_send_command_multiline("AT+CMGL=0","+CMGL:",&p_response);

        for (p_cur = p_response->p_intermediates; p_cur != NULL;
                p_cur = p_cur->p_next)
        {
            char *line = p_cur->line;
            RLOGD("read SMS CMGL line=%s",line);
            err = at_tok_start(&line);
            if(err < 0)
            {
                continue;
            }
            RLOGD("read SMS CMGL start line=%s",line);
            err = at_tok_nextint(&line, &location);
            if(err < 0)
            {
                continue;
            }
            RLOGD("read SMS CMGL location=%d",location);

            RIL_requestTimedCallback ( receiveSMS, ( void* )(long)location, NULL );
        }
    }
    at_response_free(p_response);
}

/** do post-AT+CFUN=1 initialization */
static void onRadioPowerOn()
{
    RLOGD("******** Enter onRadioPowerOn() ********");
#ifdef USE_TI_COMMANDS
    /*  Must be after CFUN=1 */
    /*  TI specific -- notifications for CPHS things such */
    /*  as CPHS message waiting indicator */

    at_send_command("AT%CPHS=1", NULL);

    /*  TI specific -- enable NITZ unsol notifs */
    at_send_command("AT%CTZV=1", NULL);
#endif

    pollSIMState(NULL);
}

/** do post- SIM ready initialization */
static void onSIMReady()
{
    int err;
    char *line;
    int network_mode = 2;
    ATResponse *p_response = NULL;
    RLOGD("******** Enter %s ********", __FUNCTION__);
	/* BEGIN: Deleted by eric.li, 2019/1/10   PN:0014627 android5 cannot enter sim init with property */
	/* END:   Deleted by eric.li, 2019/1/10   PN:0014627 android5 cannot enter sim init with property */
    err = at_send_command_numeric("AT+QCIMI",&p_response);
    if((err < 0) || (0 == p_response->success))
    {
        at_response_free(p_response);
        err = at_send_command_numeric("AT+CIMI",&p_response);

        if((err < 0) || (0 == p_response->success))
        {
            RLOGD("Fibocom unknow operator");
            goto error;
        }
    }
    line = p_response->p_intermediates->line;
    *(line+5) = '\0';
    if((0 == strcmp(line,"46003")) || (0 == strcmp(line,"20404")))
    {
        cur_oper = ODM_CT_OPERATOR_3G;
    }
    else if(0 == strcmp(line,"46011"))
    {
        cur_oper = ODM_CT_OPERATOR_4G;
    }
    else if((0 == strcmp(line,"46000")) || (0 == strcmp(line,"46002")) ||
            (0 == strcmp(line,"46007")) || (0 == strcmp(line,"46004")) ||
            (0 == strcmp(line,"46008")))
    {
        cur_oper = ODM_CM_OPERATOR;
    }
    else if((0 == strcmp(line,"46001"))||(0 == strcmp(line,"46006")) ||
            (0 == strcmp(line,"46009")))
    {
        cur_oper = ODM_CU_OPERATOR;
    }
    else
    {
        RLOGD("Fibocom unkonw mcc and mnc,line = %s\r",line);
        cur_oper = ODM_CM_OPERATOR;
        at_response_free(p_response);
        p_response = NULL;
    }
    
    at_response_free(p_response);
    p_response = NULL;

    RLOGD("[%s,%d]cur_oper:%d, mode_flag:%d", __FUNCTION__, __LINE__, cur_oper, mode_flag);    //mode_flag defaults to 0

	if (mode_flag < GHT_NL668)
	{
    err = at_send_command_singleline("AT+MODODR?", "+MODODR:", &p_response);
    if (err == 0 && p_response->success != 0)
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);

        err = at_tok_nextint(&line, &network_mode);
        if (err < 0)
        {
                at_response_free(p_response);
            return ;
        }
    }
    // <!--modified by wangyi@2018.07.13 for optimizing time consuming of network available after radio power-on
        at_response_free(p_response);
    p_response = NULL;
    // end-->
    if((ODM_CT_OPERATOR_3G==cur_oper) || (ODM_CT_OPERATOR_4G==cur_oper))
    {
        if(7 == network_mode)
        {
            at_send_command("AT+MODODR=9",&p_response);
        }
        else if(3 == network_mode)
        {
            at_send_command("AT+MODODR=8",&p_response);
        }
    }
    else
    {
        if((9 == network_mode) || (10 == network_mode))
        {
            if(ODM_CM_OPERATOR==cur_oper)
            {
                at_send_command("AT+MODODR=6",&p_response);
            }
            else if(ODM_CU_OPERATOR==cur_oper)
            {
                at_send_command("AT+MODODR=1",&p_response);
            }
        }
        else if(8 == network_mode)
        {
            at_send_command("AT+MODODR=3",&p_response);
        }
    }
    if(NULL != p_response)
    {
        at_response_free(p_response);
        sleep(2);
    }
	}
error:
    at_response_free(p_response);
    p_response = NULL;

    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED, NULL, 0);
    RLOGD("******** Leave %s ********", __FUNCTION__);
    return;
// end-->
}

static void requestRadioPower(void *data, size_t datalen __unused, RIL_Token t)
{
    int onOff;

    int err;
    ATResponse *p_response = NULL;
/* BEGIN: Added by eric.li, 2018/10/20   PN:fix switch airplane on/off not auto to register in network */
   int restricted =0 ;
   //RIL_SimRefreshResult refresh_result = 2;
   RIL_SimRefreshResponse_v7 *pSimRefreshResponse = NULL;
/* END:   Added by eric.li, 2018/10/20   PN:fix switch airplane on/off not auto to register in network */
    
    //datalen;
    assert (datalen >= sizeof(int *));
    onOff = ((int *)data)[0];
	RLOGD("******** Enter requestRadioPower() ******** onOff:%d,sState:%d",onOff,sState);
    if ((onOff == 0) && (RADIO_STATE_OFF != sState))
    {
        /*begin:modifed "AT+CFUN=4" switch switch airplane on by lisf 20190418 for mantis 0019905*/
        // <!--[ODM]wangmengying@2019.11.27 fix bug34577 CFUN command set time to 20s
        err = at_send_command_timeout("AT+CFUN=4",&p_response,ATSEND_TIMEOUT_MSEC*2);
        // end--!>
        /*end:modifed "AT+CFUN=4" switch airplane on by lisf 20190418 for mantis 0019905*/
        if (err < 0 || p_response->success == 0) goto error;
        setRadioState(RADIO_STATE_OFF);
        /* BEGIN: Added by eric.li, 2019/1/21   PN:solve issue that can not receive sms issues with probability */
        gSimPostInitFlag = 0;
        /* END:   Added by eric.li, 2019/1/21   PN:solve issue that can not receive sms issues with probability */
       /*begin:added for NL678-E ppp dial by lisf 20190129*/
	if(mode_flag  == GHT_NL678_E || mode_flag  ==GHT_MDM_NORMAL)
	{
		pppd =0 ;
	}
	/*end:added for NL678-E ppp dial by lisf 20190129*/
    }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    else if ((onOff > 0) && (RADIO_STATE_OFF == sState || RADIO_STATE_SIM_NOT_READY == sState))
#else
    else if ((onOff > 0) && (RADIO_STATE_OFF == sState))
#endif
#endif
    //else if ((onOff > 0) && (RADIO_STATE_OFF == sState || ((Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11) && (RADIO_STATE_SIM_NOT_READY == sState))))
    else if ((onOff > 0) && ((RADIO_STATE_SIM_NOT_READY == sState) || (RADIO_STATE_OFF == sState) || (RADIO_STATE_UNAVAILABLE == sState) || (RADIO_STATE_SIM_READY == sState)))
    {
        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ? and sState:%s == RADIO_STATE_SIM_NOT_READY or RADIO_STATE_OFF?", __FUNCTION__, __LINE__, Ght_Android_Version, radioStateToString(sState));
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ? and sState:%s == RADIO_STATE_OFF?", __FUNCTION__, __LINE__, Ght_Android_Version);
        }
        // <!--[ODM]wangmengying@2019.11.27 fix bug34577 CFUN command set time to 20s
        err = at_send_command_timeout("AT+CFUN=1",&p_response,ATSEND_TIMEOUT_MSEC*2);
        // end--!>
        if (err < 0 || p_response->success == 0)
        {
            // Some stacks return an error when there is no SIM,
            // but they really turn the RF portion on
            // So, if we get an error, let's check to see if it
            // turned on anyway
            if (isRadioOn() != 1)
            {
                goto error;
            }
        }
        sleep(2);

        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            setRadioState( RADIO_STATE_ON);
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            setRadioState(RADIO_STATE_SIM_NOT_READY);
        }

#if 0
/*begin:modified by lisf for android8 x 20181221*/
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
      setRadioState( RADIO_STATE_ON);
#else
        setRadioState(RADIO_STATE_SIM_NOT_READY);
#endif
#endif
	/* BEGIN: Added by eric.li, 2018/10/22   PN:add status to refresh sim status */
      pSimRefreshResponse =  malloc(sizeof(RIL_SimRefreshResponse_v7));
      if (NULL == pSimRefreshResponse)
      	{
		RLOGD("malloc RIL_SimRefreshResponse_v7 failed ");
		goto error;
	 }
	 pSimRefreshResponse->aid= NULL;
	 pSimRefreshResponse->ef_id = 0;
	 pSimRefreshResponse->result = SIM_RESET;

     if(Ght_Android_Version != ANDROID_4)
     {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d != 4 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        RLOGD("RIL_UNSOL_SIM_REFRESH");
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_SIM_REFRESH, pSimRefreshResponse, sizeof(RIL_SimRefreshResponse_v7));
     }

#if 0
	 /* BEGIN: Modified by eric.li, 2019/1/15   PN:solve issue 0015594 that SIM_REFRESH with SIM_RESET lead to exception  on android4 when radio power on */
#ifndef 	 GHT_FEATURE_ANDROID4X
	 RLOGD("RIL_UNSOL_SIM_REFRESH");
	 RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_SIM_REFRESH, pSimRefreshResponse, sizeof(RIL_SimRefreshResponse_v7));
#endif	 
	 /* END:   Modified by eric.li, 2019/1/15   PN:solve issue 0015594 that SIM_REFRESH with SIM_RESET lead to exception  on android4 radio power on */
#endif

        free(pSimRefreshResponse);
	 pSimRefreshResponse	 = NULL;
	/* END:   Added by eric.li, 2018/10/22   PN:add status to refresh sim status */
    }
    else
    {
        int cfun;
        cfun = isRadioOn();
		
        RLOGD("[%s,%d] current cfun:%d, current Android:%d",__FUNCTION__, __LINE__, cfun, Ght_Android_Version);
        RLOGD("[%s,%d] Upper level request(onOff):%d, sState:%s(%d), and do nothing!",__FUNCTION__, __LINE__, onOff, radioStateToString(sState), sState);
    }

    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
	/* BEGIN: Added by eric.li, 2018/10/20   PN:fix switch airplane on/off not auto to register in network */
	    restricted = RIL_RESTRICTED_STATE_NONE;
    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_RESTRICTED_STATE_CHANGED,
                              &restricted, sizeof(int *));
      /* END:   Added by eric.li, 2018/10/20   PN:fix switch airplane on/off not auto to register in network */
    return;
error:
    at_response_free(p_response);
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}



void requestGetSimStatus(void* data __unused, size_t datalen __unused, RIL_Token t)
{
    RIL_CardStatus_v6 *p_card_status;

    char *p_buffer;
    int buffer_size;
    RLOGD("******** Enter requestGetSimStatus() ********");

    int result = getCardStatus(&p_card_status);

    if (result == RIL_E_SUCCESS)
    {
        p_buffer = (char *)p_card_status;
        buffer_size = sizeof(*p_card_status);
    }
    else
    {
        p_buffer = NULL;
        buffer_size = 0;
    }
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, result, p_buffer, buffer_size);

    freeCardStatus(p_card_status);
}

static int parseSimResponseLine(char* line, RIL_SIM_IO_Response* response) {
    char *response_raw;
    int err, length, sw1, sw2;

    err = at_tok_start(&line);
    if (err < 0) return err;

    err = at_tok_nextint(&line, &length);
    if (err < 0) return err;

    if (at_tok_hasmore(&line)) {
        err = at_tok_nextstr(&line, &response_raw);
        if (err < 0) return err;
    }

    if(length >=4)
    {
        RLOGD("length:%d, response:%s", length, response_raw);

        sscanf(response_raw + length -4, "%2x", &(response->sw1));
        sscanf(response_raw + length -2, "%2x", &(response->sw2));
        RLOGD("sw1:%d, sw2:%d", response->sw1, response->sw2);

#if 0
        if(SW1_RSP_SEND_COMMANDS == response->sw1)
        {
            switch(response->sw2)
            {
                case SW2_RSP_RESET_MODEM:
                {
                    at_send_command("AT+CFUN=0", NULL);
                    at_send_command("AT+CFUN=1", NULL);
                    response->sw1 = SW1_RSP_SUCCESS;
                    response->sw2 = SW2_RSP_SUCCESS;
                    RLOGD("new sw1:%d, sw2:%d, and reset the module", response->sw1, response->sw2);
                    break;
                }
            }
        }
#endif

        if((SW1_RSP_SEND_COMMANDS == response->sw1 || SW1_RSP_SUCCESS == response->sw1) /*&& (SW2_RSP_SUCCESS == response->sw2)*/)
        {
            if(!strncmp(response_raw, "BF31", strlen("BF31")))
            {
                RLOGD("SIM card switch succeeded!");
                //at_send_command("AT+CSIMDETECT", NULL);
                at_send_command("AT+CFUN=0", NULL);
                at_send_command("AT+CFUN=1", NULL);
                RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED, NULL, 0);
            }
        }

        response->simResponse = strndup(response_raw, length - 4);
        RLOGD("simResponse:%s", response->simResponse);
    }
    else
    {
        RLOGE("The data length is too short");
        return RET_FAIL;
    }

    return RET_SUCCESS;
}

static void requestSimOpenChannel(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int32_t session_id;
    int err;
    char cmd[SIM_CMD_MAX_SIZE];
    char dummy;
    char *line;

    // Max length is 16 bytes according to 3GPP spec 27.007 section 8.45
    if (data == NULL || datalen == 0 || datalen > 16) {
        RLOGE("Invalid data passed to requestSimOpenChannel");
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    RLOGD("data:%s, datalen:%d", data, datalen);
    snprintf(cmd, sizeof(cmd), "AT+CCHO=\"%s\"", data);

    err = at_send_command_singleline(cmd, "+CCHO:", &p_response);

    if (err < 0 || p_response == NULL || p_response->success == 0) {
        RLOGE("Error %d opening logical channel: %d",
              err, p_response ? p_response->success : 0);
        goto error;
    }


    // Ensure integer only by scanning for an extra char but expect one result
    line = p_response->p_intermediates->line;
    //RLOGD("line:%s", line);

    err = at_tok_start(&line);
    if(err < 0)
        goto error;

    err = at_tok_nextint(&line, &session_id);
    if(err < 0)
        goto error;

    RLOGD("get session_id:%d", session_id);

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, &session_id, sizeof(&session_id));
    at_response_free(p_response);
    return;

error:
    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    return;
}


static void requestSimCloseChannel(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int32_t session_id;
    int err;
    char cmd[32];

    if (data == NULL || datalen != sizeof(session_id)) {
        RLOGE("Invalid data passed to requestSimCloseChannel");
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }
    session_id = ((int32_t *)data)[0];

    snprintf(cmd, sizeof(cmd), "AT+CCHC=%" PRId32, session_id);

    err = at_send_command(cmd, &p_response);

    if (err < 0 || p_response == NULL || p_response->success == 0) {
        RLOGE("Error %d closing logical channel %d: %d",
              err, session_id, p_response ? p_response->success : 0);
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        at_response_free(p_response);
        return;
    }

    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);

    at_response_free(p_response);
}


static void requestSimTransmitApduChannel(void *data,
                                          size_t datalen,
                                          RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    char *cmd;
    char *line;
    size_t cmd_size;
    RIL_SIM_IO_Response sim_response;
    RIL_SIM_APDU *apdu = (RIL_SIM_APDU *)data;

    RLOGD("datalen:%d, sizeof(RIL_SIM_APDU):%d", datalen, sizeof(RIL_SIM_APDU));
    if (apdu == NULL || datalen != sizeof(RIL_SIM_APDU)) {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    cmd_size = 10 + (apdu->data ? strlen(apdu->data) : 0);
    //RLOGD("cmd_size:%d", cmd_size);

    asprintf(&cmd, "AT+CGLA=%d,%zu,\"%02x%02x%02x%02x%02x%s\"",
             apdu->sessionid, cmd_size, apdu->cla, apdu->instruction,
             apdu->p1, apdu->p2, apdu->p3, apdu->data ? apdu->data : "");

    err = at_send_command_singleline(cmd, "+CGLA", &p_response);
    free(cmd);
    if (err < 0 || p_response == NULL || p_response->success == 0) {
        RLOGE("Error %d transmitting APDU: %d",
              err, p_response ? p_response->success : 0);
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        at_response_free(p_response);
        return;
    }

    line = p_response->p_intermediates->line;
    err = parseSimResponseLine(line, &sim_response);

    if (err == 0) {
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS,
                              &sim_response, sizeof(sim_response));
    } else {
        RLOGE("Error %d parsing SIM response line: %s", err, line);
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    at_response_free(p_response);
}

/**
 * Synchronous call from the RIL to us to return current radio state.
 * RADIO_STATE_UNAVAILABLE should be the initial state.
 */
    static RIL_RadioState
currentState()
{
    RLOGD("******** Enter %s ********", __FUNCTION__);
    RLOGD("current state:%s", radioStateToString(sState));
    RLOGD("******** Leave %s ********", __FUNCTION__);
    return sState;
}
/**
 * Call from RIL to us to find out whether a specific request code
 * is supported by this implementation.
 *
 * Return 1 for "supported" and 0 for "unsupported"
 */

    static int
onSupports (int requestCode __unused)
{
    //@@@ todo
    RLOGD("******** Enter onSupports() ********");
    return 1;
}

static void onCancel (RIL_Token t __unused)
{
    //@@@todo
    RLOGD("******** Enter onCancel() ********");
}
/* modified by NODECOM-Aron for version control 2010.9.29 begin */
static const char * getVersion(void)
{
    RLOGD("******** Enter getVersion() ********");

    //<-- Get the REAL version number, and only change it each time you release the version
    #define REAL_VERSION "V1.0.6"
    //-->
    RLOGD("********publish version ********");
    int device_bit = 0;
    char final_version[64]={0};

    device_bit = (8 == sizeof(char *)?6:3);       //On 64-bit devices, Pointers take up 8 bytes

    if(Ght_Android_Version >= ANDROID_MIN && Ght_Android_Version <= ANDROID_MAX)
    {
        sprintf(final_version,"Fibocom_RIL_V%dX.0%d.%s", Ght_Android_Version, device_bit, REAL_VERSION);
    }
    else
    {
        sprintf(final_version,"Fibocom_RIL_V%sX.0%d.%s", "E", device_bit, REAL_VERSION);
    }

    property_set("ril.fibocom.version", final_version);
    return final_version;

#if 0
//<-- Gets the number of bits for the Android device, 32 or 64 bits
#ifndef ODM_ARM64
#define DEVICE_BIT "3"
#else
#define DEVICE_BIT "6"
#endif
//-->

//<-- Gets the Android version, such as Android7,8,9, etc
#ifdef GHT_FEATURE_ANDROID11X
#define ANDROID_VER "11"
#elif defined GHT_FEATURE_ANDROID10X
#define ANDROID_VER "10"
#elif defined GHT_FEATURE_ANDROID9X
#define ANDROID_VER "9"
#elif defined GHT_FEATURE_ANDROID8X
#define ANDROID_VER "8"
#elif defined GHT_FEATURE_ANDROID7X
#define ANDROID_VER "7"
#elif defined GHT_FEATURE_ANDROID6X
#define ANDROID_VER "6"
#elif defined GHT_FEATURE_ANDROID5X
#define ANDROID_VER "5"
#elif defined GHT_FEATURE_ANDROID4X
#define ANDROID_VER "4"
#else
#define ANDROID_VER "E"               //An error occurs when the version number is "Fibocom_RIL_VEX..."
#endif
//-->
#endif
}
/* modified by NODECOM-Aron for version control 2010.9.29 end */

void setRadioState(RIL_RadioState newState)
{
    RIL_RadioState oldState;

    RLOGD("******** Enter setRadioState() ********");

    pthread_mutex_lock(&s_state_mutex);
    RLOGD("Enter %s,oldState:%d(%s),newState:%d(%s),s_closed:%d", __FUNCTION__, sState, radioStateToString(sState), newState, radioStateToString(newState), s_closed);
    oldState = sState;

    if (s_closed > 0)
    {
        // If we're closed, the only reasonable state is
        // RADIO_STATE_UNAVAILABLE
        // This is here because things on the main thread
        // may attempt to change the radio state after the closed
        // event happened in another thread
        newState = RADIO_STATE_UNAVAILABLE;
    }

    if (sState != newState || s_closed > 0)
    {
        sState = newState;

        pthread_cond_broadcast (&s_state_cond);
    }

    pthread_mutex_unlock(&s_state_mutex);


    /* do these outside of the mutex */
    if (sState != oldState)
    {
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_RADIO_STATE_CHANGED,
                NULL, 0);

        /* FIXME onSimReady() and onRadioPowerOn() cannot be called
         * from the AT reader thread
         * Currently, this doesn't happen, but if that changes then these
         * will need to be dispatched on the request thread
         */

        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            if (sState == RADIO_STATE_ON)
            {
                onSIMReady();
            }
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            if (sState == RADIO_STATE_SIM_READY)
            {
                onSIMReady();
            }
            else if (sState == RADIO_STATE_SIM_NOT_READY)
            {
                onRadioPowerOn();
            }
        }

#if 0
/* BEGIN: Added by abby.wang, 2019/01/03   PN:fix bug14047,can not recieve sms on Android8 */
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        if (sState == RADIO_STATE_ON)
        {
            onSIMReady();
        }
#else
        if (sState == RADIO_STATE_SIM_READY)
        {
            onSIMReady();
        }
        else if (sState == RADIO_STATE_SIM_NOT_READY)
        {
            onRadioPowerOn();
        }
#endif
/* END: Added by abby.wang, 2019/01/03   PN:fix bug14047,can not recieve sms on Android8 */
#endif
    }
}
/* BEGIN: Added by eric.li, 2018/10/14   PN:add for sim io parse */
RIL_AppType getSIMType()
{
    RIL_AppType rslt = RIL_APPTYPE_UNKNOWN;
    char* line = NULL;
    ATResponse *atResponse = NULL;
    int act = -1;

    if(GHT_NL668 == mode_flag)
    {
        return RIL_APPTYPE_USIM;
    }

    int err = at_send_command_singleline("AT+GTUSIM?", "+GTUSIM:", &atResponse);
    if (err < 0 || atResponse->success == 0) {
    RLOGD("GTUSIM not support\r\n");
    goto done;
    }
    
    line = atResponse->p_intermediates->line;
    err = at_tok_start(&line);
    if(err < 0)
        goto done;

    err = at_tok_nextint(&line, &act);
    if(err < 0)
        goto done;

    if(0 == act){
        rslt = RIL_APPTYPE_SIM;
    }else if(1 == act){
        rslt = RIL_APPTYPE_USIM;
    }

 done:
    at_response_free(atResponse);
    return rslt;

}

const char *
simStatusToString(SIM_Status s) {
    switch(s) {
        case SIM_ABSENT : return "SIM_ABSENT";
        case SIM_NOT_READY: return "SIM_NOT_READY";
        case SIM_READY: return "SIM_READY";
        case SIM_PIN: return "SIM_PIN";
        case SIM_PUK: return "SIM_PUK";
        case SIM_NETWORK_PERSONALIZATION: return "SIM_NETWORK_PERSONALIZATION";
        default: return "<unknown state>";
    }
}

/* END:   Added by eric.li, 2018/10/14   PN:add for sim io parse */
/** Returns SIM_NOT_READY on error */
    SIM_Status
getSIMStatus()
{
    ATResponse *p_response = NULL;
    int err;
    int ret;
    char *cpinLine;
    char *cpinResult;

    RLOGD("******** Enter getSIMStatus() ********");
    #if 0
    if (sState == RADIO_STATE_OFF || sState == RADIO_STATE_UNAVAILABLE)
    {
        ret = SIM_NOT_READY;
        goto done;
    }
    #endif

    err = at_send_command_singleline("AT+CPIN?", "+CPIN:", &p_response);

    if (err != 0)
    {
        ret = SIM_NOT_READY;
        goto done;
    }

    switch (at_get_cme_error(p_response))
    {
        case CME_SUCCESS:
            break;

        case CME_SIM_NOT_INSERTED:

	{
		ret = SIM_ABSENT;
	}
			
            goto done;
        case SIGNAL_QCDATACARD_SIM_NOT_INSERTED:
            ret = SIM_ABSENT;
            goto done;

        default:
            ret = SIM_NOT_READY;
            goto done;
    }

    /* CPIN? has succeeded, now look at the result */

    cpinLine = p_response->p_intermediates->line;
    err = at_tok_start (&cpinLine);

    if (err < 0)
    {
        ret = SIM_NOT_READY;
        goto done;
    }

    err = at_tok_nextstr(&cpinLine, &cpinResult);

    if (err < 0)
    {
        ret = SIM_NOT_READY;
        goto done;
    }

    if (0 == strcmp (cpinResult, "SIM PIN"))
    {
        ret = SIM_PIN;
        goto done;
    }
    else if (0 == strcmp (cpinResult, "SIM PUK"))
    {
        ret = SIM_PUK;
        goto done;
    }
    else if (0 == strcmp (cpinResult, "PH-NET PIN"))
    {
        return SIM_NETWORK_PERSONALIZATION;
    }
    else if (0 != strcmp (cpinResult, "READY"))
    {
        /* we're treating unsupported lock types as "sim absent" */
        ret = SIM_ABSENT;
        goto done;
    }

    at_response_free(p_response);
    p_response = NULL;
    cpinResult = NULL;

    ret = SIM_READY;
/* BEGIN: Added by eric.li, 2019/1/10   PN:0014627 android5 cannot enter sim init with property */
    if (0 == gSimPostInitFlag && if_get_mode_flag == 1)
    {
	   odm_post_sim_init();
	   RLOGD("odm_post_sim_init complete");
    }
    RLOGD("gSimPostInitFlag [%d]", gSimPostInitFlag);
/* END:   Added by eric.li, 2019/1/10   PN:0014627 android5 cannot enter sim init with property */
done:
    at_response_free(p_response);
    return ret;
}


/**
 * Get the current card status.
 *
 * This must be freed using freeCardStatus.
 * @return: On success returns RIL_E_SUCCESS
 */
static int getCardStatus(RIL_CardStatus_v6 **pp_card_status)
{
    static RIL_AppStatus app_status_array[] =
    {
        // SIM_ABSENT = 0
        {
            RIL_APPTYPE_UNKNOWN, RIL_APPSTATE_UNKNOWN, RIL_PERSOSUBSTATE_UNKNOWN,
            NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN
        },
        // SIM_NOT_READY = 1
        {
            RIL_APPTYPE_SIM, RIL_APPSTATE_DETECTED, RIL_PERSOSUBSTATE_UNKNOWN,
            NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN
        },
        // SIM_READY = 2
        {
            RIL_APPTYPE_SIM, RIL_APPSTATE_READY, RIL_PERSOSUBSTATE_READY,
            NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN
        },
        // SIM_PIN = 3
        {
            RIL_APPTYPE_SIM, RIL_APPSTATE_PIN, RIL_PERSOSUBSTATE_UNKNOWN,
            NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN
        },
        // SIM_PUK = 4
        {
            RIL_APPTYPE_SIM, RIL_APPSTATE_PUK, RIL_PERSOSUBSTATE_UNKNOWN,
            NULL, NULL, 0, RIL_PINSTATE_ENABLED_BLOCKED, RIL_PINSTATE_UNKNOWN
        },
        // SIM_NETWORK_PERSONALIZATION = 5
        {
            RIL_APPTYPE_SIM, RIL_APPSTATE_SUBSCRIPTION_PERSO, RIL_PERSOSUBSTATE_SIM_NETWORK,
            NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN
        },
//#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
/*Begin: Wujiabao changed it to '#if 1' in 2022/07/20*/
#if 1
/*End:   Wujiabao changed it to '#if 1' in 2022/07/20*/
        // RUIM_ABSENT = 6
        { RIL_APPTYPE_UNKNOWN, RIL_APPSTATE_UNKNOWN, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // RUIM_NOT_READY = 7
        { RIL_APPTYPE_RUIM, RIL_APPSTATE_DETECTED, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // RUIM_READY = 8
        { RIL_APPTYPE_RUIM, RIL_APPSTATE_READY, RIL_PERSOSUBSTATE_READY,
          NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // RUIM_PIN = 9
        { RIL_APPTYPE_RUIM, RIL_APPSTATE_PIN, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN },
        // RUIM_PUK = 10
        { RIL_APPTYPE_RUIM, RIL_APPSTATE_PUK, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_BLOCKED, RIL_PINSTATE_UNKNOWN },
        // RUIM_NETWORK_PERSONALIZATION = 11
        { RIL_APPTYPE_RUIM, RIL_APPSTATE_SUBSCRIPTION_PERSO, RIL_PERSOSUBSTATE_SIM_NETWORK,
           NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN },
        // ISIM_ABSENT = 12
        { RIL_APPTYPE_UNKNOWN, RIL_APPSTATE_UNKNOWN, RIL_PERSOSUBSTATE_UNKNOWN,
           NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // ISIM_NOT_READY = 13
        { RIL_APPTYPE_ISIM, RIL_APPSTATE_DETECTED, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // ISIM_READY = 14
        { RIL_APPTYPE_ISIM, RIL_APPSTATE_READY, RIL_PERSOSUBSTATE_READY,
          NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // ISIM_PIN = 15
        { RIL_APPTYPE_ISIM, RIL_APPSTATE_PIN, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN },
        // ISIM_PUK = 16
        { RIL_APPTYPE_ISIM, RIL_APPSTATE_PUK, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_BLOCKED, RIL_PINSTATE_UNKNOWN },
        // ISIM_NETWORK_PERSONALIZATION = 17
        { RIL_APPTYPE_ISIM, RIL_APPSTATE_SUBSCRIPTION_PERSO, RIL_PERSOSUBSTATE_SIM_NETWORK,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN },
#endif
    };
    RIL_CardState card_state;
    int num_apps;
    int sim_status;

    RLOGD("******** Enter getCardStatus() ********");

    sim_status = getSIMStatus();
    /* BEGIN: Added by eric.li, 2018/12/25   PN:gSimstatus to trace sim status */
    gSimStatus = sim_status;
    RLOGD("gSimStatus:%d(%s)", gSimStatus, simStatusToString(gSimStatus));
    /* END:   Added by eric.li, 2018/12/25   PN:gSimstatus to trace sim status */
    if (sim_status == SIM_ABSENT)
    {
        card_state = RIL_CARDSTATE_ABSENT;
        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            num_apps = 3;
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            num_apps = 1;
        }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
			num_apps = 3;
#else
			num_apps = 1;
#endif
#endif
    }
    else
    {
        card_state = RIL_CARDSTATE_PRESENT;
        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            num_apps = 3;
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            num_apps = 1;
        }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
                num_apps = 3;
#else
                num_apps = 1;
#endif
#endif

    }

    // Allocate and initialize base card status.
    RIL_CardStatus_v6 *p_card_status = malloc(sizeof(RIL_CardStatus_v6));
    memset(p_card_status, 0, sizeof(RIL_CardStatus_v6));

    p_card_status->card_state = card_state;
    p_card_status->universal_pin_state = RIL_PINSTATE_UNKNOWN;

    if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
    {
        RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        p_card_status->gsm_umts_subscription_app_index = -1;
        p_card_status->cdma_subscription_app_index = -1;
        p_card_status->ims_subscription_app_index = -1;
    }
    else
    {
        RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
        p_card_status->gsm_umts_subscription_app_index = RIL_CARD_MAX_APPS;
        p_card_status->cdma_subscription_app_index = RIL_CARD_MAX_APPS;
    }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
    p_card_status->gsm_umts_subscription_app_index = -1;
    p_card_status->cdma_subscription_app_index = -1;
    p_card_status->ims_subscription_app_index = -1;
#else
    p_card_status->gsm_umts_subscription_app_index = RIL_CARD_MAX_APPS;
    p_card_status->cdma_subscription_app_index = RIL_CARD_MAX_APPS;
#endif
#endif

    p_card_status->num_applications = num_apps;
    RIL_AppType apptype = getSIMType();
    /*begin:modified for when sim status is SIM_ABSENT,RIL7 will restart by lisf 20181124*/
    if(sim_status == SIM_ABSENT)
    {
	apptype = RIL_APPTYPE_UNKNOWN;
    }
    /*end:modified for when sim status is SIM_ABSENT,RIL7 will restart by lisf 20181124*/
    RLOGD("sim_type = %d", apptype);
    // Initialize application status
    int i;
    for (i = 0; i < RIL_CARD_MAX_APPS; i++)
    {
        p_card_status->applications[i] = app_status_array[SIM_ABSENT];
    }

    // Pickup the appropriate application status
    // that reflects sim_status for gsm.
    if (num_apps != 0)
    {
        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            p_card_status->num_applications = 3;
        }
        else
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d, < 8 or > 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            p_card_status->num_applications = 1;
        }

#if 0
        // Only support one app, gsm
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        p_card_status->num_applications = 3;
 #else
         p_card_status->num_applications = 1;
#endif
#endif
        p_card_status->gsm_umts_subscription_app_index = 0;

        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            p_card_status->cdma_subscription_app_index = 1;
            p_card_status->ims_subscription_app_index = 2;
        }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        p_card_status->cdma_subscription_app_index = 1;
        p_card_status->ims_subscription_app_index = 2;
#endif
#endif
        // Get the correct app status
        p_card_status->applications[0] = app_status_array[sim_status];
		p_card_status->applications[0].app_type = apptype;

        if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
        {
            RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            p_card_status->applications[1] = app_status_array[sim_status + 6];
            p_card_status->applications[2] = app_status_array[sim_status + 12];
        }

#if 0
#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
        p_card_status->applications[1] = app_status_array[sim_status + 6];
        p_card_status->applications[2] = app_status_array[sim_status + 12];
#endif
#endif
    }

    *pp_card_status = p_card_status;
    return RIL_E_SUCCESS;
}

/**
 * Free the card status returned by getCardStatus
 */
static void freeCardStatus(RIL_CardStatus_v6 *p_card_status)
{
    RLOGD("******** Enter freeCardStatus() ********");
    free(p_card_status);
}

/**
 * SIM ready means any commands that access the SIM will work, including:
 *  AT+CPIN, AT+CSMS, AT+CNMI, AT+CRSM
 *  (all SMS-related commands)
 */

static void pollSIMState (void *param __unused)
{
    RLOGD("******** Enter pollSIMState() ********");

    if (sState != RADIO_STATE_SIM_NOT_READY)
    {
        // no longer valid to poll
        return;
    }

    switch(getSIMStatus())
    {
        case SIM_ABSENT:
        case SIM_PIN:
        case SIM_PUK:
        case SIM_NETWORK_PERSONALIZATION:
        default:
            setRadioState(RADIO_STATE_SIM_LOCKED_OR_ABSENT);
            /* BEGIN: Added by eric.li, 2019/1/21   PN:solve issue that can not receive sms issues with probability */
            gSimPostInitFlag = 0;
            /* END:   Added by eric.li, 2019/1/21   PN:solve issue that can not receive sms issues with probability */
            return;

        case SIM_NOT_READY:
            RIL_requestTimedCallback (pollSIMState, NULL, &TIMEVAL_SIMPOLL);
            /* BEGIN: Added by eric.li, 2019/1/21   PN:solve issue that can not receive sms issues with probability */
            gSimPostInitFlag = 0;
            /* END:   Added by eric.li, 2019/1/21   PN:solve issue that can not receive sms issues with probability */
            return;

        case SIM_READY:
            setRadioState(RADIO_STATE_SIM_READY);
            return;
    }
}

/** returns 1 if on, 0 if off, and -1 on error */
static int isRadioOn()
{
    ATResponse *p_response = NULL;
    int err;
    char *line;
    char ret;

    RLOGD("******** Enter isRadioOn() ********");

    err = at_send_command_singleline("AT+CFUN?", "+CFUN:", &p_response);

    if (err < 0 || p_response->success == 0)
    {
        // assume radio is off
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextbool(&line, &ret);
    if (err < 0) goto error;

    at_response_free(p_response);

    return (int)ret;

error:

    at_response_free(p_response);
    return -1;
}

//return value
//0-----3GPP
//1-----3GPP2
int parse_technology_response(const char *response)
{
    int err;
    char *line;
    int tec;
    int skip;
    line = strdup(response);
    RLOGD("parse_technology_response line=%s",line);
    err = at_tok_start(&line);
    if (err < 0)
    {
        RLOGD("tok_start err");
        return 0;
    }
    err = at_tok_nextint(&line, &skip);
    if (err < 0)
    {
        RLOGD("skip err");
        return 0;
    }
    err = at_tok_nextint(&line, &tec);
    if (err < 0)
    {
        RLOGD("tec err");
        return 0;
    }
    if(12 == tec)
    {
        RLOGD("CDMA");
        return 6;
    }
    else if((13 == tec) || (14 == tec) || (15 == tec))
    {
        RLOGD("EVDO");
        return 8;
    }
    else if((1 == tec) || (2 == tec) || (3 == tec))
    {
        RLOGD("GSM");
        return 1;
    }
    else if((9 == tec) || (10 == tec) || (11 == tec))
    {
        RLOGD("LTE");
        return 14;
    }
    else
    {    RLOGD("HSPA");
        return 11;
    }
}


static void waitForClose()
{
    RLOGD("******** Enter waitForClose() ********");

    pthread_mutex_lock(&s_state_mutex);

    while (s_closed == 0)
    {
        pthread_cond_wait(&s_state_cond, &s_state_mutex);
    }

    pthread_mutex_unlock(&s_state_mutex);
    RLOGD("******** Leave waitForClose() ********");
}


/* Called on command or reader thread */
static void onATReaderClosed()
{
    RLOGD("******** Enter onATReaderClosed() ********");
    at_close();
    s_closed = 1;

    setRadioState (RADIO_STATE_UNAVAILABLE);
    RLOGD("AT channel closed\n");
}

/* Called on command thread */
static void onATTimeout()
{
    RLOGD("******** Enter onATTimeout() ********");
    at_close();

    s_closed = 1;

    /* FIXME cause a radio reset here */

    setRadioState (RADIO_STATE_UNAVAILABLE);
    RLOGD("AT channel timeout; closing exit rild reset modem!\n");
    //system("echo at+reset > /dev/ttyUSB3");
    usleep(100000);
    //system("echo at+reset > /dev/ttyUSB1");
    //qualcomm_diag_reset();
    exit(EXIT_FAILURE);
}

static void usage(char *s __unused)
{
    RLOGD("******** Enter usage() ********");
#ifdef RIL_SHLIB
#ifdef HAVE_DATA_DEVICE
    fprintf(stderr, "reference-ril requires: -p <tcp port> or -d /dev/tty_device -m /dev/data_device -t type\n");
#else
    fprintf(stderr, "reference-ril requires: -p <tcp port> or -d /dev/tty_device\n");
#endif
#else
    fprintf(stderr, "usage: %s [-p <tcp port>] [-d /dev/tty_device]\n", s);
    exit(-1);
#endif
}



/**
 * Initialize everything that can be configured while we're still in
 * AT+CFUN=0
 */
void initializeCallback(void *param __unused)
{
    ATResponse *p_response = NULL;
    int err;

    RLOGD("******** Enter initializeCallback() ********");

    setRadioState (RADIO_STATE_OFF);

    at_handshake();
    // <!--[ODM]wangmengying@2019.8.16 [SN-20190712001,SN-20190608001]optimization ppp time
    //sleep(3);
    // end-->
    /* note: we don't check errors here. Everything important will
       be handled in onATTimeout and onATReaderClosed */

    /*  atchannel is tolerant of echo but it must */
    /*  have verbose result codes */
    //at_send_command("ATE0Q0V1", NULL);
    at_send_command("ATE0", NULL);
    at_send_command("ATQ0", NULL);
    at_send_command("ATV1", NULL);

    /*  No auto-answer */
    at_send_command("ATS0=0",NULL);

    /*  Extended errors */
	/*begin: Modified by lisf for NL668-CN-00 mantis 0012816 & mantis 0012820*/
	at_send_command("AT+CMEE=1", NULL);
	/*end: Modified by lisf for NL668-CN-00 mantis 0012816 & mantis 0012820*/

#ifdef V35_Normal_Version_to_open_CREG

    /*  Network registration events */
    err = at_send_command("AT+CREG=2", &p_response);

    /* some handsets -- in tethered mode -- don't support CREG=2 */
    if (err < 0 || p_response->success == 0)
    {
        at_send_command("AT+CREG=1", NULL);
    }

    at_response_free(p_response);
#endif

    /*  GPRS registration events */
    at_send_command("AT+CGREG=2", NULL);

    at_send_command("AT+CEREG=2", NULL);

    /*  Call Waiting notifications */
    at_send_command("AT+CCWA=1", NULL);

    /*  Alternating voice/data off */
    at_send_command("AT+CMOD=0", NULL);

    //at_send_command("AT+NWMINDEN=0", NULL);
    /*  Not muted */
    //   at_send_command("AT+CMUT=0", NULL);     /*for MF226, there is no audio, masked*/

    /*  +CSSU unsolicited supp service notifications */
    at_send_command("AT+CSSN=0,1", NULL);

    /*  no connected line identification */
    at_send_command("AT+COLP=0", NULL);

    /*  HEX character set */
    //add by NODECOM pulong
    //at_send_command("AT+CSCS=\"HEX\"", NULL);
    at_send_command("AT+CSCS=\"IRA\"", NULL);

    /*  USSD unsolicited */
    at_send_command("AT+CUSD=1", NULL);

    /*  Enable +CGEV GPRS event notifications, but don't buffer */
    at_send_command("AT+CGEREP=2,1", NULL);

    /*  SMS PDU mode */
    at_send_command("AT$QCMGF=0", NULL);

    at_send_command("AT+CMGF=0", NULL);

    at_send_command("AT+CAVIMS=1", NULL);

#ifdef SIGNAL_MODEM
    //at_send_command("AT+CGDCONT=2", NULL);
    at_send_command("AT+CGDCONT=3", NULL);
    at_send_command("AT+CGDCONT=4", NULL);
    at_send_command("AT+CGDCONT=5", NULL);
#endif

    if(mode_flag == GHT_L716)
    {
        at_send_command("AT+GTRNDIS=0,1", NULL);
    }
#ifdef USE_TI_COMMANDS
    at_send_command("AT%CPI=3", NULL);

    /*  TI specific -- notifications when SMS is ready (currently ignored) */
    at_send_command("AT%CSTAT=1", NULL);

#endif /* USE_TI_COMMANDS */
/* BEGIN: Added by eric.li, 2018/10/12   PN:fix bug 0010804 for problems answer call inwhen ppp connected  */
    at_send_command("AT+GTSET=\"CALLBREAK\",0", NULL);
/* END:   Added by eric.li, 2018/10/12   PN:fix bug 0010804 for problems answer call inwhen ppp connected  */

// <!--modified by wangyi@2018.07.13 for optimizing time consuming of network available after radio power-on
    //at_send_command("ATH", NULL);
    //sleep(5);
// end-->

// <!--[ODM]wangmengying@2019.8.16 [SN-20190608001]Customized AT commands
    initReserveAtCommand();
// end-->

    /* assume radio is off on error */
    if (isRadioOn() > 0)
    {

        if(ANDROID_4 == Ght_Android_Version || ANDROID_6 == Ght_Android_Version)
        {
            RLOGD("[%s,%d]: version_check Ght_Android_Version:%d == 4 or == 6 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
            setRadioState (RADIO_STATE_SIM_NOT_READY);
        }
        else
        {
            setRadioState (RADIO_STATE_ON);
        }

#if 0
// <!--[ODM]wangmengying@2019.10.31 fix bug31873,Android8 may be called is not at the beginning and needs to be set RADIO_STATE_ON
#if defined GHT_FEATURE_ANDROID6X || defined GHT_FEATURE_ANDROID4X
        setRadioState (RADIO_STATE_SIM_NOT_READY);
#else
        setRadioState (RADIO_STATE_ON);
#endif
// end-->
#endif

/* BEGIN: Added by eric.li, 2019/1/21   PN:solve issue that can not receive sms issues with probability */
     if (1 == gSimPostInitFlag)
     {
        //in android6 need reset this flag to push CNMI send down to modem
        gSimPostInitFlag = 0;
     }
/* END:   Added by eric.li, 2019/1/21   PN:solve issue that can not receive sms issues with probability */
    }
}


/*** Callback methods from the RIL library to us ***/
/**
 * Call from RIL to us to make a RIL_REQUEST
 *
 * Must be completed with a call to RIL_onRequestComplete()
 *
 * RIL_onRequestComplete() may be called from any thread, before or after
 * this function returns.
 *
 * Will always be called from the same thread, so returning here implies
 * that the radio is ready to process another command (whether or not
 * the previous command has completed).
 */

    static void
onRequest (int request, void *data, size_t datalen, RIL_Token t)
{
    static int sn = 0;


    /* Ignore all requests except RIL_REQUEST_GET_SIM_STATUS
     * when RADIO_STATE_UNAVAILABLE.
     */
    RLOGD("********%3d, onRequest(%d): %s********", sn, request,requestToString(request));
    sn++;
    if (sState == RADIO_STATE_UNAVAILABLE
            && request != RIL_REQUEST_GET_SIM_STATUS
       )
    {
        RLOGD("state is unavailable and not get sim status");
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_RADIO_NOT_AVAILABLE, NULL, 0);
        return;
    }

    /* Ignore all non-power requests when RADIO_STATE_OFF
     * (except RIL_REQUEST_GET_SIM_STATUS)
     */
     /* 
     *Added by eric.li, 2018/10/22 
     *(except RIL_REQUEST_GET_RADIO_CAPABILITY)
     *(except RIL_REQUEST_BASEBAND_VERSION)
     *(except RIL_REQUEST_GET_IMEI)
     *(except RIL_REQUEST_GET_IMEISV)
     *End
     *Added by eric.li, 2018/12/30
     *(except RIL_REQUEST_GET_IMSI)
     *to solve issue 0014143,set prefered network with unkonw operator when exption happened
     *End
     */
    if (sState == RADIO_STATE_OFF
            && !(request == RIL_REQUEST_RADIO_POWER
                || request == RIL_REQUEST_GET_SIM_STATUS
                #if (RIL_VERSION > 9)
                || request == RIL_REQUEST_GET_RADIO_CAPABILITY
                #endif
//#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
/*Begin: Wujiabao changed it to '#if 1' in 2022/07/20*/
#if 1
/*End:   Wujiabao changed it to '#if 1' in 2022/07/20*/
                || request == RIL_REQUEST_DEVICE_IDENTITY
 #endif
                || request == RIL_REQUEST_GET_IMEI
                || request == RIL_REQUEST_GET_IMEISV
                || request == RIL_REQUEST_BASEBAND_VERSION
                || request == RIL_REQUEST_GET_IMSI)
       )
    {
        RLOGD("state is off and request is not radio_power or get sim status");
        RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_RADIO_NOT_AVAILABLE, NULL, 0);
        return;
    }


    /**
     * we re-order the request by its function
     * the first part is initialize
     * the second part is sim
     * the third part is network
     * the fourth part other function, such as IMEIBaseBandVersion and so on
     * the fifth part is sms
     * the sixth part is voice
     */

    switch (request)
    {
        /**
         * the first part : initialize
         */
        case RIL_REQUEST_GET_SIM_STATUS:
            {
                requestGetSimStatus(data,datalen,t);
                break;
            }

        case RIL_REQUEST_RADIO_POWER:
            {
                requestRadioPower(data, datalen, t);
                break;
            }
            /**
             * the second part : sim
             */

        case RIL_REQUEST_SIM_IO:
            {   //add by zhengjianrong for MA510 RIL BEGIN
                if(mode_flag == GHT_M910_GL || mode_flag == GHT_MA510_GL){
                //add by zhengjianrong for MA510 RIL END
                    requestSIM_IO_M910(data,datalen,t);
                }
                else{
                    requestSIM_IO(data,datalen,t);
                }
                break;
            }

        case RIL_REQUEST_QUERY_FACILITY_LOCK:
            {
                requestQueryFacilityLock(data, datalen, t);
                break;
            }

        case RIL_REQUEST_SET_FACILITY_LOCK:
            {
                requestSetFacilityLock(data, datalen, t);
                break;
            }

        case RIL_REQUEST_ENTER_SIM_PIN:
        case RIL_REQUEST_ENTER_SIM_PUK:
        case RIL_REQUEST_ENTER_SIM_PIN2:
        case RIL_REQUEST_ENTER_SIM_PUK2:
            {
                //requestEnterSimPin(data, datalen, t);
                requestEnterSimPin(request, data, datalen, t);
                break;
            }
        case RIL_REQUEST_CHANGE_SIM_PIN:
        case RIL_REQUEST_CHANGE_SIM_PIN2:
            {
                //requestChangeSimPin(data, datalen, t);
                requestChangeSimPin(request, data, datalen, t);
                break;
            }
            //Aron modified for sim pin and puk 20101122 end


            /**
             * the third part : network
             */

        case RIL_REQUEST_SIGNAL_STRENGTH:
            {
/*                if(mode_flag == GHT_FG650)
                    requestSignalStrength_CESQ(data, datalen, t);
                else
*/
                    requestSignalStrength_Generic(data, datalen, t);
                break;
            }

        case RIL_REQUEST_VOICE_REGISTRATION_STATE:
        case RIL_REQUEST_DATA_REGISTRATION_STATE:
            {
                if(mode_flag == GHT_M910_GL || mode_flag == GHT_MA510_GL)
                {
                    requestRegistrationStateM910(request, data, datalen, t);
                }
                else
                {
                    requestRegistrationState(request, data, datalen, t);
                }
                break;
            }

        case RIL_REQUEST_OPERATOR:
            {
                if(mode_flag == GHT_L610 || GHT_MC919 == mode_flag || GHT_MC66x == mode_flag)
                {
                    requestOperator(data, datalen, t);
                }
                else
                {
                    requestOperator_Generic(data, datalen, t);
                }
                break;
            }
#if (RIL_VERSION != 7)
        case RIL_REQUEST_SET_INITIAL_ATTACH_APN:
            {   //add by zhengjianrong for MA510 RIL BEGIN
                if(mode_flag == GHT_M910_GL || mode_flag == GHT_MA510_GL){
                //add by zhengjianrong for MA510 RIL END
                    requestSetInitialAttachAPNM910(data, datalen, t);
                }
                else{
                    requestSetInitialAttachAPN(data, datalen, t);
                }
                break;
            }
#endif
        case RIL_REQUEST_SETUP_DATA_CALL:
            {
                requestSetupDataCall(data, datalen, t);
                break;
            }

        case RIL_REQUEST_DEACTIVATE_DATA_CALL:
            {
                requestDeactivateDataCall(data, datalen, t);
                break;
            }
        case RIL_REQUEST_SET_NETWORK_SELECTION_AUTOMATIC:
            {
                requestSetNetworkSelectionAutomatic(t);
                break;
            }

        case RIL_REQUEST_SET_NETWORK_SELECTION_MANUAL:
            {
                requestSetNetworkSelectionManual(data, datalen, t);
                break;
            }

        case RIL_REQUEST_SET_PREFERRED_NETWORK_TYPE:
            {

                /*TODO*/
                RLOGD("set preferred network type: %d", ((int *)data)[0]);    // debug ++
                //add by zhengjianrong for MA510 RIL BEGIN
                if(mode_flag == GHT_M910_GL || mode_flag == GHT_757S || mode_flag == GHT_MA510_GL)
                //add by zhengjianrong for MA510 RIL END
                {
                    requestSetPreferredNetworkType_M910(data, datalen,t);
                }
                else if(GTRAT_Support_Flag)
                {
                    requestSetPreferredNetworkType(data, datalen, t);
                }
                else
                {
                    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
                }
                break;
            }

        case RIL_REQUEST_GET_PREFERRED_NETWORK_TYPE:
            {   //add by zhengjianrong for MA510 RIL BEGIN
                if(mode_flag == GHT_M910_GL || mode_flag == GHT_757S || mode_flag == GHT_MA510_GL){
                //add by zhengjianrong for MA510 RIL END
                    requestGetPreferredNetworkTypeM910(data, datalen, t);
                }
                else if(GTRAT_Support_Flag)
                {
                    requestGetPreferredNetworkType(data, datalen, t);
                }
                else
                {
                    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
                }
                break;
            }

        case RIL_REQUEST_QUERY_AVAILABLE_NETWORKS:
            {
                requestQueryAvailableNetworks(data, datalen, t);
                break;
            }

        case RIL_REQUEST_GET_NEIGHBORING_CELL_IDS:
            {
                 requestNeighboringCellIds(data,datalen,t);
                 break;
            }
        case RIL_REQUEST_GET_CELL_INFO_LIST:
            {
                requestGetCellInfoList(data, datalen, t);
            }
            break;

        case RIL_REQUEST_DATA_CALL_LIST:
            {
                requestDataCallList(data, datalen, t);
                break;
            }

        case RIL_REQUEST_QUERY_NETWORK_SELECTION_MODE:
            {
                requestQueryNetworkSelectionMode(data, datalen, t);
                break;
            }

        case RIL_REQUEST_SET_LOCATION_UPDATES:
            {
                requestSetLocationUpdates(data,datalen,t);
                break;
            }
        case RIL_REQUEST_SCREEN_STATE:
            {
                requestScreenState(data, datalen, t);
                break;
            }

            /**
             * the fourth part : other function, such as IMEIBaseBandVersion and so on
             */

        case RIL_REQUEST_GET_IMSI:
            {
		  if(RADIO_STATE_OFF != sState)
		  {
                   requestGetIMSI(data,datalen,t);
		  }
		  else
		  {
        		RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_RADIO_NOT_AVAILABLE, NULL, 0);
		  }
                break;
            }

        case RIL_REQUEST_GET_IMEISV:
            {
                if(GHT_H330S == mode_flag)
				{RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);}
                else
                    requestGetIMEISV(data,datalen,t);
                break;
            }

        case RIL_REQUEST_GET_IMEI:
            {
                requestGetIMEI(data,datalen,t);
                break;
            }

        case RIL_REQUEST_SEND_USSD:
            {
                requestSendUSSD(data, datalen, t);
                break;
            }

        case RIL_REQUEST_CANCEL_USSD:
            {
                requestCancelUSSD(data,datalen,t);
                break;
            }

        case RIL_REQUEST_BASEBAND_VERSION:
            {
                requestBasebandVersion(data,datalen,t);
                break;
            }

        case RIL_REQUEST_OEM_HOOK_RAW:
            {
                // echo back data
                RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, data, datalen);
                break;
            }

        case RIL_REQUEST_OEM_HOOK_STRINGS:
            {
                requestOemHookStrings(data,datalen,t);
                break;
            }

        case RIL_REQUEST_QUERY_CLIP:
            {
                requestQueryClip(data, datalen, t);
                break;
            }

            /**
             * the fifth part : sms
             */

        case RIL_REQUEST_SEND_SMS:
            {
                requestSendSMS(data, datalen, t);
                break;
            }
/* BEGIN: Added by eric.li, 2019/1/9   PN:add support for send more message */
       case  RIL_REQUEST_SEND_SMS_EXPECT_MORE:
	     {
	      if(mode_flag == GHT_FG650)
		  	requestSendSMS(data, datalen, t);
		  else
		    requestSendSMSExpectMore(data, datalen, t);
		  break;
	     }
/* END:   Added by eric.li, 2019/1/9   PN:add support for send more message */

        case RIL_REQUEST_SMS_ACKNOWLEDGE:
            {
                requestSMSAcknowledge(data, datalen, t);
                break;
            }

        case RIL_REQUEST_WRITE_SMS_TO_SIM:
            {
                requestWriteSmsToSim(data, datalen, t);
                break;
            }

        case RIL_REQUEST_DELETE_SMS_ON_SIM:
            {
                requestDeleteSmsOnSim(data, datalen, t);
                break;
            }
#if 1
        case RIL_REQUEST_GSM_GET_BROADCAST_SMS_CONFIG:
            {
		#if (RIL_VERSION  > 11)
		/* BEGIN: Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
		if (SIM_READY != gSimStatus)
		{
	            RIL_onRequestComplete( t, RIL_E_INVALID_STATE, NULL, 0 );	
		}else
        #endif
		{
		/* END:   Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
                requestGsmGetBroadcastSMSConfig(data, datalen, t);
		}
                break;
            }

        case RIL_REQUEST_GSM_SET_BROADCAST_SMS_CONFIG:
            {
	#if (RIL_VERSION  > 11)
		/* BEGIN: Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
		if (SIM_READY != gSimStatus)
		{
	            RIL_onRequestComplete( t, RIL_E_INVALID_STATE, NULL, 0 );	
		}
        else
	#endif
		{
		/* END:   Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
                requestGsmSetBroadcastSMSConfig(data, datalen, t);
		}
                break;
            }

        case RIL_REQUEST_GSM_SMS_BROADCAST_ACTIVATION:
            {
	#if (RIL_VERSION  > 11)
		/* BEGIN: Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
		if (SIM_READY != gSimStatus)
		{
	            RIL_onRequestComplete( t, RIL_E_INVALID_STATE, NULL, 0 );	
		}else
	#endif
		{
		/* END:   Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
                requestGsmSMSBroadcastActivation(data, datalen, t);
		}
                break;
            }

        case RIL_REQUEST_GET_SMSC_ADDRESS:
            {
	#if (RIL_VERSION  > 11)
		/* BEGIN: Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
		if (SIM_READY != gSimStatus)
		{
	            RIL_onRequestComplete( t, RIL_E_INVALID_STATE, NULL, 0 );	
		}else
	#endif
		{
		/* END:   Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
                requestGetSMSCAddress(data, datalen, t);
		}
                break;
            }

        case RIL_REQUEST_SET_SMSC_ADDRESS:
            {
	#if (RIL_VERSION  > 11)
		/* BEGIN: Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
		if (SIM_READY != gSimStatus)
		{
	            RIL_onRequestComplete( t, RIL_E_INVALID_STATE, NULL, 0 );	
		}else
	#endif
		{
		/* END:   Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
                requestSetSMSCAddress(data, datalen, t);
		}
                break;
            }

        case RIL_REQUEST_REPORT_SMS_MEMORY_STATUS:
            {
	#if (RIL_VERSION  > 11)
		/* BEGIN: Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
		if (SIM_READY != gSimStatus)
		{
	            RIL_onRequestComplete( t, RIL_E_INVALID_STATE, NULL, 0 );	
		}else
	#endif
		{
		/* END:   Modified by eric.li, 2018/12/25   PN:if sim status is not ready,including pin/puk, force return back */
                requestReportSMSMemoryStatus(data, datalen, t);
		}
                break;
            }

#endif

            /**
             * the sixth part : voice
             */
        case RIL_REQUEST_GET_CURRENT_CALLS:
            {
                if(Voice_Support_Flag && getProfileBool("AT", "CLCC", true))
                {
                    requestGetCurrentCalls(data, datalen, t);
                }
                else
                {
                    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
                }
                break;
            }

        case RIL_REQUEST_DIAL:
            {
                if(Voice_Support_Flag)
                {
                    requestDial(data, datalen, t);
                }
                else
                {
                    RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
                }
                break;
            }

        case RIL_REQUEST_HANGUP:
            {
                requestHangup(data, datalen, t);
                break;
            }

        case RIL_REQUEST_HANGUP_WAITING_OR_BACKGROUND:
            {
                // 3GPP 22.030 6.5.5
                // "Releases all held calls or sets User Determined User Busy
                //  (UDUB) for a waiting call."
                //at_send_command("AT+CHLD=0", NULL);
                /* at_send_command("AT+CHUP", NULL);*/
                /* success or failure is ignored by the upper layer here.
                   it will call GET_CURRENT_CALLS and determine success that way */
                /* RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0); */
                requestHangupWaitingOrBackground(data,datalen,t);
                break;
            }

        case RIL_REQUEST_HANGUP_FOREGROUND_RESUME_BACKGROUND:
            {
                // 3GPP 22.030 6.5.5
                // "Releases all active calls (if any exist) and accepts
                //  the other (held or waiting) call."
                //at_send_command("AT+CHLD=1", NULL);
                /* at_send_command("AT+CHUP", NULL);*/
                /* success or failure is ignored by the upper layer here.
                   it will call GET_CURRENT_CALLS and determine success that way */
                /*RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);*/
                requestHangupForegroundResumeBackground(data,datalen,t);
                break;
            }

        case RIL_REQUEST_SWITCH_WAITING_OR_HOLDING_AND_ACTIVE:
            {
                // 3GPP 22.030 6.5.5
                // "Places all active calls (if any exist) on hold and accepts
                //  the other (held or waiting) call."
                /* at_send_command("AT+CHLD=2", NULL); */

                /*
#ifdef WORKAROUND_ERRONEOUS_ANSWER
s_expectAnswer = 1;
#endif*/  /* WORKAROUND_ERRONEOUS_ANSWER */

                /* success or failure is ignored by the upper layer here.
                   it will call GET_CURRENT_CALLS and determine success that way */
                /* RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);*/
                requestSwitchWaitingOrHoldingAndActive(data,datalen,t);
                break;
            }

        case RIL_REQUEST_ANSWER:
            {
                /* at_send_command("ATA", NULL);*/
                /*
#ifdef WORKAROUND_ERRONEOUS_ANSWER
s_expectAnswer = 1;
#endif */ /* WORKAROUND_ERRONEOUS_ANSWER */

                /* success or failure is ignored by the upper layer here.
                   it will call GET_CURRENT_CALLS and determine success that way */
                /*RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);*/
                requestAnswer(data,datalen,t);
                break;
            }

        case RIL_REQUEST_CONFERENCE:
            {
                // 3GPP 22.030 6.5.5
                // "Adds a held call to the conversation"
                /* at_send_command("AT+CHLD=3", NULL);*/

                /* success or failure is ignored by the upper layer here.
                   it will call GET_CURRENT_CALLS and determine success that way */
                /* RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0); */
                requestConference(data,datalen,t);
                break;
            }

        case RIL_REQUEST_UDUB:
            {
                /* user determined user busy */
                /* sometimes used: ATH */
                /* at_send_command("ATH", NULL); */

                /* success or failure is ignored by the upper layer here.
                   it will call GET_CURRENT_CALLS and determine success that way */
                /* RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);*/
                requestUDUB(data,datalen,t);
                break;
            }

        case RIL_REQUEST_SEPARATE_CONNECTION:
            {
                requestSeparateConnection(data,datalen,t);
                break;
            }

        case RIL_REQUEST_DTMF:
            {
                requestDTMF(data,datalen,t);
                break;
            }

        case RIL_REQUEST_DTMF_STOP:
            {
                requestDTMFStop(data,datalen,t);
                break;
            }

        case RIL_REQUEST_DTMF_START:
            {
                requestDTMFStart(data,datalen,t);
                break;
            }

        case RIL_REQUEST_SET_MUTE:
            {
                RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
                break;
            }

        case  RIL_REQUEST_GET_MUTE:
            {
                requestGetMute(data, datalen, t);
                break;
            }
        case  RIL_REQUEST_GET_CLIR:
            {
                requestGetClir(data, datalen, t);
                break;
            }

        case  RIL_REQUEST_SET_CLIR:
            {
                requestSetClir(data, datalen, t);
                break;
            }
// <!--added by wangmengying@2018.8.1 for Call Forwarding Number and Conditions
        case RIL_REQUEST_SET_CALL_FORWARD:
            {
                requestSetCallForward(data, t);
                break;
            }
        case RIL_REQUEST_QUERY_CALL_FORWARD_STATUS:
            {
                requestQueryCallForwardStatus(data, t);
                break;
            }
// end--!>
        case RIL_REQUEST_QUERY_CALL_WAITING:
            {
                requestQueryCallWaiting(data, datalen, t);
                break;
            }

        case RIL_REQUEST_SET_CALL_WAITING:
            {
                requestSetCallWaiting(data, datalen, t);
                break;
            }
		/* BEGIN: Added by eric.li, 2018/10/16   PN:add support radio capability */
#if (RIL_VERSION > 9 )
        case RIL_REQUEST_GET_RADIO_CAPABILITY:
		{
		    char  android_version[PROP_VALUE_MAX];
		    __system_property_get("ro.build.version.release", android_version);
		            requestGetRadioCapablility(data, datalen, t);
		            RLOGD("Android Version [%s], support requestGetRadioCapablility request\r\n", android_version);
		}
		break;
#endif
		/* END:   Added by eric.li, 2018/10/16   PN:add support radio capability */
//#if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
/*Begin: Wujiabao changed it to '#if 1' in 2022/07/20*/
#if 1
/*End:   Wujiabao changed it to '#if 1' in 2022/07/20*/
        case RIL_REQUEST_DEVICE_IDENTITY:
        {
            requestDeviceIdentity(data, datalen, t);
            break;
        }
        case RIL_REQUEST_GET_HARDWARE_CONFIG:
        {
            requestGetHardwareConfig(data, datalen, t);
            break;
        }
#endif
//#ifndef GHT_FEATURE_ANDROID4X
/*Begin: Wujiabao changed it to '#if 1' in 2022/07/20*/
#if 1
/*End:   Wujiabao changed it to '#if 1' in 2022/07/20*/
        case RIL_REQUEST_SET_DATA_PROFILE:
        {
            RLOGD("[%s] set data profile ",__FUNCTION__);
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
            break;
        }
        case RIL_REQUEST_VOICE_RADIO_TECH:
        {
            RLOGD("[%s] VOICE_RADIO_TECH ",__FUNCTION__);
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
            break;
        }
        case RIL_REQUEST_CDMA_SET_ROAMING_PREFERENCE:
        {
            RLOGD("[%s] RIL_REQUEST_CDMA_SET_ROAMING_PREFERENCE ",__FUNCTION__);
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
            break;
        }
        case RIL_REQUEST_CDMA_SUBSCRIPTION:
        {
            RLOGD("[%s] RIL_REQUEST_CDMA_SUBSCRIPTION ",__FUNCTION__);
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
            break;
        }
        case RIL_REQUEST_CDMA_QUERY_ROAMING_PREFERENCE:
        {
            RLOGD("[%s] RIL_REQUEST_CDMA_QUERY_ROAMING_PREFERENCE ",__FUNCTION__);
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
            break;
        } 
        case RIL_REQUEST_ALLOW_DATA:
        {
            int allowdata = ((int *)data)[0];

            //<--Start:Modified by Wujiabao in 2022/05/05, because we always thought modules supported data call
            RLOGD("[%s] allowdata:%d, %s",__FUNCTION__, allowdata, allowdata == 1? "allow":"disallow");
            if (allowdata == 0)
            {
                RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
            }
            else
            {
                RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
            }
            //--End:Modified by Wujiabao in 2022/05/05, because we always thought modules supported data call---!>

            break;
        }
#endif

        case RIL_REQUEST_SIM_OPEN_CHANNEL:
        {
            requestSimOpenChannel(data, datalen, t);
            break;
        }
        case RIL_REQUEST_SIM_CLOSE_CHANNEL:
        {
            requestSimCloseChannel(data, datalen, t);
            break;
        }
        case RIL_REQUEST_SIM_TRANSMIT_APDU_CHANNEL:
        {
            requestSimTransmitApduChannel(data, datalen, t);
            break;
        }


        default:
            RLOGE("stephen-ril Response RIL_onRequestComplete RIL_E_SUCCESS (%s:%d)",__FUNCTION__,__LINE__);RIL_onRequestComplete(t, RIL_E_REQUEST_NOT_SUPPORTED, NULL, 0);
            break;
    }
}
// <!--[ODM]lindong@2017.12.13 for Sim hot plug
void SimStatusChangedCallback(void *param __unused)
{
    RLOGD("[%s,%d]sState %d[%s]",__FUNCTION__, __LINE__, sState, radioStateToString(sState));
    setRadioState(RADIO_STATE_SIM_READY);
    RLOGD("[%s,%d]sState %d[%s]",__FUNCTION__, __LINE__, sState, radioStateToString(sState));
    RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(
            RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED,
            NULL, 0);
    RLOGD("[%s,%d]sState %d[%s]",__FUNCTION__, __LINE__, sState, radioStateToString(sState));
    RLOGD("[%s,%d]",__FUNCTION__, __LINE__);
}
// end-->
extern void cdma_pdu_2_3gpp_pdu(char *pdu_3gpp2, char *pdu_3gpp);
/**
 * Called by atchannel when an unsolicited line appears
 * This is called on atchannel's reader thread. AT commands may
 * not be issued here
 */
static void onUnsolicited (const char *s, const char *sms_pdu)
{
    char *line = NULL;
    int err;
    RLOGD("******** Enter onUnsolicited() ********");
	/* BEGIN: Deleted by eric.li, 2019/1/10   PN:0014627 android5 cannot enter sim init with property */
	/* END:   Deleted by eric.li, 2019/1/10   PN:0014627 android5 cannot enter sim init with property */

    /* Ignore unsolicited responses until we're initialized.
     * This is OK because the RIL library will poll for initial state
     */
    if (sState == RADIO_STATE_UNAVAILABLE)
    {
        RLOGD("it is exit onunsolicited because RADIO_STATE_UNAVAILABLE");
        return;
    }

    if (strStartsWith(s, "%CTZV:"))
    {
        /* TI specific -- NITZ time */
        char *response;

        line = strdup(s);
        at_tok_start(&line);

        err = at_tok_nextstr(&line, &response);

        if (err != 0)
        {
            RLOGD("invalid NITZ line %s\n", s);
        }
        else
        {
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                    RIL_UNSOL_NITZ_TIME_RECEIVED,
                    response, strlen(response));
        }
    }
    else if (strStartsWith(s,"+CRING:")
            || strStartsWith(s,"RING")
            //|| strStartsWith(s,"NO CARRIER")
            || strStartsWith(s,"+CCWA")
            || strStartsWith(s,"CONNECT")
            //|| strStartsWith(s,"^DSCI:")
            )
    {
        /* BEGIN: Added by eric.li, 2018/10/11   PN:fix bug for ring call */
            if (strStartsWith(s,"+CRING:")
                || strStartsWith(s,"RING")){
          RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_CALL_RING, NULL, 0); //Add for notify application play ring, case 0010804
        }
    /* END:   Added by eric.li, 2018/10/11   PN:fix bug for ring call */

        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                RIL_UNSOL_RESPONSE_CALL_STATE_CHANGED,
                NULL, 0);
#ifdef WORKAROUND_FAKE_CGEV
        RIL_requestTimedCallback (onDataCallListChanged, NULL, NULL); //TODO use new function
#endif /* WORKAROUND_FAKE_CGEV */
    }
    else if (strStartsWith(s,"+CREG:")
            ||strStartsWith(s,"+CGREG:")
            ||strStartsWith(s,"+CEREG:")
            ||strStartsWith(s,"+C5GREG:")
            ||strStartsWith(s,"+NWTYPEIND:")
            ||strStartsWith(s,"^MODE:")
            )
    {
    /* BEGIN: Modified by eric.li, 2019/2/23   PN:0015171 fix android8 cfun display signal issue*/
        #if 0 //Modified by zjr 2019/07/15 PN:0024628 fix android7 restarts after closing the flight mode can not access the Internet
    if (sState >= RADIO_STATE_ON || sState == RADIO_STATE_SIM_READY)
        #endif /*ODM_ARM64 */
    {
        RLOGD("Network State Changed.");
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED,NULL, 0);
    }
    /* END:   Modified by eric.li, 2019/2/23   PN: 0015171 android8 cfun display signal issue*/
#ifdef WORKAROUND_FAKE_CGEV
/* BEGIN: Modified by eric.li, 2019/2/18   PN:debounce for network detach */
        {
                struct timeval network_detach = {0, 100000};
                RLOGD("%s,%d,onUNsol str[%s]", __FUNCTION__,__LINE__,s);
                RIL_requestTimedCallback (onDataCallListChanged, NULL, &network_detach);
        }
#endif /* WORKAROUND_FAKE_CGEV */
/* BEGIN: Added by eric.li, 2018/11/5   PN:0010759  hotplug issue */
	{
		int sim_status;
		sim_status = getSIMStatus();
		RLOGD("sState: %d(%s), sim_status: %d" , sState, radioStateToString(sState),sim_status);
		if(SIM_NOT_READY >= sim_status)
		{
		        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(
				            RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED,
				            NULL, 0);
		}
	}
/* END:   Added by eric.li, 2018/11/5   PN:0010759  hotplug issue */
    }
    else if (strStartsWith(s, "+CMT:"))
    {
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                RIL_UNSOL_RESPONSE_NEW_SMS,
                sms_pdu, strlen(sms_pdu));
    }
    else if (strStartsWith(s, "^DATADISCONN"))
    {
        RIL_requestTimedCallback (onDeactiveDataCallList, NULL, NULL);
    }
    else if (strStartsWith(s, "^HCMGSS:") ||
            strStartsWith(s, "^HCMGSF0"))
    {
        RLOGD("handover_flag = %d",handover_flag);
        if(1 == handover_flag)
        {
            RIL_requestTimedCallback (OnResumeLTENetwork, NULL, NULL);
            handover_flag = 0;
        }
    }
    else if(strStartsWith(s, "^DSCI:")
            || strStartsWith(s,"NO CARRIER"))
    {
        RLOGD("voice_handover_flag = %d",voice_handover_flag);
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                RIL_UNSOL_RESPONSE_CALL_STATE_CHANGED,
                NULL, 0);
#ifdef WORKAROUND_FAKE_CGEV
        RIL_requestTimedCallback (onDataCallListChanged, NULL, NULL); //TODO use new function
#endif /* WORKAROUND_FAKE_CGEV */
        if(1 == voice_handover_flag)
        {
            RIL_requestTimedCallback (OnResumeLTENetwork, NULL, NULL);
            voice_handover_flag = 0;
        }
    }

    //add by gaojing to test at+ecm
    else if (strStartsWith(s, "+CDS:"))
    {
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                RIL_UNSOL_RESPONSE_NEW_SMS_STATUS_REPORT,
                sms_pdu, strlen(sms_pdu));
    }
    else if(strStartsWith(s,"+CMGR:"))
    {
        if(sms_type == SMS_GENERAL || sms_type == SMS_BROADCAST)
        {
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                RIL_UNSOL_RESPONSE_NEW_SMS,
                sms_pdu, strlen(sms_pdu));

        }
        else if (sms_type == SMS_SEND_REPORT)
        {
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                    RIL_UNSOL_RESPONSE_NEW_SMS_STATUS_REPORT,
                    sms_pdu, strlen(sms_pdu));
        }
    }
    else if (strStartsWith(s, "+CGEV:"))
    {
        RLOGD("%s,%d, NW DETACH", __FUNCTION__, __LINE__);
        #if 1
        if(mode_flag != GHT_FG650)
        {
            if(strStartsWith(s,"+CGEV: NW DETACH") || strStartsWith(s,"+CGEV: NW DEACT"))
            {
                RLOGD("%s,%d", __FUNCTION__, __LINE__);
                #ifdef ODM_ARM64
                RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED,NULL, 0);
                #endif          
                onDeactiveDataCallList();          
            }   
            struct timeval network_detach = {0, 100000};
            RIL_requestTimedCallback (onDataCallListChanged, NULL, &network_detach);
            //   RIL_requestTimedCallback (onDataCallListChanged, NULL, NULL);
        }
        #endif
    }
    #ifdef WORKAROUND_FAKE_CGEV
    else if (strStartsWith(s, "+CME ERROR: 150"))
    {
        RIL_requestTimedCallback (onDataCallListChanged, NULL, NULL);
    }
    #endif /* WORKAROUND_FAKE_CGEV */
    else if ( strStartsWith(s, "+CMTI:")  || strStartsWith(s, "+CBMI:") || strStartsWith(s, "+CDSI:"))
    {
        onNewSmsNotification((char *)s); // modify by FPL
    }
    else if(strStartsWith(s,"+CUSD:"))
    {
        char *response;
        char *uusd_line;
        uusd_line = strdup(s);
        at_tok_start(&uusd_line);
        err = at_tok_nextstr(&uusd_line, &response);
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse (
                RIL_UNSOL_ON_USSD,
                response, strlen(response));
    }
    // <!--[ODM]lindong@2017.12.13 for Sim hot plug
    else if(strStartsWith(s,"+SIM: Inserted") || strStartsWith(s,"+SIM: READY") || strStartsWith(s,"+SIM READY"))
    {
        RLOGD("[%s,%d]Report SIM Inserted, sState:%d(%s)", __FUNCTION__, __LINE__, sState, radioStateToString(sState));
        if(sState != RADIO_STATE_OFF && sState != RADIO_STATE_UNAVAILABLE)
        {
            struct timeval SimStatusChangded = {2, 0};
            RLOGD("[%s,%d]Report SIM Inserted status changed callback timeout[%ld]", __FUNCTION__, __LINE__, SimStatusChangded.tv_sec);
            RIL_requestTimedCallback(SimStatusChangedCallback, NULL, &SimStatusChangded);
            RLOGD("[%s,%d]Report SIM Inserted status changed", __FUNCTION__, __LINE__);
        }
    }
    else if(strStartsWith(s,"+SIM: Removed") ||  strStartsWith(s,"+SIM: Drop")) //modified by lisf for debug 20181225
    {
        setRadioState(RADIO_STATE_SIM_NOT_READY);
        RLOGD("[%s,%d]Report SIM Removed status changed", __FUNCTION__, __LINE__);
        RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED,NULL, 0);
        //�ر�ppp���� ����ͨ��
        if (mode_flag == GHT_NL678_E){
            if(ppp_fd > 0){
                at_send_command("ATH", NULL);
                close(ppp_fd);
                ppp_fd = -1;
            }
            pppd = 0;
            RLOGE("stephen-ril Response RIL_onUnsolicitedResponse (%s:%d) ,data(NULL)",__FUNCTION__,__LINE__);RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,NULL, 0);
		}
        else{
            onDeactiveDataCallList();
        }
        RLOGD("[%s,%d]Report SIM Removed status changed", __FUNCTION__, __LINE__);
    }
    else
    {
        RLOGD("Unknown statement,ignoring...:%s",s);
    }

    free(line);
    RLOGD("******** Leave onUnsolicited() ********");
}

    static void *
mainLoop(void *param __unused)
{
    int fd;
    int ret;
    RLOGD("******** Enter mainLoop() ********");
#ifdef HAVE_DATA_DEVICE
    struct stat dummy;
#endif
#ifdef SIGNAL_MODEM
    struct termios new_termios, old_termios;
#endif

    at_set_on_reader_closed(onATReaderClosed);
    at_set_on_timeout(onATTimeout);

    for (;;)
    {
        fd = -1;
        while  (fd < 0)
        {
#ifdef HAVE_DATA_DEVICE
            /* If the modem have two channel, e.g. UART for AT command and USB for data,
               we check the data channel firstly (e.g. /dev/ttyUSB0) so that after AT handshake
               we can make sure the data channel is ready.
               */
            if((!dialmode) && (stat(s_data_device_path, &dummy)))
            {
                RLOGD ("opening data channel device - %s. retrying...", s_data_device_path);
              //  goto get_device;
            }
#endif
            if (s_port > 0)
            {

                if(Ght_Android_Version >= ANDROID_8 && Ght_Android_Version <= ANDROID_11)
                {
                    RLOGD("[%s,%d]: version_check 8 <= Ght_Android_Version:%d <= 11 ?", __FUNCTION__, __LINE__, Ght_Android_Version);
                    fd = socket_network_client("localhost",s_port, SOCK_STREAM);
                }

#if 0
          #if defined GHT_FEATURE_ANDROID8X || defined GHT_FEATURE_ANDROID9X || defined GHT_FEATURE_ANDROID10X
                 fd = socket_network_client("localhost",s_port, SOCK_STREAM);
	   #else
                //fd = socket_loopback_client(s_port, SOCK_STREAM);
	   #endif
#endif
            }
            else if (s_device_socket)
            {
                if (!strcmp(s_device_path, "/dev/socket/qemud"))
                {
                    /* Qemu-specific control socket */
                    fd = socket_local_client( "qemud",
                            ANDROID_SOCKET_NAMESPACE_RESERVED,
                            SOCK_STREAM );
                    if (fd >= 0 )
                    {
                        char  answer[2];

                        if ( write(fd, "gsm", 3) != 3 ||
                                read(fd, answer, 2) != 2 ||
                                memcmp(answer, "OK", 2) != 0)
                        {
                            close(fd);
                            fd = -1;
                        }
                    }
                }
                else
                    fd = socket_local_client( s_device_path,
                            ANDROID_SOCKET_NAMESPACE_FILESYSTEM,
                            SOCK_STREAM );
            }
            else if (s_device_path != NULL)
            {
                fd = open (s_device_path, O_RDWR);
                if ( fd >= 0 && !memcmp( s_device_path, "/dev/ttyS", 9 ) )
                {
                    /* disable echo on serial ports */
                    struct termios  ios;
                    tcgetattr( fd, &ios );
                    ios.c_lflag = 0;  /* disable ECHO, ICANON, etc... */
                    tcsetattr( fd, TCSANOW, &ios );
                }
            }

            if (fd < 0)
            {

                RLOGD ("opening AT interface. retrying...:%s",strerror(errno));
//get_device:
                sleep(1);
                RLOGD("open port fail,retry usb detect");
                memset(&s_usbPortDevice,0,sizeof(USBPortDevice));
                ret = getUsbPortInfo(&s_usbPortDevice);
                if (!ret)
                {
                    s_device_path = s_usbPortDevice.atchannel;
                    if (dialmode == 0)
                    {
                        property_set("ril.datachannel", s_usbPortDevice.datachannel);
#ifdef HAVE_DATA_DEVICE
                        s_data_device_path = s_usbPortDevice.datachannel;
#endif
                    }
                }
                /* never returns */
            }
        }

#ifdef SIGNAL_MODEM
        /* Set UART parameters (e.g. Buad rate) for connecting with SIGNAL modem */
        tcgetattr(fd, &old_termios);
        new_termios = old_termios;
        new_termios.c_lflag &= ~(ICANON | ECHO | ISIG);
        new_termios.c_cflag |= (CREAD | CLOCAL);
        new_termios.c_cflag &= ~(CSTOPB | PARENB | CRTSCTS);
        new_termios.c_cflag &= ~(CBAUD | CSIZE) ;
        new_termios.c_cflag |= (B115200 | CS8);
        ret = tcsetattr(fd, TCSANOW, &new_termios);
        if(ret < 0)
        {
            RLOGD ("Fail to set UART parameters. tcsetattr return %d \n", ret);
            return 0;
        }
#endif

        s_closed = 0;
        ret = at_open(fd, onUnsolicited);

        if (ret < 0)
        {
            RLOGD ("AT error %d on at_open\n", ret);
            return 0;
        }
        else
            RLOGD("AT open successfully!");

        /* Some SIGNAL USB datacards (e.g. E180) bootup and attach to network a little bit slowly(e.g. 20s).
           Delay RIL init so that we can always get correct network status (i.e. +COPS?).
           FIX ME: this should be removed in future. Service layer should be responsible to handle "late" attach.
           */
        property_set("ril.currentapntype", "default"); //add by duanshitao 20111003

        if(dialmode == DIAL_RAS_MOD) //RAS_MOD
        {
            if((ret = start_ppp_check_pthread())<0)
            {
                RLOGD("%s: start_ppp_check_pthread() failed: %s", __FUNCTION__, strerror(errno));
                return 0;
            }
        }
        else if(dialmode == DIAL_NDIS_MOD)
        {
            if((ret = start_ndis_do_dhcp_pthread())<0)
            {
                RLOGD("%s: start_ndis_do_dhcp_pthread() failed: %s", __FUNCTION__, strerror(errno));
                return 0;
            }
        }
        RIL_requestTimedCallback(initializeCallback, NULL, &TIMEVAL_DELAYINIT);

        // Give initializeCallback a chance to dispatched, since
        // we don't presently have a cancellation mechanism
        sleep(1);

        waitForClose();
        RLOGD("Re-opening after close");
    }
}

#ifdef RIL_SHLIB

pthread_t s_tid_mainloop;

pthread_t s_tid_pingloop;

int start_ppp_check_pthread()
{
    int ret = -1;
    pthread_attr_t attr;
    pthread_attr_init (&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    ret = pthread_create(&s_tid_mainloop, &attr, ppp_main_loop,  NULL);
    return ret;
}
int start_ndis_do_dhcp_pthread()
{
    int ret = -1;
    pthread_attr_t attr;
    pthread_attr_init (&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    ret = pthread_create(&s_tid_ndisloop, &attr, ndis_main_loop,  NULL);
    return ret;
}

Android_Version Ght_Android_Version = ANDROID_4;


int getRIL_VERSION()
{
//ro.build.version.release
    int ret, Android_version;
    char Android_ver_str[PROPERTY_VALUE_MAX] = {0};

    ret = property_get("ro.build.version.release", Android_ver_str, "");
    if(ret > 0)
    {
        Android_version = atoi(Android_ver_str);
        if(Android_version > 0)
        {
            Ght_Android_Version = (Android_Version)Android_version;
            RLOGD("Android version:%d, Ght_Android_Version:%d", Android_version, Ght_Android_Version);
        }
        else
        {
            RLOGE("Got the wrong Android version:%s", Android_ver_str);
            goto error;
        }
    }
    else
    {
        RLOGE("Failed to get value of ro.build.version.release!!!");
        goto error;
    }

    if(Android_version < ANDROID_MIN || Android_version > ANDROID_MAX)
    {
        RLOGE("Android %d is not supported!!!", Android_version);
        goto error;
    }
    else
    {
        if(ANDROID_4 == Android_version)
        {
            s_callbacks.version = 9;
        }
        else if((ANDROID_5 == Android_version) || (ANDROID_6 == Android_version))
        {
            s_callbacks.version = 11;
        }
        else if((Android_version >= ANDROID_7) && (Android_version <= ANDROID_11))
        {
            s_callbacks.version = 12;
        }
        else
        {
            RLOGE("[%s,%d] Unknown Android version:%d", __FUNCTION__, __LINE__, Android_version);
            goto error;
        }
    }

    return s_callbacks.version;

error:
    s_callbacks.version = 6;
    return s_callbacks.version;
}

const RIL_RadioFunctions *RIL_Init(const struct RIL_Env *env,int argc, char **argv)
{
    int ret = 0;
    int opt;
    char dialmodesetbybuildprop[PROPERTY_VALUE_MAX] ={0};
    pthread_attr_t attr;
    s_rilenv = env;
    RLOGD("******** Enter RIL_Init() ********");
    char *cmd = NULL;

    asprintf(&cmd, "setenforce 0");
    RLOGD("%s",cmd);
    system(cmd); 
    free(cmd);

    RLOGD("RIL_VERSION:%d", getRIL_VERSION());
    RLOGD("FIBOCOM VERSION: %s",getVersion());
    RLOGD("%s",getKernelVersion());

    memset(&s_usbPortDevice,0,sizeof(USBPortDevice));
    do
    {
        sleep(1);
        ret = getUsbPortInfo(&s_usbPortDevice);
        if(ret){
            RLOGD("please check usb port state,RIL do not detech the usb devices");
        }
    }while(ret);

    s_device_path = s_usbPortDevice.atchannel;
    RLOGD("fibocom get atchannel = %s", s_device_path);
    s_diag_device_path = s_usbPortDevice.diagchannel;
    RLOGD("fibocom get diagchannel = %s", s_diag_device_path);
#ifdef HAVE_DATA_DEVICE
    if (dialmode==0)
    {
        s_data_device_path = s_usbPortDevice.datachannel;
        property_set("ril.datachannel", s_usbPortDevice.datachannel);
        RLOGD("fibocom get datachannel = %s", s_data_device_path);
    }
#endif

#ifdef ODM_DEVMODE
    dialmode = ODM_DEVMODE;
#endif
    while ( -1 != (opt = getopt(argc, argv, "p:d:s:c:w:"))) {
        switch (opt) {
            case 'w':
                dialmode = atoi(optarg);
                if (dialmode > 2) {
                    usage(argv[0]);
                    return NULL;
                }
            break;
            default:
                break;
        }
    }

    ret = 0; 
    ret = property_get("ril.fibocom.dialmode", dialmodesetbybuildprop, ""); 
    if(ret > 0) 
    {    
         if ( atoi(dialmodesetbybuildprop)>=0 && atoi(dialmodesetbybuildprop) <=3 )
         {    
            dialmode = atoi(dialmodesetbybuildprop);
         }    
         else{
            RLOGD("setting dialmode error :  ril.fibocom.dialmode=0 or 1 or 2 \n");
         }    
    }
    RLOGD("Opening dialmode %d\n", dialmode);

    if (s_port < 0 && s_device_path == NULL)
    {
        usage(argv[0]);
        return NULL;
    }

#ifdef HAVE_DATA_DEVICE
    if ((!dialmode) && (s_data_device_path == NULL))
    {
        usage(argv[0]);
        return NULL;
    }
#endif
    pthread_attr_init (&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    ret = pthread_create(&s_tid_mainloop, &attr, mainLoop, NULL);

    if(getProfileBool("PING", "PINGWDT", 0))
    {
        ret = pthread_create(&s_tid_pingloop, &attr, pingLoop, NULL);
    }
    else
    {
        RLOGD("The PINGWDT thread is not currently enabled!");
    }

    return &s_callbacks;
}
#else /* RIL_SHLIB */
int main (int argc, char **argv)
{
    int ret;
    int fd = -1;
    int opt;
    RLOGD("it's enterring main,so RIL_SHLIB is not defined");
    RLOGD("******** Enter main() ********");
    while ( -1 != (opt = getopt(argc, argv, "p:d:")))
    {
        switch (opt)
        {
            case 'p':
                s_port = atoi(optarg);
                if (s_port == 0)
                {
                    usage(argv[0]);
                }
                RLOGD("Opening loopback port %d\n", s_port);
                break;

            case 'd':
                s_device_path = optarg;
                RLOGD("Opening tty device %s\n", s_device_path);
                break;
#ifdef HAVE_DATA_DEVICE
            case 'u':
                s_data_device_path = optarg;
                RLOGD("Opening tty device %s\n", s_data_device_path);
                break;
#endif
            case 's':
                s_device_path   = optarg;
                s_device_socket = 1;
                RLOGD("Opening socket %s\n", s_device_path);
                break;
            default:
                usage(argv[0]);
        }
    }

    if (s_port < 0 && s_device_path == NULL)
    {
        usage(argv[0]);
    }

    RIL_register(&s_callbacks);
    mainLoop(NULL);

    return 0;
}

#endif /* RIL_SHLIB */

int g_fd_port = -1;
int serial_connect(const char *str_port)
{
        struct termios newtio;

        if(!str_port)
        {
                RLOGD("invalid parameter!");
                return -1;
        }

        RLOGD("port[%s] connecting...", str_port);

        g_fd_port = open (str_port, O_RDWR);
        if(g_fd_port < 0)
        {
                RLOGD("port[%s] open failed! errno[%d]", str_port, errno);
                goto error_exit;
        }

        if(tcgetattr(g_fd_port, &newtio) != 0)
        {
                RLOGD("port[%s] tcgetattr failed! errno[%d]", str_port, errno);
                goto error_exit;
        }

        cfmakeraw(&newtio);

        /*set baudrate*/
        cfsetispeed(&newtio, B4000000);
        cfsetospeed(&newtio, B4000000);

        /*set char bit size*/
        newtio.c_cflag &= ~CSIZE;
        newtio.c_cflag |= CS8;

        /*set check sum*/
        newtio.c_cflag &= ~PARENB;

        /*set stop bit*/
        newtio.c_cflag &= ~CSTOPB;
        newtio.c_cflag |= CLOCAL |CREAD;
        newtio.c_cflag &= ~(PARENB | PARODD);

        newtio.c_iflag &= ~(INPCK | BRKINT |PARMRK | ISTRIP | INLCR | IGNCR | ICRNL);
        newtio.c_iflag |= IGNBRK;
        newtio.c_iflag &= ~(IXON|IXOFF|IXANY);

        newtio.c_oflag = 0;

        newtio.c_lflag = 0;

        /*set wait time*/
        newtio.c_cc[VMIN] = 0;
        newtio.c_cc[VTIME] = 0;

        tcflush(g_fd_port, TCIFLUSH);
        tcflush(g_fd_port, TCOFLUSH);

        if(tcsetattr(g_fd_port, TCSANOW, &newtio) !=0 )
        {
                RLOGD("port[%s] tcsetattr failed! errno[%d]", str_port, errno);
                goto error_exit;
        }

        RLOGD("port[%s] connected!", str_port);

        return 0;

error_exit:

        if(g_fd_port >= 0)
        {
                close(g_fd_port);
                g_fd_port = -1;
        }

        return -1;
}

int serial_disconnect()
{
        if(g_fd_port >= 0)
        {
                close(g_fd_port);
                g_fd_port = -1;
        }

        return 0;
}

unsigned long serial_read(unsigned char *p_in_buffer, unsigned long in_buffer_size, unsigned long *p_bytes_read)
{
        int read_len = 0;

        if(g_fd_port < 0)
        {
                RLOGD("please open port first!");
                return 0;
        }

        if(!p_in_buffer || in_buffer_size <= 0)
                return 0;

        read_len = read(g_fd_port, p_in_buffer, in_buffer_size);
        if(read_len < 0)
        {
                RLOGD("read com port error :%d,  errno[%d]", read_len, errno);
                read_len = 0;
        }

        if(p_bytes_read)
                *p_bytes_read = read_len;

        return read_len;
}

unsigned long serial_write_hexstring(const char *str_in_buffer)
{
        unsigned long write_cnt = 0;
        unsigned long str_len = 0;
        char ch_high, ch_low;
        unsigned char *buffer_to_write = NULL;
        unsigned long cb_wrote = 0;
        unsigned long i;

        if(g_fd_port < 0)
        {
                RLOGD("please open port first!");
                return 0;
        }

        str_len = (unsigned long)strlen(str_in_buffer);

        if(!str_in_buffer || str_len <= 0)
                goto error_exit;

        buffer_to_write = (unsigned char *)malloc(str_len);
        if(!buffer_to_write)
        {
                RLOGD("malloc %lu bytes failed! errno[%d]", str_len, errno);
                goto error_exit;
        }

        while(*str_in_buffer != '\0' && (*str_in_buffer + 1) != '\0')
        {
                ch_high = tolower(*str_in_buffer);
                ch_low = tolower(*(str_in_buffer + 1));
                if ((('0' <= ch_high && '9' >= ch_high) || ('a' <= ch_high && 'f' >= ch_high)) && 
                                (('0' <= ch_low && '9' >= ch_low) || ('a' <= ch_low && 'f' >= ch_low)))
                {
                        if ('0' <= ch_high && '9' >= ch_high)
                        {
                                buffer_to_write[write_cnt] = (ch_high - '0') << 4;
                        }
                        else
                        {
                                buffer_to_write[write_cnt] = (0x0a + ch_high - 'a') << 4;
                        }

                        if ('0' <= ch_low && '9' >= ch_low)
                        {
                                buffer_to_write[write_cnt] |= (ch_low - '0');
                        }
                        else
                        {
                                buffer_to_write[write_cnt] |= (0x0a + ch_low - 'a');
                        }
                        write_cnt++;
                        str_in_buffer += 2;
                }
                else
                        str_in_buffer++;
        }

        if(write_cnt <= 0)
                goto error_exit;

	 for(i=0;i<write_cnt;i++)
	 {
	      RLOGD("serial_write_hexstring:buffer_to_write[%lu]=0x%x", i, buffer_to_write[i]);
	 }

        /*just write data to device*/
        cb_wrote = write(g_fd_port, buffer_to_write, write_cnt);
        if(cb_wrote <= 0)
        {
                RLOGD("port[0x%x] write error! errno[%d]", g_fd_port, errno);
                goto error_exit;
        }

        if(buffer_to_write)
                free(buffer_to_write);

        return cb_wrote;

error_exit:

        if(buffer_to_write)
                free(buffer_to_write);

        return 0;
}

// <!--[ODM]wangmengying@2019.8.16 [SN-20190608001]Customized AT commands
void initReserveAtCommand()
{
    RLOGD("Enter --- [%s,%d]",__FUNCTION__,__LINE__);

    char reserve_at_commad_1[PROPERTY_VALUE_MAX]={0};
    char reserve_at_commad_2[PROPERTY_VALUE_MAX]={0};
    char reserve_at_commad_3[PROPERTY_VALUE_MAX]={0};

    property_get("ril.reserve.cmd1",reserve_at_commad_1,"");
    property_get("ril.reserve.cmd2",reserve_at_commad_2,"");
    property_get("ril.reserve.cmd3",reserve_at_commad_3,"");

    RLOGD("initReserveAtCommand reserve_at_commad_1=%s,reserve_at_commad_2=%s,reserve_at_commad_3=%s",
            reserve_at_commad_1,reserve_at_commad_2,reserve_at_commad_3);

    if( 0 != strcmp(reserve_at_commad_1, ""))
    {
        at_send_command(reserve_at_commad_1, NULL);
    }

    if( 0 != strcmp(reserve_at_commad_2, ""))
    {
        at_send_command(reserve_at_commad_2, NULL);
    }

    if( 0 != strcmp(reserve_at_commad_3, ""))
    {
        at_send_command(reserve_at_commad_3, NULL);
    }

    RLOGD("Leave --- [%s,%d]",__FUNCTION__,__LINE__);
}
// end-->

int qualcomm_diag_reset()
{
        char *p_config_rsp_line = NULL;
        int b_rsp_ok,try_read,i,rsp_len;
        char str_port_name[128] = {0};

        p_config_rsp_line = (char *)malloc(1024);

        strcpy(str_port_name,s_diag_device_path);

        if(!p_config_rsp_line)
        {
                RLOGD("malloc (%d) bytes buffer for response package line failed! errno[%d]", 1024, errno);
                goto error_exit;
        }
		
        if(serial_connect(str_port_name) <0)
        {
                goto error_exit;
        }

        if(!serial_write_hexstring("29 01 00 31 40 7e"))
                goto error_exit;

        b_rsp_ok = 0;
        try_read = 500;
	  RLOGD("qualcomm_diag_reset:off line respose: ");
        do
        {
                rsp_len = serial_read((unsigned char *)p_config_rsp_line, 1024, NULL);
                if(rsp_len >= 0)
                {
                        for(i = 0; i < rsp_len; i++)
                        {
                                RLOGD("%02x ", p_config_rsp_line[i]);
                                if(p_config_rsp_line[i] == 0x7e)
                                        b_rsp_ok = 1;
                        }
                }
                else
                {
                        usleep(ATSEND_TIMEOUT_MSEC);
                }
        }while(!b_rsp_ok && try_read--);

	  usleep(500000);

        if(!serial_write_hexstring("29 02 00 59 6a 7e"))
                goto error_exit;

        b_rsp_ok = 0;
        try_read = 500;
	  RLOGD("qualcomm_diag_reset:respose: ");
        do
        {
                rsp_len = serial_read((unsigned char *)p_config_rsp_line, 1024, NULL);
                if(rsp_len >= 0)
                {
                        for(i = 0; i < rsp_len; i++)
                        {
                                RLOGD("%02x ", p_config_rsp_line[i]);
                                if(p_config_rsp_line[i] == 0x7e)
                                        b_rsp_ok = 1;
                        }
                }
                else
                {
                        usleep(ATSEND_TIMEOUT_MSEC);
                }
        }while(!b_rsp_ok && try_read--);


        serial_disconnect();

        return 1;

error_exit:

        RLOGD("Log stop error.");

        serial_disconnect();

        return 0;
}

