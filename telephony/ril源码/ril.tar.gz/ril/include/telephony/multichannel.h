/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /* ISSUES:
 * - SMS retransmit (specifying TP-Message-ID)
 *
 */

/**
 * TODO
 *
 * Supp Service Notification (+CSSN)
 * GPRS PDP context deactivate notification
 *
 */


#ifndef ANDROID_RIL_MULTI_CHANNEL_H
#define ANDROID_RIL_MULTI_CHANNEL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <pthread.h>
#include "../leadcore-ril/atchannel.h"


/*the count numbers of channel */
#define RIL_DEVICE_MAX_COUNT        (1)

/*rild 0*/
#define DEV_CHANNEL1       "5566"
#define DEV_CHANNEL2       "5566"
#define DEV_CHANNEL3       "5566"
#define DEV_CHANNEL4       "5566"
#define DEV_CHANNEL5       "5566"
#define DEV_CHANNEL6       "5566"
#define DEV_CHANNEL7       "5566"
#define DEV_CHANNEL8       "5566"

/*
#define DEV_CHANNEL2        "/dev/TTYEMS03"
#define DEV_CHANNEL3        "/dev/TTYEMS10"
#define DEV_CHANNEL4        "/dev/TTYEMS11"
#define DEV_CHANNEL5        "/dev/TTYEMS16"
#define DEV_CHANNEL6        "/dev/TTYEMS26"
#define DEV_CHANNEL7        "/dev/TTYEMS30"
#define DEV_CHANNEL8        "/dev/TTYEMS31"
//#define DEV_CHANNEL9        "/dev/TTYEMS33"
//#define DEV_CHANNEL10       "/dev/TTYEMS34"*/


/*rild 1*/
#define DEV_CHANNEL9        "5588"
#define DEV_CHANNEL10       "5588"
#define DEV_CHANNEL11       "5588"
#define DEV_CHANNEL12       "5588"
#define DEV_CHANNEL13       "5588"
#define DEV_CHANNEL14       "5588"
#define DEV_CHANNEL15       "5588"
#define DEV_CHANNEL16       "5588"

/*#define DEV_CHANNEL9        "/dev/TTYEMS35"
#define DEV_CHANNEL10       "/dev/TTYEMS17"
#define DEV_CHANNEL11       "/dev/TTYEMS18"
#define DEV_CHANNEL12       "/dev/TTYEMS23"
#define DEV_CHANNEL13       "/dev/TTYEMS24"
#define DEV_CHANNEL14       "/dev/TTYEMS25"
#define DEV_CHANNEL15       "/dev/TTYEMS33"
#define DEV_CHANNEL16       "/dev/TTYEMS34"
//#define DEV_CHANNEL19       "/dev/TTYEMS38"
//#define DEV_CHANNEL20       "/dev/TTYEMS39"*/

#define RILD0_FIRST_DEV_CHANNEL     DEV_CHANNEL1
#define RILD1_FIRST_DEV_CHANNEL     DEV_CHANNEL9

typedef struct {

    int m_type;

    const char *m_responsePrefix;

    const char *m_smsPDU;

    ATResponse *mp_response;

    int m_fd;

    const char *m_at_ch_name;

    pthread_t m_thread_id;

} Ril_requestAtSender;

#ifdef __cplusplus
}
#endif

#endif /*ANDROID_RIL_MULTI_CHANNEL_H*/
