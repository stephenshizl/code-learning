/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : ata-tok.c
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#define ATA_TOK_C



/*---------------------------- include head file -----------------------------*/

#include "pub-sys.h"
#include "pub-err.h"
#include "pub-log.h"

//#include "main.h"
#include "ata-tok.h"



/*---------------------- external variable declaration -----------------------*/



/*----------------- external function prototype declaration ------------------*/



/*----------------------- file-local macro definition ------------------------*/



/*----------------- file-local constant and type definition ------------------*/



/*---------------- file-local function prototype declaration -----------------*/

static SINT8 is_start_with(const char *str_ptr, const char *prefix_ptr);

static void skip_white_space(char **p_cur);

static SINT32 parse_string( SINT8 **string_ptr, SINT8 *output_ptr, UINT16 max_string_len );
static SINT32 parse_data( SINT8 **string_ptr, UINT32 max_output_len, UINT8 *output_ptr, UINT32 *real_output_len_ptr );
static SINT32 parse_hex( SINT8 **string_ptr, UINT32 *output_ptr, UINT16 max_char_num );
static SINT32 parse_hex_data( SINT8 **string_ptr, UINT32 max_output_len, UINT8 *output_ptr, UINT32 *real_output_len_ptr );
static SINT32 parse_uint8( SINT8 **string_ptr, UINT8 *output_ptr );
static SINT32 parse_uint16( SINT8 **string_ptr, UINT16 *output_ptr );
static SINT32 parse_uint32( SINT8 **string_ptr, UINT32 *output_ptr );
static SINT32 parse_sint8( SINT8 **string_ptr, SINT8 *output_ptr );
static SINT32 parse_sint16( SINT8 **string_ptr, SINT16 *output_ptr );
static SINT32 parse_omit( SINT8 **string_ptr );



/*--------------------- file-local variables definition ----------------------*/



/*--------------------------- function definition ----------------------------*/

/*******************************************************************************
 * Function: is_start_with
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Check if the string starts with prefix.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type           In/Out    Description
 *     ------------  -------------  --------  ---------------------------------
 *     str_ptr       const char *   In        string to check
 *     prefix_ptr    const char *   In        prefix string
 *
 * Return:
 * ----------------------------
 *     0: the string does not start with the prefix;
 *     1: the string starts with the prefix;
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static SINT8 is_start_with(const char *str_ptr, const char *prefix_ptr)
{
    for( ; *str_ptr != '\0' && *prefix_ptr != '\0'; str_ptr++, prefix_ptr++ )
    {
        if( *str_ptr != *prefix_ptr )
        {
            return 0;
        }
    }

    return *prefix_ptr == '\0';
}

/*******************************************************************************
 * Function: skip_white_space
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Jump over all the space char: ' '.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     p_cur              char **       In/Out        data to check
 *
 * Return:
 * ----------------------------
 *     (none)
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static void skip_white_space(char **p_cur)
{
    if( !p_cur || !(*p_cur))
        return;

    /* Warning: don't use isspace() since char '\r' is meaningful for us. */
//    while( **p_cur != '\0' && isspace(**p_cur) )
    while( ' ' == **p_cur )
    {
        (*p_cur)++;
    }
}

/*******************************************************************************
 * Function: parse_string
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "string".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         SINT8 *       Out           parsed data
 *     max_string_len     UINT16        In            max length
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_string( SINT8 **string_ptr, SINT8 *output_ptr, UINT16 max_string_len )
{
    UINT16 i;
    SINT8 *input_ptr;

    input_ptr=*string_ptr;

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr || 0 == max_string_len )
    {
        return ERR_NONE;
    }

    /* the first quotation means the beginning of the string type parameter */
    if ( '\"' != *input_ptr )
    {
        return ERR_INVALID_PARAM;
    }

    input_ptr=input_ptr+1;

    for( i=0; i<(max_string_len+1); i++ )
    {
        /* the second quotation means the end of the string type parameter */
        if ( '\"' == *input_ptr
                && ( ',' == *( input_ptr+1 ) || '\r' == *( input_ptr+1 ) || '\0' == *( input_ptr+1 ) ) )
        {
            *output_ptr='\0';
            *string_ptr=input_ptr+1;
            return ERR_NONE;
        }

        if( i < max_string_len )
        {
            *output_ptr++ = *input_ptr++;
        }
        else
        {
            LOG_WARNING( ("string data is larger than max length") );
            return ERR_INVALID_PARAM_VALUE;
        }
    }

    /*
     * If this point is reached, then the string length exceeds
     * the max allowed length, we should consider the parameter
     * is not valid
     */
    return ERR_INVALID_PARAM_VALUE;
}

/*******************************************************************************
 * Function: parse_data
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "data".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name                 Type        In/Out      Description
 *     -------------------  ----------  ----------  ----------------------------
 *     string_ptr           SINT8 **    In          data to parse
 *     max_output_len       UINT32      In          max length of the output buffer
 *     output_ptr           UINT8 *     Out         parsed data
 *     real_output_len_ptr  UINT32      Out         length of the data that parsed
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_data( SINT8 **string_ptr, UINT32 max_output_len, UINT8 *output_ptr, UINT32 *real_output_len_ptr )
{
    SINT8   *input_ptr = NULL;
    SINT8   *end_ptr = NULL;
    UINT32  data_len = 0;

    if( !string_ptr || !(*string_ptr)
        || !output_ptr || !real_output_len_ptr )
    {
        LOG_ERR(ERR_INVALID_PARAM);
        return ERR_INVALID_PARAM;
    }

    *real_output_len_ptr = 0;

    input_ptr = *string_ptr;

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    end_ptr = ( SINT8 * )strchr(( CHAR * )input_ptr, ',' );
    if ( NULLPTR == end_ptr )
    {
        end_ptr = ( SINT8 * )strchr(( CHAR * )input_ptr, '\r' );
    }

    /*If the comma mark is not found, then all the input string is parameter*/

    if ( NULLPTR == end_ptr )
    {
        data_len = strlen(( CHAR * )input_ptr );
    }
    else
    {
        data_len = end_ptr - input_ptr;
    }

    *string_ptr = input_ptr + data_len;

    /* If the length exceed the max allowed length of the parameter,
     * the parse fails, the parameter is invalid */

    if ( data_len > max_output_len )
    {
        return ERR_INVALID_PARAM_VALUE;
    }
    else
    {
        memcpy( output_ptr,input_ptr,data_len );
        *real_output_len_ptr = data_len;
        return ERR_NONE;
    }
}

/*******************************************************************************
 * Function: parse_hex
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "hex".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         UINT32 *      Out           parsed data
 *     max_char_num       UINT16        In            max length
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_hex( SINT8 **string_ptr, UINT32 *output_ptr, UINT16 max_char_num )
{
    UINT32 output;
    SINT8 *input_ptr;


    /*HEX parameter is limited to 8 bytes*/

    if ( max_char_num>8 )
    {
        return ERR_INVALID_PARAM;
    }

    /*Get the string point*/
    input_ptr=*string_ptr;

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    output=0;

    while (( 0!=max_char_num )&&( '\0'!=*input_ptr )&&( ','!=*input_ptr )&&( '\r'!=*input_ptr ) )
    {
        output=output*16;

        if ( *input_ptr>='0' && *input_ptr<='9' )
        {
            output=output + *input_ptr - '0';
        }
        else if ( *input_ptr>='a' && *input_ptr<='f' )
        {
            output=output + *input_ptr - 'a' + 10;
        }
        else if ( *input_ptr>='A' && *input_ptr<='F' )
        {
            output=output + *input_ptr - 'A' + 10;
        }
        else
        {
            /*If the character is not a hex character, then we consider
             *the hex parameter is ended, and we should revise the
             *output to the original value*/
            output = output/16;
            return ERR_INVALID_PARAM_VALUE;
            /*            break;*/
        }

        input_ptr = input_ptr+1;

        max_char_num = max_char_num-1;
    }

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;

    *output_ptr = output;

    return ERR_NONE;
}

/*******************************************************************************
 * Function: parse_hex_data
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "hex data".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name                 Type        In/Out      Description
 *     -------------------  ----------  ----------  ----------------------------
 *     string_ptr           SINT8 **    In          data to parse
 *     max_output_len       UINT32      In          max length of the output buffer
 *     output_ptr           UINT8 *     Out         parsed data
 *     real_output_len_ptr  UINT32      Out         length of the data that parsed
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_hex_data( SINT8 **string_ptr, UINT32 max_output_len, UINT8 *output_ptr, UINT32 *real_output_len_ptr )
{
    SINT8   *input_ptr = NULL;
    SINT8   *end_ptr = NULL;
    UINT32  data_len = 0;
    UINT32  i = 0;

    if( !string_ptr || !(*string_ptr)
        || !output_ptr || !real_output_len_ptr )
    {
        LOG_ERR(ERR_INVALID_PARAM);
        return ERR_INVALID_PARAM;
    }

    *real_output_len_ptr = 0;

    input_ptr = *string_ptr;

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    end_ptr = ( SINT8 * )strchr(( CHAR * )input_ptr, ',' );
    if ( NULLPTR == end_ptr )
    {
        end_ptr = ( SINT8 * )strchr(( CHAR * )input_ptr, '\r' );
    }

    if ( NULLPTR == end_ptr )
    {
        /* If the comma mark is not found, then all the input string is parameter. */
        data_len = strlen(( CHAR * )input_ptr );
    }
    else
    {
        data_len = end_ptr - input_ptr;
    }

    /* If the length exceed the max allowed length of the parameter, the parse
     * fails, the parameter is invalid */
    if( (data_len % 2) != 0
        || (data_len / 2) > max_output_len )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    for( i=0; i<data_len/2; i++ )
    {
        if( '0' <= input_ptr[i*2] && input_ptr[i*2] <= '9' )
            output_ptr[i] = (input_ptr[i*2] - '0') * 16;
        else if( 'a' <= input_ptr[i*2] && input_ptr[i*2] <= 'f' )
            output_ptr[i] = (input_ptr[i*2] - 'a' + 10) * 16;
        else if( 'A' <= input_ptr[i*2] && input_ptr[i*2] <= 'F' )
            output_ptr[i] = (input_ptr[i*2] - 'A' + 10) * 16;
        else
        {
            LOG_ERR_EXT( ERR_INVALID_PARAM_VALUE, ("invalid hex char: %02x", input_ptr[i*2]) );
            return ERR_INVALID_PARAM_VALUE;
        }

        if( '0' <= input_ptr[i*2+1] && input_ptr[i*2+1] <= '9' )
            output_ptr[i] += (input_ptr[i*2+1] - '0');
        else if( 'a' <= input_ptr[i*2+1] && input_ptr[i*2+1] <= 'f' )
            output_ptr[i] += (input_ptr[i*2+1] - 'a' + 10);
        else if( 'A' <= input_ptr[i*2+1] && input_ptr[i*2+1] <= 'F' )
            output_ptr[i] += (input_ptr[i*2+1] - 'A' + 10);
        else
        {
            LOG_ERR_EXT( ERR_INVALID_PARAM_VALUE, ("invalid hex char: %02x", input_ptr[i*2+1]) );
            return ERR_INVALID_PARAM_VALUE;
        }
    }
    *real_output_len_ptr = data_len / 2;

    *string_ptr = input_ptr + data_len;

    return ERR_NONE;
}

/*******************************************************************************
 * Function: parse_uint8
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "UINT8".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         UINT8 *       Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_uint8( SINT8 **string_ptr, UINT8 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while (( isdigit( *input_ptr ) ) && ( output <=0xff ) )
    {
        output= output*10;
        output = output + *input_ptr - '0';
        input_ptr=input_ptr+1;
    }

    /*
     *  if the number exceed 255, then it is not a UINT8 type parameter,
     *  so we consider the parameter is wrong
     */
    if ( output>0xff )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    *output_ptr=( UINT8 )output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/*******************************************************************************
 * Function: parse_uint16
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "UINT16".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         UINT16 *      Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_uint16( SINT8 **string_ptr, UINT16 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while (( isdigit( *input_ptr ) ) && ( output <=0xffff ) )
    {
        output= output*10;
        output = output + *input_ptr - '0';
        input_ptr=input_ptr+1;
    }

    /*
     *  if the number exceed 0xffff, then it is not a UINT16 type parameter,
     *  so we consider the parameter is wrong
     */
    if ( output>0xffff )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    *output_ptr=( UINT16 )output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/*******************************************************************************
 * Function: parse_uint32
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "UINT32".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         UINT32 *      Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_uint32( SINT8 **string_ptr, UINT32 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while ( isdigit( *input_ptr ) )
    {
        if ( output <=429496729 )
        {
            if ( output==429496729 )
            {
                if ( *input_ptr - '0'>5 )
                {
                    return ERR_INVALID_PARAM_VALUE;
                }
            }

            output= output*10;

            output = output + *input_ptr - '0';
            input_ptr=input_ptr+1;
        }
        else /*exceed 0xffffffff*/
        {
            return ERR_INVALID_PARAM_VALUE;
        }
    }

    *output_ptr=output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/*******************************************************************************
 * Function: parse_sint8
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "SINT8".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         SINT8 *       Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_sint8( SINT8 **string_ptr, SINT8 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while (( isdigit( *input_ptr ) ) && ( output <=0x7f ) )
    {
        output= output*10;
        output = output + *input_ptr - '0';
        input_ptr=input_ptr+1;
    }

    /*
     *  if the number exceed 0x7f, then it is not a SINT8 type parameter,
     *  so we consider the parameter is wrong
     */
    if ( output>0x7f )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    *output_ptr=( SINT8 )output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/*******************************************************************************
 * Function: parse_sint16
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse a data of type "SINT16".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         SINT16 *      Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_sint16( SINT8 **string_ptr, SINT16 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while (( isdigit( *input_ptr ) ) && ( output <=0x7fff ) )
    {
        output= output*10;
        output = output + *input_ptr - '0';
        input_ptr=input_ptr+1;
    }

    /*
     *  if the number exceed 0x7f, then it is not a SINT16 type parameter,
     *  so we consider the parameter is wrong
     */
    if ( output>0x7fff )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    *output_ptr=( SINT16 )output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/*******************************************************************************
 * Function: parse_omit
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Omit a parameter.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
static SINT32 parse_omit( SINT8 **string_ptr )
{
    SINT8 *input_ptr;

    input_ptr=*string_ptr;

    /*If parameter is ommited, then the input parameter should not be modified*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while ( *input_ptr != '\0' && *input_ptr != '\r' && *input_ptr != ',' )
    {
        input_ptr=input_ptr+1;
    }

    *string_ptr=input_ptr;
    return ERR_NONE;
}
#if 0
/*******************************************************************************
 * Function: at_tok_req_end_str
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Return the suffix string of a request AT.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     (none)
 *
 * Return:
 * ----------------------------
 *     the suffix string of a request AT.
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
char *at_tok_req_end_str( void )
{
    return "\r";
}
#endif
/*******************************************************************************
 * Function: at_tok_rsp_begin_str
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Return the prefix string of a response AT.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     (none)
 *
 * Return:
 * ----------------------------
 *     the prefix string of a response AT
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
char *at_tok_rsp_begin_str( void )
{
    return "\r\n";
}

/*******************************************************************************
 * Function: at_tok_rsp_end_str
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Return the suffix string of a response AT.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     (none)
 *
 * Return:
 * ----------------------------
 *     the suffix string of a response AT
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
char *at_tok_rsp_end_str( void )
{
    return "\r\n";
}

/*******************************************************************************
 * Function: at_tok_rsp_ok_str
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Return the "OK" response AT.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     (none)
 *
 * Return:
 * ----------------------------
 *     the "OK" response AT
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
char *at_tok_rsp_ok_str( void )
{
    return "\r\nOK\r\n";
}

/*******************************************************************************
 * Function: at_tok_get_a_cmd_line
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the AT command line and try to find the header and tailer.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     buf_ptr            char *        In            AT buffer
 *     buf_len            UINT32        In            length of AT buffer
 *     begin_ptr          char **       Out           begin of the AT
 *     end_ptr            char **       Out           end of the AT
 *     is_first           SINT8         In            if it is the first AT of the command line
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
SINT32 at_tok_get_a_cmd_line( char *buf_ptr, UINT32 buf_len, char **begin_ptr, char **end_ptr, SINT8 is_first )
{
    SINT32  ret_val = ERR_NOT_FOUND;

    LOG_FUNC();

    if( !buf_ptr
        || buf_len == 0
        || !begin_ptr
        || !end_ptr )
    {
        /* Error: invalid parameter. */
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    *begin_ptr = *end_ptr = NULL;

    if( is_first )
    {
        *begin_ptr = strstr((char *)buf_ptr, "AT" );
        if( *begin_ptr )
        {
            (*begin_ptr) += 2;
        }
        else
        {
            *begin_ptr = strstr((char *)buf_ptr, "at" );
            if( *begin_ptr )
            {
                (*begin_ptr) += 2;
            }
        }
    }
    else
    {
        *begin_ptr = buf_ptr;
    }

    if( *begin_ptr )
    {
        int is_dial = 0;
        skip_white_space(begin_ptr);
        *end_ptr = *begin_ptr;

        if( 'd' == **begin_ptr || 'D' == **begin_ptr )
        {
            is_dial = 1;
        }

        while( **end_ptr )
        {
            if( '"' == **end_ptr )
            {
                (*end_ptr)++;
                while( **end_ptr && **end_ptr != '"' ) (*end_ptr)++;
                if( '"' == **end_ptr )
                    (*end_ptr)++;
                else
                    break;
            }
            else if( '\r' == **end_ptr )
                break;
            else if( ';' == **end_ptr && !is_dial )
                break;
            else
                (*end_ptr)++;
        }

        if( '\r' == **end_ptr || (';' == **end_ptr && !is_dial) )
        {
            ret_val = ERR_NONE;
        }
    }

    if( ret_val != ERR_NONE )
    {
        LOG_WARNING( ("Not found a whole command line") );

        /* Note: we'd better not reset the pointer here. */
//        *begin_ptr = *end_ptr = NULL;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: at_tok_get_a_rsp_line
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the AT response line and try to find the header and tailer.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     buf_ptr            char *        In            AT buffer
 *     buf_len            UINT32        In            length of AT buffer
 *     begin_ptr          char **       Out           begin of the AT
 *     end_ptr            char **       Out           end of the AT
 *     len_ptr            UINT32 *      Out           length of the begin_ptr -> end_ptr
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
SINT32 at_tok_get_a_rsp_line( char *buf_ptr, UINT32 buf_len, char **begin_ptr, char **end_ptr, UINT32 *len_ptr )
{
    SINT32  ret_val = ERR_NOT_FOUND;

//    LOG_FUNC();

    if( !buf_ptr
        || buf_len == 0
        || !begin_ptr
        || !end_ptr
        || !len_ptr )
    {
        /* Error: invalid parameter. */
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    *begin_ptr = *end_ptr = NULL;
    *len_ptr = 0;

    *begin_ptr = strstr((char *)buf_ptr, "\r\n" );
    if( *begin_ptr )
    {
        if(buf_len == 2)
        {
             LOG_WARNING( ("response is only <CR><LF>") );
             return ret_val;
	}
        *end_ptr = *begin_ptr + 2;
        while( **end_ptr & ((UINT32)(*end_ptr - buf_ptr) < buf_len))
        {
            if( '"' == **end_ptr )
            {
                (*end_ptr)++;
                while( **end_ptr && **end_ptr != '"' ) (*end_ptr)++;
                if( '"' == **end_ptr )
                    (*end_ptr)++;
                else
                    break;
               
                if((UINT32)(*end_ptr - buf_ptr) >= buf_len)
                {
                    LOG_WARNING( ("end_ptr over the buffer end!") );
		    break;
		}
            }
            else if( '\r' == **end_ptr && '\n' == *(*end_ptr + 1) )
            {
                (*end_ptr) += 2;
                *len_ptr = *end_ptr - *begin_ptr;
                ret_val = ERR_NONE;
                break;
            }
            else
            {
                (*end_ptr)++;
            }
        }
    }

    if( ret_val != ERR_NONE )
    {
        LOG_WARNING( ("Not found a whole response line") );

        /* Note: we'd better not reset the pointer here. */
//        *begin_ptr = *end_ptr = NULL;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: at_tok_parse
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the data according to the specified type.
 *     Type definition:
 *         'H' means type: "hex"
 *         'U' means type: "UINT8"
 *         'V' means type: "UINT16"
 *         'L' means type: "UINT32"
 *         'I' means type: "SINT8"
 *         'J' means type: "SINT16"
 *         'S' means type: "string"
 *         'D' means type: "data"
 *         'A' means type: "hex data"
 *         'O' means     : omit a parameter
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     type_ptr           char *        In            format
 *     varpars            va_list       Out           parsed data
 *
 * Return:
 * ----------------------------
 *     >= 0: parameters that parsed
 *     < 0: error
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
SINT32 at_tok_parse( SINT8 **string_ptr, const char *type_ptr, va_list varpars )
{
    SINT8   *input_ptr = NULL;
    UINT32  max_len = 0;
    SINT32  ret_val = ERR_NONE;
    SINT32  parsed_number = 0;

    LOG_FUNC();

    /* Check parameter. */
    if( !string_ptr || !*string_ptr || !type_ptr )
    {
        /* Error: invalid parameter. */
        LOG_ERR_EXT( ERR_INVALID_PARAM, ("%d, %d, %d", !string_ptr, !*string_ptr, !type_ptr) );
        return -1;
    }

    /* Get the point of the string*/
    input_ptr = *string_ptr;

    skip_white_space((char **)(&input_ptr));

    if ( '\0' == *input_ptr || '\r' == *input_ptr )
    {
        return parsed_number;
    }

    while ( '\0' != *type_ptr )
    {
        switch ( toupper( *type_ptr ) )
        {
            case( 'H' ):
            {
                /*
                 *  The parameter is hexadecimal type, the max length of hexadecimal
                 *  is limited to 8 bytes
                 */
                ret_val= parse_hex( &input_ptr, va_arg( varpars, UINT32* ), 8 );
            }
            break;

            case( 'U' ):
            {
                /* The parameter is a "UINT8" type */
                ret_val = parse_uint8( &input_ptr, va_arg( varpars, UINT8* ) );
            }
            break;

            case( 'V' ):
            {
                /* The parameter is a "UINT16" type */
                ret_val = parse_uint16( &input_ptr, va_arg( varpars, UINT16* ) );
            }
            break;

            case( 'L' ):
            {
                /* The parameter is a "UINT32" type */
                ret_val = parse_uint32( &input_ptr, va_arg( varpars, UINT32* ) );
            }
            break;

            case( 'I' ):
            {
                /* The parameter is a "SINT8" type */
                ret_val = parse_sint8( &input_ptr, va_arg( varpars, SINT8* ) );
            }
            break;

            case( 'J' ):
            {
                /* The parameter is a "SINT16" type */
                ret_val = parse_sint16( &input_ptr, va_arg( varpars, SINT16* ) );
            }
            break;

            case( 'S' ):
            {
                /* The parameter is a "String" type, the first parameter is the max length
                 * allowed of the string*/
                max_len = va_arg( varpars, UINT32 );
                ret_val = parse_string( &input_ptr, va_arg( varpars, SINT8* ),( UINT16 )max_len );
            }
            break;

            case( 'D' ):
            {
                UINT8   *data_ptr = NULL;
                UINT32  *len_ptr = NULL;

                max_len = va_arg( varpars, UINT32 );
                data_ptr = va_arg( varpars, UINT8* );
                len_ptr = va_arg( varpars, UINT32* );

                ret_val = parse_data( &input_ptr, max_len, data_ptr, len_ptr );
            }
            break;

            case( 'A' ):
            {
                UINT8   *data_ptr = NULL;
                UINT32  *len_ptr = NULL;

                max_len = va_arg( varpars, UINT32 );
                data_ptr = va_arg( varpars, UINT8* );
                len_ptr = va_arg( varpars, UINT32* );

                ret_val = parse_hex_data( &input_ptr, max_len, data_ptr, len_ptr );
            }
            break;

            case( 'O' ):
            {
                ret_val = parse_omit( &input_ptr );
            }
            break;

            default:
            {
                /* If the type is not supported, then we consider its a error  */
                ret_val = ERR_INVALID_PARAM;
            }
            break;
        }

        if( ERR_NONE == ret_val )
        {
            if( *type_ptr != 'O' )
            {
                parsed_number++;
            }
        }
        else
        {
            /*If some error is occured when parse a parameter, then we consider the parameter
             *of this command is not valid*/
            *string_ptr = input_ptr;
            LOG_ERR( ERR_INVALID_PARAM );
            return -1;
        }

        /* If no more parameters are existed, we should end it */
        if ( '\0' == *input_ptr || '\r' == *input_ptr )
        {
            *string_ptr =  input_ptr;

            LOG_INFO(("parsed parameter count: %d", parsed_number));

            return parsed_number;
        }

        /* If the next character is not ",", then it's a invalid parameter */
        if ( ',' != *input_ptr )
        {
            *string_ptr = input_ptr;
            LOG_ERR( ERR_INVALID_PARAM );
            return -1;
        }
        else
        {
            input_ptr=input_ptr+1;
        }

        /* If no more parameters are existed, we should end it */
        if ( '\0' == *input_ptr || '\r' == *input_ptr )
        {
            *string_ptr =  input_ptr;

            LOG_INFO(("parsed parameter count: %d", parsed_number));

            return parsed_number;
        }

        type_ptr++;

        skip_white_space((char **)(&input_ptr));
    }

    /*Bring out the point to first untreated character*/
    *string_ptr = input_ptr;

    LOG_INFO(("parsed parameter count: %d", parsed_number));

    return parsed_number;
}

/*******************************************************************************
 * Function: at_tok_parse_ext
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the data according to the specified type.
 *     Type definition:
 *         'H' means type: "hex"
 *         'U' means type: "UINT8"
 *         'V' means type: "UINT16"
 *         'L' means type: "UINT32"
 *         'I' means type: "SINT8"
 *         'J' means type: "SINT16"
 *         'S' means type: "string"
 *         'D' means type: "data"
 *         'A' means type: "hex data"
 *         'O' means     : omit a parameter
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     type_ptr           char *        In            format
 *     ...                              Out           parsed data
 *
 * Return:
 * ----------------------------
 *     >= 0: parameters that parsed
 *     < 0: error
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
SINT32 at_tok_parse_ext( SINT8 **string_ptr, char *type_ptr, ... )
{
    va_list varpars;
    SINT8   *input_ptr = NULL;
    UINT32  max_len = 0;
    SINT32  ret_val = ERR_NONE;
    SINT32  parsed_number = 0;

    LOG_FUNC();

    /* Check parameter. */
    if( !string_ptr || !*string_ptr
        || !type_ptr )
    {
        /* Error: invalid parameter. */
        LOG_ERR_EXT( ERR_INVALID_PARAM, ("%d, %d, %d", !string_ptr, !(*string_ptr), !type_ptr) );
        return -1;
    }

    va_start( varpars, type_ptr );

    /* Get the point of the string*/
    input_ptr = *string_ptr;

    skip_white_space((char **)(&input_ptr));

    if ( '\0' == *input_ptr || '\r' == *input_ptr )
    {
        va_end( varpars );
        return parsed_number;
    }

    while ( '\0' != *type_ptr )
    {
        switch ( toupper( *type_ptr ) )
        {
            case( 'H' ):
            {
                /*
                 *  The parameter is hexadecimal type, the max length of hexadecimal
                 *  is limited to 8 bytes
                 */
                ret_val= parse_hex( &input_ptr, va_arg( varpars, UINT32* ), 8 );
            }
            break;

            case( 'U' ):
            {
                /* The parameter is a "UINT8" type */
                ret_val = parse_uint8( &input_ptr, va_arg( varpars, UINT8* ) );
            }
            break;

            case( 'V' ):
            {
                /* The parameter is a "UINT16" type */
                ret_val = parse_uint16( &input_ptr, va_arg( varpars, UINT16* ) );
            }
            break;

            case( 'L' ):
            {
                /* The parameter is a "UINT32" type */
                ret_val = parse_uint32( &input_ptr, va_arg( varpars, UINT32* ) );
            }
            break;

            case( 'I' ):
            {
                /* The parameter is a "SINT8" type */
                ret_val = parse_sint8( &input_ptr, va_arg( varpars, SINT8* ) );
            }
            break;

            case( 'J' ):
            {
                /* The parameter is a "SINT16" type */
                ret_val = parse_sint16( &input_ptr, va_arg( varpars, SINT16* ) );
            }
            break;

            case( 'S' ):
            {
                /* The parameter is a "String" type, the first parameter is the max length
                 * allowed of the string*/
                max_len = va_arg( varpars, UINT32 );
                ret_val = parse_string( &input_ptr, va_arg( varpars, SINT8* ),( UINT16 )max_len );
            }
            break;

            case( 'D' ):
            {
                UINT8   *data_ptr = NULL;
                UINT32  *len_ptr = NULL;

                max_len = va_arg( varpars, UINT32 );
                data_ptr = va_arg( varpars, UINT8* );
                len_ptr = va_arg( varpars, UINT32* );

                ret_val = parse_data( &input_ptr, max_len, data_ptr, len_ptr );
            }
            break;

            case( 'A' ):
            {
                UINT8   *data_ptr = NULL;
                UINT32  *len_ptr = NULL;

                max_len = va_arg( varpars, UINT32 );
                data_ptr = va_arg( varpars, UINT8* );
                len_ptr = va_arg( varpars, UINT32* );

                ret_val = parse_hex_data( &input_ptr, max_len, data_ptr, len_ptr );
            }
            break;

            case( 'O' ):
            {
                ret_val = parse_omit( &input_ptr );
            }
            break;

            default:
            {
                /* If the type is not supported, then we consider its a error  */
                ret_val = ERR_INVALID_PARAM;
            }
            break;
        }

        if( ERR_NONE == ret_val )
        {
            if( *type_ptr != 'O' )
            {
                parsed_number++;
            }
        }
        else
        {
            /*If some error is occured when parse a parameter, then we consider the parameter
             *of this command is not valid*/
            va_end( varpars );
            *string_ptr = input_ptr;
            LOG_ERR(ERR_INVALID_PARAM);
            return -1;
        }

        /* If no more parameters are existed, we should end it */
        if ( '\0' == *input_ptr || '\r' == *input_ptr )
        {
            va_end( varpars );
            *string_ptr =  input_ptr;

            LOG_INFO(("parsed parameter count: %d", parsed_number));

            return parsed_number;
        }

        /* If the next character is not ",", then it's a invalid parameter */
        if ( ',' != *input_ptr )
        {
            va_end( varpars );
            *string_ptr =  input_ptr;
            LOG_ERR(ERR_INVALID_PARAM);
            return -1;
        }
        else
        {
            input_ptr=input_ptr+1;
        }

        /* If no more parameters are existed, we should end it */
        if ( '\0' == *input_ptr || '\r' == *input_ptr )
        {
            va_end( varpars );
            *string_ptr =  input_ptr;

            LOG_INFO(("parsed parameter count: %d", parsed_number));

            return parsed_number;
        }

        type_ptr++;

        skip_white_space((char **)(&input_ptr));
    }

    va_end( varpars );

    /*Bring out the point to first untreated character*/
    *string_ptr = input_ptr;

    LOG_INFO(("parsed parameter count: %d", parsed_number));

    return parsed_number;
}

/*******************************************************************************
 * Function: at_tok_parse_param_count
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the count of parameters in the AT data.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name             Type           In/Out        Description
 *     ---------------  -------------  ----------    --------------------------
 *     buf_ptr          const char *   In            data to parse
 *     buf_len          UINT32         In            length of the data
 *
 * Return:
 * ----------------------------
 *     >= 0: parameters that parsed
 *     < 0: error
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
SINT32 at_tok_parse_param_count( const char *buf_ptr, UINT32 buf_len )
{
    UINT32  i = 0;
    SINT8   param_count = ERR_NONE;
    char    *cur_ptr = (char *)buf_ptr;

//    LOG_FUNC();

    /* Check parameter. */
    if( !buf_ptr )
    {
        /* Error: invalid parameter. */
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    while( ' ' == *cur_ptr )
    {
        cur_ptr++;
        i++;
    }

    if( '\0' == *cur_ptr || '\r' == *cur_ptr )
    {
        param_count = 0;
    }
    else
    {
        param_count = 1;
        while( cur_ptr && *cur_ptr != '\0' && *cur_ptr != '\r' && i < buf_len )
        {
            if( ',' == *cur_ptr )
            {
                param_count++;
            }
            else if( '"' == *cur_ptr )
            {
                while( cur_ptr && *cur_ptr != '"' && *cur_ptr != '\0' && *cur_ptr != '\r' && i < buf_len )
                {
                    cur_ptr++;
                    i++;
                }

                if( '\0' == *cur_ptr || '\r' == *cur_ptr )
                    break;
            }

            cur_ptr++;
            i++;
        }
    }

    LOG_INFO(("parameter count: %d", param_count));

    return param_count;
}

/*******************************************************************************
 * Function: at_tok_is_final_rsp
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Check if the AT string contains the final response.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name             Type           In/Out        Description
 *     ---------------  -------------  ----------    --------------------------
 *     at_ptr           const char *   In            AT string to check
 *
 * Return:
 * ----------------------------
 *     0: the AT string does not contain the final response;
 *     1: the AT string contains the final response;
 *
 * Note:
 * ----------------------------
 *
 ******************************************************************************/
SINT8 at_tok_is_final_rsp(const char *at_ptr)
{
    static const char * final_rsp_ptr[] =
    {
        "\r\nCONNECT\r\n",
        "\r\nOK\r\n",
        "\r\nBUSY\r\n",
        "\r\n+CMS ERROR: ",
        "\r\n+CME ERROR: ",
        "\r\nERROR\r\n",
        "\r\nNO CARRIER\r\n",
        "\r\nNO ANSWER\r\n",
        "\r\nNO DIALTONE\r\n",
    };
    UINT8   count = sizeof(final_rsp_ptr) / sizeof(char *);
    UINT8   i = 0;

    /* Check parameter. */
    if( !at_ptr )
    {
        /* Error: invalid parameter. */
        LOG_ERR( ERR_INVALID_PARAM );
        return 0;
    }

    for( i=0 ; i<count; i++ )
    {
//        if( is_start_with(at_ptr, final_rsp_ptr[i]) )
        if( strstr(at_ptr, final_rsp_ptr[i]) )
        {
            return 1;
        }
    }

    return 0;
}



#undef ATA_TOK_C
