#include "stk.h"
#include "at_tok.h"
//chenchi add start

#include "pub-err.h"
#include "pub-log.h"
#include "pub-util.h"
#include "pub-aos.h"
#include "atchannel.h"
#include <utils/Log.h>
#include <telephony/ril.h>

#include <pthread.h>


extern void RIL_onRequestComplete(RIL_Token t, RIL_Errno e,
                           void *response, size_t responselen);

extern void RIL_onUnsolicitedResponse(int unsolResponse, const void *data,
                                size_t datalen);

#define DB_RIL 1
#define DBBD(l,s) {if (l) s;}
//#define LOG_TAG "STK"

#define LOG_WARNING( x )
#define LOG_INFO( x )

/* Padding to ensure the structure is 4-byte boundary. */
#define ST_PADDING_1(n)                         UINT8   m_pad_ ## n
#define ST_PADDING_2(n)                         UINT8   m_pad_ ## n[2]
#define ST_PADDING_3(n)                         UINT8   m_pad_ ## n[3]

#define ST_PADDING_VALUE_1                      0
#define ST_PADDING_VALUE_2                      {0, 0}
#define ST_PADDING_VALUE_3                      {0, 0, 0}

/* Convert UINT8 data to string, example:
 *     0x12 -> "12"
 */
#define U8_2_STR( u8, str )                                                     \
        do                                                                      \
        {                                                                       \
            if( str )                                                           \
            {                                                                   \
                const char  ascii_table_a[16] =                                 \
                        { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',     \
                          'A', 'B', 'C', 'D', 'E', 'F' };                       \
                                                                                \
                str[0] = ascii_table_a[(u8 >> 4) & 0x0F];                       \
                str[1] = ascii_table_a[u8 & 0x0F];                              \
            }                                                                   \
        } while(0);

/* Convert string to UINT8 data, example:
 *     "12" -> 0x12
 */
#define STR_2_U8( str, u8 )                                                     \
        do                                                                      \
        {                                                                       \
            if( str )                                                           \
            {                                                                   \
                if( '0' <= str[0] && str[0] <= '9' )                            \
                    u8 = (str[0] - '0') * 16;                                   \
                else if( 'A' <= str[0] && str[0] <= 'F' )                       \
                    u8 = (str[0] - 'A' + 10) * 16;                              \
                else if( 'a' <= str[0] && str[0] <= 'f' )                       \
                    u8 = (str[0] - 'a' + 10) * 16;                              \
                                                                                \
                if( '0' <= str[1] && str[1] <= '9' )                            \
                    u8 += (str[1] - '0');                                       \
                else if( 'A' <= str[1] && str[1] <= 'F' )                       \
                    u8 += (str[1] - 'A' + 10);                                  \
                else if( 'a' <= str[1] && str[1] <= 'f' )                       \
                    u8 += (str[1] - 'a' + 10);                                  \
             }                                                                  \
        } while(0);


/* The max length of the at command that send to or receive from HLS. */
//#define AT_CMD_STR_MAX_LEN                      600
#define AT_CMD_STR_MAX_LEN                        2048

#ifndef BOOL
#define BOOL int

#ifndef TRUE
#define TRUE (BOOL)1
#endif
#ifndef FALSE
#define FALSE (BOOL)0
#endif

#endif

//chenchi add end

/*----------------- file-local constant and type definition ------------------*/
//FIX:3gpp-31.124[27.22.#.##.#] 20141115 begin
//setup the event list table.
static const int EVENT_LIST_TABLE_MAX_LEN = 15;

typedef struct {
    UINT8*  mcc;
    UINT8*  mnc;
    UINT8*  tac;
    UINT8*  ci;
} USAT_LocationInfomation;

typedef struct {//Provide Local Information
    UINT32  info_type;
    UINT32  length;
    UINT8*  info_string;
} USAT_DLOCIN;
static char s_str_type = '0x02';
//FIX:3gpp-31.124[27.22.#.##.#] 20141115 end

typedef struct
{
    UINT8   m_cmd_number;
    UINT8   m_cmd_type;
    UINT8   m_cmd_qualifier;
    ST_PADDING_1(0);

    UINT32  m_data_len;
    UINT8   m_data[BUFFER_DATA_LEN];
    UINT32  m_data_pdu_len;
} STK_CMD_DETAIL_ST;

/*--------------------- file-local variables definition ----------------------*/

static STK_CMD_DETAIL_ST    stk_cmd_detail_st =
{
    0,                                          /* m_cmd_number */
    0,                                          /* m_cmd_type */
    0,                                          /* m_cmd_qualifier */
    ST_PADDING_VALUE_1,

    0,                                          /* m_data_len */
    {0},                                        /* m_data */
    0,
};

#define CHECK_FREE_LEN( free_len, add_len )                                     \
do                                                                              \
{                                                                               \
    if( free_len < add_len )                                                    \
    {                                                                           \
        LOG_ERR_EXT( ERR_INVALID_PARAM,("%d < %d", free_len, add_len) );        \
        return ERR_INVALID_PARAM;                                               \
    }                                                                           \
    else                                                                        \
    {                                                                           \
        free_len -= add_len;                                                    \
    }                                                                           \
} while(0);

#define CONVERT_STK_TAG(tag)                                                    \
        do                                                                      \
        {                                                                       \
            if( tag < 0x80 && tag != 0x18 )                                     \
            {                                                                   \
                tag |= 0x80;                                                    \
            }                                                                   \
        } while(0);

#define PACK_TLV_LENGTH(apdu_ptr, apdu_len, apdu_free_len, len_value)           \
        do                                                                      \
        {                                                                       \
            if( len_value > 0x7F )                                              \
            {                                                                   \
                CHECK_FREE_LEN( apdu_free_len, 4 );                             \
                U8_2_STR( 0x81, (&apdu_ptr[apdu_len]) );                        \
                apdu_len += 2;                                                  \
                U8_2_STR( len_value, (&apdu_ptr[apdu_len]) );                   \
                apdu_len += 2;                                                  \
            }                                                                   \
            else                                                                \
            {                                                                   \
                U8_2_STR( len_value, (&apdu_ptr[apdu_len]) );                   \
                apdu_len += 2;                                                  \
            }                                                                   \
        } while(0);
        
static void *auto_send_terminal_rsp_loop( void *param );
static void *auto_send_terminal_rsp_ok_loop( void *param );
static void *auto_send_sms_loop( void *param );
static void *auto_send_ussd_loop( void *param );
static void *auto_deal_poll_interval( void *param );
static void *auto_deal_poll_off( void *param );
static void *auto_hungup_allcs( void *param );
//FIX:3gpp-31.124[27.22.#.##.#] 20141115 begin
static void *auto_access_techology( void *param );
static void *auto_network_measurement_result( void *param );
static void *auto_network_measurement_timing_advance( void *param );
static void *auto_location_infomation( void *param );
static void *auto_setup_event_list( void *param );
//FIX:3gpp-31.124[27.22.#.##.#] 20141115 end

//111111
#define ERR_NONE 0
#define ERR_CALL_C_FUNC -1
#define ERR_INVALID_PARAM -2
#define ERR_UNKNOWN -3

#if 0 //chenchi add 20101101
#define SINT32 int
#define UINT8 int  //chenchi add 20101101  wrong type
#define SINT16 int
#elif 1
#define SINT32 int
#define UINT8 unsigned char
#define SINT16 int
#endif //chenchi add 20101101

#define LOG_FUNC()
#define LOG_ERR( err_code )
#define LOG_ERR_EXT( err_code, x )

extern UINT8 getSimCardType();

BOOL g_bDsatref_ok = FALSE;//Fix Bug00001377 by gaofeng 20130805

static char *s_stk_send_envelops_str = NULL;
static int s_sw2_val = 0;
static pthread_mutex_t s_stk_send_envelope_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t s_stk_send_envelope_cond = PTHREAD_COND_INITIALIZER;
BOOL b_lr_exp_len = FALSE;


//SINT32 at_stk_jump_over_tlv_data_obj(UINT8 tag, char **pro_cmd_ptr, SINT8 is_mandatory )
SINT32 at_stk_jump_over_tlv_data_obj(UINT8 tag, char **pro_cmd_ptr, int is_mandatory )
{
    SINT32  ret_val = ERR_NONE;
    UINT8   tmp = 0;

    if( !pro_cmd_ptr || !(*pro_cmd_ptr) )
    {
        /* Error: invalid parameter. */
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    STR_2_U8( (*pro_cmd_ptr), tmp );
    CONVERT_STK_TAG(tmp);

    if( tag == tmp )
    {
        UINT8   length = 0;

        /* Jump over <tag>. */
        (*pro_cmd_ptr) += 2;

        /* Jump over <Length>. */
        STK_GET_TLV_LEN( (*pro_cmd_ptr), length );

        /* Jump over <data>. */
        (*pro_cmd_ptr) += (length * 2);
    }
    else if(is_mandatory)
    {
        LOG_ERR_EXT( ERR_INVALID_PARAM, ("[STK]tag dismatch: 0x%02X != 0x%02X", tag, tmp) );
        ret_val = ERR_INVALID_PARAM;
    }
    else
    {
        /* If the tag is optional, then ignore the error. */
        LOG_WARNING( ("[STK]tag dismatch: 0x%02X != 0x%02X", tag, tmp) );
    }

    return ret_val;
}

SINT32 at_stk_pack_tlv_command_details( UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr )
{
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = 0;

    /* Check parameter. */
    if( !apdu_ptr || !apdu_len_ptr || !apdu_free_len_ptr )
    {
            /* Error: invalid parameter. */
            return ERR_INVALID_PARAM;
    }

    apdu_len = *apdu_len_ptr;
    apdu_free_len = *apdu_free_len_ptr;

    /* <tag> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( STK_TAG_COMMAND_DETAILS, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Length> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( 0x03, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Command number> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( stk_cmd_detail_st.m_cmd_number, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Type of command> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( stk_cmd_detail_st.m_cmd_type, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Command Qualifier> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( stk_cmd_detail_st.m_cmd_qualifier, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    *apdu_len_ptr = apdu_len;
    *apdu_free_len_ptr = apdu_free_len;

    return ERR_NONE;
}

SINT32 at_stk_pack_tlv_device_id( UINT8 src_dev, UINT8 dst_dev, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr )
{
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = 0;

    /* Check parameter. */
    if( !apdu_ptr || !apdu_len_ptr || !apdu_free_len_ptr )
    {
      /* Error: invalid parameter. */
      return ERR_INVALID_PARAM;
    }

    apdu_len = *apdu_len_ptr;
    apdu_free_len = *apdu_free_len_ptr;

    /* <tag> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( STK_TAG_DEVICE_IDENTITY, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Length> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( 0x02, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Source device identity> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( src_dev, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Destination device identity> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( dst_dev, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    *apdu_len_ptr = apdu_len;
    *apdu_free_len_ptr = apdu_free_len;

    return ERR_NONE;
}

SINT32 at_stk_pack_tlv_result( UINT8 result, STK_ADDITIONAL_RESULT_ST *result_ptr, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr )
{
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = 0;
    UINT32  len_value = 0;

    /* Check parameter.
    * Note: result_ptr can be NULL.
    */
    if( !apdu_ptr || !apdu_len_ptr || !apdu_free_len_ptr )
    {
      /* Error: invalid parameter. */
      return ERR_INVALID_PARAM;
    }

    apdu_len = *apdu_len_ptr;
    apdu_free_len = *apdu_free_len_ptr;

    /* <tag> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( STK_TAG_RESULT, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Length> */
    len_value = 0x01;
    if( result_ptr )
    {
      len_value += result_ptr->m_len;
    }
    PACK_TLV_LENGTH(apdu_ptr, apdu_len, apdu_free_len, len_value);

    /* <General result> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( result, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Additional information on result> */
    if( result_ptr )
    {
      CHECK_FREE_LEN( apdu_free_len, (result_ptr->m_len) );
      /* todo */
      apdu_len += (result_ptr->m_len);
    }

    *apdu_len_ptr = apdu_len;
    *apdu_free_len_ptr = apdu_free_len;

    return ERR_NONE;
}

// add [by chenshu 2012-02-15] for add rsp
SINT32 at_stk_pack_tlv_rsp( UINT8* data, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr )
{
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = 0;
    UINT8   i = 2;

    /* Check parameter.
    * Note: result_ptr can be NULL.
    */
    if( !apdu_ptr || !apdu_len_ptr || !apdu_free_len_ptr )
    {
        /* Error: invalid parameter. */
        return ERR_INVALID_PARAM;
    }

    apdu_len = *apdu_len_ptr;
    apdu_free_len = *apdu_free_len_ptr;

    /* <tag> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( data[0], (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <Length> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( data[1], (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <rspData> */
    CHECK_FREE_LEN( apdu_free_len, data[1]*2 );
    for (; i <= data[1]+1; i++ ) {
        U8_2_STR( data[i], (&apdu_ptr[apdu_len]) );
        apdu_len += 2;
    }

    *apdu_len_ptr = apdu_len;
    *apdu_free_len_ptr = apdu_free_len;

    return ERR_NONE;
}
// add [by chenshu 2012-02-15] end


//SINT32 at_stk_pack_tlv_data_obj(UINT8 tag, char **pro_cmd_ptr, SINT8 is_mandatory, UINT8 *out_data, UINT32 out_size, UINT32 *out_len )
SINT32 at_stk_pack_tlv_data_obj(UINT8 tag, char **pro_cmd_ptr, int is_mandatory, UINT8 *out_data, UINT32 out_size, UINT32 *out_len )
{
    SINT32  ret_val = ERR_NONE;
    UINT8   length = 0;
    UINT8   tmp = 0;

    LOG_FUNC();

    if( !pro_cmd_ptr || !(*pro_cmd_ptr)
        || !out_data
        || !out_len )
    {
        /* Error: invalid parameter. */
        DBBD(DB_RIL, RLOGD("[STK] invalid parameter"));
        return ERR_INVALID_PARAM;
    }

    memset( out_data, 0x00, out_size );

    STR_2_U8( (*pro_cmd_ptr), tmp );
    if( tmp < 0x80 && tmp != 0x18 )
    {
        tmp |= 0x80;
    }

    if( tag == tmp )
    {
        /* Jump over <tag>. */
        (*pro_cmd_ptr) += 2;

        /* Jump over <Length>. */
        STK_GET_TLV_LEN( (*pro_cmd_ptr), *out_len );
        if( *out_len > out_size )
        {
            DBBD(DB_RIL, RLOGD("[STK]data(%ld) > size(%ld)", *out_len, out_size) );
            *out_len = out_size;
        }

        /* Jump over <data>. */
        memcpy( out_data, *pro_cmd_ptr, (*out_len) * 2 );
        (*pro_cmd_ptr) += (length * 2);
    }
    else if(is_mandatory)
    {
        DBBD(DB_RIL, RLOGD("[STK]tag dismatch: 0x%02X != 0x%02X", tag, tmp) );
        ret_val = ERR_INVALID_PARAM;
    }
    else
    {
        /* If the tag is optional, then ignore the error. */
        DBBD(DB_RIL, RLOGD("[STK]tag dismatch: 0x%02X != 0x%02X", tag, tmp) );
    }

    return ret_val;
}

SINT32 get_ril_unsol_stk_command_type(UINT8 **begin_ptr, UINT8 **end_ptr)
{
    char    *pro_cmd_ptr = NULL;
    char    *pro_cmd_begin_ptr = NULL;
    UINT32  lr = 0;
    UINT8   len = 0;
    UINT8   tmp = 0;

    if(**end_ptr){
    }
    /* Check parameter.
    * WARNING: never check "end_ptr", we won't use it here. */
    if( !begin_ptr || !(*begin_ptr) )
    {
      /* Error: invalid parameter. */
      LOG_ERR( ERR_INVALID_PARAM );
      return RIL_UNSOL_STK_PROACTIVE_COMMAND;
    }

    /* Skip the <length> */
    pro_cmd_ptr = strstr((char *)(*begin_ptr), ",");
    if( pro_cmd_ptr )
    {
      /* Jump over ",". */
      pro_cmd_ptr++;

      /* Jump over <Lr>. */
      STR_2_U8( pro_cmd_ptr, lr );
      pro_cmd_ptr += 2;

      /* check the <tag>. */
      STR_2_U8( pro_cmd_ptr, tmp );
      if( STK_TAG_PROACTIVE_UICC == tmp )
      {
          pro_cmd_begin_ptr = pro_cmd_ptr;

          /* Jump over <tag>. */
          pro_cmd_ptr += 2;

          /* Jump over <len>. */
          STK_GET_TLV_LEN(pro_cmd_ptr, len);

          STR_2_U8( pro_cmd_ptr, tmp );
          CONVERT_STK_TAG(tmp);
          if( STK_TAG_COMMAND_DETAILS == tmp )
          {
              /* Command details data object, refer to: ts_102.223-8.6 */

              /* Jump over <tag>. */
              pro_cmd_ptr += 2;

              /* The <len> of <Command details> should always be 0x03. */
              STR_2_U8( pro_cmd_ptr, tmp );
              if( 3 == tmp )
              {
                  /* Jump over <len>. */
                  pro_cmd_ptr += 2;

                  STR_2_U8( pro_cmd_ptr, stk_cmd_detail_st.m_cmd_number );
                  STR_2_U8( (pro_cmd_ptr+2), stk_cmd_detail_st.m_cmd_type );
                  STR_2_U8( (pro_cmd_ptr+4), stk_cmd_detail_st.m_cmd_qualifier );

                  LOG_INFO(("[STK]cmd_number(%d), cmd_type(0x%02X), cmd_qualifier(%d)", stk_cmd_detail_st.m_cmd_number, stk_cmd_detail_st.m_cmd_type, stk_cmd_detail_st.m_cmd_qualifier));

                  /* Jump over <Command number>, <Type of command>, <Command Qualifier> */
                  pro_cmd_ptr += 6;

                  switch(stk_cmd_detail_st.m_cmd_type)
                  {
                      case STK_CMD_ID_SET_UP_CALL:
                      case STK_CMD_ID_SEND_SS:
                      case STK_CMD_ID_SEND_USSD:
                      case STK_CMD_ID_SEND_SMS:
                      case STK_CMD_ID_SEND_DTMF:
                      {
                          //handle sms send
                          return RIL_UNSOL_STK_EVENT_NOTIFY;
                      }
                      break;
                      case STK_CMD_ID_REFRESH:
                      {
                          return RIL_UNSOL_SIM_REFRESH;
                      }
                      break;
                      default:
                      {
                          return RIL_UNSOL_STK_PROACTIVE_COMMAND;
                      }
                      break;
                  }
              }
              else
              {
                  LOG_ERR_EXT( ERR_UNKNOWN, ("[STK]invalid length of <Command details>: 0x%02x(%d)", tmp, tmp) );
              }
          }
          else
          {
              LOG_INFO(("[STK]not support tag: 0x%02X(%d)", tmp, tmp));

              stk_cmd_detail_st.m_cmd_number = 0;
              stk_cmd_detail_st.m_cmd_type = 0;
              stk_cmd_detail_st.m_cmd_qualifier = 0;
          }
      }
      else
      {
          LOG_WARNING( ( "[STK]unknown tag: 0x%02X(%d)", tmp, tmp ) );
      }
    }
    else
    {
      LOG_ERR_EXT( ERR_UNKNOWN, ( "[STK]Invalid <pro_command>") );
    }
    return RIL_UNSOL_STK_PROACTIVE_COMMAND;
}

//Add by guolei2@leadcoretech.com for L1811_Bug00001048   SIM/USIM CLA error START
UINT8 convertSimClass(int simClass) {
    UINT8 nResult = 0;
    switch(simClass) {
        case RIL_APPTYPE_SIM:
            nResult = CARD_CLASS_SIM;
            break;
        case RIL_APPTYPE_USIM:
            nResult = CARD_CLASS_USIM;
            break;
        default:
            nResult = CARD_CLASS_OTHER;
    }
    DBBD(DB_RIL, RLOGD("[STK] convertSimClass nResult=%d", nResult));
    return nResult;
}
//Add by guolei2@leadcoretech.com for L1811_Bug00001048   SIM/USIM CLA error END

SINT32 at_stk_pack_apdu_header( UINT8 head_ins, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr )
{
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = 0;

    /* Check parameter. */
    if( !apdu_ptr || !apdu_len_ptr || !apdu_free_len_ptr )
    {
      /* Error: invalid parameter. */
      LOG_ERR_EXT( ERR_INVALID_PARAM,("[STK]%d, %d, %d", !apdu_ptr, !apdu_len_ptr, !apdu_free_len_ptr) );
      return ERR_INVALID_PARAM;
    }

    *apdu_len_ptr = 0;
    apdu_len = 0;
    apdu_free_len = *apdu_free_len_ptr;

    UINT8 nSimClass;
/*L1813_Bug00000701, wangsheng, 2013-07-10, start*/
//#if (OPT_SIM_COUNT == 1)
//    nSimClass = STK_CMD_HEAD_CLA_80;
//#else
    nSimClass = convertSimClass(getSimCardType());
//#endif/*if (OPT_SIM_COUNT > 1)*/
/*L1813_Bug00000701, wangsheng, 2013-07-10, end*/

    /* <CLA> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR(nSimClass, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <INS> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( head_ins, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <P1> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( STK_CMD_HEAD_P1, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    /* <P2> */
    CHECK_FREE_LEN( apdu_free_len, 2 );
    U8_2_STR( STK_CMD_HEAD_P2, (&apdu_ptr[apdu_len]) );
    apdu_len += 2;

    apdu_ptr[apdu_len] = '\0';

    *apdu_len_ptr = apdu_len;
    *apdu_free_len_ptr = apdu_free_len;
    
    return ERR_NONE;
}


SINT32 at_stk_pack_apdu( UINT8 *apdu_data_ptr, UINT32 data_len, UINT8 head_ins, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr )
{
    SINT32  ret_val = ERR_NONE;
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = 0;

    /* Check parameter. */
    //Modify by guolei2@leadcoretech.com, 2012/03/01, 20120228-00050,Add refresh case SIM_INIT START
    if (STK_CMD_HEAD_INS_FETCH == head_ins) {
    /*If command is FETCH does not need to check apdu_data_ptr, due to no data transfer to SIM*/
        if( !apdu_ptr || !apdu_len_ptr || !apdu_free_len_ptr )
        {
            /* Error: invalid parameter. */
            LOG_ERR_EXT( ERR_INVALID_PARAM,("[STK]%d, %d, %d, %d", !apdu_data_ptr, !apdu_ptr, !apdu_len_ptr, !apdu_free_len_ptr) );
            return ERR_INVALID_PARAM;
        }
    } else {
        if( !apdu_data_ptr || !apdu_ptr || !apdu_len_ptr || !apdu_free_len_ptr )
        {
            /* Error: invalid parameter. */
            LOG_ERR_EXT( ERR_INVALID_PARAM,("[STK]%d, %d, %d, %d", !apdu_data_ptr, !apdu_ptr, !apdu_len_ptr, !apdu_free_len_ptr) );
            return ERR_INVALID_PARAM;
        }
    }
         //Modify by guolei2@leadcoretech.com, 2012/03/01, 20120228-00050,Add refresh case SIM_INIT END

    *apdu_len_ptr = 0;
    apdu_len = 0;
    apdu_free_len = *apdu_free_len_ptr;

    ret_val = at_stk_pack_apdu_header( head_ins, apdu_ptr, &apdu_len, &apdu_free_len );
    if( ERR_NONE == ret_val )
    {
        //Modify by guolei2@leadcoretech.com, 2012/03/01, 20120228-00050,Add refresh case SIM_INIT START
        if (STK_CMD_HEAD_INS_FETCH == head_ins) {
            /*No need the data len and data field  according to 102.221 chapter 11.2.3 FETCH command*/
       } else {
            /* <Lc>: Number of bytes in the command data field */
            CHECK_FREE_LEN( apdu_free_len, 2 );
            U8_2_STR( (data_len / 2), (&apdu_ptr[apdu_len]) );
            apdu_len += 2;

            /* <data> */
            CHECK_FREE_LEN( apdu_free_len, 2 );
            memcpy( &apdu_ptr[apdu_len], apdu_data_ptr, data_len );
            apdu_len += data_len;
       }
       //Modify8 by guolei2@leadcoretech.com, 2012/03/01, 20120228-00050,Add refresh case SIM_INIT END

       /* <Le>: Maximum number of data bytes expected in response of the command */
       CHECK_FREE_LEN( apdu_free_len, 2 );
       U8_2_STR( 0x00, (&apdu_ptr[apdu_len]) );     /* 00 means max number of bytes(256) */
       apdu_len += 2;

       apdu_ptr[apdu_len] = '\0';

       *apdu_len_ptr = apdu_len;
       *apdu_free_len_ptr = apdu_free_len;
    }

    return ret_val;
}

int convertCommandType(int nType)
{
    switch(nType)
    {
        case STK_CMD_ID_SEND_SMS:
            return RIL_UNSOL_STK_EVENT_NOTIFY;
#ifdef USE_AP_STK_MODE
        case STK_CMD_ID_REFRESH:/* Leadcore: fix Req00000143, chengyuxin, 20110223, Add refresh tag refer to: ts_102.223-9.4 */
            return RIL_UNSOL_SIM_REFRESH;
#endif
        default:
            return RIL_UNSOL_STK_PROACTIVE_COMMAND;
    }
}

SINT32 preHandleProactiveStk(char **begin_ptr, int lenght)
{
   // UINT32  ret_val = 0;
    char    *pro_cmd_ptr = NULL;
    char    *pro_cmd_begin_ptr = NULL;
    UINT32  lr = 0;
    UINT8   len = 0;
    UINT8   tmp = 0;
    int nProactiveCommandType = ERROR_RETURN;
    int tlv_len = 0;
    int temp_lr = 0;
    int low_lr = 0;
    int high_lr = 0;
    tlv_len = lenght;
    RLOGD("[STK]preHandleProactiveStk tlv_len = %d", tlv_len);

    /* Check parameter. */
    if( !begin_ptr || !(*begin_ptr) )
    {
      return ERROR_RETURN;
    }

    /* Skip the <length> */
    pro_cmd_ptr = strstr((char *)(*begin_ptr), ",");
    if( pro_cmd_ptr )
    {
      /* Jump over ",". */
      pro_cmd_ptr++;

      /* Jump over <Lr>. */

      STR_2_U8( pro_cmd_ptr, lr );
      temp_lr = (lr + 3) * 2;//len + data + sw1 + sw2
      RLOGD("[STK]preHandleProactiveStk len+data+sw1+sw2 = %d, lr = %lu", temp_lr, lr);

      if( temp_lr != tlv_len)
      {
         b_lr_exp_len = TRUE;
         STR_2_U8( pro_cmd_ptr, high_lr );
         pro_cmd_ptr += 2;
         STR_2_U8( pro_cmd_ptr, low_lr );
      }
      pro_cmd_ptr += 2;

      /* check the <tag>. */
      STR_2_U8( pro_cmd_ptr, tmp );
      if( STK_TAG_PROACTIVE_UICC == tmp )
      {
          pro_cmd_begin_ptr = pro_cmd_ptr;

          /* Jump over <tag>. */
          pro_cmd_ptr += 2;

          /* Jump over <len>. */
          STK_GET_TLV_LEN(pro_cmd_ptr, len);

          STR_2_U8( pro_cmd_ptr, tmp );
          CONVERT_STK_TAG(tmp);
            if( STK_TAG_COMMAND_DETAILS == tmp )
            {
              /* Command details data object, refer to: ts_102.223-8.6 */

              /* Jump over <tag>. */
              pro_cmd_ptr += 2;

              /* The <len> of <Command details> should always be 0x03. */
              STR_2_U8( pro_cmd_ptr, tmp );
              if( 3 == tmp )
              {
                  /* Jump over <len>. */
                  pro_cmd_ptr += 2;

                  STR_2_U8( pro_cmd_ptr, stk_cmd_detail_st.m_cmd_number );
                  STR_2_U8( (pro_cmd_ptr+2), stk_cmd_detail_st.m_cmd_type );
                  STR_2_U8( (pro_cmd_ptr+4), stk_cmd_detail_st.m_cmd_qualifier );
                  DBBD(DB_RIL, RLOGD("before convertCommandType type =%d", stk_cmd_detail_st.m_cmd_type));
                  if ((nProactiveCommandType = convertCommandType(stk_cmd_detail_st.m_cmd_type)) != -1 )
                  {
#ifdef USE_AP_STK_MODE
                      DBBD(DB_RIL, RLOGD("after convertCommandType nProactiveCommandType=%d", nProactiveCommandType) );
                      /* Jump over <Command number>, <Type of command>, <Command Qualifier> */
                      pro_cmd_ptr += 6;

                      DBBD(DB_RIL, RLOGD("before jump device_identity pro_cmd_ptr=%s", pro_cmd_ptr) );

                      /* Jump over <Device identity>. */
                      ret_val = at_stk_jump_over_tlv_data_obj( STK_TAG_DEVICE_IDENTITY, &pro_cmd_ptr, 1 );
                      if( ret_val != ERR_NONE )
                      {
                          DBBD(DB_RIL, RLOGD("[STK] Device identity ERROR") );
                          return ERROR_RETURN;
                      }

                        //handle sms send
                      if (stk_cmd_detail_st.m_cmd_type == STK_CMD_ID_SEND_SMS)
                      {
                          /* Jump over <Alpha identifier> if it exists. */

                          ret_val = at_stk_jump_over_tlv_data_obj( STK_TAG_ALPHA_ID, &pro_cmd_ptr, 1 );
                          if( ret_val != ERR_NONE )
                          {
                              DBBD(DB_RIL, RLOGD("[STK] Alpha identifier is not exist") );
                              //fix bug: Bug00000580
                              //return ERROR_RETURN;
                          }
                          /* Try to jump over <Address>. */
                          //original code
                          //ret_val = at_stk_jump_over_tlv_data_obj( STK_TAG_ADDRESS, &pro_cmd_ptr, 0 );
                          //parse ADDRESS

                          UINT8   addressData[BUFFER_DATA_LEN];
                          int addressLength = 0;
                          int tmpAddressLength = 0;
                          UINT8   currentTag= 0;
                          STR_2_U8( pro_cmd_ptr, currentTag );
                          CONVERT_STK_TAG(currentTag);
                          int pduIndex = 0;
                          int pduCount = 0;
                          if (currentTag == STK_TAG_ADDRESS) {
                              //handle length
                              int length = 0;
                              char* pTmp = pro_cmd_ptr+2;

                              DBBD(DB_RIL, RLOGD("[STK] run point 1") );

                              STR_2_U8( pTmp, length );
                              DBBD(DB_RIL, RLOGD("[STK] run point 1.1") );
                              if ( 0x81 == length ) {
                                  addressData[0] = *(pro_cmd_ptr + 4);
                                  addressData[1] = *(pro_cmd_ptr + 5);
                              }
                              else {
                                  addressData[0] = *(pro_cmd_ptr + 2);
                                  addressData[1] = *(pro_cmd_ptr + 3);
                              }
                              addressLength = 1;
                              DBBD(DB_RIL, RLOGD("[STK] run point 2") );

                              ret_val = at_stk_pack_tlv_data_obj(
                                      STK_TAG_ADDRESS,
                                      &pro_cmd_ptr,
                                      0,
                                      &(addressData[2]),
                                      BUFFER_DATA_LEN - 2,
                                      &tmpAddressLength );//addressLength = (actural char count /2)
                              pro_cmd_ptr += (tmpAddressLength * 2);
                              DBBD(DB_RIL, RLOGD("[STK] run point 3") );
                              memcpy( &(stk_cmd_detail_st.m_data[0]),
                                      addressData,
                                      ( addressLength + tmpAddressLength) * 2 );
                              stk_cmd_detail_st.m_data_len = addressLength + tmpAddressLength;
                          } else {
                              stk_cmd_detail_st.m_data[0] = '0';
                              stk_cmd_detail_st.m_data[1] = '0';
                              stk_cmd_detail_st.m_data_len = 1;
                          }
                          DBBD(DB_RIL, RLOGD("[STK] run point 4") );
                          pduIndex = stk_cmd_detail_st.m_data_len * 2;
                          DBBD(DB_RIL, RLOGD("[STK] before auto_send_sms_loop sms pdu pro_cmd_ptr=%s", pro_cmd_ptr) );
                          DBBD(DB_RIL, RLOGD("[STK] before auto_send_sms_loop sms pdu pro_cmd_ptr=%s", &stk_cmd_detail_st.m_data) );
                          ret_val = at_stk_pack_tlv_data_obj(
                                  STK_TAG_SMS_TPDU,
                                  &pro_cmd_ptr,
                                  1,
                                  &(stk_cmd_detail_st.m_data[pduIndex]),
                                  (BUFFER_DATA_LEN - stk_cmd_detail_st.m_data_len * 2) ,
                                  &(pduCount) );

                          stk_cmd_detail_st.m_data_len += pduCount;
                          stk_cmd_detail_st.m_data_pdu_len = pduCount;
    
                          DBBD(DB_RIL, RLOGD("[STK] before auto_send_sms_loop m_data=%s", stk_cmd_detail_st.m_data) );
                          DBBD(DB_RIL, RLOGD("[STK] before auto_send_sms_loop m_data_len=%d", stk_cmd_detail_st.m_data_len) );
                          DBBD(DB_RIL, RLOGD("[STK] before auto_send_sms_loop m_data_pdu_len=%d", stk_cmd_detail_st.m_data_pdu_len) );

                          if( ret_val != ERR_NONE )
                          {
                              DBBD(DB_RIL, RLOGD("[STK] expect tag 0x%02X not found", STK_TAG_SMS_TPDU) );
                              return ERROR_RETURN;
                          }

                          pthread_t   thread_id;
                          DBBD(DB_RIL, RLOGD("[STK] before auto_send_sms_loop"));
                          pthread_create( &thread_id,
                                  NULL,
                                  auto_send_sms_loop,
                                  NULL );
                          DBBD(DB_RIL, RLOGD("[STK] after auto_send_sms_loop"));
                      }
                      //handle sms send end

                      // add [by chenshu 2012-02-15] for send_ussd
                      if (stk_cmd_detail_st.m_cmd_type == STK_CMD_ID_SEND_USSD) {
                          /* Jump over <Alpha identifier> if it exists. */
                          ret_val = at_stk_jump_over_tlv_data_obj( STK_TAG_ALPHA_ID, &pro_cmd_ptr, 1 );
                          if( ret_val != ERR_NONE )
                          {
                              DBBD(DB_RIL, RLOGD("[STK] Alpha identifier is not exist"));
                              //fix bug: Bug00000580
                              //return ERROR_RETURN;
                          }
                          ret_val = at_stk_pack_tlv_data_obj(
                                  STK_TAG_USSD_STRING,
                                  &pro_cmd_ptr,
                                  1,
                                  stk_cmd_detail_st.m_data,
                                  BUFFER_DATA_LEN,
                                  &(stk_cmd_detail_st.m_data_len) );

                          pthread_t   thread_id;
                          pthread_create( &thread_id,
                                  NULL,
                                  auto_send_ussd_loop,
                                  NULL );
                      }
                      // add [by chenshu 2012-02-15] end
                      // add [by chenshu 2012-02-22] for poll interval/off
                      if (stk_cmd_detail_st.m_cmd_type == STK_CMD_ID_POLL_INTERVAL) {
                            ret_val = at_stk_pack_tlv_data_obj(
                                    STK_TAG_DURATION,
                                    &pro_cmd_ptr,
                                    1,
                                    stk_cmd_detail_st.m_data,
                                    BUFFER_DATA_LEN,
                                    &(stk_cmd_detail_st.m_data_len) );
                            pthread_t   thread_id;
                            pthread_create( &thread_id,
                                    NULL,
                                    auto_deal_poll_interval,
                                    NULL );
                            return RIL_UNSOL_SIM_REFRESH; // need to return while in handleStkProactiveCommand
                      }
                      if (stk_cmd_detail_st.m_cmd_type == STK_CMD_ID_POLLING_OFF) {
                            pthread_t   thread_id;
                            pthread_create( &thread_id,
                                    NULL,
                                    auto_deal_poll_off,
                                    NULL );
                            return RIL_UNSOL_SIM_REFRESH; // need to return while in handleStkProactiveCommand
                      }
                      // add [by chenshu 2012-02-22] end

                      //FIX:3gpp-31.124[27.22.#.##.#] 20141115 begin
                      if (stk_cmd_detail_st.m_cmd_type == STK_CMD_ID_PROVIDE_LOCAL_INFO) {
                            DBBD(DB_RIL, RLOGD("[STK] STK_CMD_ID_PROVIDE_LOCAL_INFO  -S- m_cmd_qualifier=%d", stk_cmd_detail_st.m_cmd_qualifier) );
                            ret_val = at_stk_pack_tlv_data_obj(
                                      STK_TAG_LOCATION_INFO,
                                      &pro_cmd_ptr,
                                      1,
                                      stk_cmd_detail_st.m_data,
                                      BUFFER_DATA_LEN,
                                      &(stk_cmd_detail_st.m_data_len) );
                            switch (stk_cmd_detail_st.m_cmd_qualifier)
                            {
                             case 0x00: //PROVIDE LOCAL INFORMATION "00" IMEI of the ME[1.17]
                                    {
                                        pthread_t   thread_id;
                                        pthread_create( &thread_id,
                                                NULL,
                                                auto_location_infomation,
                                                NULL );
                                    }
                                    break;

                             case 0x02: //PROVIDE LOCAL INFORMATION "02" Network Measurement Results[1.15]
                                    {
                                        pthread_t   thread_id;
                                        pthread_create( &thread_id,
                                                NULL,
                                                auto_network_measurement_result,
                                                NULL );
                                    }
                                    break;

                             case 0x05: //PROVIDE LOCAL INFORMATION "05" Timing Advance
                                    {
                                        pthread_t   thread_id;
                                        pthread_create( &thread_id,
                                                NULL,
                                                auto_network_measurement_timing_advance,
                                                NULL );
                                    }
                                    break;

                             case 0x06: //PROVIDE LOCAL INFORMATION "06" Access Technology[1.14]
                                    {
                                        pthread_t   thread_id;
                                        pthread_create( &thread_id,
                                                NULL,
                                                auto_access_techology,
                                                NULL );
                                    }
                                    break;
                             default:
                                    RLOGD("[STK] STK_CMD_ID_PROVIDE_LOCAL_INFO -default-");
                                    break;

                            }
                            RLOGD("[STK] STK_CMD_ID_PROVIDE_LOCAL_INFO -E-");
                        }
                        if(stk_cmd_detail_st.m_cmd_type == STK_CMD_ID_SET_UP_EVENT_LIST) {//EVENT DOWNLOAD 
                            RLOGD("[STK] STK_CMD_ID_SET_UP_EVENT_LIST -S-");
                            ret_val = at_stk_pack_tlv_data_obj(
                                      STK_TAG_FILE_LIST,
                                      &pro_cmd_ptr,
                                      1,
                                      stk_cmd_detail_st.m_data,
                                      BUFFER_DATA_LEN,
                                      &(stk_cmd_detail_st.m_data_len) );

                                        pthread_t   thread_id;
                                        pthread_create( &thread_id,
                                                NULL,
                                                auto_setup_event_list,
                                                NULL );

                            RLOGD("[STK] STK_CMD_ID_SET_UP_EVENT_LIST -E-");
                        }
                        //FIX:3gpp-31.124[27.22.#.##.#] 20141115 end

                        if(stk_cmd_detail_st.m_cmd_type == STK_CMD_ID_SET_UP_CALL) {
                            switch(stk_cmd_detail_st.m_cmd_qualifier)
                            {
                                case 0x04:
                                case 0x05:
                                {
                                    pthread_t   thread_id;
                                    pthread_create( &thread_id,
                                            NULL,
                                            auto_hungup_allcs,
                                            NULL );
                                    sleep(2);
                                 }
                                    break;
                                default:
                                    break;
                             }
                        }                        
                        /* Leadcore: fix Req00000143, chengyuxin, 20110223, Add refresh tag refer to: ts_102.223-9.4 */
                        if (nProactiveCommandType == RIL_UNSOL_SIM_REFRESH) 
                        {
                            DBBD(DB_RIL, RLOGD("[STK] handleStkProactiveCommand RIL_UNSOL_SIM_REFRESH qualifier=%x", stk_cmd_detail_st.m_cmd_qualifier));

                            int* pData = (int*)malloc(2*sizeof(int));
                            if (pData == NULL)
                                return ERROR_RETURN;

                            //Add by guolei2@leadcoretech.com, 2012/03/01, 20120228-00050,Add refresh case SIM_INIT START 3
                            switch (stk_cmd_detail_st.m_cmd_qualifier)
                            {
                             case 0x04: 
                                    {
                                        pData[0] = SIM_RESET;
                                        pData[1] = NULL;
                                        /* Fix Inc00000013 by gaofeng 20130604 begin */
                                        pthread_t   thread_id;
                                        DBBD(DB_RIL, RLOGD("[STK]  sendModemRefresh"));
                                        pthread_create( &thread_id,
                                              NULL,
                                              sendModemRefresh,
                                              NULL );
                                        /* Fix Inc00000013 by gaofeng 20130604 end */
                                        RIL_onUnsolicitedResponse (
                                        nProactiveCommandType,
                                        pData, 2* sizeof(int));
                                    }
                                    break;
                              case 0x01:
                                    {
                                        /* Leadcore: fix Req00000160, 20110304, chengyuxin, process refresh command for file updated*/
                                        pData[0] = SIM_FILE_UPDATE;
                                        ret_val = at_stk_pack_tlv_data_obj(
                                            STK_TAG_FILE_LIST,
                                            &pro_cmd_ptr,
                                            1,
                                            stk_cmd_detail_st.m_data,
                                            BUFFER_DATA_LEN,
                                            &(stk_cmd_detail_st.m_data_len) );


                                        DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_SIM_REFRESH m_data=%s", stk_cmd_detail_st.m_data) );
                                        DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_SIM_REFRESH m_data_len=%d", stk_cmd_detail_st.m_data_len) );

                                        if( ret_val != ERR_NONE )
                                        {
                                            DBBD(DB_RIL, RLOGD("[STK] expect tag 0x%02X not found", STK_TAG_FILE_LIST) );
                                            free(pData);
                                            pData = NULL;
                                            return ERROR_RETURN;
                                        }

                                        UINT32  len       = stk_cmd_detail_st.m_data_len;

                                        int nCount = 0;
                                        UINT8 nTmp = 0;
                                        int nCopyCount = 4;
                                        UINT8*  data = stk_cmd_detail_st.m_data;
                                        char* pEfid = (char*)malloc(sizeof(char)*4);

                                        //1207 013F007F106F3A
                                        UINT8 nFileCount = 0;
                                        STR_2_U8( data, nFileCount );

                                        DBBD(DB_RIL, RLOGD("[STK] nFileCount = %d", nFileCount) );
                                        if (nFileCount == 1 && (len*2) >= 10) {
                                            while(nCount < 4) {
                                                pEfid[--nCopyCount] = data[len*2 - nCount -1];
                                                nCount++;
                                            }

                                            DBBD(DB_RIL, RLOGD("[STK] 0") );

                                            STR_2_U8( pEfid, nTmp );
                                            pData[1] = nTmp<<8;

                                            char* pTemp = pEfid+2;
                                            STR_2_U8( pTemp, nTmp ); 
                                            pData[1] |= nTmp;
                                            RIL_onUnsolicitedResponse (
                                            nProactiveCommandType,
                                            pData, 2* sizeof(int));
                                        }
                                        free(pEfid);
                                        pEfid = NULL;
                                        nProactiveCommandType = RIL_UNSOL_STK_PROACTIVE_COMMAND;
                                    }
                                    break;
                              case 0x00:
                              case 0x02:
                                 /* Fix Inc00000013 by gaofeng 20130604 begin */
                                  ret_val = at_stk_pack_tlv_data_obj(
                                          STK_TAG_FILE_LIST,
                                          &pro_cmd_ptr,
                                          1,
                                          stk_cmd_detail_st.m_data,
                                          BUFFER_DATA_LEN,
                                          &(stk_cmd_detail_st.m_data_len) );
                                  DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_SIM_REFRESH m_data=%s", stk_cmd_detail_st.m_data) );
                                  DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_SIM_REFRESH m_data_len=%ld", stk_cmd_detail_st.m_data_len) );
                                  /* Fix Inc00000013 by gaofeng 20130604 end */
                              case 0x03:
                                    {
                                        pData[0] = SIM_INIT;
                                        pData[1] = NULL;
                                        RIL_onUnsolicitedResponse (
                                        nProactiveCommandType,
                                        pData, 2* sizeof(int));
                                        pthread_t   thread_id;
                                        DBBD(DB_RIL, RLOGD("[STK]  sendModemRefresh"));
                                        pthread_create( &thread_id,
                                              NULL,
                                              sendModemRefresh,
                                              NULL );
                                     }
                                     break;
                              default:
                                    DBBD(DB_RIL, RLOGD("[STK]  command REFRESH qualifier does not be supported!!") );
                                    break;
                            }
                            //Add by guolei2@leadcoretech.com, 2012/03/01, 20120228-00050 Add refresh case SIM_INIT END

                            if (NULL != pData)
                            {
                                free(pData);
                                pData = NULL;
                            }
                        }
#endif
                        return nProactiveCommandType;
                    }
                    else
                        return ERROR_RETURN;
                }
                return ERROR_RETURN;
          }
      }
      else
      {
          stk_cmd_detail_st.m_cmd_number = 0;
          stk_cmd_detail_st.m_cmd_type = 0;
          stk_cmd_detail_st.m_cmd_qualifier = 0;
          return ERROR_RETURN;
      }
    }
    else
    {
        return ERROR_RETURN;
    }

    return ERROR_RETURN;
}

//Add by guolei2@leadcoretech.com START for SIM REFRESH let modem refresh
void  sendModemRefresh(void)
{
    char *cmd = NULL;
    int err = 0;
    ATResponse  *p_response = NULL;
    //check parameters
    if (stk_cmd_detail_st.m_cmd_qualifier  < 0) {
        RLOGE("ERROR: sendModemRefresh refresh_type not support = %d\n", stk_cmd_detail_st.m_cmd_qualifier);
        return;
    }

    /* Fix Inc00000013 by gaofeng 20130604 begin */
    if ((stk_cmd_detail_st.m_cmd_qualifier == 0)
          || (stk_cmd_detail_st.m_cmd_qualifier == 3)
          || (stk_cmd_detail_st.m_cmd_qualifier == 4)) {
        /* sim initialization */
        asprintf(&cmd, "AT^DSATREF=%d", stk_cmd_detail_st.m_cmd_qualifier);
        DBBD(DB_RIL, RLOGD("[STK] AT^DSATREF=%d",stk_cmd_detail_st.m_cmd_qualifier));
    } else if (stk_cmd_detail_st.m_cmd_qualifier == 2) {
        UINT8* data = stk_cmd_detail_st.m_data;

        //1207 01 3F00 7F10 6F3A
        //9207 01 3F00 7F20 6F30
        //jump over the tag (2 bytes) and length (2 bytes)
        UINT8 nFileCount = 0;
        STR_2_U8( data, nFileCount );
        DBBD(DB_RIL, RLOGD("[STK] nFileCount = %d", nFileCount) );
        data +=2;
        DBBD(DB_RIL, RLOGD("[STK] nFileList = %s, nFileListLen = %zu", data, strlen((const char*)data)) );
         /* sim initialization */
        asprintf(&cmd, "AT^DSATREF=%d,%zu,\"%s\"", stk_cmd_detail_st.m_cmd_qualifier, strlen((const char*)data), data);
        DBBD(DB_RIL, RLOGD("[STK] AT_COMMAND = %s",cmd));
    }
    /* Fix Inc00000013 by gaofeng 20130604 end */
    else {
        RLOGE("ERROR: sendModemRefresh refresh_type = %d  not support\n",
            stk_cmd_detail_st.m_cmd_qualifier);
        return ;
    }

    at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err != 0) {
        RLOGD("Send SIM refresh command fail");
        goto error;
    }

    RLOGD("[stk] err = %d, g_bDsatref_ok = %d",at_get_cme_error(p_response), g_bDsatref_ok);
    switch (at_get_cme_error(p_response)) {
        case CME_SUCCESS:
            //Fix Bug00001377 by gaofeng 20130805 begin
            if (stk_cmd_detail_st.m_cmd_qualifier == 4)
            {
                g_bDsatref_ok = TRUE;
                RLOGD("[stk]  g_bDsatref_ok = %d",g_bDsatref_ok);
            }
            //Fix Bug00001377 by gaofeng 20130805 end
            break;

        case CME_SIM_PIN_REQUIRED:
            asprintf(&cmd, "AT+CPIN=\"123402\"");
            at_send_command(cmd, NULL);
            if (NULL != cmd) {
                free(cmd);
                cmd = NULL;
            }
            break;
        default:
            RLOGD("p_response = %d not support!", at_get_cme_error(p_response));
            goto error;
    }

    at_response_free(p_response);
    /* Fix Inc00000013 by gaofeng 20130604 begin */
    if (stk_cmd_detail_st.m_cmd_qualifier != 4)
    {
        stk_send_terminal_response(STK_RESULT_00, NULL);
    }
    /* Fix Inc00000013 by gaofeng 20130604 end */
    return;

error:
    at_response_free(p_response);
    RLOGE("ERROR: requestRefreshOperation failed\n");
    /* Fix Inc00000013 by gaofeng 20130604 begin */
    if (stk_cmd_detail_st.m_cmd_qualifier != 4)
    {
        stk_send_terminal_response(STK_RESULT_20, NULL);
    }
    /* Fix Inc00000013 by gaofeng 20130604 end */
}

//Add by guolei2@leadcoretech.com END for SIM REFRESH let modem refresh
SINT8 stk_send_terminal_response(UINT8 result, UINT8* rspData)
{
    SINT32  ret_val = 0;
    UINT32  lc_pos = 0;
    UINT8   apdu_a[STK_APDU_MAX_LEN*2+1] = {0};         /* APDU to modem, with ascii format */
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = sizeof(apdu_a) - 1;
    //UINT8   rsp_data_a[STK_APDU_MAX_LEN*2+1] = {0};     /* response APDU from modem, with ascii format */
    SINT8   is_ok = 0;
    char *cmd = NULL;
    char *line;
    char *sw;
    int len = 0;
    const char *prefix;
    ATResponse *p_response = NULL;

    DBBD(DB_RIL, RLOGD("[STK] stk_send_terminal_response\n"));
    /* Build the TERMINAL RESPONSE, the structure of APDU data refer to: ts_102.223 6.8 */

    /* Build the APDU head. */
    ret_val = at_stk_pack_apdu_header(
        STK_CMD_HEAD_INS_TERMINAL_RESPONSE,
        apdu_a,
        &apdu_len,
        &apdu_free_len );

    /* Build the <Lc>. Here we still do not know the data length, so just fill 0 here, and it will be updated later. */
    lc_pos = apdu_len;
    U8_2_STR( 0x00, (&apdu_a[lc_pos]) );
    apdu_len += 2;

    /* Build "Command details". */
    if( ERR_NONE == ret_val )
    {
        ret_val = at_stk_pack_tlv_command_details(
            apdu_a,
            &apdu_len,
            &apdu_free_len );
    }

    /* Build "Device identities". */
    if( ERR_NONE == ret_val )
    {
        ret_val = at_stk_pack_tlv_device_id(
            STK_DEV_TERMINAL,
            STK_DEV_UICC,
            apdu_a,
            &apdu_len,
            &apdu_free_len );
    }

    /* Build "Result". */
    if( ERR_NONE == ret_val )
    {
        ret_val = at_stk_pack_tlv_result(
            result,
            NULL,
            apdu_a,
            &apdu_len,
            &apdu_free_len );
    }

    /* Build "Response". */
    if( ERR_NONE == ret_val && rspData != NULL ) {
        RLOGD("stk_send_terminal_response: build ResData\n");
        ret_val = at_stk_pack_tlv_rsp(
            rspData,
            apdu_a,
            &apdu_len,
            &apdu_free_len );
    }

    if( ERR_NONE == ret_val )
    {
        /* <Le> */
        RLOGD("stk_send_terminal_response: build le\n");
        U8_2_STR( 0x00, (&apdu_a[apdu_len]) );     /* 00 means max number of bytes(256) */
        apdu_len += 2;
        apdu_a[apdu_len] = '\0';

        /* Fill the <Lc>. */
        if( apdu_len >= (lc_pos + 2 + 2) )
        {
            /* <APDU head><Lc><data><Le> */
            U8_2_STR( ((apdu_len - (lc_pos + 2 + 2)) / 2), (&apdu_a[lc_pos]) );
        }

        asprintf(&cmd, "AT+CSIM=%lu,%s", apdu_len, (char*)apdu_a);
        prefix = "+CSIM:";
        ret_val = at_send_command_singleline(cmd, prefix, &p_response);
        if (cmd != NULL)
        {
            free(cmd);
            cmd = NULL;
        }

        if (ret_val < 0 || p_response->success == 0) goto error;

        line = p_response->p_intermediates->line;
        DBBD(DB_RIL, RLOGD("[STK] line= %s\n", line));

        ret_val = at_tok_start(&line);
        if (ret_val < 0) goto error;
        ret_val = at_tok_nextint(&line, &len);
        if (ret_val < 0) goto error;

        DBBD(DB_RIL, RLOGD("[STK] len %d\n", len));

        /*Leadcore: fix Req00000135, 20110224, chengyuxin, support RFID SIM card*/
        if (len != 4) goto error;

        ret_val = at_tok_nextstr(&line, &sw);
        if (ret_val < 0) goto error;
        DBBD(DB_RIL, RLOGD("[STK] sw %s\n", sw));
        if ((sw[0] == '9') && ((sw[1] == '0') || (sw[1] == '1'))) {
            if (sw[1] == '0') {
                DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_STK_SESSION_END"));
                RIL_onUnsolicitedResponse (RIL_UNSOL_STK_SESSION_END, NULL, 0);
            }
        } else {
            goto error;
        }
    }

error:
    at_response_free(p_response);
    return is_ok;
}

//FIX:3gpp-31.124[27.22.#.##.#] 20141115 begin
SINT8 stk_send_envelope(UINT8 result, UINT8* rspData)
{
    SINT32  ret_val = 0;
    UINT32  lc_pos = 0;
    UINT8   apdu_a[STK_APDU_MAX_LEN*2+1] = {0};         /* APDU to modem, with ascii format */
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = sizeof(apdu_a) - 1;
    //UINT8   rsp_data_a[STK_APDU_MAX_LEN*2+1] = {0};     /* response APDU from modem, with ascii format */
    SINT8   is_ok = 0;
    char *cmd = NULL;
    char *line;
    char *sw;
    int len = 0;
    const char *prefix;
    ATResponse *p_response = NULL;

    DBBD(DB_RIL, RLOGD("[STK] stk_send_envelope\n"));
    /* Build the ENVELOPE RESPONSE, the structure of APDU data refer to: ts_102.223 6.8 */

    /* Build the APDU head. */
    ret_val = at_stk_pack_apdu_header(
        STK_CMD_HEAD_INS_ENVELOPE,
        apdu_a,
        &apdu_len,
        &apdu_free_len );

    /* Build the <Lc>. Here we still do not know the data length, so just fill 0 here, and it will be updated later. */
    lc_pos = apdu_len;
    U8_2_STR( 0x00, (&apdu_a[lc_pos]) );
    apdu_len += 2;

    /* Build "Command details". */
    if( ERR_NONE == ret_val )
    {
        ret_val = at_stk_pack_tlv_command_details(
            apdu_a,
            &apdu_len,
            &apdu_free_len );
    }

    /* Build "Device identities". */
    if( ERR_NONE == ret_val )
    {
        ret_val = at_stk_pack_tlv_device_id(
            STK_DEV_TERMINAL,
            STK_DEV_UICC,
            apdu_a,
            &apdu_len,
            &apdu_free_len );
    }

    /* Build "Result". */
    if( ERR_NONE == ret_val )
    {
        ret_val = at_stk_pack_tlv_result(
            result,
            NULL,
            apdu_a,
            &apdu_len,
            &apdu_free_len );
    }

    /* Build "Response". */
    if( ERR_NONE == ret_val && rspData != NULL ) {
        RLOGD("stk_send_envelope: build ResData\n");
        ret_val = at_stk_pack_tlv_rsp(
            rspData,
            apdu_a,
            &apdu_len,
            &apdu_free_len );
    }

    if( ERR_NONE == ret_val )
    {
        /* <Le> */
        RLOGD("stk_send_envelope: build le\n");
        U8_2_STR( 0x00, (&apdu_a[apdu_len]) );     /* 00 means max number of bytes(256) */
        apdu_len += 2;
        apdu_a[apdu_len] = '\0';

        /* Fill the <Lc>. */
        if( apdu_len >= (lc_pos + 2 + 2) )
        {
            /* <APDU head><Lc><data><Le> */
            U8_2_STR( ((apdu_len - (lc_pos + 2 + 2)) / 2), (&apdu_a[lc_pos]) );
        }

        asprintf(&cmd, "AT+CSIM=%lu,%s", apdu_len, (char*)apdu_a);
        prefix = "+CSIM:";
        ret_val = at_send_command_singleline(cmd, prefix, &p_response);
        if (cmd != NULL)
        {
            free(cmd);
            cmd = NULL;
        }

        if (ret_val < 0 || p_response->success == 0) goto error;

        line = p_response->p_intermediates->line;
        DBBD(DB_RIL, RLOGD("[STK] stk_send_envelope line= %s\n", line));

        ret_val = at_tok_start(&line);
        if (ret_val < 0) goto error;
        ret_val = at_tok_nextint(&line, &len);
        if (ret_val < 0) goto error;

        DBBD(DB_RIL, RLOGD("[STK] stk_send_envelope len %d\n", len));

        if (len != 4) goto error;

        ret_val = at_tok_nextstr(&line, &sw);
        if (ret_val < 0) goto error;
        DBBD(DB_RIL, RLOGD("[STK]stk_send_envelope sw %s\n", sw));
        if ((sw[0] == '9') && ((sw[1] == '0') || (sw[1] == '1'))) {
            if (sw[1] == '0') {
                DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_STK_SESSION_END"));
                RIL_onUnsolicitedResponse (RIL_UNSOL_STK_SESSION_END, NULL, 0);
            }
        } else {
            goto error;
        }
    }

error:
    at_response_free(p_response);
    return is_ok;
}
//FIX:3gpp-31.124[27.22.#.##.#] 20141115 end

/* Leadcore:begin fix_bug00004085, 20110901, chengyuxin, supporting Command Qualifier: 0x01(1) - SMS packing by the ME required*/
#define GUC  0x10  
STATIC CONST UINT8 sc_sms_latin1_gsm_table_a[256] =
{
    /*    0      1     2     3     4     5     6     7 */
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,    /* 0x07 */
    GUC,  GUC,  0x0a, GUC,  GUC,  0x0d, GUC,  GUC,    /* 0x0f */
    GUC,  GUC,  GUC,  GUC,  0x14, GUC,  GUC,  GUC,
    GUC,  GUC,  GUC,  0x1B, GUC,  GUC,  GUC,  GUC,
    0x20, 0x21, 0x22, 0x23, 0x02, 0x25, 0x26, 0x27,
    0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
    0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
    0x00, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
    0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
    0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x11,
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
    0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
    0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77,
    0x78, 0x79, 0x7a, GUC,  GUC,  GUC,  GUC,  GUC,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  /* 0x8f */
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  /* 0x9f */
    GUC,  0x40, GUC,  0x01, 0x24, 0x03, GUC,  0x5f,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  0x60,
    0x41, 0x41, 0x41, 0x41, 0x5b, 0x0e, 0x1c, 0x09,
    0x45, 0x1f, 0x45, 0x45, 0x49, 0x49, 0x49, 0x49, /* 0xcf */
    GUC,  0x5d, 0x4f, 0x4f, 0x4f, 0x4f, 0x5c, GUC,
    0x0b, 0x55, 0x55, 0x55, 0x5e, 0x59, GUC,  0x1e,
    0x7f, 0x61, 0x61, 0x61, 0x7b, 0x0f, 0x1d, 0x09,
    0x04, 0x05, 0x65, 0x65, 0x07, 0x69, 0x69, 0x69,
    GUC,  0x7d, 0x08, 0x6f, 0x6f, 0x6f, 0x7c, GUC,
    0x0c, 0x06, 0x75, 0x75, 0x7e, 0x79, GUC,  0x79
};

VOID g_sc_util_ascii_to_7bit( UINT8 *ascii_str_ptr,
                              UINT8 *str_7bit_ptr,
                              UINT8 max_ascii_length )
{
    SINT32 i, j;
    UINT8 ch;
    UINT8 bit_count = 0;
    UINT8 offset = 0;


    if ((!ascii_str_ptr) || (!str_7bit_ptr))
    {
        return;
    }

    str_7bit_ptr[offset] = 0x00;

    for (i = 0; i < max_ascii_length && ascii_str_ptr[i]; i++)
    {
        ch = sc_sms_latin1_gsm_table_a[ascii_str_ptr[i]];

        for (j = 0; j < 7; j++)
        {
            if (bit_count == 8)
            {
                bit_count = 0;
                offset++;
                str_7bit_ptr[offset] = 0x00;
            }

            if ((1 << j) & ch)
            {
                str_7bit_ptr[offset] |= (UINT8) (1 << bit_count);
            }
            else
            {
                str_7bit_ptr[offset] &= (UINT8) ~ (1 << bit_count);
            }

            bit_count++;
        }

        if(ch == 0x1B && (i+1<max_ascii_length && ascii_str_ptr[i+1]))
        {
            i++;
            ch = ascii_str_ptr[i];
            for ( j = 0; j < 7; j++ )
            {
                if ( bit_count == 8 )
                {
                    bit_count = 0;
                    offset++;
                    str_7bit_ptr[offset] = 0x00;
                }
            
                if (( 1 << j ) & ch )
                {
                    str_7bit_ptr[offset] |= ( UINT8 )( 1 << bit_count );
                }
                else
                {
                    str_7bit_ptr[offset] &= ( UINT8 )~( 1 << bit_count );
                }
            
                bit_count++;
            }
        }
    }
}


int at_tok_nextu8(char **p_cur, unsigned int *p_out)
{
    char temp_a[3] = {0};
    long l = 0;
    char *end = NULL;
    if (*p_cur == NULL||*(*p_cur) == '\0') {
        return -1;
    }
    strncpy(temp_a, *p_cur, 2);

    *p_cur += 2;

    l = strtoul(temp_a, &end, 16);

    *p_out = (unsigned int)l;
    return 0;

}

static void handleSendSmsWithPack(char * pApdu) {
    SINT32 ret_val = ERR_NONE;
    char *cmd = NULL;    
    ATResponse *p_response = NULL;
    int index = 0;
    int index7bitByte = 0;

    memcpy(stk_cmd_detail_st.m_data, pApdu, strlen(pApdu));

    stk_cmd_detail_st.m_data_len = 18;
    stk_cmd_detail_st.m_data_pdu_len = 17;

    char* pCmdBuffer = (char*)malloc(sizeof(UINT8)* AT_CMD_STR_MAX_LEN);
    memset(pCmdBuffer, 0x00, sizeof(UINT8)* AT_CMD_STR_MAX_LEN);

    char* pDataBuffer = (char*)malloc(sizeof(UINT8)* AT_CMD_STR_MAX_LEN);
    memset(pDataBuffer, 0x00, sizeof(UINT8)* AT_CMD_STR_MAX_LEN);

    char* pCursor = NULL;

    pCursor = pApdu;

    // 1. copy smsc to pCmdBuffer
//    int nSmscStrLength = (stk_cmd_detail_st.m_data_len - stk_cmd_detail_st.m_data_pdu_len) * 2;
//    strncpy(pCmdBuffer, pApdu, nSmscStrLength);
    int nSmscStrLength = 0;
    STR_2_U8(pCursor, nSmscStrLength);
    nSmscStrLength++;
    nSmscStrLength *= 2;
    strncat(pCmdBuffer, pCursor, nSmscStrLength);
    pCursor += nSmscStrLength; //010008810156080000000653494D435850


    // 2. parse message type
    int nStrOffsetForTPVP = 0;
    BOOL bIsExistUDHI = FALSE;
    unsigned int temp_int;
    unsigned char byte1 = 0;
    char* temp_in = pCursor;

    if(at_tok_nextu8(&temp_in, &temp_int) == 0)
    {
        byte1 = (unsigned char)temp_int;

        switch(((SC_SMS_SUB_BYTE1*)&byte1)->v_vpf)
        {
          case TP_VP_NOT_PRESENT:
            nStrOffsetForTPVP = 0;
            break;
          case TP_VP_ENHANCED_FORMAT:
            nStrOffsetForTPVP = TP_VP_ENHANCED_FORMAT_STR_OFFSET;
            break;
          case TP_VP_RELATIVE_FORMAT:
            nStrOffsetForTPVP = TP_VP_RELATIVE_FORMAT_STR_OFFSET;
            break;
          case TP_VP_ABSOLUTE_FORMAT:
            nStrOffsetForTPVP = TP_VP_ABSOLUTE_FORMAT_STR_OFFSET;
            break;
          default:
            break;
        }

        if (((SC_SMS_SUB_BYTE1*)&byte1)->v_udhi == 1)
            bIsExistUDHI = TRUE;
    }

//    // 3. copy info to pCmdBuffer and move to pdu data
//    int nSettingLength = 0;
//    int nAddressStrLength = 0;
//
//    // number length
//    STR_2_U8((&pCursor[DESTINATION_ADDRESS_OFFSET_INDEX]), nAddressStrLength);//08:strlen, type:81 str:01560800
//
//    nSettingLength = (APDU_HEADER_TYPE_STR_LENGTH + TP_MR_STR_LENGTH + nAddressStrLength + DESTINATION_ADDRESS_META_STR_LENGTH
//        + TP_PID_STR_LENGTH + TP_DCS_STR_LENGTH + nStrOffsetForTPVP);
//
//    strncpy(pCmdBuffer + nSmscStrLength, pCursor, nSettingLength);
//
//    pCursor += nSettingLength;//0653494D435850

    /* byte 1 */
    strncat(pCmdBuffer, pCursor, 2);
    pCursor += 2;

    /* Message Reference */
    strncat(pCmdBuffer, pCursor, 2);
    pCursor += 2;

    /* Destination Address */
    int nAddressStrLength = 0;
    STR_2_U8(pCursor, nAddressStrLength);
    if((nAddressStrLength % 2) == 1)    nAddressStrLength++;
    nAddressStrLength += (2 * 2);
    strncat(pCmdBuffer, pCursor, nAddressStrLength);
    pCursor += nAddressStrLength;

    /* PID */
    strncat(pCmdBuffer, pCursor, 2);
    pCursor += 2;

    /* DCS ==> 7bit ref: 23.038 V5.0.0 */
    // modify [by chenshu 2012-01-04] for fix [Bug00005505]
    /*original code
    strncat(pCmdBuffer, pCursor, 2);
    */
    UINT8   dcs = 0;
    char    tmpBuf[4] = "";
    char    *pTmp = tmpBuf;

    STR_2_U8(pCursor, dcs);

    dcs = dcs & 0xF3;

    U8_2_STR(dcs, pTmp);
    strncat(pCmdBuffer, tmpBuf, 2);
    pCursor += 2;
    // modify [by chenshu 2012-01-04] end

    /* Validity Period */
    strncat(pCmdBuffer, pCursor, nStrOffsetForTPVP);
    pCursor += nStrOffsetForTPVP;

    int nSettingLength = APDU_HEADER_TYPE_STR_LENGTH
            + TP_MR_STR_LENGTH
            + nAddressStrLength
            + TP_PID_STR_LENGTH
            + TP_DCS_STR_LENGTH
            + nStrOffsetForTPVP;

    // 3. parse pdu data and convert 
    int nTotalDataByteLength;
    STR_2_U8(pCursor, nTotalDataByteLength);//06

    char c7bitByteLenght[3] = {0,0,0};
    char* pQ = c7bitByteLenght;
    U8_2_STR(nTotalDataByteLength, pQ);

    // 3.1 copy pdu length to pCmdBuffer
    strcat(pCmdBuffer, c7bitByteLenght);
    pCursor += 2;

    // 3.2 check bIsExistUDHI
    int nUdhByteLength = 0;
    if (bIsExistUDHI) {
        char *pUdh = (char *)malloc(sizeof(char)*(AT_CMD_STR_MAX_LEN));
        memset(pUdh, 0x00, sizeof(char)* (AT_CMD_STR_MAX_LEN));

        STR_2_U8(pCursor, nUdhByteLength);

        strncpy(pUdh, pCursor, (nUdhByteLength*2 + 2));
        strcat(pCmdBuffer, pUdh);
        free(pUdh);
        pUdh = NULL;
    }

    int nDataByteLength = 0;
    if (nUdhByteLength > 0) {
        nDataByteLength = nTotalDataByteLength - (nUdhByteLength + 1);
        pCursor += (nUdhByteLength*2 + 2);
    }
    else {
        nDataByteLength = nTotalDataByteLength;
    }


    UINT8 *ascii_str_ptr = (UINT8 *)malloc(sizeof(UINT8)*(nDataByteLength +1));
    memset(ascii_str_ptr, 0x00, sizeof(UINT8)* (nDataByteLength +1));

    UINT8 *str_7bit_ptr = (UINT8 *)malloc(sizeof(UINT8)*(nDataByteLength +1)); 
    memset(str_7bit_ptr, 0x00, sizeof(UINT8)* (nDataByteLength +1));

    // 3.2 byte data array
    for(index = 0; index < nDataByteLength; index++) {
        STR_2_U8(pCursor, ascii_str_ptr[index]);
        pCursor += 2;
    }

    g_sc_util_ascii_to_7bit(ascii_str_ptr, str_7bit_ptr, nDataByteLength);

    int n7bitByteLength = 0;

    n7bitByteLength = strlen((char*)str_7bit_ptr);

    for(index7bitByte = 0; index7bitByte < n7bitByteLength; index7bitByte++) {
        char t[3] = {0,0,0};
        char* pT = t;
        U8_2_STR(str_7bit_ptr[index7bitByte], pT);
        strcat(pDataBuffer, t);
    }

    // 4. calculate cmdLength
    int nCmdLength = 0;
    if (nUdhByteLength > 0) 
    {
        nCmdLength = nSettingLength/2 + (nUdhByteLength*2 + 2)/2 + n7bitByteLength + 1 ;
    }
    else
    {
        nCmdLength = nSettingLength/2 + n7bitByteLength + 1;
    }

    // 5. copy data to pCmdBuffer
    strcat(pCmdBuffer, pDataBuffer);

    // 6. send sms
    //pCmdBuffer, nCmdLength

    DBBD(DB_RIL, RLOGD("[STK] in at_stk_send_sms pCmdBuffer = %s", pCmdBuffer));
    DBBD(DB_RIL, RLOGD("[STK] in at_stk_send_sms nCmdLength= %d", nCmdLength));

    asprintf(&cmd, "AT+CMGS=%d", nCmdLength);

    DBBD(DB_RIL, RLOGD("[STK] in at_stk_send_sms cmd = %s", cmd));

    ret_val = at_send_command_sms(cmd, pCmdBuffer, "+CMGS:", &p_response);
    DBBD(DB_RIL, RLOGD("[STK] in handleSendSmsWithPack ret_val = %d,p_response->success = %d", ret_val, p_response->success));
    if (ret_val != 0 || (p_response != NULL && p_response->success == 0)) { 
        stk_send_terminal_response( STK_RESULT_20, NULL );
    }
    else {
        stk_send_terminal_response( STK_RESULT_00, NULL );
    } 

    free(cmd);
    free(pCmdBuffer);
    free(pDataBuffer);
    free(ascii_str_ptr);
    free(str_7bit_ptr);
    at_response_free(p_response);
}
/* Leadcore:end fix_bug00004085, 20110901, chengyuxin, supporting Command Qualifier: 0x01(1) - SMS packing by the ME required*/

/* Leadcore: fix Bug00001073, 20110321, chengyuxin, clear the send sms function*/
static void *at_stk_send_sms()
{
    SINT32 ret_val = ERR_NONE;
    char *cmd = NULL;    
    UINT8 cmd_buf[AT_CMD_STR_MAX_LEN];
    ATResponse *p_response = NULL;
    
    /* If the STK says "SMS packing by the ME required", then we just change
     * the DCS to "8 bit data".
     * Note:
     *     It is really not a good way to resolve it. It's better to
     *     re-encode the user data, but it is much more complicated.
     */
    if( stk_cmd_detail_st.m_cmd_qualifier )
    {
        handleSendSmsWithPack((char *)stk_cmd_detail_st.m_data);
       
        return NULL;
    }

    asprintf(&cmd, "AT+CMGS=%ld", stk_cmd_detail_st.m_data_pdu_len);

    DBBD(DB_RIL, RLOGD("[STK] in at_stk_send_sms cmd = %s", cmd));

    memset( &(cmd_buf), 0x00, AT_CMD_STR_MAX_LEN  );

    //modification for parse sms address
    //cmd_buf[0] = '0';
    //cmd_buf[1] = '0';
    memcpy( &(cmd_buf[0]),
            stk_cmd_detail_st.m_data,
            (stk_cmd_detail_st.m_data_len) * 2 );

    DBBD(DB_RIL, RLOGD("[STK] in at_stk_send_sms m_data = %s", stk_cmd_detail_st.m_data));
    DBBD(DB_RIL, RLOGD("[STK] in at_stk_send_sms m_buf_a = %s", cmd_buf));
    
    ret_val = at_send_command_sms(cmd,(char *) cmd_buf, "+CMGS:", &p_response);
    if(p_response != NULL){
        DBBD(DB_RIL, RLOGD("[STK] in at_stk_send_sms ret_val = %d,p_response->success = %d", ret_val, p_response->success));
    } else {
        DBBD(DB_RIL, RLOGD("[STK] in at_stk_send_sms ret_val = %d,p_response is NULL", ret_val));
    }
    if (ret_val != 0 || (p_response != NULL && p_response->success == 0)) {
        stk_send_terminal_response( STK_RESULT_20, NULL );
    }
    else {
        stk_send_terminal_response( STK_RESULT_00, NULL );
    } 

    at_response_free(p_response);
    free(cmd);
    return NULL;
}

static void *auto_send_sms_loop( void *param )
{
    /* Since Android does not support pthread_cancel(), so here we use signal
     * to inform the thread exit.
     */
    //signal(PUB_UTIL_THREAD_END_SIGNAL, pub_util_handle_thread_signal);
    DBBD(DB_RIL, RLOGD("[STK] in auto_send_sms_loop"));
    at_stk_send_sms();

    return NULL;
}

static void *auto_send_terminal_rsp_loop( void *param )
{
    /* Since Android does not support pthread_cancel(), so here we use signal
     * to inform the thread exit.
     */
    //signal(PUB_UTIL_THREAD_END_SIGNAL, pub_util_handle_thread_signal);

    stk_send_terminal_response( STK_RESULT_20, NULL);

    return NULL;
}
/* Leadcore End: stk utility functions*/

static void *auto_send_terminal_rsp_ok_loop( void *param )
{
    stk_send_terminal_response( STK_RESULT_00, NULL);

    return NULL;
}

/* Leadcore Begin: stk functions*/
void requestStkSendTerminalResponse(void *data, size_t datalen, RIL_Token t)
{
    int err = 0;
    char *cmd = NULL;
    char *line;
    const char *prefix;
    ATResponse *p_response = NULL;
    UINT8   apdu_a[STK_APDU_MAX_LEN*2+1] = {0};         /* APDU to modem, with ascii format */
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = sizeof(apdu_a) - 1;
    SINT32  ret_val = 0;
    int len = strlen(data);
    char *sw;

    DBBD(DB_RIL, RLOGD("[STK] data= %s, data[0] = %c, datalen = %d", (char*)data, ((char*)data)[0], datalen));
    /* Build the TERMINAL RESPONSE, the structure of APDU data refer to: ts_102.223 6.8 */
    ret_val = at_stk_pack_apdu(
        (UINT8*)data,
        len,
        STK_CMD_HEAD_INS_TERMINAL_RESPONSE,
        apdu_a,
        &apdu_len,
        &apdu_free_len );

    if (ret_val != 0) goto error;
    DBBD(DB_RIL, RLOGD("[STK] apdu %s\n", apdu_a));

    asprintf(&cmd, "AT+CSIM=%lu,%s", apdu_len, (char*)apdu_a);
    prefix = "+CSIM:";

    pthread_t tid = pthread_self();
    DBBD(DB_RIL, RLOGD("[STK] TerminalResponse thread id=%8ld\n", tid));
    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (NULL != cmd)
    {
        free(cmd);
        cmd = NULL;
    }

/* FIX L1809OG_Bug00000407 2011-01-31 zoufeng begin */
//  if (err != 0) goto error;
    if (err != 0 || p_response->success == 0) goto error;
/* FIX L1809OG_Bug00000407 2011-01-31 zoufeng end */

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &len);
    if (err < 0) goto error;
    DBBD(DB_RIL, RLOGD("[STK] len %d\n", len));

    if (len != 4) goto error;

    err = at_tok_nextstr(&line, &sw);
    if (err < 0) goto error;
    DBBD(DB_RIL, RLOGD("[STK] sw %s\n", sw));
    if ((sw[0] == '9') && ((sw[1] == '0') || (sw[1] == '1'))) {
        if (sw[1] == '0') {
            DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_STK_SESSION_END"));
            RIL_onUnsolicitedResponse (RIL_UNSOL_STK_SESSION_END, NULL, 0);
        }
    } else {
        goto error;
    }

    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS,  NULL, 0);
    return;

error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

void  requestStkSendEnvelopeCommand(void *data, size_t datalen, RIL_Token t)
{
    int err = 0;
    char *cmd = NULL;
    char *line;
    const char *prefix;
    ATResponse *p_response = NULL;
    UINT8   apdu_a[STK_APDU_MAX_LEN*2+1] = {0};         /* APDU to modem, with ascii format */
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = sizeof(apdu_a) - 1;
    SINT32  ret_val = 0;
    int len = strlen(data);
    char *response = NULL;

    DBBD(DB_RIL, RLOGD("[STK] requestStkSendEnvelopeCommand data= %s", (char*)data));
    /* Build the ENVELOPE RESPONSE, the structure of APDU data refer to: ts_102.223*/
    ret_val = at_stk_pack_apdu(
        (UINT8*)data,
        len,
        STK_CMD_HEAD_INS_ENVELOPE,
        apdu_a,
        &apdu_len,
        &apdu_free_len );

    if (ret_val != 0) goto error;
    DBBD(DB_RIL, RLOGD("[STK] apdu %s\n", apdu_a));

    asprintf(&cmd, "AT+CSIM=%lu,%s", apdu_len, (char*)apdu_a);
    prefix = "+CSIM:";

    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (cmd != NULL)
    {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    DBBD(DB_RIL, RLOGD("[STK] line= %s\n", line));

    err = at_tok_start(&line);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &len);
    if (err < 0) goto error;
    err = at_tok_nextstr(&line, &response);
    if (err < 0) goto error;

    DBBD(DB_RIL, RLOGD("[STK] response= %s\n", response));
    if ((response[0] == '9') && ((response[1] == '0') || (response[1] == '1'))) {
        if (response[1] == '0')
        {
            DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_STK_SESSION_END"));
            RIL_onUnsolicitedResponse (RIL_UNSOL_STK_SESSION_END, NULL, 0);
        }
    } else {
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS,  response, strlen(response));
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void setTimespecRelative(struct timespec *p_ts, long long msec)
{
    struct timeval tv;

    gettimeofday(&tv, (struct timezone *) NULL);

    /* what's really funny about this is that I know
       pthread_cond_timedwait just turns around and makes this
       a relative time again */
    p_ts->tv_sec = tv.tv_sec + (msec / 1000);
    p_ts->tv_nsec = (tv.tv_usec + (msec % 1000) * 1000L ) * 1000L;
}

void requestStkSendEnvelopeWithStatus(void *data, size_t datalen, RIL_Token t)
{
    int err = 0;
    char *cmd = NULL;
    char *line;
    const char *prefix;
    ATResponse *p_response = NULL;
    UINT8   apdu_a[STK_APDU_MAX_LEN*2+1] = {0};         /* APDU to modem, with ascii format */
    UINT32  apdu_len = 0;
    UINT32  apdu_free_len = sizeof(apdu_a) - 1;
    SINT32  ret_val = 0;
    int len = strlen(data);
    char *response = NULL;
    RIL_SIM_IO_Response sr;

    memset(&sr, 0, sizeof(sr));

    DBBD(DB_RIL, RLOGD("[STK] requestStkSendEnvelopeWithStatus data= %s", (char*)data));
    /* Build the ENVELOPE RESPONSE, the structure of APDU data refer to: ts_102.223*/
    ret_val = at_stk_pack_apdu(
        (UINT8*)data,
        len,
        STK_CMD_HEAD_INS_ENVELOPE,
        apdu_a,
        &apdu_len,
        &apdu_free_len );

    if (ret_val != 0) goto error;
    DBBD(DB_RIL, RLOGD("[STK] apdu %s\n", apdu_a));

    asprintf(&cmd, "AT+CSIM=%lu,%s", apdu_len, (char*)apdu_a);
    prefix = "+CSIM:";
    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (cmd != NULL)
    {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    DBBD(DB_RIL, RLOGD("[STK] line= %s\n", line));

    err = at_tok_start(&line);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &len);
    if (err < 0) goto error;
    err = at_tok_nextstr(&line, &response);
    if (err < 0) goto error;

    DBBD(DB_RIL, RLOGD("[STK] response= %s\n", response));
    if ((response[0] == '9') && ((response[1] == '0') || (response[1] == '1')) && strlen(response) == 4) {
        if (response[1] == '0')
        {
            DBBD(DB_RIL, RLOGD("[STK] RIL_UNSOL_STK_SESSION_END"));
            RIL_onUnsolicitedResponse (RIL_UNSOL_STK_SESSION_END, NULL, 0);
        }
    } else {
        DBBD(DB_RIL, RLOGE("[STK] goto error !!!!!"));
        goto error;
    }

    sr.sw1 = (response[0] - '0') << 4 | (response[1] - '0');
    sr.sw2 = (response[2] - '0') << 4 | (response[3] - '0');
    pthread_mutex_lock(&s_stk_send_envelope_mutex);
    if (response[1] == '1' && sr.sw2 > 0 && s_sw2_val == 0)
    {
        struct timespec ts;
        long long timeoutMsec = 60*1000;

        s_sw2_val = sr.sw2;
        setTimespecRelative(&ts, timeoutMsec);
        RLOGD("[STK]begin wait response for s_stk_send_envelops_str: %s", s_stk_send_envelops_str);
        pthread_cond_timedwait(&s_stk_send_envelope_cond, &s_stk_send_envelope_mutex, &ts);
        RLOGD("[STK]end wait response for s_stk_send_envelops_str: %s", s_stk_send_envelops_str);
        sr.simResponse = s_stk_send_envelops_str;
        s_sw2_val = 0;
    }
    pthread_mutex_unlock(&s_stk_send_envelope_mutex);
    DBBD(DB_RIL, RLOGD("[STK] sw1 = 0x%x, sw2 = 0x%x, simResponse = %s", sr.sw1, sr.sw2, sr.simResponse));

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &sr, sizeof(sr));

    if(s_stk_send_envelops_str != NULL) {
        free(s_stk_send_envelops_str);
        s_stk_send_envelops_str = NULL;
    }

    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

int handleStkEnvelope(char *response, int length) {
    int tlv_len = 0;
    int isHandled = 0;
    int high_lr = 0;
    int low_lr = 0;
    int temp_lr = 0;
    int lr = 0;
    char *pos = response;
    int rspLen = strlen(response);

    tlv_len = length;
    STR_2_U8(pos, lr);
    temp_lr = (lr + 3) * 2;//len + data + sw1 + sw2
    RLOGD("[STK]get response for len+data+sw1+sw2_lr = %d, tlv_len = %d", temp_lr, tlv_len);

    if( temp_lr != tlv_len)
    {
        b_lr_exp_len = TRUE;
        STR_2_U8(pos, high_lr);
        pos += 2;
        STR_2_U8(pos, low_lr);
        lr = (high_lr<<8) + low_lr;
        RLOGD("[STK]get response for lr = %d, high_lr = %d, low_lr = %d", lr, high_lr, low_lr);
    }

    pos += 2;

    pthread_mutex_lock(&s_stk_send_envelope_mutex);
    if (s_sw2_val == lr) {
        int len = 0;
        int tag = 0;
        int isSmsPdu = 0;

        pos += 4;
        while(pos < (response + rspLen)) {
            STR_2_U8(pos, tag); pos += 2;
            CONVERT_STK_TAG(tag);
            if(STK_TAG_SMS_TPDU == tag) {
                STR_2_U8(pos, len); pos += 2;
                isSmsPdu = 1;
                RLOGD("[STK]get response for: %d", s_sw2_val);
                break;
            } else {
                STR_2_U8(pos, len); pos += 2;
                pos += (len * 2);
            }
        }

        if(isSmsPdu) {
            s_sw2_val = 0;
            if(s_stk_send_envelops_str != NULL) {
                free(s_stk_send_envelops_str);
                s_stk_send_envelops_str = NULL;
            }
            s_stk_send_envelops_str = (char *)malloc((len * 2) + 1);
            if(s_stk_send_envelops_str != NULL) {
                memset(s_stk_send_envelops_str, 0x00, ((len * 2) + 1));
                strncpy(s_stk_send_envelops_str, pos, (len * 2));
            } else {
                RLOGE("[STK]malloc(s_stk_send_envelops_str) failed!");
            }
            pthread_cond_signal(&s_stk_send_envelope_cond);
            isHandled = 1;
        }
    }
    pthread_mutex_unlock(&s_stk_send_envelope_mutex);

    return isHandled;
}

void handleStkProactiveCommand(const char *s, const char *sms_pdu)
{
    char *line = NULL;
    char *p = NULL;
    char *response = NULL;
    char* pResponseCommand = NULL;
    int length = 0, err = 0, nResponseLength = 0;
    UINT8** begin_ptr;
    int nProactiveCommandType = 0;
    int isHandled = 0;
    b_lr_exp_len = FALSE;

    DBBD(DB_RIL, RLOGD("[STK] in handleStkProactiveCommand\n"));    
    if (s == NULL)
    {
        DBBD(DB_RIL, RLOGD("invalid DTUSATURC command\n"));
        return;
    }

    //get length and command
    p = line = strdup(s);
    err = at_tok_start(&p);
    begin_ptr = (UINT8**)(&p);
    if (err < 0) goto error;

    err = at_tok_nextint(&p, &length);
    if (err < 0) goto error;

    DBBD(DB_RIL, RLOGD("[STK] handleStkProactiveCommand response length=%d\n", length));

    if(at_tok_hasmore(&p) == 0) goto error;

    err = at_tok_nextstr(&p, &(response));
    if (err < 0)  goto error;

    DBBD(DB_RIL, RLOGD("[STK] handleStkProactiveCommand response=%s\n", response));

    nResponseLength = strlen(response);
    DBBD(DB_RIL, RLOGD("[STK] handleStkProactiveCommand nResponseLength =%d\n", nResponseLength));
    if(strlen(response) <= STK_UNSOL_CMD_DEL_COUNT) goto error;

    isHandled = handleStkEnvelope(response, length);
    DBBD(DB_RIL, RLOGD("[STK] handleStkProactiveCommand isHandled =%d\n", isHandled));
    if(isHandled) {
        pthread_t   thread_id;

        pthread_create( &thread_id,
                NULL,
                auto_send_terminal_rsp_ok_loop,
                NULL );
        goto done;
    }

    nProactiveCommandType = preHandleProactiveStk(&s, length);
    DBBD(DB_RIL, RLOGD("[STK] handleStkProactiveCommand nProactiveCommandType =%d\n", nProactiveCommandType));
    if (nProactiveCommandType == -1) {
        pthread_t   thread_id;
        pthread_create( &thread_id,
        NULL,
        auto_send_terminal_rsp_loop,
        NULL );  
        goto done;
    }
#ifdef USE_AP_STK_MODE

    /* Leadcore: fix Req00000143, chengyuxin, 20110223, Add refresh tag refer to: ts_102.223-9.4 */
    if (nProactiveCommandType == RIL_UNSOL_SIM_REFRESH) {
        goto done;
    }
#endif

    DBBD(DB_RIL, RLOGD("[STK] handleStkProactiveCommand b_lr_exp_len=%d\n", b_lr_exp_len));
    if(b_lr_exp_len)
    {
        pResponseCommand = (char*)malloc(sizeof(char)*(nResponseLength - 7));
        if (pResponseCommand == NULL)  goto error;
        pResponseCommand[0] = '\0';
        strncpy(pResponseCommand, response + 4, (nResponseLength - 8));
        pResponseCommand[nResponseLength - 8] = '\0';
    } else {
        pResponseCommand = (char*)malloc(sizeof(char)*(nResponseLength - STK_UNSOL_CMD_DEL_COUNT +1));
        if (pResponseCommand == NULL)  goto error;
        pResponseCommand[0] = '\0';
        strncpy(pResponseCommand, response + STK_UNSOL_CMD_HEAD_COUNT, (nResponseLength - STK_UNSOL_CMD_DEL_COUNT));
        pResponseCommand[nResponseLength -STK_UNSOL_CMD_DEL_COUNT] = '\0';
    }

    DBBD(DB_RIL, RLOGD("[STK] handleStkProactiveCommand Command=%s, len=%d, Type=%d\n", pResponseCommand, strlen(pResponseCommand), nProactiveCommandType));

    pthread_t   tid = pthread_self();
    RIL_onUnsolicitedResponse (nProactiveCommandType, pResponseCommand, strlen(pResponseCommand));

    free(pResponseCommand);
    pResponseCommand = NULL;
done:
error:
    if (line != NULL)
    {
        free(line);
        line = NULL;
    }
}

// add [by chenshu 2012-02-15] for send_ussd
static void *auto_send_ussd_loop( void *param )
{
    char*            cmd = NULL;
    ATResponse*      p_response = NULL;
    UINT8            dcs = 0;
    char*            line = NULL;
    int              mResponse = 0;
    char*            strResponse = NULL;
    int              dcsResponse;
    UINT8*           data = stk_cmd_detail_st.m_data;
    UINT8*           rspData = NULL;

    STR_2_U8(data, dcs);
    data += 2;

    RLOGD("in auto_send_ussd_loop: dcs = %d", dcs);
    if (0xFF != dcs) {
        int err;
        asprintf(&cmd, "AT+CUSD=%d,\"%s\",%d", 1, data, dcs);
        err = at_send_command_singleline_timeout(cmd, "+CUSD:", 6000, &p_response);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }

        if (err != 0 || (p_response != NULL && p_response->success == 0)) {
            goto error;
        }

        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &mResponse);
        if (err < 0) goto error;
        err = at_tok_nextstr(&line, &strResponse);
        err = at_tok_nextint(&line, &dcsResponse);

        if(strResponse == NULL || mResponse > 1) {
            RLOGD("STK_RESULT_37");
            stk_send_terminal_response( STK_RESULT_37, NULL );
        }else {
            int nStrResponseLen = strlen(strResponse)/2;
            RLOGD("STK_RESULT_00: strlen = %d", nStrResponseLen);
            rspData = (UINT8*)malloc(sizeof(UINT8)*(3+nStrResponseLen));
            rspData[0] = STK_TAG_TEXT_STRING;
            rspData[1] = 1 + nStrResponseLen;
            rspData[2] = dcsResponse;
            char* strTemp = strResponse;
            int index = 0;
            int rspDataIndex = 3;
            for(; index < nStrResponseLen; index++) {
                STR_2_U8(strTemp, rspData[rspDataIndex]);
                rspDataIndex++;
                strTemp += 2;
            }
            stk_send_terminal_response( STK_RESULT_00, rspData );
        }
    }else {
        stk_send_terminal_response( STK_RESULT_20, NULL );
        RLOGD("USSD DCS is not correct!");
    }
    at_response_free(p_response);
    free(rspData);
    return NULL;

error:
    RLOGD("STK_RESULT_21");
    stk_send_terminal_response( STK_RESULT_21, NULL );
    at_response_free(p_response);

    return NULL;
}
// add [by chenshu 2012-02-15] end
// add [by chenshu 2012-02-15] for poll interval/off
static void *auto_deal_poll_interval( void *param )
{
    char*            cmd = NULL;
    int              err;
    ATResponse*      p_response = NULL;
    UINT8            timeUint = 0;
    UINT8            timeInterval = 0;
    UINT8            tempTime = 0;
    UINT8*           rspData = NULL;
    UINT8*           data = stk_cmd_detail_st.m_data;

    STR_2_U8(data, timeUint);
    data += 2;

    STR_2_U8(data, timeInterval);

    RLOGD("in auto_deal_poll_interval, timeUint = %d, timeInterval = %d",timeUint, timeInterval);

    switch (timeUint) {
        case 0: tempTime = timeInterval*60; break;
        case 1: tempTime = timeInterval; break;
        case 2: tempTime = timeInterval/10; break;
    }
    // [Modem] The maximum of interval time is 30S
    if (tempTime > 30) {
        timeUint = 1;
        timeInterval = 15;
    }

    asprintf(&cmd, "AT^DUSATP=0,%d,%d", timeUint, timeInterval);
    err = at_send_command(cmd, &p_response);

    if (err != 0 || (p_response != NULL && p_response->success == 0)) {
        stk_send_terminal_response( STK_RESULT_20, NULL);
        RLOGD("AT^DUSATP, error!");
    }else {
        rspData = (UINT8*)malloc(sizeof(UINT8)*4);
        rspData[0] = STK_TAG_DURATION;
        rspData[1] = 2;
        rspData[2] = timeUint;
        rspData[3] = timeInterval;
        stk_send_terminal_response( STK_RESULT_00, rspData);
    }
    at_response_free(p_response);
    free(cmd);
    free(rspData);
    return NULL;
}

static void *auto_deal_poll_off( void *param )
{
    int              err;
    ATResponse*      p_response = NULL;

    RLOGD("in auto_deal_poll_off");

    err = at_send_command("AT^DUSATP=1", &p_response);

    if (err != 0 || (p_response != NULL && p_response->success == 0)) {
        stk_send_terminal_response( STK_RESULT_20, NULL);
        RLOGD("AT^DUSATP, error!");
    }else {
        stk_send_terminal_response( STK_RESULT_00, NULL);
    }
    at_response_free(p_response);
    return NULL;
}

// add [by chenshu 2012-02-15] end

static void *auto_hungup_allcs( void *param )
{
    int              err;
    ATResponse*      p_response = NULL;

    RLOGD("in auto_hungup_allcs");

    err = at_send_command("AT^DHUP=0,17", &p_response);
    if (err != 0 || (p_response != NULL && p_response->success == 0)) {
        RLOGD("auto_hungup_allcs_first, error!");
    }
    at_response_free(p_response);
    p_response = NULL;

    err = at_send_command("AT^DHUP=1,17", &p_response);
    if (err != 0 || (p_response != NULL && p_response->success == 0)) {
        RLOGD("auto_hungup_allcs_second, error!");
    }
    at_response_free(p_response);
    return NULL;
}

//FIX:3gpp-31.124[27.22.#.##.#] 20141115 begin
//27.22.4.15.1/14
static void *auto_access_techology( void *param )
{
    UINT8*           rspData = NULL;
    int err;
    int actmode = -1;
    int exchanged_mode = -1;
    ATResponse *p_response = NULL;
    const char *cmd;
    const char *prefix;
    char *line, *p;
    int commas = -1;
    int skip;
    RLOGD("auto_access_techology...");

    cmd = "AT^DACTI?";
    prefix = "^DACTI:";//<act>: integer type,indicate current access technology

    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;
    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }

    switch (commas) {
        case 1:
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &actmode);
            if (err < 0) goto error;
            break;
        default:
            goto error;
    }
    RLOGD("auto_access_techology, before actmode=%d", actmode);

    switch (actmode) {
        case 0:
        case 1:
            exchanged_mode = 0;
            break;
        case 2:
            exchanged_mode = 3;
            break;
        case 7:
            exchanged_mode = 8;
            break;
        default:
            goto error;
    }
    RLOGD("auto_access_techology, exchanged_mode=%d", exchanged_mode);

    rspData = (UINT8*)malloc(sizeof(UINT8) * 3);
    rspData[0] = 0x3F;
    rspData[1] = 1;
    rspData[2] = exchanged_mode;
    stk_send_terminal_response( STK_RESULT_00, rspData);

    at_response_free(p_response);
    //free(cmd);
    free(rspData);
    return NULL;
error:
    RLOGD("auto_access_techology,STK_RESULT_21");
    stk_send_terminal_response( STK_RESULT_21, NULL );
    at_response_free(p_response);
    return NULL;
}

//27.22.4.15.1/15-timing advance
static void *auto_network_measurement_timing_advance( void *param )
{
    UINT8*         rspData = NULL;
    int err;
    ATResponse *p_response = NULL;
    const char *cmd = NULL;
    const char *prefix;
    char *line;
    USAT_DLOCIN *local_info_result;

    local_info_result = (USAT_DLOCIN *)alloca(sizeof(USAT_DLOCIN));
    if(local_info_result == NULL) goto error;

    memset (local_info_result, 0, sizeof(USAT_DLOCIN));

    RLOGD(">>>auto_network_measurement_timing_advance...");
    asprintf(&cmd, "AT^DLOCIN=1");
    prefix = "^DLOCIN:";

    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(local_info_result->info_type));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(local_info_result->length));
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &(local_info_result->info_string));
    if (err < 0) goto error;

    int local_info_len = local_info_result->length;
    int len_resp = local_info_len / 2;
    RLOGD(">>>local_info_len= %d,len_resp=%d", local_info_len,len_resp);
    rspData = (UINT8*)malloc(sizeof(UINT8) * (len_resp + 2));//2:tag and len
    if (NULL == rspData)
        goto error;
    //810301260582028281830100AE020000
    rspData[0] = 0xAE;
    rspData[1] = 0x02;
    if(len_resp > 0)
    {
        //info_string
        char* str_local_info = local_info_result->info_string;
        int rspDataIndex = 2;
        RLOGD(">>>str_local_info= %d", strlen(str_local_info));

        int local_info_index = 0;
        int local_len = local_info_len/2;
        for(; local_info_index < local_len; local_info_index++) {
            STR_2_U8(str_local_info, rspData[rspDataIndex]);
            rspDataIndex++;
            str_local_info += 2;
        }
    }
    else
    {
        rspData[2] = 0x00;
        rspData[3] = 0x00;
    }

    stk_send_terminal_response( STK_RESULT_00, rspData);
    RLOGD("auto_network_measurement_timing_advance----success----");

    at_response_free(p_response);
    if (NULL != rspData)
        free(rspData);

    return NULL;

error:
    RLOGD("auto_network_measurement_timing_advance,STK_RESULT_21");
    stk_send_terminal_response( STK_RESULT_21, NULL );
    at_response_free(p_response);

    return NULL;
}

//27.22.4.15.1/15-network measurement results and BCCH channel list
static void *auto_network_measurement_result( void *param )
{
    UINT8*         rspData = NULL;
    int err;
    ATResponse *p_response = NULL;
    const char *cmd = NULL;
    const char *prefix;
    char *line;
    USAT_DLOCIN *local_info_result;

    local_info_result = (USAT_DLOCIN *)alloca(sizeof(USAT_DLOCIN));
    if(local_info_result == NULL) goto error;

    memset (local_info_result, 0, sizeof(USAT_DLOCIN));

    RLOGD(">>>auto_network_measurement_result... ...");
    asprintf(&cmd, "AT^DLOCIN=0,0");
    prefix = "^DLOCIN:";

    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err != 0 || p_response->success == 0) goto error;
    //^DLOCIN:0,0,""

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(local_info_result->info_type));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(local_info_result->length));
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &(local_info_result->info_string));
    if (err < 0) goto error;

    int local_info_len = local_info_result->length;
    RLOGD(">>>local_info_len: %d", local_info_len);

    if(local_info_len > 0)
    {
        int len_resp = local_info_len / 2;
        RLOGD(">>>len_resp=%d", len_resp);
        rspData = (UINT8*)malloc(sizeof(UINT8) * (len_resp + 2));//2:tag and len
        rspData[0] = 0x96;
        //info_string
        char* str_local_info = local_info_result->info_string;
        int rspDataIndex = 2;
        int local_info_index = 0;
        int local_len = strlen(str_local_info)/2;

        RLOGD(">>>str_local_info= %d, local_len=%d", strlen(str_local_info),local_len);
        for(; local_info_index < local_len; local_info_index++) {
            STR_2_U8(str_local_info, rspData[rspDataIndex]);
            rspDataIndex++;
            str_local_info += 2;
        }

        rspData[1] = local_len;
        /*
        int len_resp = local_info_len / 2;
        RLOGD(">>>len_resp: %d", len_resp);
        rspData = (UINT8*)malloc(sizeof(UINT8) * (len_resp + 3));//2:tag and len and '02'
        rspData[0] = 0x96;
        //info_string
        char* str_local_info = local_info_result->info_string;
        int rspDataIndex = 3;
        int local_info_index = 0;
        int local_len = strlen(str_local_info)/2;

        RLOGD(">>>str_local_info= %d, local_len=%d", strlen(str_local_info),local_len);
        for(; local_info_index < local_len; local_info_index++) {
        STR_2_U8(str_local_info, rspData[rspDataIndex]);
        rspDataIndex++;
        str_local_info += 2;
        }

        rspData[1] = local_len + 1;//1:02
        rspData[2] = 0x02;
        */
    }
    else
    {
        //801400001581030126008202828183010096050200000000
        RLOGD(">>>96050200000000 for cmcc test...");
        rspData = (UINT8*)malloc(sizeof(UINT8) * 7);
        rspData[0] = 0x96;//tag
        rspData[1] = 0x05;//len
        rspData[2] = 0x02;
        rspData[3] = 0x00;
        rspData[4] = 0x00;
        rspData[5] = 0x00;
        rspData[6] = 0x00;
    }

    stk_send_terminal_response( STK_RESULT_00, rspData);
    RLOGD("auto_network_measurement_result----success----");

    at_response_free(p_response);
    if (NULL != rspData)
        free(rspData);

    return NULL;

error:
    RLOGD("auto_network_measurement_result,STK_RESULT_21");
    stk_send_terminal_response( STK_RESULT_21, NULL );
    at_response_free(p_response);

    return NULL;
}

//27.22.4.15.1/17
static void *auto_location_infomation( void *param )
{
    UINT8*         rspData = NULL;
    char *         temp_mcc  = NULL;
    char *         temp_mnc  = NULL;
    char *         temp_data = NULL;
    char *         temp_str  = NULL;
    int err;
    ATResponse *p_response = NULL;
    const char *cmd;
    const char *prefix;
    char *line;
    USAT_LocationInfomation *loca_info;

    loca_info = (USAT_LocationInfomation *)alloca(sizeof(USAT_LocationInfomation));
    if(loca_info == NULL) goto error;

    memset (loca_info, 0, sizeof(USAT_LocationInfomation));

    cmd = "AT^DCNT";
    prefix = "^DCNT:";

    //^DCNT:"425","01","0136","000080AB"
    err = at_send_command_singleline(cmd, prefix, &p_response);
    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &(loca_info->mcc));
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &(loca_info->mnc));
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &(loca_info->tac));
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &(loca_info->ci));
    if (err < 0) goto error;

    /*loca_info->mcc = "425";
    loca_info->mnc = "01";
    loca_info->tac = "0136";
    loca_info->ci  = "000080AB";*/
    int len = (strlen(loca_info->mcc) + strlen(loca_info->mnc) + strlen(loca_info->tac) + strlen(loca_info->ci))/2;
    RLOGD(">>>location_infomation:len = %d,mcc:%d,mnc:%d,lac:%d,ci:%d", len, strlen(loca_info->mcc), strlen(loca_info->mnc), strlen(loca_info->tac) ,strlen(loca_info->ci));

    //rspData
    rspData = (UINT8*)malloc(sizeof(UINT8) * (len + 1 + 2 ));//2:tag and len
    if (rspData == NULL) goto error;
    rspData[0] = 0x93;//tag

    //mcc-mnc
    temp_mcc = (char*)malloc(sizeof(char) * (strlen(loca_info->mcc) + 1));//'\0'
    if (temp_mcc == NULL) goto error;

    memset( temp_mcc, 0x00, strlen(loca_info->mcc) + 1);
    memcpy( temp_mcc, loca_info->mcc, strlen(loca_info->mcc));
    char mccmnc_str[6] = {0};
    mccmnc_str[0] = temp_mcc[1];//mcc2
    mccmnc_str[1] = temp_mcc[0];//mcc1
    mccmnc_str[3] = temp_mcc[2];//mcc3

    temp_mnc = (char*)malloc(sizeof(char) * (strlen(loca_info->mnc) + 1));//'\0'
    if (temp_mnc == NULL) goto error;

    memset(temp_mnc, 0x00, strlen(loca_info->mnc) + 1);
    memcpy( temp_mnc, loca_info->mnc, strlen(loca_info->mnc));
    if(strlen(loca_info->mnc) < 3)
    {
        mccmnc_str[2] = 'F';//mnc3
        mccmnc_str[4] = temp_mnc[1];//mnc2
        mccmnc_str[5] = temp_mnc[0];//mnc1
    }else
    {
        mccmnc_str[2] = temp_mnc[2];//mnc3
        mccmnc_str[4] = temp_mnc[1];//mnc2
        mccmnc_str[5] = temp_mnc[0];//mnc1
    }

    char *tempPtr = NULL;
    int rspDataIndex = 2;
    int mccmnc_index = 0;
    int mcc_mnc_len = sizeof(mccmnc_str)/sizeof(mccmnc_str[0]);
    RLOGD("auto_location_infomation,strlen(mccmnc_str)=%d",mcc_mnc_len);
    temp_data = (char*)malloc(sizeof(char) * (mcc_mnc_len + 1));
    if (temp_data == NULL) goto error;
    memset( temp_data, 0x00, mcc_mnc_len+1);
    memcpy( temp_data, mccmnc_str, mcc_mnc_len);

    tempPtr = temp_data;
    for(; mccmnc_index < mcc_mnc_len/2; mccmnc_index++) {//put mccmnc
        STR_2_U8(tempPtr , rspData[rspDataIndex]);
        rspDataIndex++;
        tempPtr += 2;
    }
    tempPtr = NULL;
    RLOGD(">>>location_infomation:mcc-mnc rspDataIndex:%d", rspDataIndex);

    //tac
    char* str_tac = loca_info->tac;
    int tac_index = 0;
    int tac_len = strlen(str_tac)/2;
    for(; tac_index < tac_len; tac_index++) {//put tac
        STR_2_U8(str_tac, rspData[rspDataIndex]);
        rspDataIndex++;
        str_tac += 2;
    }
    RLOGD(">>>location_infomation:tac rspDataIndex:%d", rspDataIndex);

    //ci
    char* str_ci = loca_info->ci;
    int ci_index = 0;
    int ci_len = strlen(str_ci)/2;

    temp_str = (char*)malloc(sizeof(char) * (strlen(str_ci) + 1));//'\0'
    if (temp_str == NULL) goto error;
    memset(temp_str, 0x00, strlen(str_ci) + 1);

    str_ci++;//"0180490d"++ -> "180490d"
    strncpy(temp_str, str_ci, strlen(str_ci));
    strcat(temp_str, "F");//"180490d"++ -> "180490dF"

    tempPtr = temp_str;
    for(; ci_index < ci_len; ci_index++) {//put ci
        STR_2_U8(tempPtr, rspData[rspDataIndex]);
        rspDataIndex++;
        tempPtr += 2;
    }
    tempPtr = NULL;
    RLOGD(">>>len + 1=%d,rspDataIndex:%d", len + 1, rspDataIndex);

    rspData[1] = len + 1;//len

    stk_send_terminal_response( STK_RESULT_00, rspData);
    RLOGD(">>>location_infomation-----success-----");

    at_response_free(p_response);
    if (NULL != temp_str)
        free(temp_str);

    if (NULL != temp_data)
        free(temp_data);

    if (NULL != temp_mnc)
        free(temp_mnc);

    if (NULL != temp_mcc)
        free(temp_mcc);

    if (NULL != rspData)
        free(rspData);

    return NULL;

error:
    RLOGD("auto_location_infomation,STK_RESULT_21");
    stk_send_terminal_response( STK_RESULT_21, NULL );
    at_response_free(p_response);
    if (NULL != temp_str)
        free(temp_str);

    if (NULL != temp_data)
        free(temp_data);

    if (NULL != temp_mnc)
        free(temp_mnc);

    if (NULL != temp_mcc)
        free(temp_mcc);

    if (NULL != rspData)
        free(rspData);

    return NULL;
}

static void *auto_setup_event_list( void *param )
{
    RLOGD("auto_setup_event_list...");
    stk_send_terminal_response( STK_RESULT_00, NULL);
    return NULL;
}

//FIX:3gpp-31.124[27.22.#.##.#] 20141115 end
/* Leadcore End: stk functions*/
