/*******************************************************************************
 *          COPYRIGHT DATANG MOBILE COMMUNICATIONS EQUIPMENT CO.,LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : pub-pty.h
 * Version  :
 * Purpose  :
 * Authors  :
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef PUB_PTY_H
#define PUB_PTY_H



/*-------------------------- include external file ---------------------------*/

#include "pub-sys.h"
#include "pub-aos.h"
#include "pub-util.h"



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/



/*----------------------- constant and type definition -----------------------*/

typedef struct
{
    int             m_ptm_fd;                   /* fd of the ptm */
    char            m_pts_name_a[40];           /* the real name of the pts, usually it is something like: /dev/pts/1 */
    char            m_pts_mapping_name_a[28];   /* a friendly name of the pts, it is a symlink of the real name */
    SINT8           m_is_nonblock_mode;         /* if the ptm use non-block mode */
    ST_PADDING_3(1);
} PUB_PTY_INFO_ST;



/*--------------------------- variables definition ---------------------------*/



/*---------------------- function prototype declaration ----------------------*/

extern SINT32 pub_pty_open(PUB_PTY_INFO_ST *pty_info_ptr);
extern SINT32 pub_pty_close(PUB_PTY_INFO_ST *pty_info_ptr);
extern SINT32 pub_pty_delete_mapping(PUB_PTY_INFO_ST *pty_info_ptr);



#endif /* PUB_PTY_H */
