/* Created by ZouFeng, 2010-07-23 */

/* 
    ����:
        ���豸 "/dev/muxtest"
            ѭ��ָ������
                -> ����: AT\r
                -> ��ȡӦ��
            ÿ��100�δ�ӡ����

    ����:
        arm-linux-gcc -static -o uart-at-loop uart-at-loop.c

    ʹ��:
        ./uart-at-loop -c 500
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>

#define PRINTF(x)                               \
        do                                      \
        {                                       \
            printf x;                           \
            fflush(stdout);                     \
        } while(0);

static void prompt_usage( const char *name_ptr )
{
    printf( "\n"
            "Usage: %s [OPTION]\n"
            "  -c <count>             Count that send AT.\n"
            "Example:\n"
            "  %s -c 1000\n"
            "\n",
            name_ptr,
            name_ptr );
    exit(0);
}

int circle_write(int fd, long count)
{
    long    count_tested = 0;
    int     write_len = 0;
    int     read_len = 0;
    char    read_buf_a[60] = "";
    int     is_error = 0;
    int     ret_val = 0;

    if(fd <= 0 || count <= 0)
    {
        PRINTF(("parameter error\n"));
        return -1;
    }

    while(count_tested <= count)
    {
        /* write */
        write_len = write(fd, "AT\r", 3);
        if( write_len < 0 )
        {
            PRINTF(("write() fail: %d - %s\n", errno, strerror(errno)));
            break;
        }
        else if( write_len != 3 )
        {
            PRINTF(("write not complete"));
            break;
        }

        /* read */
        while(1)
        {
            memset( read_buf_a, 0x00, sizeof(read_buf_a) );
            read_len = read(fd, read_buf_a, sizeof(read_buf_a) - 1);
            if( read_len < 0 )
            {
                PRINTF(("read() fail: %d - %s\n", errno, strerror(errno)));
                is_error = 1;
                break;
            }
            else if( strstr(read_buf_a, "\r\nOK\r\n")
                    || strstr(read_buf_a, "\r\nERROR\r\n")
                    || strstr(read_buf_a, "\r\n+CME ERROR")
                    || strstr(read_buf_a, "\r\n+CMS ERROR") )
            {
                /* Got the response. */
                break;
            }
        }

        if( is_error )
        {
            break;
        }

        count_tested++;

        if( 0 == (count_tested % 100) )
        {
            PRINTF(("    %ld/%ld\n", count_tested, count));
        }
    }

    if(count_tested < count)
    {
        ret_val = -1;
    }

    return ret_val;
}

int main( int argc, char *argv[] )
{
    long    count = 0;
    char    *uart_device_ptr = "/dev/muxtest";

    if( argc > 1 )
    {
        int opt = 0;
        while( -1 != (opt = getopt(argc, argv, "d:c:i:s:wph")) )
        {
            switch(opt)
            {
                case 'c':
                    count = atol(optarg);
                break;

                case 'h':
                case '?':
                default:
                    prompt_usage( argv[0] );
                break;
            }
        }
    }
    else
    {
        prompt_usage( argv[0] );
    }

    if(count > 0)
    {
        int fd_uart = -1;
        fd_uart = open(uart_device_ptr, O_RDWR);
        while( fd_uart < 0 && ENOENT == errno )
        {
            sleep(1);
            fd_uart = open(uart_device_ptr, O_RDWR);
        }

        if( fd_uart > 0 )
        {
            circle_write(fd_uart, count);

            close(fd_uart);
        }
        else
        {
            PRINTF(("open() %s fail: %d - %s\n", uart_device_ptr, errno, strerror(errno)));
        }
    }
    else
    {
        PRINTF(("count is 0\n"));
    }

    return 0;
}

