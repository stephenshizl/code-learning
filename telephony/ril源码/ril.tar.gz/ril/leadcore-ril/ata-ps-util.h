#ifndef	_ATA_PS_UTIL_H_
#define	_ATA_PS_UTIL_H_

struct ifaddrs {
	struct ifaddrs  *ifa_next;
	char		*ifa_name;
	unsigned int	 ifa_flags;
	struct sockaddr	*ifa_addr;
	struct sockaddr	*ifa_netmask;
	struct sockaddr	*ifa_dstaddr;
	void		*ifa_data;
};

/*
 * This may have been defined in <net/if.h>.  Note that if <net/if.h> is
 * to be included it must be included before this header file.
 */
#ifndef	ifa_broadaddr
#define	ifa_broadaddr	ifa_dstaddr	/* broadcast address interface */
#endif

#include <sys/cdefs.h>
#include <telephony/ril.h>

#define IN6_ARE_INTERFACE_ADDR_EQUAL(a,b) \
	((((__const uint32_t *) (a))[2] == ((__const uint32_t *) (b))[2])  \
	 && (((__const uint32_t *) (a))[3] == ((__const uint32_t *) (b))[3]))


__BEGIN_DECLS
extern int getifaddrs(struct ifaddrs **ifap);
extern void freeifaddrs(struct ifaddrs *ifa);
extern SINT32 ps_get_ra_ipv6_addr(UINT8 pdp_cid, char *ra_addr);
extern void ps_set_ra_auto_mode(char *iface,BOOL flag);
extern BOOL ps_check_lmi_ip_exist(char *iface);

__END_DECLS

#endif