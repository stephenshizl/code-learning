/* //device/system/reference-ril/at_tok.c
**
** Copyright 2006, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#include "at_tok.h"
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/******************************************************************************
*
 * Function: at_tok_req_end_str
 * --------------------------------------------------------------------------
---
 * Purpose:
 * ----------------------------
 *     Return the suffix string of a request AT.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     (none)
 *
 * Return:
 * ----------------------------
 *     the suffix string of a request AT.
 *
 * Note:
 * ----------------------------
 *
 
******************************************************************************/
char *at_tok_req_end_str( void )
{
    return "\r";
}
/**
 * Starts tokenizing an AT response string
 * returns -1 if this is not a valid response string, 0 on success.
 * updates *p_cur with current position
 */
int at_tok_start(char **p_cur)
{
    if (*p_cur == NULL) {
        return -1;
    }

    // skip prefix
    // consume "^[^:]:"

    *p_cur = strchr(*p_cur, ':');

    if (*p_cur == NULL) {
        return -1;
    }

    (*p_cur)++;

    return 0;
}

static void skipWhiteSpace(char **p_cur)
{
    if (*p_cur == NULL) return;

    while (**p_cur != '\0' && isspace(**p_cur)) {
        (*p_cur)++;
    }
}

static void skipNextComma(char **p_cur)
{
    if (*p_cur == NULL) return;

    while (**p_cur != '\0' && **p_cur != ',') {
        (*p_cur)++;
    }

    if (**p_cur == ',') {
        (*p_cur)++;
    }
}

static char * nextTok(char **p_cur)
{
    char *ret = NULL;

    skipWhiteSpace(p_cur);

    if (*p_cur == NULL) {
        ret = NULL;
    } else if (**p_cur == '"') {
        (*p_cur)++;
        ret = strsep(p_cur, "\"");
        skipNextComma(p_cur);
    } else {
        ret = strsep(p_cur, ",");
    }

    return ret;
}


/**
 * Parses the next integer in the AT response line and places it in *p_out
 * returns 0 on success and -1 on fail
 * updates *p_cur
 * "base" is the same as the base param in strtol
 */

static int at_tok_nextint_base(char **p_cur, int *p_out, int base, int  uns)
{
    char *ret;

    if (*p_cur == NULL) {
        return -1;
    }

    ret = nextTok(p_cur);

    if (ret == NULL) {
        return -1;
    } else {
        long l;
        char *end;

        if (uns)
            l = strtoul(ret, &end, base);
        else
            l = strtol(ret, &end, base);

        *p_out = (int)l;

        if (end == ret) {
            return -1;
        }
    }

    return 0;
}

/**
 * Parses the next base 10 integer in the AT response line
 * and places it in *p_out
 * returns 0 on success and -1 on fail
 * updates *p_cur
 */
int at_tok_nextint(char **p_cur, int *p_out)
{
    return at_tok_nextint_base(p_cur, p_out, 10, 0);
}

/**
 * Parses the next base 16 integer in the AT response line
 * and places it in *p_out
 * returns 0 on success and -1 on fail
 * updates *p_cur
 */
int at_tok_nexthexint(char **p_cur, int *p_out)
{
    return at_tok_nextint_base(p_cur, p_out, 16, 1);
}

int at_tok_nextbool(char **p_cur, char *p_out)
{
    int ret;
    int result;

    ret = at_tok_nextint(p_cur, &result);

    if (ret < 0) {
        return -1;
    }

    // booleans should be 0 or 1
    if (!(result == 0 || result == 1)) {
        return -1;
    }

    if (p_out != NULL) {
        *p_out = (char)result;
    }

    return ret;
}

int at_tok_nextstr(char **p_cur, char **p_out)
{
    if (*p_cur == NULL) {
        return -1;
    }

    *p_out = nextTok(p_cur);

    return 0;
}

/** returns 1 on "has more tokens" and 0 if no */
int at_tok_hasmore(char **p_cur)
{
    return ! (*p_cur == NULL || **p_cur == '\0');
}


#if 0 //chenchi add


/******************************************************************************
*
 * Function: parse_omit
 * --------------------------------------------------------------------------
---
 * Purpose:
 * ----------------------------
 *     Omit a parameter.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 
******************************************************************************/
static SINT32 parse_omit( SINT8 **string_ptr )
{
    SINT8 *input_ptr;

    input_ptr=*string_ptr;

    /*If parameter is ommited, then the input parameter should not be modified
*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while ( *input_ptr != '\0' && *input_ptr != '\r' && *input_ptr != ',' )
    {
        input_ptr=input_ptr+1;
    }

    *string_ptr=input_ptr;
    return ERR_NONE;
}


/******************************************************************************
*
 * Function: parse_uint8
 * --------------------------------------------------------------------------
---
 * Purpose:
 * ----------------------------
 *     Parse a data of type "UINT8".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         UINT8 *       Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 
******************************************************************************/
static SINT32 parse_uint8( SINT8 **string_ptr, UINT8 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified
*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while (( isdigit( *input_ptr ) ) && ( output <=0xff ) )
    {
        output= output*10;
        output = output + *input_ptr - '0';
        input_ptr=input_ptr+1;
    }

    /*
     *  if the number exceed 255, then it is not a UINT8 type parameter,
     *  so we consider the parameter is wrong
     */
    if ( output>0xff )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    *output_ptr=( UINT8 )output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/******************************************************************************
*
 * Function: parse_uint16
 * --------------------------------------------------------------------------
---
 * Purpose:
 * ----------------------------
 *     Parse a data of type "UINT16".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         UINT16 *      Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 
******************************************************************************/
static SINT32 parse_uint16( SINT8 **string_ptr, UINT16 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified
*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while (( isdigit( *input_ptr ) ) && ( output <=0xffff ) )
    {
        output= output*10;
        output = output + *input_ptr - '0';
        input_ptr=input_ptr+1;
    }

    /*
     *  if the number exceed 0xffff, then it is not a UINT16 type parameter,
     *  so we consider the parameter is wrong
     */
    if ( output>0xffff )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    *output_ptr=( UINT16 )output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/******************************************************************************
*
 * Function: parse_uint32
 * --------------------------------------------------------------------------
---
 * Purpose:
 * ----------------------------
 *     Parse a data of type "UINT32".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         UINT32 *      Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 
******************************************************************************/
static SINT32 parse_uint32( SINT8 **string_ptr, UINT32 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified
*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while ( isdigit( *input_ptr ) )
    {
        if ( output <=429496729 )
        {
            if ( output==429496729 )
            {
                if ( *input_ptr - '0'>5 )
                {
                    return ERR_INVALID_PARAM_VALUE;
                }
            }

            output= output*10;

            output = output + *input_ptr - '0';
            input_ptr=input_ptr+1;
        }
        else /*exceed 0xffffffff*/
        {
            return ERR_INVALID_PARAM_VALUE;
        }
    }

    *output_ptr=output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/******************************************************************************
*
 * Function: parse_sint8
 * --------------------------------------------------------------------------
---
 * Purpose:
 * ----------------------------
 *     Parse a data of type "SINT8".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         SINT8 *       Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 
******************************************************************************/
static SINT32 parse_sint8( SINT8 **string_ptr, SINT8 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified
*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while (( isdigit( *input_ptr ) ) && ( output <=0x7f ) )
    {
        output= output*10;
        output = output + *input_ptr - '0';
        input_ptr=input_ptr+1;
    }

    /*
     *  if the number exceed 0x7f, then it is not a SINT8 type parameter,
     *  so we consider the parameter is wrong
     */
    if ( output>0x7f )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    *output_ptr=( SINT8 )output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}

/******************************************************************************
*
 * Function: parse_sint16
 * --------------------------------------------------------------------------
---
 * Purpose:
 * ----------------------------
 *     Parse a data of type "SINT16".
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     output_ptr         SINT16 *      Out           parsed data
 *
 * Return:
 * ----------------------------
 *     = 0: success
 *     < 0: error
 *     > 0: undefined
 *
 * Note:
 * ----------------------------
 *
 
******************************************************************************/
static SINT32 parse_sint16( SINT8 **string_ptr, SINT16 *output_ptr )
{
    UINT32 output;
    SINT8 *input_ptr;


    input_ptr=*string_ptr;
    output=0;

    /*If parameter is ommited, then the input parameter should not be modified
*/

    if ( ',' == *input_ptr || '\r' == *input_ptr || '\0' == *input_ptr )
    {
        return ERR_NONE;
    }

    while (( isdigit( *input_ptr ) ) && ( output <=0x7fff ) )
    {
        output= output*10;
        output = output + *input_ptr - '0';
        input_ptr=input_ptr+1;
    }

    /*
     *  if the number exceed 0x7f, then it is not a SINT16 type parameter,
     *  so we consider the parameter is wrong
     */
    if ( output>0x7fff )
    {
        return ERR_INVALID_PARAM_VALUE;
    }

    *output_ptr=( SINT16 )output;

    /*Bring out the point to first untreated character*/
    *string_ptr=input_ptr;
    return ERR_NONE;
}



/******************************************************************************
*
 * Function: at_tok_parse_ext
 * --------------------------------------------------------------------------
---
 * Purpose:
 * ----------------------------
 *     Parse the data according to the specified type.
 *     Type definition:
 *         'H' means type: "hex"
 *         'U' means type: "UINT8"
 *         'V' means type: "UINT16"
 *         'L' means type: "UINT32"
 *         'I' means type: "SINT8"
 *         'J' means type: "SINT16"
 *         'S' means type: "string"
 *         'D' means type: "data"
 *         'A' means type: "hex data"
 *         'O' means     : omit a parameter
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name               Type          In/Out        Description
 *     ---------------    ----------    ----------    --------------------
 *     string_ptr         SINT8 *       In            data to parse
 *     type_ptr           char *        In            format
 *     ...                              Out           parsed data
 *
 * Return:
 * ----------------------------
 *     >= 0: parameters that parsed
 *     < 0: error
 *
 * Note:
 * ----------------------------
 *
 
******************************************************************************/

SINT32 at_tok_parse_ext( SINT8 **string_ptr, char *type_ptr, ... )
{
    va_list varpars;
    SINT8   *input_ptr = NULL;
    UINT32  max_len = 0;
    SINT32  ret_val = ERR_NONE;
    SINT32  parsed_number = 0;

    LOG_FUNC();

    /* Check parameter. */
    if( !string_ptr || !*string_ptr
        || !type_ptr )
    {
        /* Error: invalid parameter. */
        LOG_ERR_EXT( ERR_INVALID_PARAM, ("%d, %d, %d", !string_ptr, !(*
string_ptr), !type_ptr) );
        return -1;
    }

    va_start( varpars, type_ptr );

    /* Get the point of the string*/
    input_ptr = *string_ptr;

    skip_white_space((char **)(&input_ptr));

    if ( '\0' == *input_ptr || '\r' == *input_ptr )
    {
        va_end( varpars );
        return parsed_number;
    }

    while ( '\0' != *type_ptr )
    {
        switch ( toupper( *type_ptr ) )
        {
            case( 'H' ):
            {
                /*
                 *  The parameter is hexadecimal type, the max length of 
hexadecimal
                 *  is limited to 8 bytes
                 */
                ret_val= parse_hex( &input_ptr, va_arg( varpars, UINT32* ), 8 
);
            }
            break;

            case( 'U' ):
            {
                /* The parameter is a "UINT8" type */
                ret_val = parse_uint8( &input_ptr, va_arg( varpars, UINT8* ) );
            }
            break;

            case( 'V' ):
            {
                /* The parameter is a "UINT16" type */
                ret_val = parse_uint16( &input_ptr, va_arg( varpars, UINT16* 
) );
            }
            break;

            case( 'L' ):
            {
                /* The parameter is a "UINT32" type */
                ret_val = parse_uint32( &input_ptr, va_arg( varpars, UINT32* 
) );
            }
            break;

            case( 'I' ):
            {
                /* The parameter is a "SINT8" type */
                ret_val = parse_sint8( &input_ptr, va_arg( varpars, SINT8* ) );
            }
            break;

            case( 'J' ):
            {
                /* The parameter is a "SINT16" type */
                ret_val = parse_sint16( &input_ptr, va_arg( varpars, SINT16* 
) );
            }
            break;

            case( 'S' ):
            {
                /* The parameter is a "String" type, the first parameter is 
the max length
                 * allowed of the string*/
                max_len = va_arg( varpars, UINT32 );
                ret_val = parse_string( &input_ptr, va_arg( varpars, SINT8* ),
( UINT16 )max_len );
            }
            break;

            case( 'D' ):
            {
                UINT8   *data_ptr = NULL;
                UINT32  *len_ptr = NULL;

                max_len = va_arg( varpars, UINT32 );
                data_ptr = va_arg( varpars, UINT8* );
                len_ptr = va_arg( varpars, UINT32* );

                ret_val = parse_data( &input_ptr, max_len, data_ptr, len_ptr );
            }
            break;

            case( 'A' ):
            {
                UINT8   *data_ptr = NULL;
                UINT32  *len_ptr = NULL;

                max_len = va_arg( varpars, UINT32 );
                data_ptr = va_arg( varpars, UINT8* );
                len_ptr = va_arg( varpars, UINT32* );

                ret_val = parse_hex_data( &input_ptr, max_len, data_ptr, 
len_ptr );
            }
            break;

            case( 'O' ):
            {
                ret_val = parse_omit( &input_ptr );
            }
            break;

            default:
            {
                /* If the type is not supported, then we consider its a 
error  */
                ret_val = ERR_INVALID_PARAM;
            }
            break;
        }

        if( ERR_NONE == ret_val )
        {
            if( *type_ptr != 'O' )
            {
                parsed_number++;
            }
        }
        else
        {
            /*If some error is occured when parse a parameter, then we 
consider the parameter
             *of this command is not valid*/
            va_end( varpars );
            *string_ptr = input_ptr;
            LOG_ERR(ERR_INVALID_PARAM);
            return -1;
        }

        /* If no more parameters are existed, we should end it */
        if ( '\0' == *input_ptr || '\r' == *input_ptr )
        {
            va_end( varpars );
            *string_ptr =  input_ptr;

            LOG_INFO(("parsed parameter count: %d", parsed_number));

            return parsed_number;
        }

        /* If the next character is not ",", then it's a invalid parameter */
        if ( ',' != *input_ptr )
        {
            va_end( varpars );
            *string_ptr =  input_ptr;
            LOG_ERR(ERR_INVALID_PARAM);
            return -1;
        }
        else
        {
            input_ptr=input_ptr+1;
        }

        /* If no more parameters are existed, we should end it */
        if ( '\0' == *input_ptr || '\r' == *input_ptr )
        {
            va_end( varpars );
            *string_ptr =  input_ptr;

            LOG_INFO(("parsed parameter count: %d", parsed_number));

            return parsed_number;
        }

        type_ptr++;

        skip_white_space((char **)(&input_ptr));
    }

    va_end( varpars );

    /*Bring out the point to first untreated character*/
    *string_ptr = input_ptr;

    LOG_INFO(("parsed parameter count: %d", parsed_number));

    return parsed_number;
}

#endif

