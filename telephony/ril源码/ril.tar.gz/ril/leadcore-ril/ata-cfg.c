/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : ata-cfg.c
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#define ATA_CFG_C



/*---------------------------- include head file -----------------------------*/

#include "pub-sys.h"
#include "pub-log.h"
#include "pub-err.h"

//#include "main.h"
#include "ata-cfg.h"



#ifdef OPT_ENABLE_LC_ATA_CONFIG



/*---------------------- external variable declaration -----------------------*/



/*----------------- external function prototype declaration ------------------*/



/*----------------------- file-local macro definition ------------------------*/



/*----------------- file-local constant and type definition ------------------*/



/*---------------- file-local function prototype declaration -----------------*/

static SINT32 parse_lc_ata_cfg(const char *file_ptr);
static SINT32 parse_sys_cfg(const char *file_ptr);
static SINT32 parse_cfg_system_prop(const char *file_ptr);



/*--------------------- file-local variables definition ----------------------*/

LC_ATA_CFG_ST   lc_ata_cfg_st;



/*--------------------------- function definition ----------------------------*/

/*******************************************************************************
 * Function: parse_lc_ata_cfg
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the config file of lc-ata.
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name           Type                 In/Out  Description
 *     -------------  -------------------  ------  ----------------------------
 *     file_ptr       const char *         In      config file name
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
static SINT32 parse_lc_ata_cfg(const char *file_ptr)
{
    SINT32    ret_val = ERR_NONE;
    FILE    *fp = NULL;
    BOOL    is_end = 0;
    UINT32    data_len=0;
    char    buf_a[100];
    char    *param_ptr = NULL;
    char    *value_ptr = NULL;
    char    *cfg_file_ptr = (char *)file_ptr;
    UINT16  line = 0;

    LOG_FUNC();

    if( !cfg_file_ptr )
    {
        /* Use the default file. */
        cfg_file_ptr = "/opl/etc/lc-oms-ata.cfg";
    }
    fp = fopen(cfg_file_ptr, "r");

    if(fp)
    {
        while(!is_end && line < 300)
        {
            ret_val = cfg_get_line( fp, buf_a, sizeof(buf_a), &data_len, &is_end );
            if( ERR_NONE == ret_val )
            {
                ret_val = cfg_get_param_and_value(buf_a, &param_ptr, &value_ptr);
            }
            if( ERR_NONE == ret_val
                && param_ptr && strlen(param_ptr) > 0
                && value_ptr && strlen(value_ptr) > 0 )
            {
                if( 0 == strcmp(param_ptr, "lc.act.mode") )
                {
                    lc_ata_cfg_st.m_is_act_valid = 1;
                    lc_ata_cfg_st.m_act_mode = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.act.mode = %d", lc_ata_cfg_st.m_act_mode));
                }
                else if( 0 == strcmp(param_ptr, "lc.ps.log.data.info") )
                {
                    lc_ata_cfg_st.m_is_ps_log_data_info = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.ps.log.data.info = %d", lc_ata_cfg_st.m_is_ps_log_data_info));
                }
                else if( 0 == strcmp(param_ptr, "lc.cs.log.data.info") )
                {
                    lc_ata_cfg_st.m_is_cs_log_data_info = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.cs.log.data.info = %d", lc_ata_cfg_st.m_is_cs_log_data_info));
                }
                else if( 0 == strcmp(param_ptr, "lc.cs.log.data") )
                {
                    lc_ata_cfg_st.m_is_cs_log_data = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.cs.log.data = %d", lc_ata_cfg_st.m_is_cs_log_data));
                }
                else if( 0 == strcmp(param_ptr, "lc.vp.log.data.info") )
                {
                    lc_ata_cfg_st.m_is_vp_log_data_info = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.vp.log.data.info = %d", lc_ata_cfg_st.m_is_vp_log_data_info));
                }
                else if( 0 == strcmp(param_ptr, "lc.vp.log.data") )
                {
                    lc_ata_cfg_st.m_is_vp_log_data = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.vp.log.data = %d", lc_ata_cfg_st.m_is_vp_log_data));
                }
                else if( 0 == strcmp(param_ptr, "lc.audio.log.data.info") )
                {
                    lc_ata_cfg_st.m_is_audio_log_data_info = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.audio.log.data.info = %d", lc_ata_cfg_st.m_is_audio_log_data_info));
                }
                else if( 0 == strcmp(param_ptr, "lc.audio.log.data") )
                {
                    lc_ata_cfg_st.m_is_audio_log_data = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.audio.log.data = %d", lc_ata_cfg_st.m_is_audio_log_data));
                }
#ifdef OPT_SOFT_MODEM
                else if( 0 == strcmp(param_ptr, "lc.sm.log.data.info") )
                {
                    lc_ata_cfg_st.m_is_sm_log_data_info = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.sm.log.data.info = %d", lc_ata_cfg_st.m_is_sm_log_data_info));
                }
                else if( 0 == strcmp(param_ptr, "lc.sm.log.data") )
                {
                    lc_ata_cfg_st.m_is_sm_log_data = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.sm.log.data = %d", lc_ata_cfg_st.m_is_sm_log_data));
                }
#endif
#if (defined OPT_ENABLE_ELOG) && (defined OPT_USER_LGE)
                else if( 0 == strcmp(param_ptr, "lc.elog.log.data.info") )
                {
                    lc_ata_cfg_st.m_is_elog_log_data_info = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.elog.log.data.info = %d", lc_ata_cfg_st.m_is_elog_log_data_info));
                }
                else if( 0 == strcmp(param_ptr, "lc.elog.log.data") )
                {
                    lc_ata_cfg_st.m_is_elog_log_data = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.elog.log.data = %d", lc_ata_cfg_st.m_is_elog_log_data));
                }
#endif
                else if( 0 == strcmp(param_ptr, "lc.h324m.ap") )
                {
                    lc_ata_cfg_st.m_is_ap_324 = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.h324m.ap = %d", lc_ata_cfg_st.m_is_ap_324));
                }
#ifdef OPT_ENABLE_REPORT_RSSI
                else if( 0 == strcmp(param_ptr, "lc.rssi.period") )
                {
                    lc_ata_cfg_st.m_rssi_period = atoi(value_ptr);
                    LOG_INFO(("[cfg]lc.rssi.period = %d (second)", lc_ata_cfg_st.m_rssi_period));
                }
#endif
                else if( 0 == strcmp(param_ptr, "lc.ppp.path.pppd") )
                {
                    strncpy( lc_ata_cfg_st.m_pppd_path_a, value_ptr, sizeof(lc_ata_cfg_st.m_pppd_path_a) - 1 );
                    LOG_INFO(("[cfg]lc.ppp.path.pppd = %s", lc_ata_cfg_st.m_pppd_path_a));
                }
                else if( 0 == strcmp(param_ptr, "lc.ppp.path.provider") )
                {
                    strncpy( lc_ata_cfg_st.m_pppd_provider_path_a, value_ptr, sizeof(lc_ata_cfg_st.m_pppd_provider_path_a) - 1 );
                    LOG_INFO(("[cfg]lc.ppp.path.provider = %s", lc_ata_cfg_st.m_pppd_provider_path_a));
                }
                else if( 0 == strcmp(param_ptr, "lc.ppp.path.pid") )
                {
                    strncpy( lc_ata_cfg_st.m_pppd_pid_path_a, value_ptr, sizeof(lc_ata_cfg_st.m_pppd_pid_path_a) - 1 );
                    LOG_INFO(("[cfg]lc.ppp.path.pid = %s", lc_ata_cfg_st.m_pppd_pid_path_a));
                }
                else if( 0 == strcmp(param_ptr, "lc.ppp.mru") )
                {
                    lc_ata_cfg_st.m_pppd_mru = strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]lc.ppp.mru = %d", lc_ata_cfg_st.m_pppd_mru));
                }
                else if( 0 == strcmp(param_ptr, "lc.ppp.mtu") )
                {
                    lc_ata_cfg_st.m_pppd_mtu = strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]lc.ppp.mtu = %d", lc_ata_cfg_st.m_pppd_mtu));
                }
#ifdef OPT_DUAL_PORT_COMMUNICATION
                else if( 0 == strcmp(param_ptr, "lc.tty.ps1") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_ps1_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_ps1_a) - 1 );
                    LOG_INFO(("[cfg]lc.tty.ps1 = %s", lc_ata_cfg_st.m_channel_ps1_a));
                }
                else if( 0 == strcmp(param_ptr, "lc.tty.ps2") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_ps2_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_ps2_a) - 1 );
                    LOG_INFO(("[cfg]lc.tty.ps2 = %s", lc_ata_cfg_st.m_channel_ps2_a));
                }
                else if( 0 == strcmp(param_ptr, "lc.tty.ps3") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_ps3_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_ps3_a) - 1 );
                    LOG_INFO(("[cfg]lc.tty.ps3 = %s", lc_ata_cfg_st.m_channel_ps3_a));
                }
                else if( 0 == strcmp(param_ptr, "lc.dual.port") )
                {
                    lc_ata_cfg_st.m_dual_port_communication = strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]lc.dual.port = %d", lc_ata_cfg_st.m_dual_port_communication));
                }
                else if( 0 == strcmp(param_ptr, "lc.usb.poweroff") )
                {
                    lc_ata_cfg_st.m_is_enable_power_off_usb = strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]lc.usb.poweroff = %d", lc_ata_cfg_st.m_is_enable_power_off_usb));
                }
#endif /* #ifdef OPT_DUAL_PORT_COMMUNICATION */
                else if( 0 == strcmp(param_ptr, "lc.for.cta") )
                {
                    lc_ata_cfg_st.m_is_for_cta = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.for.cta = %d", lc_ata_cfg_st.m_is_for_cta));
                }
#ifdef OPT_RESET_MODEM
                else if( 0 == strcmp(param_ptr, "lc.reset.enable") )
                {
                    lc_ata_cfg_st.m_reset_is_enable = *value_ptr - '0';
                    LOG_INFO(("[cfg]lc.reset.enable = %d", lc_ata_cfg_st.m_reset_is_enable));
                }
                else if( 0 == strcmp(param_ptr, "lc.reset.modem") )
                {
                    strncpy( lc_ata_cfg_st.m_reset_modem_string_a, value_ptr, sizeof(lc_ata_cfg_st.m_reset_modem_string_a) - 1 );
                    LOG_INFO(("[cfg]lc.reset.modem = %s", lc_ata_cfg_st.m_reset_modem_string_a));
                }
#endif
                else if( 0 == strcmp(param_ptr, "lc.log.size") )
                {
                    lc_ata_cfg_st.m_log_size = strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]lc.log.size = %ld", lc_ata_cfg_st.m_log_size));
                }
                else if( 0 == strcmp(param_ptr, "lc.tty.speed") )
                {
                    lc_ata_cfg_st.m_tty_speed = strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]lc.tty.speed = %ld", lc_ata_cfg_st.m_tty_speed));
                }
            }

            line++;
        }

        fclose(fp);

        ret_val = ERR_NONE;
    }
    else
    {
        LOG_SYS_ERR("fopen");
        LOG_ERR_EXT(ERR_CALL_C_FUNC, ("fail to open file: %s", cfg_file_ptr));
        ret_val = ERR_CALL_C_FUNC;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: parse_sys_cfg
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the config file of system.
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name           Type                 In/Out  Description
 *     -------------  -------------------  ------  ----------------------------
 *     file_ptr       const char *         In      config file name
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
static SINT32 parse_sys_cfg(const char *file_ptr)
{
    SINT32    ret_val = ERR_NONE;
    FILE    *fp = NULL;
    BOOL    is_end = 0;
    UINT32    data_len=0;
    char    buf_a[100];
    char    *param_ptr = NULL;
    char    *value_ptr = NULL;
    char    *cfg_file_ptr = (char *)file_ptr;
    UINT16  line = 0;

    LOG_FUNC();

    if( !cfg_file_ptr )
    {
        /* Use the default file. */
        cfg_file_ptr = "/opl/etc/board.prop";
    }
    fp = fopen(cfg_file_ptr, "r");

    if(fp)
    {
        while(!is_end && line < 300)
        {
            ret_val = cfg_get_line( fp, buf_a, sizeof(buf_a), &data_len, &is_end );
            if( ERR_NONE == ret_val )
            {
                ret_val = cfg_get_param_and_value(buf_a, &param_ptr, &value_ptr);
            }
            if( ERR_NONE == ret_val
                && param_ptr && strlen(param_ptr) > 0
                && value_ptr && strlen(value_ptr) > 0 )
            {
                if( 0 == strcmp(param_ptr, "hw.tty.at") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_at_prefix_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_at_prefix_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.at = %s", lc_ata_cfg_st.m_channel_at_prefix_a));
                }
                else if( 0 == strcmp(param_ptr, "hw.tty.ps") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_ps_prefix_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_ps_prefix_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.ps = %s", lc_ata_cfg_st.m_channel_ps_prefix_a));
                }
                else if( 0 == strcmp(param_ptr, "hw.tty.cs") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_cs_prefix_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_cs_prefix_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.cs = %s", lc_ata_cfg_st.m_channel_cs_prefix_a));
                }
                else if( 0 == strcmp(param_ptr, "hw.tty.audio") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_audio_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_audio_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.audio = %s", lc_ata_cfg_st.m_channel_audio_a));
                }
                else if( 0 == strcmp(param_ptr, "hw.tty.vpdevice.at") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_vp_at_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_vp_at_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.vpdevice.at = %s", lc_ata_cfg_st.m_channel_vp_at_a));
                }
                else if( 0 == strcmp(param_ptr, "hw.tty.vpdevice.video") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_vp_video_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_vp_video_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.vpdevice.video = %s", lc_ata_cfg_st.m_channel_vp_video_a));
                }
                else if( 0 == strcmp(param_ptr, "hw.tty.at.lge") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_lge_at_prefix_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_lge_at_prefix_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.at.lge = %s", lc_ata_cfg_st.m_channel_lge_at_prefix_a));
                }
                else if( 0 == strcmp(param_ptr, "hw.tty.at.test") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_at_test_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_at_test_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.at.test = %s", lc_ata_cfg_st.m_channel_at_test_a));
                }
#ifdef OPT_FACTORY_DEFINED_AT
                else if( 0 == strcmp(param_ptr, "hw.tty.at.factory") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_at_factory_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_at_factory_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.at.factory = %s", lc_ata_cfg_st.m_channel_at_factory_a));
                }
#endif
#if (defined OPT_ENABLE_ELOG) && (defined OPT_USER_LGE)
                else if( 0 == strcmp(param_ptr, "hw.tty.elog.at") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_elog_at_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_elog_at_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.elog.at = %s", lc_ata_cfg_st.m_channel_elog_at_a));
                }
                else if( 0 == strcmp(param_ptr, "hw.tty.elog.data") )
                {
                    strncpy( lc_ata_cfg_st.m_channel_elog_data_a, value_ptr, sizeof(lc_ata_cfg_st.m_channel_elog_data_a) - 1 );
                    LOG_INFO(("[cfg]hw.tty.elog.data = %s", lc_ata_cfg_st.m_channel_elog_data_a));
                }
#endif
                else if( 0 == strcmp(param_ptr, "hw.machine.name") )
                {
                    strncpy( lc_ata_cfg_st.m_machine_name_a, value_ptr, sizeof(lc_ata_cfg_st.m_machine_name_a) - 1 );
                }
            }

            line++;
        }

        fclose(fp);

        ret_val = ERR_NONE;
    }
    else
    {
        LOG_SYS_ERR("fopen");
        LOG_ERR_EXT(ERR_CALL_C_FUNC, ("fail to open file: %s", cfg_file_ptr));
        ret_val = ERR_CALL_C_FUNC;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: parse_cfg_system_prop
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the config file: /opl/etc/system.prop
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name           Type                 In/Out  Description
 *     -------------  -------------------  ------  ----------------------------
 *     file_ptr       const char *         In      config file name
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
static SINT32 parse_cfg_system_prop(const char *file_ptr)
{
    SINT32    ret_val = ERR_NONE;
    FILE    *fp = NULL;
    BOOL    is_end = 0;
    UINT32    data_len=0;
    char    buf_a[100];
    char    *param_ptr = NULL;
    char    *value_ptr = NULL;
    char    *cfg_file_ptr = (char *)file_ptr;
    UINT16  line = 0;

    LOG_FUNC();

    if( !cfg_file_ptr )
    {
        /* Use the default file. */
        cfg_file_ptr = "/opl/etc/system.prop";
    }
    fp = fopen(cfg_file_ptr, "r");

    if(fp)
    {
        while(!is_end && line < 300)
        {
            ret_val = cfg_get_line( fp, buf_a, sizeof(buf_a), &data_len, &is_end );
            if( ERR_NONE == ret_val )
            {
                ret_val = cfg_get_param_and_value(buf_a, &param_ptr, &value_ptr);
            }

            if( ERR_NONE == ret_val
                && param_ptr && strlen(param_ptr) > 0
                && value_ptr && strlen(value_ptr) > 0 )
            {
                if( 0 == strcmp(param_ptr, "sys.statusbar.rssi.bar0") )
                {
                    lc_ata_cfg_st.m_rssi_bar0 = (UINT8)strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]sys.statusbar.rssi.bar0 = %d", lc_ata_cfg_st.m_rssi_bar0));
                }
                else if( 0 == strcmp(param_ptr, "sys.statusbar.rssi.bar1") )
                {
                    lc_ata_cfg_st.m_rssi_bar1 = (UINT8)strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]sys.statusbar.rssi.bar1 = %d", lc_ata_cfg_st.m_rssi_bar1));
                }
                else if( 0 == strcmp(param_ptr, "sys.statusbar.rssi.bar2") )
                {
                    lc_ata_cfg_st.m_rssi_bar2 = (UINT8)strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]sys.statusbar.rssi.bar2 = %d", lc_ata_cfg_st.m_rssi_bar2));
                }
                else if( 0 == strcmp(param_ptr, "sys.statusbar.rssi.bar3") )
                {
                    lc_ata_cfg_st.m_rssi_bar3 = (UINT8)strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]sys.statusbar.rssi.bar3 = %d", lc_ata_cfg_st.m_rssi_bar3));
                }
                else if( 0 == strcmp(param_ptr, "sys.statusbar.rssi.bar4") )
                {
                    lc_ata_cfg_st.m_rssi_bar4 = (UINT8)strtol( value_ptr, NULL, 10 );
                    LOG_INFO(("[cfg]sys.statusbar.rssi.bar4 = %d", lc_ata_cfg_st.m_rssi_bar4));
                }
                else if( 0 == strcmp(param_ptr, "apps.setting.product.vendor") )
                {
                    strncpy( lc_ata_cfg_st.m_product_vendor_a, value_ptr, sizeof(lc_ata_cfg_st.m_product_vendor_a) - 1 );
                }
                else if( 0 == strcmp(param_ptr, "apps.setting.product.model") )
                {
                    strncpy( lc_ata_cfg_st.m_product_model_a, value_ptr, sizeof(lc_ata_cfg_st.m_product_model_a) - 1 );
                }
            }

            line++;
        }

        fclose(fp);

        ret_val = ERR_NONE;
    }
    else
    {
        LOG_SYS_ERR("fopen");
        LOG_ERR_EXT(ERR_CALL_C_FUNC, ("fail to open file: %s", cfg_file_ptr));
        ret_val = ERR_CALL_C_FUNC;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: cfg_get_line
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Read a line data from a file.
 *
 * Used variables:
 * ----------------------------
 *     lc_ata_cfg_st
 *
 * Params:
 * ----------------------------
 *     Name           Type           In/Out  Description
 *     -------------  -------------  ------  ----------------------------------
 *     fp             FILE *         In      file handle
 *     buf_ptr        char *         Out     buffer that storage the data
 *     buf_size       UINT32         In      size of the buffer
 *     data_len_ptr   UINT32 *       Out     len of the data that read
 *     is_end_ptr     BOOL *         Out     if get the end of the file
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     Note of the getc():
 *     If the integer value returned by getc() is stored into a variable of
 *     type char and then compared against the integer constant EOF, the
 *     comparison may never succeed, because sign-extension of a variable of
 *     type char on widening to integer is implementation-defined.
 *
 ******************************************************************************/
SINT32 cfg_get_line( FILE *fp, char *buf_ptr, UINT32 buf_size, UINT32 *data_len_ptr, BOOL *is_end_ptr )
{
    SINT32  ret_val = 0;
    int     ch;
    UINT32  i = 0;

//    LOG_FUNC();

    if( !fp
        || !buf_ptr
        || !data_len_ptr
        || !is_end_ptr )
    {
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    *data_len_ptr = 0;
    *is_end_ptr = 0;
    memset( buf_ptr, 0x00, buf_size );

    i = 0;
    ch = getc(fp);
    while( 1 )
    {
        if ( '\n' == ch || EOF == ch )
        {
            if( EOF == ch )
            {
                *is_end_ptr = 1;
            }

            break;
        }
        else
        {
            if( i < buf_size )
            {
                buf_ptr[i] = (char )ch;
            }

            i++;
        }

        ch = getc(fp);
    }

    *data_len_ptr = strlen(buf_ptr);

    /* Remove the char '\r'. */
    if( *data_len_ptr > 0 )
    {
        while( '\r' == buf_ptr[*data_len_ptr-1] )
        {
            buf_ptr[*data_len_ptr-1] = 0x00;
            (*data_len_ptr)--;
        }
    }

    return ret_val;
}

/*******************************************************************************
 * Function: cfg_get_param_and_value
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the config file of system.
 *
 * Used variables:
 * ----------------------------
 *     lc_ata_cfg_st
 *
 * Params:
 * ----------------------------
 *     Name           Type            In/Out  Description
 *     -------------  --------------  ------  ---------------------------------
 *     line_ptr       char *          In      data to parse
 *     param_ptr      char **         Out     name of the config
 *     value_ptr      char **         Out     value of the config
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     The data in "line_ptr" will be changed.
 *
 ******************************************************************************/
SINT32 cfg_get_param_and_value(char *line_ptr, char **param_ptr, char **value_ptr )
{
    char    *p1 = NULL;
    char    *p2 = NULL;
    SINT32    ret_val = ERR_NONE;

//    LOG_FUNC();

    if( !line_ptr || !param_ptr || !value_ptr )
    {
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    while( ' ' == *line_ptr )
        line_ptr++;

    if( '#' == *line_ptr )
    {
//        LOG_INFO(( "note line: %s", line_ptr ) );
        return ERR_NOT_FOUND;
    }

    p1 = strstr(line_ptr, "=");
    if( p1 )
    {
        *p1 = '\0';

        p2 = p1 + 1;
        p1--;

        while( ' ' == *p1 )
        {
            *p1 = '\0';
            p1--;
        }
        *param_ptr = line_ptr;

        while( ' ' == *p2 ) p2++;
        while( strlen(p2) > 0
               && ' ' == p2[strlen(p2)-1] )
        {
            p2[strlen(p2)-1] = '\0';
        }
        *value_ptr = p2;

//        LOG_INFO(("[cfg]param[%s] = value[%s]", *param_ptr, *value_ptr));
    }
    else
    {
//        LOG_INFO(( "invalid line: %s", line_ptr ) );
        ret_val = ERR_NOT_FOUND;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: cfg_parse_init
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse all the config files that lc-ata will use.
 *
 * Used variables:
 * ----------------------------
 *     lc_ata_cfg_st
 *
 * Params:
 * ----------------------------
 *     Name           Type            In/Out  Description
 *     -------------  --------------  ------  ---------------------------------
 *     (None)
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
SINT32 cfg_parse_init(void)
{
    SINT32  ret_val = ERR_NONE;

    LOG_FUNC();

    memset( &lc_ata_cfg_st, 0x00, sizeof(LC_ATA_CFG_ST) );
    lc_ata_cfg_st.m_is_ap_324 = 0;
    lc_ata_cfg_st.m_is_for_cta = 0;

    ret_val = parse_lc_ata_cfg(NULL);
    ret_val = parse_sys_cfg(NULL);
    ret_val = parse_cfg_system_prop(NULL);

    strncpy( lc_ata_cfg_st.m_hardware_a, pub_util_get_hardware_name(), sizeof(lc_ata_cfg_st.m_hardware_a) - 1 );

    /* Log the product infomation. */
    {
        struct timespec tp;
        char    sys_info_a[64];
        int     sec = 0;
        int     i = 0;
        int     len = 0;

        clock_gettime(CLOCK_REALTIME, &tp);
        sec = (tp.tv_sec % 10);

        snprintf( sys_info_a,
                sizeof(sys_info_a) - 1,
                "%d-%s %s %s %s",
                sec,
                lc_ata_cfg_st.m_machine_name_a,
                lc_ata_cfg_st.m_product_vendor_a,
                lc_ata_cfg_st.m_product_model_a,
                lc_ata_cfg_st.m_hardware_a );
        len = strlen(sys_info_a);
        for( i=2; i<len; i++ )
        {
            sys_info_a[i] += sec;
        }
        LOG_DATA( "[cfg]", (UINT8 *)sys_info_a, len );
    }

    return ret_val;
}
#endif /* #ifdef OPT_ENABLE_LC_ATA_CONFIG */



#undef ATA_CFG_C
