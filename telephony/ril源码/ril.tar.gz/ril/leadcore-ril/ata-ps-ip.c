/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : ata-ps-ap.c
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : chenhua
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 * 1. 2014.8.1     chenhua          create
 ******************************************************************************/

#define ATA_PS_IP_C


/*---------------------------- include head file -----------------------------*/

#include "ata-ps.h"
#include "ata-tok.h"
#include "pub-err.h"
#include "pub-log.h"
#include "pub-util.h"
#include "pub-aos.h"
#include "atchannel.h"
#include <utils/Log.h>
#include "at_tok.h"
#include <telephony/ril.h>
#include <pthread.h>
#include "netutils/ifc.h"
#include "ata-ps-util.h"
#include <sys/system_properties.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/if_arp.h>
#include <netinet/in.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>

#ifdef OPT_ENABLE_LC_ATA_CONFIG
#include "ata-cfg.h"
#endif /* #ifdef OPT_ENABLE_LC_ATA_CONFIG */



/*---------------------- external variable declaration -----------------------*/
extern pthread_mutex_t network_op_mutex;
extern int network_op_mutex_ref;
/*----------------- external function prototype declaration ------------------*/
extern void RIL_onRequestComplete(RIL_Token t, RIL_Errno e,
                           void *response, size_t responselen);

extern void RIL_onUnsolicitedResponse(int unsolResponse, const void *data,
                                size_t datalen);

extern int property_set(const char *key, const char *value);
extern int property_get(const char *key, char *value, const char *default_value);

/*----------------------- file-local macro definition ------------------------*/
//#define LOG_TAG 							"SRIL"
#define CME_ERROR_NONE                          	-1
#define CMS_ERROR_NONE                          	-1
#define ATA_SYS_CMD_BUF_LEN			128
#define ATA_PS_4G_BACKGROUND_CID		1
#define PROP_VALUE_MAX  92

/*----------------- file-local constant and type definition ------------------*/



/*---------------- file-local function prototype declaration -----------------*/

static SINT32 ps_active_pdp(UINT8 pdp_cid);
static SINT32 ps_update_pdp_info(UINT8 pdp_cid);
static SINT32 ps_switch_data_state(UINT8 pdp_cid);
static SINT32 ps_reset_pdp_info( PDP_INFO_ST *pdp_info_ptr );
static SINT32 ps_open_lmi(UINT8 pdp_cid);
static SINT32 ps_close_lmi(UINT8 pdp_cid);
static UINT8 ps_convert_protocol_to_numeric(char * prototol_str);
static BOOL ps_is_lte_mode(void);
static BOOL ps_is_pdp_connecting(UINT8 pdp_cid); //not use
static SINT32 ps_set_pdp_status(UINT8 pdp_cid,PS_STATE_EN state);
static BOOL ps_is_received_other_cid(UINT8 pdp_cid,UINT8 * other_cid);
static BOOL ps_is_cid_other(UINT8 pdp_cid);//not use
static SINT32 ps_prepare_ms(UINT8 pdp_cid , char *protocol,  char *apn,  char *user,  char *password);
static SINT32 ps_get_idle_pdp_cid(ATA_PS_PDP_REQ_ST * pdp_req , UINT8 *pdp_cid);
static BOOL ps_is_background_pdp(UINT8 pdp_cid);
static SINT32 ps_deactive_pdp(UINT8 pdp_cid);
static PDP_INFO_ST *ps_get_pdp_info_by_ril_cid( UINT8 ril_cid );
static SINT32 ps_deactive_link(UINT8 ril_cid);
static SINT32 ps_set_lmi_ifname(UINT8 pdp_cid, char *dev_name, UINT8 len);
static SINT32 ps_query_pdp_info(int pdp_cid,ATA_PS_PDP_NETNETWORK_ST* network_info);
static BOOL ps_is_same_apn(char * apn1,char * apn2);
static BOOL ps_is_reusable_protocol_type(UINT8 pdp_req_type, UINT8 pdp_act_type, UINT8 new_pdp_req_type,BOOL strict_matching,UINT8 * reuse_pdp_type);
static PDP_INFO_ST * ps_find_reusable_link(ATA_PS_PDP_REQ_ST * pdp_req);
static SINT32 ps_get_idle_ril_cid(UINT8 *ril_cid);
static PDP_INFO_ST *  ps_active_new_link(ATA_PS_PDP_REQ_ST * pdp_req);
static void ps_update_data_call_list(RIL_Token *t);
static BOOL ps_check_background_pdp_reusable(char *apn, char *req_pdp_type,BOOL check_protocol,UINT8 * reuse_pdp_type);
static BOOL ps_is_app_used(UINT8 pdp_cid);
static SINT32 ps_set_qos(UINT8 pdp_cid);
static SINT32 ps_stop_pdp(UINT8 cid);
static SINT32 ps_stop(UINT8 pdp_cid);
static SINT32 ps_lmi_set_addrs(char *dev, char *ipaddr, char *mask); //used for BIH
PDP_INFO_ST *ps_get_pdp_info_by_pdp_cid( UINT8 pdp_cid );
static PDP_INFO_ST *ps_get_idle_pdp_info( UINT8 pdp_cid );
static SINT32 ps_get_idle_netif(char *ifname, int ifname_len);
static SINT32 ps_set_ril_cid(UINT8 ril_cid,PDP_INFO_ST *  pdp_info);
static SINT32 ps_set_pdp_apn(UINT8 pdp_cid, char *apn, UINT8 len);
static SINT32 ps_set_req_pdp_type(UINT8 pdp_cid,UINT8 req_pdp_type);
static SINT32 ps_get_req_pdp_type(UINT8 pdp_cid,UINT8 *req_pdp_type);//not use
static SINT32 ps_set_act_pdp_type(UINT8 pdp_cid,UINT8 act_pdp_type);
static SINT32 ps_get_act_pdp_type(UINT8 pdp_cid,UINT8 *act_pdp_type);//not use
static SINT32 ps_set_reuse_pdp_type(UINT8 pdp_cid,UINT8 reuse_pdp_type);
static SINT32 ps_get_reuse_pdp_type(UINT8 pdp_cid,UINT8 *reuse_pdp_type);
static SINT32 ps_set_other_cid(UINT8 pdp_cid,UINT8 other_cid);
static UINT8 ps_get_other_cid(UINT8 pdp_cid);
static SINT32 ps_get_lmi_ifname(char *ifname, int ifname_len,UINT8 pdp_cid);
SINT32 ps_get_pdp_state(UINT8 pdp_cid);
static SINT32 ps_set_addr_ipv4(UINT8 pdp_cid, char *addr_ipv4, UINT8 len);
static SINT32 ps_get_addr_ipv4(UINT8 cid, char *addr_ipv4, UINT8 len);
static SINT32 ps_set_dns_ipv4(UINT8 pdp_cid, char *dns1_ipv4, char *dns2_ipv4, UINT8  dns1_ipv4_len, UINT8  dns2_ipv4_len);
static SINT32 ps_set_gateway_ipv4(UINT8 pdp_cid, char *gateway_ipv4, UINT8 len);
static SINT32 ps_set_addr_ipv6(UINT8 pdp_cid, char *addr_ipv6, UINT8 len);
static SINT32 ps_get_addr_ipv6(UINT8 pdp_cid, char *addr_ipv6, UINT8 len);
static SINT32 ps_get_addr_link_local_ipv6(UINT8 cid, char *ipaddr_link_local_v6, UINT8 len);
static SINT32 ps_set_dns_ipv6(UINT8 pdp_cid, char *dns1_ipv6, char *dns2_ipv6, UINT8  dns1_ipv6_len, UINT8  dns2_ipv6_len);
static SINT32 ps_set_gateway_ipv6(UINT8 pdp_cid, char *gateway_ipv6, UINT8 len);
static SINT32 ps_get_ipadr_and_name(UINT8 pdp_cid, char *device_name, char *ipaddr,UINT8 pdp_type);
static SINT32 ps_get_dns_and_gateway(UINT8 pdp_cid, char *dnses, char *gateways,UINT8 pdp_type);
static BOOL ps_is_idle_netif(char * ifname);
static SINT32 ps_get_pdp_cid_by_ril_cid( UINT8 ril_cid ,UINT8 * pdp_cid);
static SINT32 ps_get_act_pdp_type_by_ril_cid(UINT8 ril_cid,UINT8 * act_pdp_type);
static SINT32 ps_get_apn(UINT8 pdp_cid,UINT8 * apn, UINT8 apn_len);
static SINT32 ps_set_interface_id_ipv6(UINT8 pdp_cid, char *ipv6_interface_id, UINT8 len);
static SINT32 ps_get_interface_id_ipv6(UINT8 pdp_cid, char *ipv6_interface_id, UINT8 len);
static SINT32 ps_set_cid_ipv6(UINT8 pdp_cid);
static void ps_send_ipv6_info_to_modem(UINT8 pdp_cid);
static SINT32 get_bip_bear_type();
static void ps_clean_ipv4_info(UINT8 pdp_cid);
static void ps_clean_ipv6_info(UINT8 pdp_cid);

static void * th_ps_ipv6_ra_config(void *param);
static void * th_ps_deactive_pdp(void *param);

SINT32 cfg_get_line( FILE *fp, char *buf_ptr, UINT32 buf_size, 
                            UINT32 *data_len_ptr, BOOL *is_end_ptr );
SINT32 cfg_get_param_and_value(char *line_ptr, char **param_ptr, 
                                      char **value_ptr );

static TTY_INFO_ST *get_idle_tty();
static UINT8 get_idle_tty_index(char *tty_device_name);
void DisableEcho(int fd);
void set_speed(int fd, int speed);
SINT32 set_parity(int fd, int databits, int stopbits, int parity,int rts, 
               int fax_or_s);






/*--------------------- file-local variables definition ----------------------*/


PDP_INFO_ST  pdp_info_st[PDP_MAX_COUNT];

static BOOL ata_ps_switch = FALSE;

static const struct timeval RETRY_TIMEVAL_1S = {1, 0};


/*--------------------------- function definition ----------------------------*/




/*******************************************************************************
 * Function: ps_get_idle_pdp_info
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Get an idle pdp info.
 *
 * Used variables:
 * ----------------------------
 *     pdp_info_st
 *
 * Params:
 * ----------------------------
 *     Name             Type               In/Out  Description
 *     ---------------  -----------------  ------  ----------------------------
 *     cid              UINT8              In      cid
 *
 * Return:
 * ----------------------------
 *     PDP info.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static PDP_INFO_ST *ps_get_idle_pdp_info( UINT8 pdp_cid )
{
    UINT8       i = 0;
    PDP_INFO_ST *pdp_info_ptr = NULL;

    /* Try to find an idle pdp info. */
    for( i = 0; i < PDP_MAX_COUNT; i++ )
    {
        if( PS_STATE_FREE == pdp_info_st[i].pdp_state )
        {
            pdp_info_ptr = &pdp_info_st[i];
            break;
        }
    }

    if(pdp_info_ptr)
    {
        pdp_info_ptr->pdp_state = PS_STATE_USED;
        pdp_info_ptr->pdp_cid = pdp_cid;
        pdp_info_ptr->pdn_act_received = FALSE;
        pdp_info_ptr->cid_other = 0;
        RLOGD("[RIL-PS][ps_get_idle_pdp_info] found idle pdp info");
    }
    else
    {
        RLOGD("[RIL-PS][ps_get_idle_pdp_info] can't find idle pdp info");
    }

    return pdp_info_ptr;
}

/*******************************************************************************
 * Function: ps_reset_pdp_info
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Free a pdp info.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name             Type               In/Out  Description
 *     ---------------  -----------------  ------  ----------------------------
 *     pdp_info_ptr     PDP_INFO_ST *      In      pdp info
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static SINT32 ps_reset_pdp_info( PDP_INFO_ST *pdp_info_ptr )
{
    /* Check parameter. */
    if( !pdp_info_ptr )
    {
        /* Error: invalid parameter. */
        return ERR_INVALID_PARAM;
    }

    if(pdp_info_ptr->pdp_cid>0)
    {
        RLOGD("[RIL-PS][ps_reset_pdp_info cid] %d ", pdp_info_ptr->pdp_cid);
    }

    memset( pdp_info_ptr, 0x00, sizeof(PDP_INFO_ST) );
    pdp_info_ptr->pdp_cid = 0;
    pdp_info_ptr->reuse_pdp_type = PROTOCOL_UNKNOW;
    pdp_info_ptr->pdp_state = PS_STATE_FREE;
    pdp_info_ptr->pdn_act_received = FALSE;
    pdp_info_ptr->cid_other = 0;
    return ERR_NONE;
}

/*******************************************************************************
 * Function: ps_get_pdp_info_by_pdp_cid
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Get a pdp info by the cid.
 *
 * Used variables:
 * ----------------------------
 *     pdp_info_st
 *
 * Params:
 * ----------------------------
 *     Name             Type               In/Out  Description
 *     ---------------  -----------------  ------  ----------------------------
 *     cid              UINT8              In      cid
 *
 * Return:
 * ----------------------------
 *     PDP info.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
PDP_INFO_ST *ps_get_pdp_info_by_pdp_cid( UINT8 pdp_cid )
{
    UINT8   i = 0;

    if((pdp_cid<PDP_MIN_VALUE)||(pdp_cid>S_PDP_MAX_VALUE))
        return NULL;

    for( i = 0; i < PDP_MAX_COUNT; i++ )
    {
        if(( pdp_cid == pdp_info_st[i].pdp_cid )||( pdp_cid == pdp_info_st[i].cid_other ))
        {
            return &pdp_info_st[i];
        }
    }

    return NULL;
}


static SINT32 ps_lmi_set_addrs(char *dev, char *ipaddr, char *mask)
{
    int err = ERR_NONE;
    int sock_v4 = 0;
    char dev_name[IFNAMSIZ] = {0};
    struct ifreq ifr;
    struct sockaddr_in sin_v4;    //ipv4

    if ((sock_v4 = socket(AF_INET, SOCK_STREAM, 0)) < 0) //ipv4
    {
        RLOGD("[RIL-PS][ps_lmi_set_addrs] sock_v4 create socket failed: %s", strerror(errno));
        goto error;
    }

    snprintf(dev_name, IFNAMSIZ-1, "%s", dev);

    //set local address to newly-created interface     //IPV4
    memset(&ifr, 0, sizeof(struct ifreq));
    strncpy(ifr.ifr_name, dev_name, IFNAMSIZ);
    ifr.ifr_name[IFNAMSIZ - 1] = 0;
    memset(&sin_v4, 0, sizeof(struct sockaddr_in));
    sin_v4.sin_family = AF_INET;
    inet_aton(ipaddr, &sin_v4.sin_addr);
    RLOGD("[RIL-PS][ps_lmi_set_addrs] v4_addr:%s  sin_addr:%d",ipaddr,sin_v4.sin_addr.s_addr);
    memcpy(&ifr.ifr_ifru.ifru_addr, &sin_v4, sizeof(struct sockaddr_in));

    if ((err = ioctl(sock_v4, SIOCSIFADDR, (void *)&ifr)) < 0)
    {
        RLOGD("[RIL-PS][ps_lmi_set_addrs] set tun ip_v4 address failed: %s", strerror(errno));
        goto error;
    }

    memset(&sin_v4, 0, sizeof(struct sockaddr_in));
    sin_v4.sin_family = AF_INET;
    if(inet_aton(mask,&sin_v4.sin_addr) < 0)
    {
        RLOGD("[RIL-PS][ps_lmi_set_addrs] convert mask fail ! ");
    }
    memcpy(&ifr.ifr_ifru.ifru_netmask, &sin_v4, sizeof(struct sockaddr_in));

    if ((err = ioctl(sock_v4, SIOCSIFNETMASK, (void *)&ifr)) < 0)
    {
        RLOGD("[RIL-PS][ps_lmi_set_addrs] set tun ipv4 mask failed: %s", strerror(errno));
        goto error;
    }

    close(sock_v4);

    return ERR_NONE;

error:
    if (sock_v4 > 0)
    {
        close(sock_v4);
    }
    return ERR_UNKNOWN;
}

/*******************************************************************************
 * Function: ata_ps_set_fake_ipv4addr
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Start a PS conversation(including PDP & PPP).
 *
 * Used variables:
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
void ata_ps_set_fake_ipv4addr(UINT8 ril_cid, char *fake_addr)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    RLOGD("[RIL-PS][ata_ps_set_fake_ipv4addr] ril cid is %d  [ril%d]",ril_cid,current_ril_id());

    /* Check if the pdp is already activated. */
    pdp_info_ptr = ps_get_pdp_info_by_ril_cid( ril_cid );

    if (pdp_info_ptr != NULL)
    {
        if ((strlen(pdp_info_ptr->pdp_network_info.ipv6_addr) != 0 )
            && (strlen(pdp_info_ptr->pdp_network_info.ipv4_addr) == 0 )
            &&(fake_addr != NULL))
        {
            strncpy(pdp_info_ptr->pdp_network_info.ipv4_addr, fake_addr, strlen(fake_addr));
        }
        else if (fake_addr == NULL)
        {
            RLOGD("[RIL-PS][ata_ps_set_fake_ipv4addr]: set ipv4 addr to null ");
            memset(pdp_info_ptr->pdp_network_info.ipv4_addr, 0x00,PDP_IP_ADDR_LENGTH_IPV4);
        }
        RLOGD("[RIL-PS][ata_ps_set_fake_ipv4addr]: IPv4 addr = %s, IPv6 addr = %s ", pdp_info_ptr->pdp_network_info.ipv4_addr, pdp_info_ptr->pdp_network_info.ipv6_addr);
        //network prefix length is 20, so subnet mask is 255.255.240.0
        ps_lmi_set_addrs(pdp_info_ptr->ifname, pdp_info_ptr->pdp_network_info.ipv4_addr, "255.255.240.0");
        pdp_info_ptr->req_pdp_type = pdp_info_ptr->req_pdp_type|PROTOCOL_IPV4;
        pdp_info_ptr->act_pdp_type = pdp_info_ptr->act_pdp_type|PROTOCOL_IPV4;
    }
    else
    {
        RLOGD("[RIL-PS][ata_ps_set_fake_ipv4addr]: pdp_info_ptr is null !");
    }

    return;
}



static SINT32 ps_prepare_ms(UINT8 pdp_cid , char *protocol,  char *apn,  char *user,  char *password)
{
    ATResponse *p_response = NULL;
    int err;
    char *cmd = NULL;

    if((!ps_is_background_pdp(pdp_cid)) || (ps_get_pdp_state(pdp_cid) == PDP_DEACTIVED))
    {
        if(apn)
        {
            asprintf(&cmd, "AT+CGDCONT=%d,\"%s\",\"%s\",,0,0", pdp_cid, protocol, apn);
        }
        else
        {
            asprintf(&cmd, "AT+CGDCONT=%d,\"%s\",,,0,0", pdp_cid, protocol);
        }

        err = at_send_command(cmd, &p_response);
        if (NULL != cmd)
        {
            free(cmd);
            cmd = NULL;
        }

        if (err < 0 || p_response->success == 0)
        {
            RLOGD("[RIL-PS][ps_prepare_ms] +CGDCONT fail\n");
            at_response_free(p_response);
            return ERR_INVALID_PARAM;
        }

        at_response_free(p_response);
        p_response = NULL;
/*
        if (user != NULL && strlen(user) > 0
            && password != NULL && strlen(password) > 0)
        {
            asprintf(&cmd, "AT^DAUTH=%d,\"%s\",\"%s\"", pdp_cid, user, password);
            err = at_send_command(cmd, &p_response);
            if (NULL != cmd)
            {
                free(cmd);
                cmd = NULL;
            }

            if (err < 0 || p_response->success == 0)
            {
                RLOGD("[RIL-PS][ps_prepare_ms] +DAUTH fail\n");
                at_response_free(p_response);
                return ERR_INVALID_PARAM;
            }
            at_response_free(p_response);
            p_response = NULL;
        }

*/
        err = ps_set_qos(pdp_cid);
        if(ERR_NONE!=err)
        {
            return ERR_INVALID_PARAM;
        }
    }

    return ERR_NONE;
}

/*******************************************************************************
 * Function: ps_start_ms
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Start a PS conversation(including PDP & PPP).
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type             In/Out  Description
 *     ------------  ---------------  ------  ---------------------------------
 *     cid             UINT8            In          pdp cid
 *  cid_current    int *              In        pdp cid to be used
 *    simID          int                 In        the sim card
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
SINT32 ata_ps_start_network(UINT8 *ril_cid, ATA_PS_PDP_REQ_ST * pdp_req)
{
    SINT32 ret_val = ERR_NONE;
    PDP_INFO_ST *pdp_info_ptr = NULL;
    UINT8 logical_cid = 0;

    RLOGD("[RIL-PS][ata_ps_start_network] [ril%d]",current_ril_id());

    if(!pdp_req||!ril_cid)
    {
        goto error;
    }

    ret_val  = ps_get_idle_ril_cid(&logical_cid);
    if( ERR_NONE != ret_val )
    {
        goto error;
    }

    pdp_info_ptr = ps_find_reusable_link(pdp_req);
    if(pdp_info_ptr)
    {
        RLOGD("[RIL-PS][ata_ps_start_network] found reusable link");
    }
    else
    {
        RLOGD("[RIL-PS][ata_ps_start_network] no reusable link");

        pdp_info_ptr  = ps_active_new_link(pdp_req);
        if( !pdp_info_ptr )
        {
            RLOGD("[RIL-PS][ata_ps_start_network] active new pdp fail");
            goto error;
        }
    }

    ret_val  = ps_set_ril_cid(logical_cid,pdp_info_ptr);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ata_ps_start_network] ps_set_ril_cid fail");
        goto error;
    }

    *ril_cid = logical_cid;
    return ERR_NONE;

error:
    ps_deactive_link(logical_cid);

    return ERR_UNKNOWN;
}

/*******************************************************************************
 * Function: ps_stop
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Stop a PS conversation(including PDP & PPP).
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type             In/Out  Description
 *     ------------  ---------------  ------  ---------------------------------
 *     cid           UINT8            In      pdp cid
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static SINT32 ps_stop(UINT8 pdp_cid)
{
    SINT32      ret_val = ERR_NONE;
    PDP_INFO_ST *pdp_info_ptr = NULL;


    /* Check if the pdp is already activated. */
    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid( pdp_cid );
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_stop] can not get pdp_info cid %d", pdp_cid);
        return ERR_INVALID_PARAM;
    }

#ifdef OPT_PS_PPP
    ata_ps_stop_ppp(pdp_cid);
#else
	ps_close_lmi(pdp_cid);
#endif
    ps_stop_pdp(pdp_cid);

    /* We'd better always return OK. */
    return ERR_NONE;
}



/*******************************************************************************
 * Function: ps_stop_pdp
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Stop a PDP conversation.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type             In/Out  Description
 *     ------------  ---------------  ------  ---------------------------------
 *     cid           UINT8            In      pdp cid
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static SINT32 ps_stop_pdp(UINT8 cid)
{
    SINT32          ret_val = ERR_NONE;
    PDP_INFO_ST     *pdp_info_ptr = NULL;

    RLOGD("[RIL-PS][ps_stop_pdp] Enter ps_stop_pdp");
    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_stop_pdp] Can not get pdp info by cid: %d", cid);
        return ERR_INVALID_PARAM;
    }

    ret_val = ps_reset_pdp_info(pdp_info_ptr);

    return ret_val;
}


/*******************************************************************************
 * Function: ps_set_qos
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Set the Qos of the pdp.
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name               Type               In/Out  Description
 *     -----------------  -----------------  ------  --------------------------
 *     cid                UINT8              In      cid of PDP
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
static SINT32 ps_set_qos(UINT8 pdp_cid)
{
    SINT32              ret_val = ERR_NONE;
    SINT32              cme_err = CME_ERROR_NONE;
    SINT32              cms_err = CMS_ERROR_NONE;
    ATA_PS_CONFIG_ST    pdp_setting_st;
    char	psRate[10] = "";
    int 	property_ret = 0;

    ret_val = ata_ps_read_config(&pdp_setting_st);
//yao.wang add on 20220816 for ps rate setting
    property_ret = property_get("persist.sys.ps.rate", psRate, NULL);
	RLOGD("[RIL-PS][ps_set_qos] get persist.sys.ps.rate ,psrate is: %s",psRate);
	if(property_ret < 0) {
        RLOGD("[RIL-PS][ps_set_qos] persist.sys.ps.rate = NULL, use the default Qos. ");
        pdp_setting_st.m_traffic_class = 2;
        pdp_setting_st.m_max_bit_ul = 2;// 2,4,6,9
        pdp_setting_st.m_max_bit_dl = 2;// 2,4,6,9
		ret_val = ERR_NONE;
    } else {
		int ps_rate = psRate[0] - '0';
        pdp_setting_st.m_traffic_class = 2;
        pdp_setting_st.m_max_bit_ul = ps_rate;// 2,4,6,9
        pdp_setting_st.m_max_bit_dl = ps_rate;// 2,4,6,9
        RLOGD("[RIL-PS][ps_set_qos] get persist.sys.ps.rate SUCCESS! set qos as:");
        RLOGD("[RIL-PS][ps_set_qos] pdp_setting_st.m_traffic_class = %d",pdp_setting_st.m_traffic_class);
        RLOGD("[RIL-PS][ps_set_qos] pdp_setting_st.m_max_bit_ul = %d",pdp_setting_st.m_max_bit_ul);
        RLOGD("[RIL-PS][ps_set_qos] pdp_setting_st.m_max_bit_dl = %d",pdp_setting_st.m_max_bit_dl);
		ret_val = ERR_NONE;
		
    	}


    if( ERR_NONE == ret_val )
    {
        char *cmd;
        int err;
        ATResponse *p_response_1 = NULL;
        asprintf(&cmd, "AT+CGEQREQ=%d,%d,%d,%d,%d,%d", pdp_cid,
                 pdp_setting_st.m_traffic_class, pdp_setting_st.m_max_bit_ul,
                 pdp_setting_st.m_max_bit_dl, pdp_setting_st.m_max_bit_ul, 
                 pdp_setting_st.m_max_bit_dl);
        err = at_send_command(cmd, &p_response_1);
        if (NULL != cmd)
        {
            free(cmd);
            cmd = NULL;
        }

        if (err < 0 || p_response_1->success == 0)
        {
            RLOGD("[RIL-PS][ps_set_qos] +CGEQREQ fail\n");
            at_response_free(p_response_1);
            return ERR_UNKNOWN;
        }
        else
        {
            at_response_free(p_response_1);
            return ERR_NONE;
        }
    }
    return ret_val;
}





/*******************************************************************************
 * Function: ps_read_config
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Read the settings of PDP(include: if auto attach GPRS, Qos info) from
 *     the config file of APP.
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name                 Type                 In/Out  Description
 *     -------------------  -------------------  ------  ----------------------
 *     pdp_setting_ptr      ATA_PS_CONFIG_ST *   Out     pdp settings
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
SINT32 ata_ps_read_config(ATA_PS_CONFIG_ST *pdp_setting_ptr)
{
    SINT32      ret_val = ERR_NONE;
    FILE        *fp = NULL;
    const char  *pdp_setting_file_ptr = "/data/etc/psqos.conf";

    LOG_FUNC();

    /* Check parameter. */
    if( !pdp_setting_ptr )
    {
        return ERR_INVALID_PARAM;
    }

    memset( pdp_setting_ptr, 0x00, sizeof(ATA_PS_CONFIG_ST) );

    fp = fopen(pdp_setting_file_ptr, "r");
    if( fp != NULL )
    {
        ret_val = fscanf( fp, "%d %d %d %d",
                          &(pdp_setting_ptr->m_is_auto_attach_gprs),
                          &(pdp_setting_ptr->m_traffic_class),
                          &(pdp_setting_ptr->m_max_bit_ul),
                          &(pdp_setting_ptr->m_max_bit_dl) );
        if( 4 == ret_val )
        {

            ret_val = ERR_NONE;
        }
        else
        {
            ret_val = ERR_CALL_C_FUNC;
        }

        fclose(fp);
    }
    else
    {
        ret_val = ERR_CALL_C_FUNC;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: ps_get_address_info
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Get the address(IP, DNS) of PDP.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type                     In/Out  Description
 *     ------------  -----------------------  ------  -------------------------
 *     cid           UINT8                    In      pdp cid
 *     address_ptr   ATA_PS_ADDRESS_INFO_ST   Out     PDP address info
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
SINT32 ata_ps_get_network_info(UINT8 ril_cid, ATA_PS_NETWORK_INFO_ST * network_info)
{
    SINT32     ret_val = ERR_NONE;
    UINT8      pdp_cid = 0;
    UINT8      reuse_pdp_type = PROTOCOL_UNKNOW;
    UINT8      current_pdp_type = PROTOCOL_UNKNOW;

    RLOGD("[RIL-PS][ata_ps_get_network_info] ril_cid %d [ril%d]", ril_cid,current_ril_id());

    if(!network_info)
    {
        ret_val = ERR_INVALID_PARAM;
        goto end;
    }

    ret_val = ps_get_pdp_cid_by_ril_cid(ril_cid,&pdp_cid);
    if(ERR_NONE != ret_val)
    {
        RLOGD("[RIL-PS][ata_ps_get_network_info] get pdp failed ,ril_cid %d ", ril_cid);
        ret_val = ERR_UNKNOWN;
        goto end;
    }

    ret_val = ps_get_reuse_pdp_type(pdp_cid,&reuse_pdp_type);
    if(ERR_NONE != ret_val)
    {
        RLOGD("[RIL-PS][ata_ps_get_network_info] get pdp req type failed ,ril_cid %d ", ril_cid);
        ret_val = ERR_UNKNOWN;
        goto end;
    }

    current_pdp_type = reuse_pdp_type;

    if(PROTOCOL_IPV4V6 == reuse_pdp_type)
    {
        char addr_ipv6[PDP_IP_ADDR_LENGTH_IPV6] = {0};
	 ret_val = ps_get_addr_ipv6(pdp_cid,addr_ipv6,PDP_IP_ADDR_LENGTH_IPV6);
        if( ERR_NONE != ret_val )
       {
           ret_val = ERR_UNKNOWN;
           goto end;
       }

       if(strlen(addr_ipv6)==0)
       {//v6 ra addr updating is not finish
           current_pdp_type = PROTOCOL_IPV4;
       }
    }

    network_info->pdp_type =  current_pdp_type;
    RLOGD("[RIL-PS][ata_ps_get_network_info] pdp_type is %d ", network_info->pdp_type);

    ret_val = ps_get_apn(pdp_cid,network_info->apn,PDP_APN_LENGTH);
    if(ERR_NONE != ret_val)
    {
        RLOGD("[RIL-PS][ata_ps_get_network_info] ps_get_apn failed ,pdp_cid %d ", pdp_cid);
        ret_val = ERR_UNKNOWN;
        goto end;
    }

    ret_val = ps_get_ipadr_and_name(pdp_cid, network_info->ifname, network_info->ip_address,current_pdp_type);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ata_ps_get_network_info] get ps_get_ipadr_and_name failed ");
        ret_val = ERR_UNKNOWN;
        goto end;
    }

    ret_val = ps_get_dns_and_gateway(pdp_cid, network_info->dnses, network_info->gateways,current_pdp_type);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ata_ps_get_network_info] get ps_get_dns_and_gateway failed ");
        ret_val = ERR_UNKNOWN;
        goto end;
    }

end:

    return ret_val;
}

/*******************************************************************************
 * Function: ps_is_app_used
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Check if the PS is used by APP accroding to the <cid>.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type                     In/Out  Description
 *     ------------  -----------------------  ------  -------------------------
 *     cid           UINT8                    In      pdp cid
 *
 * Return:
 * ----------------------------
 *     TRUE : the PS is used by APP
 *     FALSE: the PS is not used by APP(used bu PC, SoftModem)
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static BOOL ps_is_app_used(UINT8 pdp_cid)
{
    BOOL        ret_val = TRUE;
    PDP_INFO_ST *pdp_info_ptr = NULL;


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);

    if( pdp_info_ptr )
    {
        if (PS_STATE_FREE == pdp_info_ptr->pdp_state)
        {
            RLOGD("[RIL-PS][ps_is_app_used] state of cid(%d) is free ", pdp_cid);
            ret_val = FALSE;
        }
    }
    else
    {
        RLOGD("[RIL-PS][ps_is_app_used] cid(%d) is not used", pdp_cid);
        ret_val = FALSE;
    }

    return ret_val;
}

SINT32 ata_unsolicited_at_cgev(UINT8 *begin_ptr)
{
    SINT32  	ret_val = ERR_NONE;
    char    	pdp_addr[28] = {0};
    UINT8   	pdp_cid = 0, reason = 0, cid_other = 0;
    UINT8   	i = 0;
    char 	*tmp_begin_ptr = NULL;
    char 	*cmd = NULL;

    /* Check parameter. */
    if(!begin_ptr)
    {
        return ERR_INVALID_PARAM;
    }

    tmp_begin_ptr = (char *)begin_ptr;
    if (!strstr((char *)begin_ptr, "PDN"))
    {
        ret_val = at_tok_parse_ext(
                      (SINT8 **)(&tmp_begin_ptr),
                      "OSU",
                      (sizeof(pdp_addr) - 1), pdp_addr,
                      &pdp_cid,
                      (char *)NULL );

        if( 2 == ret_val )
        {
            /*if receive NW REACT,it is consedered to be disconnected*/
            if( strstr((char *)begin_ptr, "ME ACT"))
            {
                if (ps_is_app_used(pdp_cid)) {
	            	RLOGD("receive CGEV ME ACT, cid = %d, pdp_addr = %s", pdp_cid, pdp_addr);
					property_set("sys.ps.ipaddr", pdp_addr);
	                ret_val = ps_set_addr_ipv4(pdp_cid, pdp_addr, strlen(pdp_addr));
			    } 
            }
            else if (strstr((char *)begin_ptr, "NW DEACT") || strstr((char *)begin_ptr, "ME DEACT") ||
                     strstr((char *)begin_ptr, "NW REACT") )
            {
                pthread_t   thread_id;
                ret_val = pthread_create(&thread_id,NULL,th_ps_deactive_pdp,(void *)(UINT32) pdp_cid);
                if (ret_val != ERR_NONE) {
                    RLOGE("[RIL-PS][ata_unsolicited_at_cgev] [at_cgev] create ps deactive thread failed! errNo=%d, pdp_cid=%d", ret_val, pdp_cid);
                } else {
                    RLOGD("[RIL-PS][ata_unsolicited_at_cgev] [at_cgev] create ps deactive thread success! tid=%d, pdp_cid=%d", thread_id, pdp_cid);
                }
            }
        }
    }
    else if (strstr((char *)begin_ptr, "PDN"))
    {
        if (strstr((char *)begin_ptr, "PDN ACT"))
        {
            tmp_begin_ptr = strstr(((char *)begin_ptr), "ACT");
            if(NULL != tmp_begin_ptr)
            {
                tmp_begin_ptr += strlen("ACT");
                RLOGD("[RIL-PS][ata_unsolicited_at_cgev] [at_cgev] PDN ACT string: %s", tmp_begin_ptr);
                ret_val = at_tok_parse_ext((SINT8 **)(&tmp_begin_ptr), "UUU", &pdp_cid, &reason, &cid_other );
                RLOGD("[RIL-PS][ata_unsolicited_at_cgev] [at_cgev]PDN ACT cid = %d, reason = %d, cid_other = %d", pdp_cid, reason, cid_other);
            }
            //nothing to do
        }

        if (strstr((char *)begin_ptr, "PDN DEACT"))
        {
            tmp_begin_ptr = strstr(((char *)begin_ptr), "DEACT");
            if(NULL != tmp_begin_ptr)
            {
                tmp_begin_ptr += strlen("DEACT");
                RLOGD("[RIL-PS][ata_unsolicited_at_cgev] [at_cgev] PDN DEACT string: %s", tmp_begin_ptr);
                ret_val = at_tok_parse_ext((SINT8 **)(&tmp_begin_ptr), "U", &pdp_cid );
                RLOGD("[RIL-PS][ata_unsolicited_at_cgev] [at_cgev] PDN DEACT cid: %d", pdp_cid);
            }

            pthread_t   thread_id;
            ret_val = pthread_create(&thread_id,NULL,th_ps_deactive_pdp,(void *)(UINT32) pdp_cid);
            if (ret_val != ERR_NONE) {
                RLOGE("[RIL-PS][ata_unsolicited_at_cgev] [at_cgev] PDN create ps deactive thread failed! errNo=%d, pdp_cid=%d", ret_val, pdp_cid);
            } else {
                RLOGD("[RIL-PS][ata_unsolicited_at_cgev] [at_cgev] PDN create ps deactive thread success! tid=%d, pdp_cid=%d", thread_id, pdp_cid);
            }
        }
    }

    return ret_val;
}

static SINT32 ps_get_ipadr_and_name(UINT8 pdp_cid, char *device_name, char *ipaddr,UINT8 pdp_type)
{
    PDP_INFO_ST     *pdp_info_ptr = NULL;
	RLOGD( "[panda_wyy_0728][ps_get_ipadr_and_name] device_name=%s, ipaddr=%s",device_name,ipaddr);

    if(ipaddr == NULL || device_name == NULL)   //should add other conditions, todo
    {
        return ERR_INVALID_PARAM;
    }

    if(pdp_type<PROTOCOL_IPV4||pdp_type>PROTOCOL_IPV4V6)
    {
        RLOGD( "[RIL-PS][ps_get_ipadr_and_name] req_pdp_type error ");
        return ERR_INVALID_PARAM;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        return ERR_UNKNOWN;
    }
    RLOGD("ps_get_ipadr_and_name, ipaddr = %s, device_name = %s, pdp_type = %d",
            pdp_info_ptr->pdp_network_info.ipv4_addr, pdp_info_ptr->ifname, pdp_type);

    memcpy(device_name, pdp_info_ptr->ifname, strlen(pdp_info_ptr->ifname));


    if(PROTOCOL_IPV4 == pdp_type)
    {
        memcpy(ipaddr, pdp_info_ptr->pdp_network_info.ipv4_addr, strlen(pdp_info_ptr->pdp_network_info.ipv4_addr));
    }
    else if(PROTOCOL_IPV6 == pdp_type)
    {
        memcpy(ipaddr, pdp_info_ptr->pdp_network_info.ipv6_addr, strlen(pdp_info_ptr->pdp_network_info.ipv6_addr));
    }
    else if(PROTOCOL_IPV4V6 == pdp_type)
    {
        memcpy(ipaddr, pdp_info_ptr->pdp_network_info.ipv4_addr, strlen(pdp_info_ptr->pdp_network_info.ipv4_addr));
        if (strlen(pdp_info_ptr->pdp_network_info.ipv4_addr)  != 0 && strlen(pdp_info_ptr->pdp_network_info.ipv6_addr)  != 0)
        {
            memcpy((ipaddr + strlen(pdp_info_ptr->pdp_network_info.ipv4_addr)), " ", 1);  //space delimited
            memcpy((ipaddr + strlen(pdp_info_ptr->pdp_network_info.ipv4_addr) + 1), pdp_info_ptr->pdp_network_info.ipv6_addr, strlen(pdp_info_ptr->pdp_network_info.ipv6_addr));
        }
        else if (strlen(pdp_info_ptr->pdp_network_info.ipv6_addr)  != 0)
        {
            memcpy(ipaddr, pdp_info_ptr->pdp_network_info.ipv6_addr, strlen(pdp_info_ptr->pdp_network_info.ipv6_addr));
        }
    }

    return ERR_NONE;
}

static SINT32 ps_get_dns_and_gateway(UINT8 pdp_cid, char *dnses, char *gateways,UINT8 pdp_type)
{
    PDP_INFO_ST     *pdp_info_ptr = NULL;
    char *tmp_dns_ptr =  dnses;
    char *tmp_gateway_ptr = gateways;
    char *ipv4_default_gateway  = "0.0.0.0";
    char *ipv6_default_gateway = "0:0:0:0:0:0:0:0";
	RLOGD("[panda_wyy_0728] cid: %d,dnses = %d,gateways = %d,pdp_type = %d", pdp_cid,strlen(dnses),strlen(gateways),pdp_type) ;

    if(dnses == NULL || gateways == NULL)
    {
        RLOGD("[RIL-PS][ps_get_dns_and_gateway] parameter is null ");
        return ERR_INVALID_PARAM;
    }

    if(pdp_type<PROTOCOL_IPV4||pdp_type>PROTOCOL_IPV4V6)
    {
        RLOGD( "[RIL-PS][ps_get_dns_and_gateway] req_pdp_type error ");
        return ERR_INVALID_PARAM;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_dns_and_gateway] Can not get pdp info by cid: %d", pdp_cid) ;
        return ERR_UNKNOWN;
    }


    if(PROTOCOL_IPV4 == pdp_type)
    {
        if ( strlen(pdp_info_ptr->pdp_network_info.ipv4_dns1) != 0)
        {
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv4_dns1, strlen(pdp_info_ptr->pdp_network_info.ipv4_dns1));
            tmp_dns_ptr += strlen(pdp_info_ptr->pdp_network_info.ipv4_dns1);
        }
        if ( strlen(dnses) != 0 &&strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2) != 0)
        {
            memcpy(tmp_dns_ptr, " ", 1);  //space delimited
            tmp_dns_ptr += 1;
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv4_dns2, strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2));
            tmp_dns_ptr += strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2);
        }
        else if (strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2) != 0)
        {
            //v4 dns1 is null
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv4_dns2, strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2));
        }

        if (strlen(pdp_info_ptr->pdp_network_info.ipv4_gateway)  != 0)
        {
                memcpy(tmp_gateway_ptr, pdp_info_ptr->pdp_network_info.ipv4_gateway, strlen(pdp_info_ptr->pdp_network_info.ipv4_gateway));
        }
        else
        {
                memcpy(tmp_gateway_ptr, ipv4_default_gateway, strlen(ipv4_default_gateway));
        }

        
    }
    else if(PROTOCOL_IPV6 == pdp_type)
    {
        if (strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1) != 0)
        {
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv6_dns1, strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1));
            tmp_dns_ptr += strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1);
        }
        else if (strlen(dnses) != 0 && strlen(pdp_info_ptr->pdp_network_info.ipv6_dns2) != 0)
        {
            memcpy(tmp_dns_ptr, " ", 1);  //space delimited
            tmp_dns_ptr += 1;
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv6_dns2, strlen(pdp_info_ptr->pdp_network_info.ipv6_dns2));
        }
        else if (strlen(pdp_info_ptr->pdp_network_info.ipv6_dns2) != 0)
        {
            //v6 dns1 is null
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv6_dns2, strlen(pdp_info_ptr->pdp_network_info.ipv6_dns2));
        }

        if (strlen(pdp_info_ptr->pdp_network_info.ipv6_gateway)  != 0)
        {
            memcpy(tmp_gateway_ptr,pdp_info_ptr->pdp_network_info.ipv6_gateway, strlen(pdp_info_ptr->pdp_network_info.ipv6_gateway));
        }
        else
        {
            memcpy(tmp_gateway_ptr, ipv6_default_gateway, strlen(ipv6_default_gateway));
        }
    }
    else if(PROTOCOL_IPV4V6 == pdp_type)
    {
        memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv4_dns1, strlen(pdp_info_ptr->pdp_network_info.ipv4_dns1));
        tmp_dns_ptr += strlen(pdp_info_ptr->pdp_network_info.ipv4_dns1);
        if (strlen(dnses) != 0 && strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2) != 0)
        {
            memcpy(tmp_dns_ptr, " ", 1);  //space delimited
            tmp_dns_ptr += 1;
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv4_dns2, strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2));
            tmp_dns_ptr += strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2);
        }
        else if (strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2) != 0)
        {
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv4_dns2, strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2));
            tmp_dns_ptr += strlen(pdp_info_ptr->pdp_network_info.ipv4_dns2);
        }

        if (strlen(dnses) != 0 && strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1) != 0)
        {
            memcpy(tmp_dns_ptr, " ", 1);  //space delimited
            tmp_dns_ptr += 1;
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv6_dns1, strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1));
            tmp_dns_ptr += strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1);
        }
        else if (strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1) != 0)
        {
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv6_dns1, strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1));
            tmp_dns_ptr += strlen(pdp_info_ptr->pdp_network_info.ipv6_dns1);
        }

        if (strlen(dnses) != 0 && strlen(pdp_info_ptr->pdp_network_info.ipv6_dns2) != 0)
        {
            memcpy(tmp_dns_ptr, " ", 1);  //space delimited
            tmp_dns_ptr += 1;
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv6_dns2, strlen(pdp_info_ptr->pdp_network_info.ipv6_dns2));
        }
        else if (strlen(pdp_info_ptr->pdp_network_info.ipv6_dns2) != 0)
        {
            memcpy(tmp_dns_ptr, pdp_info_ptr->pdp_network_info.ipv6_dns2, strlen(pdp_info_ptr->pdp_network_info.ipv6_dns2));
        }

        if (strlen(pdp_info_ptr->pdp_network_info.ipv4_addr) != 0)
        {
            if (strlen(pdp_info_ptr->pdp_network_info.ipv4_gateway)  != 0)
            {
                memcpy(tmp_gateway_ptr, pdp_info_ptr->pdp_network_info.ipv4_gateway, strlen(pdp_info_ptr->pdp_network_info.ipv4_gateway));
                tmp_gateway_ptr +=  strlen(pdp_info_ptr->pdp_network_info.ipv4_gateway);
            }
            else
            {
                memcpy(tmp_gateway_ptr, ipv4_default_gateway, strlen(ipv4_default_gateway));
                tmp_gateway_ptr += strlen(ipv4_default_gateway);
            }
        }

        if (strlen(pdp_info_ptr->pdp_network_info.ipv6_addr)  != 0)
        {
            if (strlen(gateways) != 0)
            {
                memcpy(tmp_gateway_ptr, " ", 1);  //space delimited
                tmp_gateway_ptr += 1;
            }
            if (strlen(pdp_info_ptr->pdp_network_info.ipv6_gateway)  != 0)
            {
                memcpy(tmp_gateway_ptr,pdp_info_ptr->pdp_network_info.ipv6_gateway, strlen(pdp_info_ptr->pdp_network_info.ipv6_gateway));
            }
            else
            {
                memcpy(tmp_gateway_ptr, ipv6_default_gateway, strlen(ipv6_default_gateway));
            }
        }

    }

    return ERR_NONE;
}




void ata_unsolicited_at_pcd(UINT8 *begin_ptr)
{
    //nothing to do
    return;
}

static SINT32 ps_query_pdp_info(int pdp_cid,ATA_PS_PDP_NETNETWORK_ST* network_info)
{
    SINT32      ret_val = ERR_NONE;
    char *cmd = NULL;
    int err = 0;
    int commas = 0;
    char *p = NULL;
    char *responseStr = NULL;
    int tmp_cid = 0;
    int tmp_bearer_id = 0;
    char *tmp = 0;
    ATResponse *p_response = NULL;
    int response_count = 0;
    ATLine *p_cur = NULL;
    int i, k = 0;
    int ip_format = 0xff;
    char *line = NULL;

    if(!network_info)
        return ERR_INVALID_PARAM;

    //get ip type

    asprintf(&cmd, "AT^DPAIQ=%d", pdp_cid);
    err = at_send_command_singleline(cmd, "^DPAIQ:", &p_response);
    free(cmd);

    if (err < 0 || p_response->success == 0)
    {
        RLOGD("[RIL-PS][ps_query_pdp_info] AT^DPAIQ fail");
        ret_val = ERR_UNKNOWN;
        goto error;
    }
    else
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if(err < 0)
        {
            RLOGD("[RIL-PS][ps_query_pdp_info] AT^DPAIQ at_tok_start error");
            ret_val = ERR_UNKNOWN;
            goto error;
        }
        else
        {
            int p_cid = 0;
            int req_pdp_type = 0 ;
            int act_pdp_type = 0 ;

            err = at_tok_nextint(&line, &p_cid);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_query_pdp_info] get DPAIQ qcid error ");
                ret_val = ERR_UNKNOWN;
                goto error;
            }
            network_info->pdp_cid=p_cid;

            err = at_tok_nextint(&line, &req_pdp_type);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_query_pdp_info] get req_pdp_type error ");
                ret_val = ERR_UNKNOWN;
                goto error;
            }

            network_info->req_pdp_type=req_pdp_type;
            RLOGD("[RIL-PS][ps_query_pdp_info] cid %d req_pdp_type is  %d",pdp_cid,network_info->req_pdp_type);

            err = at_tok_nextint(&line, &act_pdp_type);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_query_pdp_info] get act_pdp_type error ");
                ret_val = ERR_UNKNOWN;
                goto error;
            }

            network_info->act_pdp_type=act_pdp_type;
            RLOGD("[RIL-PS][ps_query_pdp_info] cid %d act_pdp_type is  %d",pdp_cid,network_info->act_pdp_type);

        }
        at_response_free(p_response);
        p_response = NULL;
    }

    /*if have ipv4 address only, do not wait */
    if ((network_info->act_pdp_type == PROTOCOL_IPV6 )||(network_info->act_pdp_type == PROTOCOL_IPV4V6 ))
    {
        //set  IPV6 Address Format
        err = at_send_command_singleline("AT+CGPIAF?", "+CGPIAF:", &p_response);
        if (err < 0 || p_response->success == 0)
        {
            RLOGD("[RIL-PS][ps_query_pdp_info] AT+CGPIAF? is error:%d", err);
            ret_val = ERR_UNKNOWN;
            goto error;
        }

        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_query_pdp_info] parse +CGPIAF: occurs error:%d", err);
            ret_val = ERR_UNKNOWN;
            goto error;
        }

        err = at_tok_nextint(&line, &ip_format);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_query_pdp_info] parse +CGPIAF ip_format occurs error:%d", err);
            ret_val = ERR_UNKNOWN;
            goto error;
        }

        RLOGD("[RIL-PS][ps_query_pdp_info] ip_format:%d", ip_format);

        at_response_free(p_response);
        p_response = NULL;

        if( 1 != ip_format)
        {
            err = at_send_command("AT+CGPIAF=1", &p_response);
            if (err < 0 || p_response->success == 0)
            {
                RLOGD("[RIL-PS][ps_query_pdp_info] AT+CGPIAF=1 is error:%d", err);
                ret_val = ERR_UNKNOWN;
                goto error;
            }
            at_response_free(p_response);
            p_response = NULL;
        }
    }


    asprintf(&cmd, "AT+CGCONTRDP=%d", pdp_cid);
    err = at_send_command_multiline(cmd, "+CGCONTRDP:", &p_response);
    free(cmd);

    if (err < 0 || p_response->success == 0)
    {
        RLOGD("[RIL-PS][ps_query_pdp_info] AT respond is error:%d", err);
        ret_val = ERR_UNKNOWN;
        goto error;
    }

    for (p_cur = p_response->p_intermediates; p_cur != NULL;p_cur = p_cur->p_next)
    {
        line = p_cur ->line;
        err = at_tok_start(&line);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_query_pdp_info] parse start occurs error:%d", err);
            ret_val = ERR_UNKNOWN;
            goto error;
        }

        for (p = line ; *p != '\0' ; p++)
        {
            if (*p == ',') commas++;
        }

        if (commas >= 2)
        {
            /* +CGCONTRDP: <p_cid>, <bearer_id>, <apn>, <ip_addr with subnet_mask>, <gw_addr>, <DNS_prim_addr>, <DNS_sec_addr>*/
            err = at_tok_nextint(&line, &tmp_cid);
            err = at_tok_nextint(&line, &tmp_bearer_id);
            err = at_tok_nextstr(&line, &tmp);

            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_query_pdp_info] parse apn occurs error:%d", err);
                ret_val = ERR_UNKNOWN;
                goto error;
            }

            if(strlen(network_info->apn)==0)
            {
                memcpy(network_info->apn, tmp, PDP_APN_LENGTH);
            }

            err = at_tok_nextstr(&line, &responseStr);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_query_pdp_info] parse ip occurs error:%d", err);
                ret_val = ERR_UNKNOWN;
                goto error;
            }
            //break ip addr out from ipaddr-subetmask string
            char *resp_iter_ptr = responseStr;
            int count = 0;
            int i = 0;
            int ip_len = 0;
            int interface_id_len = 0;
            char *ip_ptr = responseStr;
            char *interface_id_ptr = responseStr;
            char *colon_separator_ptr = responseStr;
            char *dot_separator_ptr = responseStr;
            int colon_separator_num = 0;
            int dot_separator_num = 0;

            count = strlen(responseStr);
            RLOGD("[RIL-PS][ps_query_pdp_info] ip_addr with subnet_mask = %s,resp_iter_ptr=%s,count =%d", responseStr, resp_iter_ptr, count);

            //check ":" colon-separator,  15 is max_count  of ":"
            while((colon_separator_num < 16) && ( i <= count) )
            {
                if ( *colon_separator_ptr == ':')
                {
                    colon_separator_num++;
                }
                colon_separator_ptr++;
                i++;
            }

            //check "." dot-separator
            i = 0;
            //check ":" colon-separator,  31 is max_count  of "."
            while((dot_separator_num < 32) && ( i <= count) )
            {
                if ( *dot_separator_ptr == '.')
                {
                    dot_separator_num++;
                }
                dot_separator_ptr++;
                i++;
            }

            RLOGD("[RIL-PS][ps_query_pdp_info] colon_separator_num=%d,dot_separator_num=%d", colon_separator_num, dot_separator_num);

            //ipv6
            if (  ((0 == colon_separator_num) && (31 == dot_separator_num) ) ||  (0 != colon_separator_num)  )
            {
                ret_val = ps_set_cid_ipv6(pdp_cid);
                if( ERR_NONE != ret_val )
                {
                    RLOGD("[RIL-PS][ps_query_pdp_info] set cid_ipv6 failed ");
                    ret_val = ERR_UNKNOWN;
                    goto error;
                }

                if((0 == colon_separator_num) && (31 == dot_separator_num) )
                {
                    BOOL found_interface_id = FALSE;
                    count = 0;
                    ip_ptr = responseStr;

                    while(count < 16)
                    {
                        if (*ip_ptr == '.')
                        {
                            count++;
                        }

                        if ((8 == count)&&(found_interface_id==FALSE))    //interface id starts here
                        {
                            interface_id_ptr = ip_ptr;
                            interface_id_ptr ++;
                            found_interface_id=TRUE;
                        }
                        ip_ptr++;
                    }

                    if((network_info->act_pdp_type == PROTOCOL_IPV6 )||(network_info->act_pdp_type == PROTOCOL_IPV4V6 ))
                    {
                        char  ipv6_link_local_addr[PDP_IP_ADDR_LENGTH_IPV6] = {0};
                        ip_len = (ip_ptr - responseStr) / sizeof(char) - 1;
                        interface_id_len = (ip_ptr - interface_id_ptr) / sizeof(char) - 1;
                        RLOGD("[RIL-PS][ps_query_pdp_info] ip_len= %d, interface_id_len = %d ", ip_len, interface_id_len);
                        if(strlen(network_info->ipv6_addr)==0)
                        {
                            memcpy(network_info->ipv6_addr, responseStr, ip_len);
                        }
                        strcpy(ipv6_link_local_addr, "254.128.0.0.0.0.0.0.");
                        memcpy(ipv6_link_local_addr + strlen("254.128.0.0.0.0.0.0."), interface_id_ptr, interface_id_len);
                        if(strlen(network_info->ipv6_link_local_addr)==0)
                        {
                            memcpy(network_info->ipv6_link_local_addr, ipv6_link_local_addr, strlen("254.128.0.0.0.0.0.0.") + interface_id_len);
                        }
                        RLOGD("[RIL-PS][ps_query_pdp_info] ipv6_addr= %s, link local addr = %s ", network_info->ipv6_addr, network_info->ipv6_link_local_addr);
                        memset(network_info->ipv6_addr, 0, PDP_IP_ADDR_LENGTH_IPV6);

                        memset(network_info->ipv6_interface_id, 0, PDP_IP_ADDR_LENGTH_IPV6);
                        strncpy(network_info->ipv6_interface_id, interface_id_ptr, interface_id_len);
                        RLOGD("[PS][ps_query_pdp_info] interface_id = %s ", interface_id_ptr);
                        
                    }

                }
                if (0 != colon_separator_num)
                {
                    BOOL found_interface_id = FALSE;
                    count = 0;
                    ip_ptr = responseStr;
                    while(count < 8)
                    {
                        if (*ip_ptr == ':')
                        {
                            count++;
                        }
                        //space separator
                        if (*ip_ptr == ' ')
                        {
                            ip_ptr++;
                            break;
                        }

                        if ((4 == count)&&(found_interface_id==FALSE))    //interface id starts here
                        {
                            interface_id_ptr = ip_ptr;
                            interface_id_ptr ++;
                            found_interface_id = TRUE;
                        }

                        ip_ptr++;

                    }
                    if((network_info->act_pdp_type == PROTOCOL_IPV6 )||(network_info->act_pdp_type == PROTOCOL_IPV4V6 ))
                    {
                        char  ipv6_link_local_addr[PDP_IP_ADDR_LENGTH_IPV6] = {0};
                        ip_len = (ip_ptr - responseStr) / sizeof(char) - 1;
                        interface_id_len = (ip_ptr - interface_id_ptr) / sizeof(char) - 1;
                        RLOGD("[RIL-PS][ps_query_pdp_info] ip_len= %d, interface_id_len = %d ", ip_len, interface_id_len);
                        RLOGD("[RIL-PS][ps_query_pdp_info] interface id = %s", interface_id_ptr);
                        if(strlen(network_info->ipv6_addr)==0)
                        {
                            memcpy(network_info->ipv6_addr, responseStr, ip_len);
                        }
                        strcpy(ipv6_link_local_addr, "fe80::");
                        memcpy(ipv6_link_local_addr + strlen("fe80::"), interface_id_ptr, interface_id_len);
                        if(strlen(network_info->ipv6_link_local_addr)==0)
                        {
                            memcpy(network_info->ipv6_link_local_addr, ipv6_link_local_addr, strlen("fe80::") + interface_id_len);
                        }
                        RLOGD("[RIL-PS][ps_query_pdp_info] ipv6_addr= %s, link local addr = %s ", network_info->ipv6_addr, network_info->ipv6_link_local_addr);
                        memset(network_info->ipv6_addr, 0, PDP_IP_ADDR_LENGTH_IPV6);
                        memset(network_info->ipv6_interface_id, 0, PDP_IP_ADDR_LENGTH_IPV6);
                        strncpy(network_info->ipv6_interface_id, interface_id_ptr, interface_id_len);
                        RLOGD("[RIL-PS][ps_query_pdp_info] interface_id = %s ", interface_id_ptr);
                    }
                }
                //gw_addr
                err = at_tok_nextstr(&line, &tmp);

                if((network_info->act_pdp_type == PROTOCOL_IPV6 )||(network_info->act_pdp_type == PROTOCOL_IPV4V6 ))
                {
                    if(strlen(network_info->ipv6_gateway)==0)
                    {
                        memcpy(network_info->ipv6_gateway,  tmp, strlen(tmp));
                    }
                    RLOGD("[RIL-PS][ps_query_pdp_info] gw_addr_ipv6 = %s", network_info->ipv6_gateway);
                }

                if (err < 0)
                {
                    RLOGD("[RIL-PS][ps_query_pdp_info] parse gw_add_ipv6 occurs error:%d", err);
                    ret_val = ERR_UNKNOWN;
                    goto error;
                }


                if((network_info->act_pdp_type == PROTOCOL_IPV6 )||(network_info->act_pdp_type == PROTOCOL_IPV4V6 ))
                {
                    char dns1_ipv6[PDP_IP_ADDR_LENGTH_IPV6] = {0};
                    char dns2_ipv6[PDP_IP_ADDR_LENGTH_IPV6] = {0};
                    //dns1
                    err = at_tok_nextstr(&line, &tmp);
                    strncpy(dns1_ipv6, tmp, strlen(tmp));
                    RLOGD("[RIL-PS][ps_query_pdp_info] dns1_ipv6 = %s", dns1_ipv6);
                    if (err < 0)
                    {
                        RLOGD("[RIL-PS][ps_query_pdp_info] parse dns_ipv61 occurs error:%d", err);
                        ret_val = ERR_UNKNOWN;
                        goto error;
                    }

                    //dns2
                    err = at_tok_nextstr(&line, &tmp);
                    strncpy(dns2_ipv6, tmp, strlen(tmp));
                    RLOGD("[RIL-PS][ps_query_pdp_info] dns2_ipv6 = %s", dns2_ipv6);
                    if (err < 0)
                    {
                        RLOGD("[RIL-PS][ps_query_pdp_info] parse dns2 occurs error:%d", err);
                        ret_val = ERR_UNKNOWN;
                        goto error;
                    }

                    if(strlen(network_info->ipv6_dns1)==0)
                    {
                        memcpy(network_info->ipv6_dns1, dns1_ipv6, strlen(dns1_ipv6));
                    }

                    if(strlen(network_info->ipv6_dns2)==0)
                    {
                        memcpy(network_info->ipv6_dns2, dns2_ipv6, strlen(dns2_ipv6));
                    }
                }
            }// end ipv6

            //ipv4
            else if (  (0 == colon_separator_num) && (7 == dot_separator_num) )
            {
                count = 0;
                ip_ptr = responseStr;

                while(count < 4)
                {
                    if (*ip_ptr == '.')
                    {
                        count++;
                    }
                    ip_ptr++;

                }

                if((network_info->act_pdp_type == PROTOCOL_IPV4 )||(network_info->act_pdp_type == PROTOCOL_IPV4V6 ))
                {
                    if(strlen(network_info->ipv4_addr)==0)
                    {
                        memcpy(network_info->ipv4_addr, responseStr, (ip_ptr - responseStr) / sizeof(char) - 1);
                    }
                    RLOGD("[RIL-PS][ps_query_pdp_info] ipv4_addr= %s", network_info->ipv4_addr);

                    //gw_addr
                    err = at_tok_nextstr(&line, &tmp);

                    if (err < 0)
                    {
                        RLOGD("[RIL-PS][ps_query_pdp_info] parse gw_addr occurs error:%d", err);
                        ret_val = ERR_UNKNOWN;
                        goto error;
                    }

                    if(strlen(network_info->ipv4_gateway)==0)
                    {
                        memcpy(network_info->ipv4_gateway , tmp, strlen(tmp));
                    }
                    RLOGD("[RIL-PS][ps_query_pdp_info] gw_addr = %s", network_info->ipv4_gateway);

                    char dns1_ipv4[PDP_IP_ADDR_LENGTH_IPV4] = {0};
                    char dns2_ipv4[PDP_IP_ADDR_LENGTH_IPV4] = {0};
                    //dns1
                    err = at_tok_nextstr(&line, &tmp);
                    strncpy(dns1_ipv4, tmp, strlen(tmp));
                    RLOGD("[RIL-PS][ps_query_pdp_info] dns1 = %s", dns1_ipv4);
                    if (err < 0)
                    {
                        RLOGD("[RIL-PS][ps_query_pdp_info] parse dns1 occurs error:%d", err);
                        ret_val = ERR_UNKNOWN;
                        goto error;
                    }
                    //dns2
                    err = at_tok_nextstr(&line, &tmp);
                    strncpy(dns2_ipv4, tmp, strlen(tmp));
                    RLOGD("[RIL-PS][ps_query_pdp_info] dns2 = %s", dns2_ipv4);
                    if (err < 0)
                    {
                        RLOGD("[RIL-PS][ps_query_pdp_info] parse dns2 occurs error:%d", err);
                        ret_val = ERR_UNKNOWN;
                        goto error;
                    }

                    if(strlen(network_info->ipv4_dns1)==0)
                    {
                        memcpy(network_info->ipv4_dns1, dns1_ipv4, strlen(dns1_ipv4));
                    }
                    if(strlen(network_info->ipv4_dns2)==0)
                    {
                        memcpy(network_info->ipv4_dns2 , dns2_ipv4, strlen(dns2_ipv4));
                    }
                }
            }// end ipv4
        }
        else
        {
            RLOGD("[RIL-PS][ps_query_pdp_info] commas is less than 2");
            ret_val = ERR_UNKNOWN;
            goto error;

        }
    }//end for

    at_response_free(p_response);
    p_response = NULL;


error:
    // resume IP Address Format
    if(0 == ip_format)
    {
        at_response_free(p_response);
        p_response = NULL;

        err = at_send_command("AT+CGPIAF=0",  &p_response);
        if (err < 0 || p_response->success == 0)
        {
            RLOGD("[RIL-PS][ps_query_pdp_info] AT+CGPIAF=0 is error:%d", err);
        }

    }

    at_response_free(p_response);

    return ret_val;
}


static SINT32 ps_update_pdp_info(UINT8 pdp_cid)
{
    SINT32  ret_val = ERR_NONE;
    ATA_PS_PDP_NETNETWORK_ST* pdp_net_info = NULL;
    UINT8 cid_other = 0;
    PDP_INFO_ST * pdp_info = NULL;
    UINT8 primer_cid_req_type = PROTOCOL_UNKNOW;
    UINT8 other_cid_req_type = PROTOCOL_UNKNOW;
    UINT8 primer_cid_act_type = PROTOCOL_UNKNOW;
    UINT8 other_cid_act_type = PROTOCOL_UNKNOW;
    UINT8 reuse_pdp_type = PROTOCOL_UNKNOW;


    pdp_info = ps_get_pdp_info_by_pdp_cid(pdp_cid);

    if(!pdp_info)
    {
        goto error;
    }

    pdp_net_info = &(pdp_info->pdp_network_info);
    memset(pdp_net_info,0,sizeof(ATA_PS_PDP_NETNETWORK_ST));

    ret_val = ps_query_pdp_info(pdp_cid,pdp_net_info);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_update_pdp_info] ps_query_pdp_info fail");
        goto error;
    }

    primer_cid_req_type = pdp_net_info->req_pdp_type;
    primer_cid_act_type = pdp_net_info->act_pdp_type;

    ret_val = ps_set_pdp_apn(pdp_info->pdp_cid,pdp_net_info->apn,PDP_APN_LENGTH);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_update_pdp_info] ps_set_pdp_apn fail");
        goto error;
    }

#if 0 

    cid_other = ps_get_other_cid(pdp_cid);
    if(cid_other > 0)
    {
        ret_val = ps_query_pdp_info(cid_other,pdp_net_info);
        if( ERR_NONE != ret_val )
        {
            RLOGD("[RIL-PS][ps_update_pdp_info] ps_query_pdp_info cid_other fail");
            goto error;
        }

        other_cid_req_type = pdp_net_info->req_pdp_type;
        other_cid_act_type = pdp_net_info->act_pdp_type;
    }
#endif

    //save primer pdp context info
    ret_val = ps_set_req_pdp_type(pdp_cid,primer_cid_req_type|other_cid_req_type);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_update_pdp_info] ps_set_req_pdp_type fail");
        goto error;
    }

    
    //update act pdp type
    ret_val = ps_set_act_pdp_type(pdp_cid,primer_cid_act_type|other_cid_act_type);
    if( ERR_NONE != ret_val )
    {
        goto error;
    }

    if( ERR_NONE != ret_val )
    {
        goto error;
    }

    ret_val = ps_get_reuse_pdp_type(pdp_cid,&reuse_pdp_type);
    if( ERR_NONE != ret_val )
    {
        goto error;
    }

    if(reuse_pdp_type == PROTOCOL_IPV4)
    {//reuse ATA_PS_4G_BACKGROUND_CID
	ps_clean_ipv6_info(pdp_cid); 
    }
    else if(reuse_pdp_type == PROTOCOL_IPV6)
    {//reuse ATA_PS_4G_BACKGROUND_CID
	ps_clean_ipv4_info(pdp_cid); 
    }
    else if(reuse_pdp_type == PROTOCOL_UNKNOW)
    {//ative new link
        //update reuse pdp type
        ret_val = ps_set_reuse_pdp_type(pdp_cid,primer_cid_act_type|other_cid_act_type);
        if( ERR_NONE != ret_val )
        {
            goto error;
        }
    }

    return ERR_NONE;

error:

    return ERR_UNKNOWN;
}


static SINT32 ps_active_pdp(UINT8 pdp_cid)
{
    ATResponse *p_response = NULL;
    char *cmd = NULL;
    SINT32 ret_val = ERR_NONE;

    if((ps_is_background_pdp(pdp_cid)) && (ps_get_pdp_state(pdp_cid) != PDP_DEACTIVED))
    {
        RLOGD("[RIL-PS][ps_active_pdp] cid %d not need to active ", pdp_cid);
        ret_val = ps_set_pdp_status(pdp_cid,PS_STATE_PDP_ACTIVATED);
        if(ERR_NONE != ret_val )
        {
            ret_val = ERR_UNKNOWN;
           goto end;
        }
        return ERR_NONE;
    }

    ret_val = ps_set_pdp_status(pdp_cid,PS_STATE_PDP_ACTIVATING);
    if(ERR_NONE != ret_val )
    {
        ret_val = ERR_UNKNOWN;
        goto end;
    }

    asprintf(&cmd, "AT+CGACT=1,%d", pdp_cid);
    ret_val = at_send_command(cmd, &p_response);
    free(cmd);

    if (ret_val < 0 || p_response->success == 0)
    {
        ret_val = ERR_UNKNOWN;
        goto end;
    }

	/*
    BOOL other_cid_exist = FALSE;
    UINT8 other_cid = 0;
    if(ps_is_received_other_cid(pdp_cid,&other_cid))
    {
        ret_val = ps_set_other_cid(pdp_cid,other_cid);
        if(ERR_NONE != ret_val )
        {
            ret_val = ERR_UNKNOWN;
            goto end;
        }
    }*/

    ret_val = ps_set_pdp_status(pdp_cid, PS_STATE_PDP_ACTIVATED);
    if(ERR_NONE != ret_val )
    {
        ret_val = ERR_UNKNOWN;
    }

end:
    at_response_free(p_response);
    return ret_val;
}

static SINT32 ps_switch_data_state(UINT8 pdp_cid)
{
    SINT32 ret_val = ERR_NONE;
    PDP_INFO_ST *pdp_info_ptr = NULL;
    char m_buf_write[128] = {0};
    ATResponse *p_response = NULL;
    int err = -1;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_switch_data_state] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_INVALID_PARAM;
    }

    if((!ps_is_background_pdp(pdp_cid)) || (ps_get_pdp_state(pdp_cid) != PDP_DATA_STATE))
    {
        char dev_name[IFNAMSIZ] = {0};

        ret_val = ps_get_lmi_ifname(dev_name,IFNAMSIZ,pdp_cid);
        if(ERR_NONE != ret_val)
        {
            RLOGD("[RIL-PS][ps_switch_data_state] invalid dev_name!");
            return ERR_INVALID_PARAM;
        }

        snprintf( m_buf_write,
                  sizeof(m_buf_write) - 1,
                  "AT^PSDEVCFG=%d,\"%s\"", pdp_cid, dev_name);

        err = at_send_command(m_buf_write, &p_response);

        if (err < 0 || p_response->success == 0)
        {
            RLOGD("[RIL-PS][ps_switch_data_state] AT^PSDEVCFG fail\n");
            ret_val = ERR_UNKNOWN;
            goto end;
        }

        at_response_free(p_response);
        p_response = NULL;

        snprintf( m_buf_write,
                  sizeof(m_buf_write) - 1,
                  "AT+CGDATA=\"M-0000\",%d", pdp_cid);

        err = at_send_command(m_buf_write, &p_response);

        if (err < 0 || p_response->success == 0)
        {
            RLOGD("[RIL-PS][ps_switch_data_state] AT^CGDATA fail\n");
            ret_val = ERR_UNKNOWN;
            goto end;
        }

        at_response_free(p_response);
        p_response = NULL;

        SINT32 cid_other = 0;
        cid_other = ps_get_other_cid(pdp_cid);
        if(cid_other > 0)
        {
            snprintf( m_buf_write,
                      sizeof(m_buf_write) - 1,
                      "AT^PSDEVCFG=%d,\"%s\"", cid_other, dev_name);

            err = at_send_command(m_buf_write, &p_response);

            if (err < 0 || p_response->success == 0)
            {
                RLOGD("[RIL-PS][ps_switch_data_state] AT^PSDEVCFG fail\n");
                ret_val = ERR_UNKNOWN;
                goto end;
            }

            at_response_free(p_response);
            p_response = NULL;

            snprintf( m_buf_write,
                      sizeof(m_buf_write) - 1,
                      "AT+CGDATA=\"M-0000\",%d", cid_other);

            err = at_send_command(m_buf_write, &p_response);

            if (err < 0 || p_response->success == 0)
            {
                RLOGD("[RIL-PS][ps_switch_data_state] AT^CGDATA fail\n");
                ret_val = ERR_UNKNOWN;
                goto end;
            }
        }

    }
    else
    {
        RLOGD("[RIL-PS][ps_switch_data_state] cid %d not need to switch data_state ", pdp_cid);
    }
end:

    at_response_free(p_response);

    return ret_val;
}

static SINT32 ps_close_lmi(UINT8 pdp_cid)
{
    SINT32 ret_val = ERR_NONE;
    PDP_INFO_ST *pdp_info_ptr = NULL;
    int len;
    char dev_name[IFNAMSIZ] = {0};
    char sys_cmd[ATA_SYS_CMD_BUF_LEN] = {0};

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if(NULL == pdp_info_ptr)
    {
        RLOGD("[RIL-PS][ps_close_lmi] pdp_info_ptr is null");
        return ERR_INVALID_PARAM;
    }

    len = strlen(pdp_info_ptr->ifname);
    if(len <= 0)
    {
        RLOGD("[RIL-PS][ps_close_lmi] lmi name is null");
        return ERR_INVALID_PARAM;
    }

    strncpy(dev_name, pdp_info_ptr->ifname, IFNAMSIZ);

    RLOGD("[RIL-PS][ps_close_lmi] close lmi , cid is %d", pdp_cid);



    snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip link set %s down", dev_name);
    RLOGD("[RIL-PS][ps_close_lmi]  %s", sys_cmd);
    ret_val =  system(sys_cmd);
    if( ret_val != 0 )
    {
        RLOGD("[RIL-PS][ps_close_lmi] down ifname  failed" );
    }


    snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip addr flush dev %s", dev_name);
    RLOGD("[RIL-PS][ps_close_lmi]  %s", sys_cmd);
    system(sys_cmd);
    if( ret_val != 0 )
    {
        RLOGD("[RIL-PS][ps_close_lmi] flush ifname  failed" );
    }

    return ERR_NONE;
}



static SINT32 ps_open_lmi(UINT8 pdp_cid)
{
    int ret = ERR_NONE;
    char sys_cmd[ATA_SYS_CMD_BUF_LEN] = {0};
    char dev_name[IFNAMSIZ] = {0};
    char ipaddr_v4[PDP_IP_ADDR_LENGTH_IPV4] = {0};
    char ipaddr_link_local_v6[PDP_IP_ADDR_LENGTH_IPV6] = {0};
    UINT8 reuse_pdp_type = PROTOCOL_UNKNOW;

    //get pdp type
    ret = ps_get_reuse_pdp_type(pdp_cid,&reuse_pdp_type);
    if(ERR_NONE != ret)
    {
        RLOGD("[RIL-PS][ps_open_lmi] get pdp reuse type failed ,pdp_cid %d ", pdp_cid);
        return ERR_UNKNOWN;
    }


    ret = ps_get_addr_ipv4(pdp_cid,ipaddr_v4,PDP_IP_ADDR_LENGTH_IPV4);
    if( ERR_NONE != ret )
    {
        return ERR_UNKNOWN;
    }

    ret = ps_get_addr_link_local_ipv6(pdp_cid,ipaddr_link_local_v6,PDP_IP_ADDR_LENGTH_IPV6);
    if( ERR_NONE != ret )
    {
        return ERR_UNKNOWN;
    }

    if((strlen(ipaddr_v4)==0)&&(strlen(ipaddr_link_local_v6)==0))
    {
        RLOGD("[RIL-PS][ps_open_lmi] invalid parameter!");
        return ERR_UNKNOWN;
    }

    RLOGD("[RIL-PS][ps_open_lmi]cid:%d, ipaddr_v4: %s,ipaddr_v6: %s", pdp_cid, ipaddr_v4, ipaddr_link_local_v6);

    ret = ps_get_lmi_ifname(dev_name, IFNAMSIZ, pdp_cid);
    if( ERR_NONE != ret )
    {
        RLOGD("[RIL-PS][ps_open_lmi] invalid dev_name!");
        return ERR_UNKNOWN;
    }

    RLOGD("[RIL-PS][ps_open_lmi] ifname is : %s", dev_name);

    snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip link set %s down", dev_name);
    RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);
    system(sys_cmd);

    snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip addr flush dev %s", dev_name);
    RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);
    system(sys_cmd);

    if((strlen(ipaddr_v4) > 0)&&(reuse_pdp_type == PROTOCOL_IPV4))
    {
        snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip addr add %s/32 dev %s", ipaddr_v4, dev_name);
        RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);

        ret =  system(sys_cmd);
        if( ret != 0 )
        {
            RLOGD("[RIL-PS][ps_open_lmi] set ip  failed" );
            return ERR_UNKNOWN;
        }
    }
    else if((strlen(ipaddr_link_local_v6) > 0)&&(reuse_pdp_type == PROTOCOL_IPV6))
    {
        snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip addr add %s/64 dev %s", ipaddr_link_local_v6, dev_name);
        RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);

        ret =  system(sys_cmd);
        if( ret != 0 )
        {
            RLOGD("[RIL-PS][ps_open_lmi] set ip failed" );
            return ERR_UNKNOWN;
        }

        snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip link set %s up", dev_name);
        RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);

        ret =  system(sys_cmd);
        if( ret != 0 )
        {
            RLOGD("[RIL-PS][ps_open_lmi] up lmi failed" );
            return ERR_UNKNOWN;
        }

        char ipv6_ra_addr[PDP_IP_ADDR_LENGTH_IPV6] = {0};
        ret = ps_get_ra_ipv6_addr(pdp_cid, ipv6_ra_addr);

        if(ERR_NONE != ret)
        {
            RLOGD("[RIL-PS][ps_open_lmi] get ra ipv6 addr failed" );
            return ERR_UNKNOWN;
        }
        else
        {
            ret = ps_set_addr_ipv6(pdp_cid,ipv6_ra_addr,PDP_IP_ADDR_LENGTH_IPV6);
            if(ERR_NONE != ret)
            {
                RLOGD("[RIL-PS][ata_ps_open_lmi] ps_set_addr_ipv6 failed" );
                return ERR_UNKNOWN;
            }
            ps_send_ipv6_info_to_modem(pdp_cid);

        }
    }
    else if((strlen(ipaddr_v4) > 0)&&(strlen(ipaddr_link_local_v6) > 0)&&(reuse_pdp_type == PROTOCOL_IPV4V6))
    {
        snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip addr add %s/32 dev %s", ipaddr_v4, dev_name);
        RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);

        ret =  system(sys_cmd);
        if( ret != 0 )
        {
            RLOGD("[RIL-PS][ps_open_lmi] set ip  failed" );
            return ERR_UNKNOWN;
        }

        snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip addr add %s/64 dev %s", ipaddr_link_local_v6, dev_name);
        RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);

        ret =  system(sys_cmd);
        if( ret != 0 )
        {
            RLOGD("[RIL-PS][ps_open_lmi] set ip failed" );
            return ERR_UNKNOWN;
        }

        snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip link set %s up", dev_name);
        RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);

        ret =  system(sys_cmd);
        if( ret != 0 )
        {
            RLOGD("[RIL-PS][ps_open_lmi] up lmi failed" );
            return ERR_UNKNOWN;
        }

        pthread_t   thread_id;
        ret = pthread_create(&thread_id,NULL,th_ps_ipv6_ra_config,(void *)(UINT32) pdp_cid);
        if (ret != ERR_NONE) {
            RLOGE("[RIL-PS][ps_open_lmi] create ps ipv6 ra config thread failed! errNo=%d, pdp_cid=%d", ret, pdp_cid);
        } else {
            RLOGD("[RIL-PS][ps_open_lmi] create ps ipv6 ra config thread success! tid=%d, pdp_cid=%d", thread_id, pdp_cid);
        }
    }
    else
    {
        RLOGD("[RIL-PS][ata_ps_open_lmi] reuse_pdp_type failed" );
        return ERR_UNKNOWN;
    }

    if (get_bip_bear_type() == 2) { //for usat cmcc test L1860_20141226-43152
        RLOGD("[RIL-PS][ps_open_lmi]echo 1 > /proc/sys/net/ipv4/tcp_rto_min_lc");

        ret =  system("echo 1 > /proc/sys/net/ipv4/tcp_rto_min_lc");
        if( ret != 0 )
        {
	        RLOGD("[RIL-PS][ps_open_lmi] cmd failed");
        }
    }

    snprintf(sys_cmd, ATA_SYS_CMD_BUF_LEN, "ip link set %s up", dev_name);
    RLOGD("[RIL-PS][ps_open_lmi]  %s", sys_cmd);

    ret =  system(sys_cmd);
    if( ret != 0 )
    {
        RLOGD("[RIL-PS][ps_open_lmi] up lmi failed" );
        return ERR_UNKNOWN;
    }

    return ERR_NONE;

}



static SINT32 ps_get_lmi_ifname(char *ifname, int ifname_len, UINT8 pdp_cid)
{
    PDP_INFO_ST * pdp_info =NULL;

    if(pdp_cid < 0)
    {
        RLOGD("[RIL-PS][ps_get_lmi_ifname] cid error %d", pdp_cid);
        return ERR_INVALID_PARAM;
    }

    if(ifname == NULL)
    {
        RLOGD("[RIL-PS][ps_get_lmi_ifname] ifname error ");
        return ERR_INVALID_PARAM;
    }

    if(ifname_len < IFNAMSIZ)
    {
        RLOGD("[RIL-PS][ps_get_lmi_ifname] ifname_len error %d", ifname_len);
        return ERR_INVALID_PARAM;
    }

    pdp_info = ps_get_pdp_info_by_pdp_cid(pdp_cid);

    if(!pdp_info)
    {
        RLOGD("[RIL-PS][ps_get_lmi_ifname] can't get ifname, cid is %d", pdp_cid);
        return ERR_INVALID_PARAM;
    }

    memcpy(ifname,pdp_info->ifname,IFNAMSIZ);

    RLOGD("[RIL-PS][ps_get_lmi_ifname] get: %s", ifname);

    return ERR_NONE;
}



BOOL ps_is_background_pdp(UINT8 pdp_cid)
{
    if(pdp_cid == ATA_PS_4G_BACKGROUND_CID)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

static void * th_ps_deactive_pdp(void *param)
{
    UINT32 pdp_cid = 0;
    pdp_cid = (UINT32) param;
    RLOGD("[RIL-PS][th_ps_deactive_pdp] pdp_cid %d , [ril%d]", pdp_cid,current_ril_id());

    RLOGD("[RIL-PS][th_ps_deactive_pdp] network_op_mutex start");
    ata_ps_set_ps_switch(TRUE);
    pthread_mutex_lock(&network_op_mutex);
    RLOGD("[RIL-PS][th_ps_deactive_pdp] network_op_mutex entry ref: %d", network_op_mutex_ref);
    network_op_mutex_ref++;
    ps_deactive_pdp((UINT8)pdp_cid);
    network_op_mutex_ref--;
    RLOGD("[RIL-PS][th_ps_deactive_pdp] network_op_mutex exit ref: %d", network_op_mutex_ref);
    pthread_mutex_unlock(&network_op_mutex);
    ata_ps_set_ps_switch(FALSE);

    return NULL;
}

static SINT32 ps_deactive_pdp(UINT8 pdp_cid)
{
    ATResponse *p_response = NULL;
    char *cmd = NULL;
    int err = 0;
    PDP_INFO_ST *pdp_info_ptr = NULL;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid( pdp_cid );
    if( !pdp_info_ptr )
    {
        return ERR_INVALID_PARAM;
    }

    RLOGD("[RIL-PS][ps_deactive_pdp] pdp_cid %d", pdp_cid);

    int biptype = get_bip_bear_type();
    if ( biptype != -1 ) {
        property_set("gsm.stk.bip.bearer.type", "-1");
    }
    if((ps_is_background_pdp(pdp_info_ptr->pdp_cid))
    &&(ps_is_lte_mode())
    &&(ata_ps_is_ps_switch()==FALSE || biptype != -1))
    {
        err = at_send_command("AT^DQDATA=2,1", &p_response);

        if (err < 0 || p_response->success == 0)
        {
            RLOGD("[RIL-PS][ps_deactive_pdp] AT^DQDATA fail\n");
        }

        at_response_free(p_response);
        p_response = NULL;
    }
    else
    {
        asprintf(&cmd, "AT+CGACT=0,%d", pdp_info_ptr->pdp_cid);
        err = at_send_command(cmd, &p_response);
        free(cmd);

        if (err < 0 || p_response->success == 0)
        {
            RLOGD("[RIL-PS][ps_deactive_pdp]Multi-ps: AT+CGACT=0,%d failed\n", pdp_info_ptr->pdp_cid);
        }

        at_response_free(p_response);
        p_response = NULL;

    }

    //deactive other cid

    if(pdp_info_ptr->cid_other > 0)
    {
            if((ps_is_background_pdp(pdp_info_ptr->cid_other))&&(ps_is_lte_mode()))
	    {
	        err = at_send_command("AT^DQDATA=2,1", &p_response);

	        if (err < 0 || p_response->success == 0)
	        {
	            RLOGD("[RIL-PS][ps_deactive_pdp] AT^DQDATA fail\n");
	        }

	        at_response_free(p_response);
	        p_response = NULL;
	    }
	    else
	    {
	        asprintf(&cmd, "AT+CGACT=0,%d", pdp_info_ptr->cid_other);
	        err = at_send_command(cmd, &p_response);
	        free(cmd);

	        if (err < 0 || p_response->success == 0)
	        {
	            RLOGD("[RIL-PS][ps_deactive_pdp]Multi-ps: AT+CGACT=0,%d failed\n", pdp_info_ptr->cid_other);
	        }

	        at_response_free(p_response);
	        p_response = NULL;
	    }


    }


    ps_stop(pdp_info_ptr->pdp_cid);

    return ERR_NONE;
}

SINT32 ps_get_pdp_state(UINT8 pdp_cid)
{
    ATResponse *p_response = NULL;
    ATLine *p_cur;
    int err;
    SINT32 ret = -1;
    int active_cid = 0;
    int active = 0;
    int n = 0;

    if(pdp_cid<0||pdp_cid>S_PDP_MAX_VALUE)
        return  PDP_DEACTIVED;

    RLOGD("[RIL-PS][ps_get_pdp_state] checking pdp cid %d state ... ", pdp_cid);
    err = at_send_command_multiline ("AT+CGACT?", "+CGACT:", &p_response);
    if (err != 0 || p_response->success == 0)
    {
        RLOGD("[RIL-PS][ps_get_pdp_state] fail,CGACT, err =%d ", err);
        at_response_free(p_response);
        return  PDP_DEACTIVED;
    }

    for (p_cur = p_response->p_intermediates; p_cur != NULL;
         p_cur = p_cur->p_next)
    {
        char *line = p_cur->line;

        err = at_tok_start(&line);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_get_pdp_state] at_tok_start fail,CGACT, err =%d ", err);
            ret =  -1;
            break;
        }

        err = at_tok_nextint(&line, &active_cid);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_get_pdp_state] cid fail,CGACT, err =%d ", err);
            ret =  -1;
            break;
        }

        if(pdp_cid != active_cid)
            continue;

        err = at_tok_nextint(&line, &active);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_get_pdp_state] cid fail,CGACT, err =%d ", err);
            ret =  -1;
            break;
        }

        if(1 == active)
        {
            ret = 0;
        }
        else
        {
            ret = -1;
        }
        break;

    }

    at_response_free(p_response);
    p_response = NULL;

    if(ret < 0)
    {
        RLOGD("[RIL-PS][ps_get_pdp_state] cid %d is PDP_DEACTIVED ", pdp_cid);
        return  PDP_DEACTIVED;
    }
    else
    {
        return PDP_DATA_STATE;
    }

#if 0
    int qcid;
    int stat;
    char *line = NULL;
    char *cmd = NULL;

    asprintf(&cmd, "AT^DQDATA=3,%d", pdp_cid);

    err = at_send_command_singleline(cmd, "^DQDATA:", &p_response);
    free(cmd);

    if (err < 0 || p_response->success == 0)
    {
        RLOGD("[RIL-PS][ps_get_pdp_state] AT^DQDATA=3,1 fail");
        RLOGD("[RIL-PS][ps_get_pdp_state] cid %d is PDP_DEACTIVED ", pdp_cid);
        ret = PDP_DEACTIVED;
    }
    else
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if(err < 0)
        {
            RLOGD("[RIL-PS][ps_get_pdp_state] at_tok_start error");
            RLOGD("[RIL-PS][ps_get_pdp_state] cid %d is PDP_DEACTIVED ", pdp_cid);
            ret =  PDP_DEACTIVED;
        }
        else
        {
            err = at_tok_nextint(&line, &n);
            if ((err < 0) || n != 3)
            {
                RLOGD("[RIL-PS][ps_get_pdp_state] get n error %d", n);
                RLOGD("[RIL-PS][ps_get_pdp_state] cid %d is PDP_DEACTIVED ", pdp_cid);
                ret =  PDP_DEACTIVED;
            }
            err = at_tok_nextint(&line, &qcid);
            if ((err < 0) || qcid != pdp_cid)
            {
                RLOGD("[RIL-PS][ps_get_pdp_state] get qcid error %d", qcid);
                RLOGD("[RIL-PS][ps_get_pdp_state] cid %d is PDP_DEACTIVED ", pdp_cid);
                ret =  PDP_DEACTIVED;
            }
            err = at_tok_nextint(&line, &stat);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_get_pdp_state] get stat error %d", stat);
                RLOGD("[RIL-PS][ps_get_pdp_state] cid %d is PDP_DEACTIVED ", pdp_cid);
                ret =  PDP_DEACTIVED;
            }

            if(stat == 0)
            {
                RLOGD("[RIL-PS][ps_get_pdp_state] get stat is  PDP_NOT_DATA_STATE");
                ret =  PDP_NOT_DATA_STATE;

            }
            else if(stat == 1)
            {
                RLOGD("[RIL-PS][ps_get_pdp_state] get stat is  PDP_DATA_STATE");
                ret =  PDP_DATA_STATE;
            }
            else
            {
                RLOGD("[RIL-PS][ps_get_pdp_state] get stat is  PDP_DEACTIVED");
                ret =  PDP_DEACTIVED;

            }
        }
    }

    at_response_free(p_response);
#endif
    return ret;
}

static SINT32 get_bip_bear_type() {
    //for usat cmcc test L1860_20141226-43152
    SINT32 bearerType = -1;
    char	propValue[PROP_VALUE_MAX] = "";
    int 	property_ret = 0;

    property_ret = property_get("gsm.stk.bip.bearer.type", propValue, NULL);
    /*
        gsm.stk.bip.bearer.type :
            '1': if apn is same , then reuse modem lte pdp(cid =1) without checking iptype
            '3': reuse modem lte pdp(cid =1) without checking apn and iptype
    */

    if(property_ret < 0) {
        RLOGD("[RIL-PS][get_bip_bear_type] get gsm.stk.bip.bearer.type failed ");
    } else {
        RLOGD("[RIL-PS][get_bip_bear_type] gsm.stk.bip.bearer.type is %c ",propValue[0]);
        if(propValue[0]=='1') {
            bearerType = 1;
        } else if (propValue[0]=='2') {
            bearerType = 2;
        } else if (propValue[0]=='3') {
            bearerType = 3;
        }
    }
    return bearerType;
}

/*

LTE PDP (Cid 1) Reuse  Strategy

1. apn must be same

2. ip type check Strategy


*/
static BOOL ps_check_background_pdp_reusable(char *apn, char *req_pdp_type,BOOL check_protocol,UINT8 * reuse_pdp_type)
{
    ATResponse *p_response = NULL;
    int err = -1;
    SINT32 ret = FALSE;
    ATLine *p_cur = NULL;
    char *line = NULL;
    int ip_format = 0xff;
    SINT32 found_ipv4 = FALSE;
    SINT32 found_ipv6 = FALSE;
    SINT32 is_same_apn = FALSE;
    SINT32 new_req_type = PROTOCOL_UNKNOW;
    BOOL check_ip_type = check_protocol;
    SINT32 bip_bear_type = -1;

    if( !apn || !req_pdp_type ||!reuse_pdp_type)
    {
        RLOGD("[RIL-PS][ps_check_background_pdp_reusable] ERR_INVALID_PARAM");
        return ERR_INVALID_PARAM;
    }

    new_req_type = ps_convert_protocol_to_numeric(req_pdp_type);
    if((new_req_type<PROTOCOL_IPV4) || (new_req_type>PROTOCOL_IPV4V6))
    {
        RLOGD("[RIL-PS][ps_check_background_pdp_reusable] pdp_type is error" );
        return FALSE;
    }

    bip_bear_type = get_bip_bear_type(); //for usat cmcc test L1860_20141226-43152
    
    //check apn
    err = at_send_command_multiline("AT+CGCONTRDP=1", "+CGCONTRDP:", &p_response);
    if (err < 0 || p_response->success == 0)
    {
        RLOGD("[RIL-PS][ps_check_background_pdp_reusable] AT+CGCONTRDP=1 fail");
        goto end;
    }
    else
    {
        int bear_id;
        int pdp_cid;
        char *pdp_apn;
        SINT32 response_count = 0;
        int commas = 0;
        char *p;
        char *responseStr = NULL;

        for (p_cur = p_response->p_intermediates; p_cur != NULL;
             p_cur = p_cur->p_next)
        {
            response_count++;
        }

        if(response_count<1)
        {
            RLOGD("[RIL-PS][ps_check_background_pdp_reusable] response_count:%d error",response_count);
            goto end;
        }


        //only need to parse first line to get apn
        line = p_response->p_intermediates->line;

        err = at_tok_start(&line);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_check_background_pdp_reusable] parse start occurs error:%d", err);
            goto end;
        }

        for (p = line ; *p != '\0' ; p++)
        {
            if (*p == ',') commas++;
        }

        if (commas >= 2)
        {
            /* +CGCONTRDP: <p_cid>, <bearer_id>, <apn>, <ip_addr with subnet_mask>, <gw_addr>, <DNS_prim_addr>, <DNS_sec_addr>*/
            err = at_tok_nextint(&line,&pdp_cid);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_check_background_pdp_reusable] get cid error %d", pdp_cid);
                goto end;
            }

            err = at_tok_nextint(&line,&bear_id);
            if ((err < 0))
            {
                RLOGD("[RIL-PS][ps_check_background_pdp_reusable] get bear_id error %d",bear_id);
                goto end;
            }

            err = at_tok_nextstr(&line,&pdp_apn);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_check_background_pdp_reusable] get pdp_apn error ");
                goto end;
            }

            is_same_apn = ps_is_same_apn(pdp_apn,apn);
        }

        if(!is_same_apn && 3 != bip_bear_type)
        {
            RLOGD("[RIL-PS][ps_check_background_pdp_reusable] not same apn");
            goto end;
        }

        at_response_free(p_response);
        p_response = NULL;
    }

    //ip type check Strategy
    err = at_send_command_singleline("AT^DPAIQ=1", "^DPAIQ:", &p_response);
    if (err < 0 || p_response->success == 0)
    {
        RLOGD("[RIL-PS][ata_ps_get_share_pdp_state] AT^DPAIQ fail");
        goto end;
    }
    else
    {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if(err < 0)
        {
            RLOGD("[RIL-PS][ps_check_background_pdp_reusable] AT^DPAIQ at_tok_start error");
            goto end;
        }
        else
        {
            int p_cid;
            int req_type ;
            int act_type ;

            err = at_tok_nextint(&line, &p_cid);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_check_background_pdp_reusable] get DPAIQ qcid error ");
                goto end;
            }

            err = at_tok_nextint(&line, &req_type);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_check_background_pdp_reusable] get req_pdp_type error ");
                goto end;
            }


            err = at_tok_nextint(&line, &act_type);
            if (err < 0)
            {
                RLOGD("[RIL-PS][ps_check_background_pdp_reusable] get act_pdp_type error ");
                goto end;
            }

            if (1 == bip_bear_type || 3 == bip_bear_type) {
                *reuse_pdp_type = act_type&new_req_type;

                RLOGD("[RIL-PS][ps_check_background_pdp_reusable] bip_bear_type is %d, reuse_pdp_type is %d!" ,bip_bear_type,*reuse_pdp_type);
                if((*reuse_pdp_type<PROTOCOL_IPV4) || (*reuse_pdp_type>PROTOCOL_IPV4V6))
                {
		        RLOGD("[RIL-PS][ps_check_background_pdp_reusable] pdp_type is error" );
		        goto end;
                }

                ret = TRUE;
                goto end;
            }

            RLOGD("[RIL-PS][ps_check_background_pdp_reusable] check_ip_type is %d ",check_ip_type);
            ret = ps_is_reusable_protocol_type (req_type,act_type,new_req_type,check_ip_type,reuse_pdp_type);

        }
    }

end:

    at_response_free(p_response);

    RLOGD("[RIL-PS][ps_check_background_pdp_reusable] return %d ",ret);
    return ret;
}


static SINT32 ps_get_idle_pdp_cid(ATA_PS_PDP_REQ_ST * pdp_req, UINT8 * pdp_cid)
{
    SINT32 cid = 0;
    BOOL found_cid = FALSE;
    PDP_INFO_ST *pdp_info_ptr = NULL;
    char *apn = NULL;
    char propValue[PROP_VALUE_MAX] = "";
    SINT32 err = ERR_NONE;
    BOOL check_protocol = TRUE;
    char dev_name[IFNAMSIZ] = {0};
    UINT8 reuse_pdp_type = PROTOCOL_UNKNOW;

    if( !pdp_req || !pdp_cid )
    {
        RLOGD("[RIL-PS][ps_get_idle_pdp_cid] ERR_INVALID_PARAM");
        return ERR_INVALID_PARAM;
    }

    if(ps_get_pdp_info_by_pdp_cid(ATA_PS_4G_BACKGROUND_CID))
    {/*if BACKGROUND PDP already used*/
        found_cid = FALSE;
    }
    else
    {
	    /*if cid ATA_PS_4G_BACKGROUD_CID is actived, ap will try to reuse this pdp connection*/
	    if(ps_get_pdp_state(ATA_PS_4G_BACKGROUND_CID) != PDP_NOT_DATA_STATE)
	    {
	        //note: if cid 1 pdp is  PDP_DATA_STATE , that means cp(ims) already reuse this pdp,  Ap can't reuse this pdp connection again.
	        found_cid = FALSE;
	    }
	    else if(ps_check_background_pdp_reusable(pdp_req->apn,pdp_req->protocol,pdp_req->check_protocol,&reuse_pdp_type))
	    {
	        cid = ATA_PS_4G_BACKGROUND_CID;
	        found_cid = TRUE;
	        RLOGD("[RIL-PS][ps_get_idle_pdp_cid] use background pdp, cid is %d",cid);
	    }
    }
    RLOGD("[RIL-PS][ps_get_idle_pdp_cid] found_cid %d", found_cid);

    /*need to setup connection by new cid*/
    if(!found_cid )
    {
        SINT32 m = 0;
        cid = 0;
        for(m = 1; m < S_PDP_MAX_VALUE; m++)
        {
            if( (ps_get_pdp_info_by_pdp_cid(m)==NULL)&&(ps_get_pdp_state(m)==PDP_DEACTIVED))
            {
                cid = m;
                RLOGD("[RIL-PS][ps_get_idle_pdp_cid] cid is %d",cid);
                break;
            }
        }
    }

    if(cid == S_PDP_MAX_VALUE)
    {
        RLOGD("[RIL-PS][ps_get_idle_pdp_cid] get cid failed");
        return ERR_UNKNOWN;
    }

    pdp_info_ptr = ps_get_idle_pdp_info(cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_idle_pdp_cid] Cannot find idle  pdp info");
        return ERR_UNKNOWN;
    }

    if(found_cid)
    {
        err = ps_set_reuse_pdp_type(ATA_PS_4G_BACKGROUND_CID,reuse_pdp_type);
        if( ERR_NONE != err )
        {
            return ERR_UNKNOWN;
        }
    }

	/*
    err = ps_get_idle_netif(dev_name, IFNAMSIZ);
    if( ERR_NONE != err )
    {
        RLOGD("[RIL-PS][ps_get_idle_pdp_cid] invalid dev_name!");
        return ERR_UNKNOWN;
    }

    err = ps_set_lmi_ifname(cid,dev_name, IFNAMSIZ);
    if( ERR_NONE != err )
    {
        RLOGD("[RIL-PS][ps_get_idle_pdp_cid] invalid dev_name!");
        return ERR_UNKNOWN;
    }*/

    *pdp_cid = cid;
    RLOGD("[RIL-PS][ps_get_idle_pdp_cid] pdp_cid is %d",cid);

    return ERR_NONE;
}

/*
 * standby 0:
 * "/dev/lmi40
 * "/dev/lmi41
 * standby 1:
 * "/dev/lmi43
 * "/dev/lmi44
 */
void ata_ps_close_lmi_in_shutdown(int ril_id)
{
    RLOGD( "[RIL-PS][ps_close_lmi_in_shutdown] ril id = %d", ril_id);
    if (0 == ril_id)
    {
        system("ip link set lmi40 down");
        system("ip addr flush dev lmi40");

        system("ip link set lmi41 down");
        system("ip addr flush dev lmi41");
    }
    else if (1 == ril_id)
    {
        system("ip link set lmi43 down");
        system("ip addr flush dev lmi43");

        system("ip link set lmi44 down");
        system("ip addr flush dev lmi44");
    }
    else
    {
        RLOGD( "[RIL-PS][ps_close_lmi_in_shutdown] invalid rilId, rilId = %d", ril_id);
    }
}

void requestOrSendDataCallList(RIL_Token *t)
{
    RLOGD("[RIL-PS][requestOrSendDataCallList] [ril%d]",current_ril_id());
    ps_update_data_call_list(t);
}

static void ps_update_data_call_list(RIL_Token *t)
{
    int ril_cid_count = 0;
    int ril_cid = 0;
    UINT32 pdp_cid = 0;
    UINT8 active_ril_pdp_list[RIL_CID_MAX_VALUE] = {0};
    SINT32 ret_val = ERR_NONE;
    UINT8 reuse_pdp_type = PROTOCOL_UNKNOW;
    UINT8 current_pdp_type = PROTOCOL_UNKNOW;

    for (ril_cid = RIL_CID_MIN_VALUE; ril_cid<=RIL_CID_MAX_VALUE; ril_cid++)
    {
        PDP_INFO_ST * pdp_info_ptr = NULL;
        pdp_info_ptr = ps_get_pdp_info_by_ril_cid(ril_cid);
        if(pdp_info_ptr)
        {
            active_ril_pdp_list[ril_cid_count]=ril_cid;
            ril_cid_count++;
        }
    }

    RLOGD("[RIL-PS][ps_update_data_call_list] actived ril cid count is %d",ril_cid_count);

    RIL_Data_Call_Response_v11 *responses =  alloca(ril_cid_count * sizeof(RIL_Data_Call_Response_v11));

    int i;
    for (i = 0; i < ril_cid_count; i++)
    {
        responses[i].status = -1;
        responses[i].suggestedRetryTime = -1;
        responses[i].cid = -1;
        responses[i].active = 0;
        responses[i].type = "";
        responses[i].ifname = "";
        responses[i].addresses = "";
        responses[i].dnses = "";
        responses[i].gateways = "";
        responses[i].pcscf = NULL;
        responses[i].mtu = 0;
    }

    //get type/ifname/apn/addresses/dnses/gateways
    for (i = 0; i< ril_cid_count; i++)
    {
        // Assume no error
        responses[i].status = 0;

        //get ril cid
        responses[i].cid = active_ril_pdp_list[i];

        ret_val = ps_get_pdp_cid_by_ril_cid(responses[i].cid,&pdp_cid);
        if(ERR_NONE != ret_val)
        {
            RLOGD("[RIL-PS][ps_update_data_call_list] get pdp failed ,ril_cid %d ", responses[i].cid);
            goto error;
        }

        //get pdp active
        if(ps_get_pdp_state(pdp_cid) == PDP_DATA_STATE)
        {
            //ony check primary pdp,don't need to check other_cid state.
            responses[i].active = 2;
        }
        else
        {
            responses[i].active = 0;
            pthread_t   thread_id;
            ret_val = pthread_create(&thread_id,NULL,th_ps_deactive_pdp,(void *) pdp_cid);
            if (ret_val != ERR_NONE) {
                RLOGE("[RIL-PS][ps_update_data_call_list] create ps deactive thread failed! errNo=%d, pdp_cid=%d", ret_val, pdp_cid);
            } else {
                RLOGD("[RIL-PS][ps_update_data_call_list] create ps deactive thread success! tid=%d, pdp_cid=%d", thread_id, pdp_cid);
            }
        }
        RLOGD("[RIL-PS][ps_update_data_call_list]  ril cid %d active status is %d",responses[i].cid,responses[i].active);

        //get pdp type
        ret_val = ps_get_reuse_pdp_type(pdp_cid,&reuse_pdp_type);
        if(ERR_NONE != ret_val)
        {
            RLOGD("[RIL-PS][ata_ps_get_network_info] get pdp reuse type failed ,ril_cid %d ", responses[i].cid);
            goto error;
        }

	current_pdp_type = reuse_pdp_type;

	if(PROTOCOL_IPV4V6 == reuse_pdp_type)
	{
	       char addr_ipv6[PDP_IP_ADDR_LENGTH_IPV6] = {0};
		ret_val = ps_get_addr_ipv6(pdp_cid,addr_ipv6,PDP_IP_ADDR_LENGTH_IPV6);
	       if( ERR_NONE != ret_val )
	      {
	          goto error;
	      }

	      if(strlen(addr_ipv6)==0)
	      {//v6 ra addr updating is not finish
	          current_pdp_type = PROTOCOL_IPV4;
	      }

	}


        if (PROTOCOL_IPV4 == current_pdp_type)
        {
            responses[i].type = alloca(3);
            memset(responses[i].type,0,3);
            strcpy(responses[i].type,"IP");
        }
        else if (PROTOCOL_IPV6 == current_pdp_type)
        {
            responses[i].type = alloca(5);
            memset(responses[i].type,0,5);
            strcpy(responses[i].type,"IPV6");
        }
        else if (PROTOCOL_IPV4V6 == current_pdp_type)
        {
            responses[i].type = alloca(7);
            memset(responses[i].type,0,7);
            strcpy(responses[i].type,"IPV4V6");
        }
        else
        {
            RLOGD("[RIL-PS][ps_update_data_call_list] cid type error ");
            goto error;
        }
        RLOGD("[RIL-PS][ps_update_data_call_list] responses[%d].type is %s",i, responses[i].type);


        //get net interface name and ip addrs
        responses[i].ifname = alloca(IFNAMSIZ);
        memset(responses[i].ifname,0,IFNAMSIZ);
        responses[i].addresses = alloca(PDP_IP_ADDR_LENGTH_IPV4 + PDP_IP_ADDR_LENGTH_IPV6 + 2);
        memset(responses[i].addresses,0,PDP_IP_ADDR_LENGTH_IPV4 + PDP_IP_ADDR_LENGTH_IPV6 + 2);
        ret_val = ps_get_ipadr_and_name(pdp_cid, responses[i].ifname, responses[i].addresses,current_pdp_type);
        if( ERR_NONE != ret_val )
        {
            goto error;
        }
        RLOGD("[RIL-PS][ps_update_data_call_list] responses[%d].addresses is %s",i, responses[i].addresses );


        //get dns and gateway address
        responses[i].dnses = alloca(PDP_IP_ADDR_LENGTH_IPV4*2 + PDP_IP_ADDR_LENGTH_IPV6*2 + 4);
        memset(responses[i].dnses,0,PDP_IP_ADDR_LENGTH_IPV4*2 + PDP_IP_ADDR_LENGTH_IPV6*2 + 4);
        responses[i].gateways = alloca(PDP_IP_ADDR_LENGTH_IPV4 + PDP_IP_ADDR_LENGTH_IPV6 + 2);
        memset(responses[i].gateways,0,PDP_IP_ADDR_LENGTH_IPV4 + PDP_IP_ADDR_LENGTH_IPV6 + 2);
        ret_val = ps_get_dns_and_gateway(pdp_cid, responses[i].dnses, responses[i].gateways,current_pdp_type);
        if( ERR_NONE != ret_val )
        {
            goto error;
        }
        RLOGD("[RIL-PS][ps_update_data_call_list] responses[%d].dnses is %s",i, responses[i].dnses );
        RLOGD("[RIL-PS][ps_update_data_call_list] responses[%d].gateways is %s",i, responses[i].gateways );
    }

    if (t != NULL)
        RIL_onRequestComplete(*t, RIL_E_SUCCESS, responses,
                              ril_cid_count * sizeof(RIL_Data_Call_Response_v11));
    else
        RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
                                  responses,
                                  ril_cid_count * sizeof(RIL_Data_Call_Response_v11));
    return ;

error:

    if (t != NULL)
        RIL_onRequestComplete(*t, RIL_E_GENERIC_FAILURE, NULL, 0);
    else
        RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
                                  NULL, 0);
    return ;
}


static UINT8 ps_convert_protocol_to_numeric(char * prototol_str)
{
    if (strcmp(prototol_str,"IP") == 0)
    {
        return PROTOCOL_IPV4;
    }
    else if (strcmp(prototol_str,"IPV6") == 0)
    {
        return PROTOCOL_IPV6;
    }
    else if (strcmp(prototol_str,"IPV4V6") == 0)
    {
        return PROTOCOL_IPV4V6;
    }
    else
    {
        return PROTOCOL_UNKNOW;
    }
}


static BOOL ps_is_lte_mode(void)
{
    int err;
    int actmode = -1;
    ATResponse *p_response = NULL;
    char *line = NULL;
    char  *p = NULL;
    int commas = -1;
    int skip;

    return FALSE;
#if 0
    err = at_send_command_singleline("AT^DACTI?", "^DACTI:", &p_response);

    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    commas = 0;
    for (p = line ; *p != '\0' ; p++)
    {
        if (*p == ',') commas++;
    }

    switch (commas)
    {
    case 1:
        err = at_tok_nextint(&line, &skip);
        if (err < 0) goto error;
        err = at_tok_nextint(&line, &actmode);
        if (err < 0) goto error;
        break;
    default:
        goto error;
    }

    at_response_free(p_response);

    if(actmode==7)
    {
        RLOGD("[RIL-PS][ps_is_lte_mode] return TRUE");
        return TRUE;
    }
    else
    {
        RLOGD("[RIL-PS][ps_is_lte_mode] return FALSE");
        return FALSE;
    }

error:
    at_response_free(p_response);
    RLOGD("[RIL-PS][ps_is_lte_mode] error, return FALSE, commas = %d", commas);
    return FALSE;
#endif
}


static BOOL ps_is_pdp_connecting(UINT8 pdp_cid)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);

    if(!pdp_info_ptr)
    {
        return FALSE;
    }

    if( PS_STATE_PDP_ACTIVATING == pdp_info_ptr->pdp_state )
    {
        RLOGD("[RIL-PS][ps_is_pdp_connecting] cid(%d) is activating", pdp_cid);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}



static SINT32 ps_set_pdp_status(UINT8 pdp_cid,PS_STATE_EN state)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_status] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        pdp_info_ptr->pdp_state =  state;
    }
    return ret;
}


static SINT32 ps_set_other_cid(UINT8 pdp_cid,UINT8 other_cid)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if((other_cid<PDP_MIN_VALUE)||(other_cid>S_PDP_MAX_VALUE))
        return ERR_INVALID_PARAM;

    if((pdp_cid<PDP_MIN_VALUE)||(pdp_cid>S_PDP_MAX_VALUE))
        return ERR_INVALID_PARAM;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_other_cid] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_INVALID_PARAM;
    }
    else
    {
        pdp_info_ptr->cid_other = other_cid;
    }

    return ERR_NONE;
}




static UINT8 ps_get_other_cid(UINT8 pdp_cid)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    UINT8 ret = 0;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_other_cid] Can not get pdp info by cid: %d", pdp_cid);
    }
    else
    {
        ret = pdp_info_ptr->cid_other;
    }

    return ret;
}


static BOOL ps_is_cid_other(UINT8 pdp_cid)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    BOOL ret = FALSE;
    int i = 0;


    for(i = 0; i < PDP_MAX_COUNT; i++)
    {
        if( (0 != pdp_info_st[i].pdp_cid) && (pdp_cid == pdp_info_st[i].cid_other))
        {
            ret = TRUE;
            break;
        }
    }


    return ret;
}



static SINT32 ps_get_req_pdp_type(UINT8 pdp_cid,UINT8 *req_pdp_type)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if((pdp_cid <PDP_MIN_VALUE)||(pdp_cid > S_PDP_MAX_VALUE))
    {
    	return ERR_INVALID_PARAM;
    }

    if(!req_pdp_type)
    {
    	return ERR_UNKNOWN;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_req_pdp_type] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        *req_pdp_type = pdp_info_ptr->req_pdp_type;
        RLOGD("[RIL-PS][ps_get_req_pdp_type] pdp cid: %d req_pdp_type is %d", pdp_cid,*req_pdp_type);
        return ERR_NONE;
    }

}

static SINT32 ps_get_act_pdp_type(UINT8 pdp_cid,UINT8 *act_pdp_type)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if((pdp_cid <PDP_MIN_VALUE)||(pdp_cid > S_PDP_MAX_VALUE))
    {
    	return ERR_INVALID_PARAM;
    }

    if(!act_pdp_type)
    {
    	return ERR_UNKNOWN;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_act_pdp_type] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        *act_pdp_type = pdp_info_ptr->act_pdp_type;
        RLOGD("[RIL-PS][ps_get_act_pdp_type] pdp cid: %d act_pdp_type is %d", pdp_cid,*act_pdp_type);
        return ERR_NONE;
    }

}

static SINT32 ps_set_pdp_apn(UINT8 pdp_cid, char *apn, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;
    int i = 0;
    int apn_network_identifier_len = 0;

    if(len > PDP_APN_LENGTH)
    {
        return ERR_INVALID_PARAM;
    }

    for(i=0; i<=strlen(apn)-1; i++)
    {
        if(apn[i]=='.')
            break;
        apn_network_identifier_len = i+1;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        if(apn_network_identifier_len > 0)
        {
            memset(pdp_info_ptr->apn, 0, PDP_APN_LENGTH);
            strncpy(pdp_info_ptr->apn, apn, apn_network_identifier_len);
            RLOGD("[RIL-PS][ps_set_pdp_apn] save pdp cid %d apn is %s", pdp_cid,pdp_info_ptr->apn);
        }
    }


    return ret;
}


static SINT32 ps_set_addr_ipv6(UINT8 pdp_cid, char *addr_ipv6, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(len > PDP_IP_ADDR_LENGTH_IPV6)
        return ERR_INVALID_PARAM;


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_addr_ipv6] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        memset(pdp_info_ptr->pdp_network_info.ipv6_addr, 0, PDP_IP_ADDR_LENGTH_IPV6);
        strncpy(pdp_info_ptr->pdp_network_info.ipv6_addr, addr_ipv6, PDP_IP_ADDR_LENGTH_IPV6);
    }

    RLOGD("[RIL-PS][ps_set_addr_ipv6] set v6 adds %s to cid: %d",pdp_info_ptr->pdp_network_info.ipv6_addr, pdp_cid);
    return ret;
}


static SINT32 ps_get_addr_ipv6(UINT8 pdp_cid, char *ipv6_addr, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if(len < PDP_IP_ADDR_LENGTH_IPV6)
        return ERR_INVALID_PARAM;

    if(!ipv6_addr)
        return ERR_INVALID_PARAM;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_addr_ipv6] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(ipv6_addr, 0, PDP_IP_ADDR_LENGTH_IPV6);
            strncpy(ipv6_addr, pdp_info_ptr->pdp_network_info.ipv6_addr, PDP_IP_ADDR_LENGTH_IPV6);
        }
    }
    return ERR_NONE;
}


static SINT32 ps_set_ipv6_link_local_addr(UINT8 pdp_cid, char *ipv6_link_local_addr, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(len > PDP_IP_ADDR_LENGTH_IPV6)
        return ERR_INVALID_PARAM;


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv6_link_local_addr, 0, PDP_IP_ADDR_LENGTH_IPV6);
            strncpy(pdp_info_ptr->pdp_network_info.ipv6_link_local_addr, ipv6_link_local_addr, len);
        }
    }


    return ret;
}

static SINT32 ps_set_gateway_ipv6(UINT8 pdp_cid, char *gateway_ipv6, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(len > PDP_IP_ADDR_LENGTH_IPV6)
        return ERR_UNKNOWN;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv6_gateway, 0, PDP_IP_ADDR_LENGTH_IPV6);
            strncpy(pdp_info_ptr->pdp_network_info.ipv6_gateway, gateway_ipv6, len);
        }
    }

    return ret;
}

static SINT32 ps_set_dns_ipv6(UINT8 pdp_cid, char *dns1_ipv6, char *dns2_ipv6, UINT8  dns1_ipv6_len, UINT8  dns2_ipv6_len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(dns1_ipv6_len >PDP_IP_ADDR_LENGTH_IPV6 || dns2_ipv6_len >PDP_IP_ADDR_LENGTH_IPV6)
    {
        return ERR_INVALID_PARAM;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        if(dns1_ipv6_len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv6_dns1, 0, PDP_IP_ADDR_LENGTH_IPV6);
            strncpy(pdp_info_ptr->pdp_network_info.ipv6_dns1, dns1_ipv6, dns1_ipv6_len);
        }
        if(dns2_ipv6_len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv6_dns2, 0, PDP_IP_ADDR_LENGTH_IPV6);
            strncpy(pdp_info_ptr->pdp_network_info.ipv6_dns2, dns2_ipv6, dns2_ipv6_len);
        }
    }

    return ret;
}

static SINT32 ps_set_addr_ipv4(UINT8 pdp_cid, char *addr_ipv4, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(len > PDP_IP_ADDR_LENGTH_IPV4)
        return ERR_INVALID_PARAM;


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv4_addr, 0, PDP_IP_ADDR_LENGTH_IPV4);
            strncpy(pdp_info_ptr->pdp_network_info.ipv4_addr, addr_ipv4, len);
            pdp_info_ptr->reuse_pdp_type = PROTOCOL_IPV4V6;
        }
    }

    return ret;
}




static SINT32 ps_set_gateway_ipv4(UINT8 pdp_cid, char *gateway_ipv4, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(len > PDP_IP_ADDR_LENGTH_IPV4)
        return ERR_INVALID_PARAM;


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv4_gateway, 0, PDP_IP_ADDR_LENGTH_IPV4);
            strncpy(pdp_info_ptr->pdp_network_info.ipv4_gateway, gateway_ipv4, len);
        }
    }


    return ret;
}

static SINT32 ps_set_dns_ipv4(UINT8 pdp_cid, char *dns1_ipv4, char *dns2_ipv4, UINT8  dns1_ipv4_len, UINT8  dns2_ipv4_len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(dns1_ipv4_len > PDP_IP_ADDR_LENGTH_IPV4 || dns2_ipv4_len > PDP_IP_ADDR_LENGTH_IPV4)
        return ERR_INVALID_PARAM;


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        if(dns1_ipv4_len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv4_dns1, 0, PDP_IP_ADDR_LENGTH_IPV4);
            strncpy(pdp_info_ptr->pdp_network_info.ipv4_dns1, dns1_ipv4, dns1_ipv4_len);
        }
        if(dns2_ipv4_len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv4_dns2, 0, PDP_IP_ADDR_LENGTH_IPV4);
            strncpy(pdp_info_ptr->pdp_network_info.ipv4_dns2, dns2_ipv4, dns2_ipv4_len);
        }
    }


    return ret;
}


void ata_ps_save_default_ps_card(int ril_id)
{

    int err = ERR_NONE;

    if(0 == ril_id)
    {
        err = property_set("persist.radio.main.ps", "0");
    }
    else if(1 == ril_id)
    {
        err = property_set("persist.radio.main.ps", "1");
    }

    if(err < 0)
    {
        RLOGD("[RIL-PS][ps_save_default_ps_card]set persist.radio.main.ps failed");
    }

    RLOGD("[RIL-PS][ata_ps_save_default_ps_card]set persist.radio.main.ps to %d ",ril_id);

    return;
}

SINT32 ata_ps_stop_network(UINT8 ril_cid)
{
    RLOGD("[RIL-PS][ata_ps_stop_network] [ril%d] ril_cid:%d",current_ril_id(), ril_cid);
    ps_deactive_link(ril_cid);
    return ERR_NONE;
}

void ata_ps_set_eps_pdn_parameters(void)
{
    char   prop_value[PROP_VALUE_MAX] = "";
    char   apn_name[PROP_VALUE_MAX] = "";
    int     apn_type = 0;
    int     ret = 0;
    char   at_cmd[40] = "";

    if (__system_property_get("ro.sys.lc.proj.target", prop_value) > 0) {
        if (strcmp(prop_value, "cucc") == 0) {
            if (__system_property_get("persist.radio.init.apn.name", prop_value) > 0)
            {
                strcpy(apn_name, prop_value);
                RLOGD("persist.radio.init.apn.name: %s", prop_value);
            }
        }
    }

    if (__system_property_get("persist.sys.lc.pdp.type", prop_value) > 0)
    {
        apn_type = prop_value[0] - '0';
        RLOGD("persist.sys.lc.pdp.type: %s", prop_value);
    }

    if((apn_type>=1) && (apn_type <=3))
    {
        snprintf(at_cmd, sizeof(at_cmd), "AT^DDPDN=%d,\"%s\"", apn_type, apn_name);
        at_send_command(at_cmd, NULL);
        return;
    }

    apn_type = 3; //default v4v6

    if(__system_property_get("persist.radio.init.apn.type", prop_value) > 0
       && strlen(prop_value) > 0)
    {
        apn_type = prop_value[0] - '0';
        RLOGD("persist.radio.init.apn.type: %d", apn_type);
    }

    snprintf(at_cmd, sizeof(at_cmd), "AT^DDPDN=%d,\"%s\"", apn_type, apn_name);
    at_send_command(at_cmd, NULL);

    return;
}



static PDP_INFO_ST *  ps_active_new_link(ATA_PS_PDP_REQ_ST * pdp_req)
{
    UINT8 pdp_cid=0;
    char *cmd = NULL;
    SINT32  ret_val = ERR_NONE;
    PDP_INFO_ST *pdp_info = NULL;

    if( !pdp_req )
    {
        RLOGD("[RIL-PS][ps_active_new_link] ERR_INVALID_PARAM");
        goto error;
    }

    ret_val = ps_get_idle_pdp_cid(pdp_req,&pdp_cid);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_active_new_link] ps_get_idle_pdp_cid fail");
        goto error;
    }

    ret_val = ps_prepare_ms(pdp_cid,pdp_req->protocol,pdp_req->apn,pdp_req->user,pdp_req->password);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_active_new_link] ps_prepare_ms fail");
        goto error;
    }

    ret_val = ps_active_pdp(pdp_cid);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_active_new_link] ps_active_pdp fail");
        goto error;
    }

#ifdef OPT_PS_PPP
    ret_val = ata_ps_start_pdp(pdp_cid);
    if( ERR_NONE != ret_val) 
    {
        RLOGD("[RIL-PS][ps_active_new_link] ata_ps_start_pdp fail");
        goto error;
    }

    ret_val = ata_ps_start_ppp(pdp_cid);
    if( ERR_NONE != ret_val)
    {
        RLOGD("[RIL-PS][ps_active_new_link] ata_ps_start_ppp fail");
        goto error; 
    }

#endif

#ifndef OPT_PS_PPP
    ret_val = ps_switch_data_state(pdp_cid);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_active_new_link] ps_switch_data_state fail");
        goto error;
    }
#endif

#ifndef OPT_PS_PPP
    //get IPv4 and IPv6 addresses and dnses, and copy them to pdp_info
    ret_val = ps_update_pdp_info(pdp_cid);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_active_new_link] ps_update_pdp_info fail");
        goto error;
    }

    ret_val = ps_open_lmi(pdp_cid);
    if( ERR_NONE != ret_val )
    {
        RLOGD("[RIL-PS][ps_active_new_link] ps_prepare_ms fail");
        goto error;
    }
#endif

    pdp_info = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( NULL == pdp_info )
    {
        RLOGD("[RIL-PS][ps_active_new_link] can not find a pdp info by cid %d",pdp_cid);
        goto error;
    }

    return pdp_info;

error:

    RLOGD("[RIL-PS][ps_active_new_link] deactivate a PDP(cid=%d) because the PDP failed", pdp_cid );
    ps_deactive_pdp(pdp_cid);
    return NULL;
}


static SINT32 ps_get_idle_ril_cid(UINT8 *ril_cid)
{
    UINT8 tmp_ril_cid=0;
    BOOL is_actived=FALSE;
    int i=0;

    if(!ril_cid)
        return ERR_INVALID_PARAM;

    for(tmp_ril_cid=1; tmp_ril_cid<RIL_CID_MAX_VALUE; tmp_ril_cid++)
    {
        is_actived=FALSE;

        for(i=0; i<PDP_MAX_COUNT; i++)
        {
            if (RIL_CID_ACTIVED == pdp_info_st[i].ril_cids[tmp_ril_cid-1])
            {
                is_actived = TRUE;
                break;
            }

        }

        if(is_actived)
        {
            continue;
        }
        else
        {
            *ril_cid = tmp_ril_cid;
            RLOGD("[RIL-PS][ps_get_idle_ril_cid] new ril cid is %d ",tmp_ril_cid);
            return ERR_NONE;
        }
    }

    RLOGD("[RIL-PS][ps_get_idle_ril_cid] get idle logical cid fail");

    return ERR_NOT_FOUND;

}


static PDP_INFO_ST * ps_find_reusable_link(ATA_PS_PDP_REQ_ST * pdp_req)
{
    SINT32 i=0;
    BOOL found_ril_cid = FALSE;
    UINT8 req_pdp_type = 0;
    UINT8 reuse_pdp_type = PROTOCOL_UNKNOW;

#ifdef OPT_PS_REUSE_LINK_ENABLE
    req_pdp_type = ps_convert_protocol_to_numeric(pdp_req->protocol);

    for(i=0; i<PDP_MAX_COUNT; i++)
    {
        if ((ps_is_reusable_protocol_type(pdp_info_st[i].req_pdp_type,pdp_info_st[i].reuse_pdp_type,req_pdp_type ,pdp_req->check_protocol,&reuse_pdp_type))
            &&(ps_is_same_apn(pdp_info_st[i].apn,pdp_req->apn))
            &&(PS_STATE_PDP_ACTIVATED == pdp_info_st[i].pdp_state))
        {
            RLOGD("[RIL-PS][ps_find_reusable_link] found reusable ril connection ,index is %d",i);
            RLOGD("[RIL-PS][ps_find_reusable_link] reuse_pdp_type is %d",pdp_info_st[i].reuse_pdp_type);
            found_ril_cid = TRUE;
            break;
        }
    }

    if(found_ril_cid)
    {
        return &pdp_info_st[i];
    }
    else
    {
        return NULL;
    }

#else
    return NULL;
#endif
}

static SINT32 ps_set_ril_cid(UINT8 ril_cid,PDP_INFO_ST *  pdp_info)
{

    if( !pdp_info )
    {
        RLOGD( "[RIL-PS][ps_set_ril_cid] pdp_info is NULL ");
        return ERR_INVALID_PARAM;
    }

    if((ril_cid >=RIL_CID_MIN_VALUE)&&(ril_cid <= RIL_CID_MAX_VALUE))
    {
        pdp_info->ril_cids[ril_cid-1]=RIL_CID_ACTIVED;
        RLOGD( "[RIL-PS][ps_set_ril_cid] set ril id %d  ",ril_cid);
        return ERR_NONE;
    }
    else
    {
        RLOGD( "[RIL-PS][ps_set_ril_cid] set ril id %d fail ", ril_cid);
        return ERR_INVALID_PARAM;
    }
}

static BOOL ps_is_same_apn(char * apn1,char * apn2)
{
    SINT32 apn1_network_identifier_len = 0;
    SINT32 apn2_network_identifier_len = 0;
    SINT32 i = 0;

    if((strlen(apn1)==0) && (strlen(apn2)==0))
    {
        RLOGD("[RIL-PS][ps_is_same_apn] same NULL apn");
        return TRUE;
    }
    else if((strlen(apn1)==0) || (strlen(apn2)==0))
    {
        RLOGD("[RIL-PS][ps_is_same_apn] is diff apn ");
        return FALSE;
    }

    /*
    3GPP 23.003

    The APN is composed of two parts as follows:
    	 The APN Network Identifier; this defines to which external network the GGSN/PGW is connected and optionally a requested service by the MS. This part of the APN is mandatory.
    	 The APN Operator Identifier; this defines in which PLMN GPRS/EPS backbone the GGSN/PGW is located. This part of the APN is optional.

    	 EXAMPLE 1: 		 province1.mnc012.mcc345.gprs
    	 EXAMPLE 2: 		 ggsn-cluster-A.provinceB.mnc012.mcc345.gprs

    */
    for(i=0; i<=strlen(apn1)-1; i++)
    {
        if(apn1[i]=='.')
            break;
        apn1_network_identifier_len = i+1;
    }

    for(i=0; i<=strlen(apn2)-1; i++)
    {
        if(apn1[i]=='.')
            break;
        apn2_network_identifier_len =  i+1;
    }

    if(apn1_network_identifier_len!=apn2_network_identifier_len)
        return FALSE;

    if(!strncasecmp(apn1,apn2,apn1_network_identifier_len))
    {
        RLOGD("[RIL-PS][ps_is_same_apn] The APN Network Identifier is same");
        return TRUE;
    }
    else if(((apn1_network_identifier_len==5) &&(apn2_network_identifier_len==5))
        &&((!strncasecmp(apn1,"3gnet",5))||(!strncasecmp(apn1,"wonet",5)))
        &&((!strncasecmp(apn2,"3gnet",5))||(!strncasecmp(apn2,"wonet",5))))
    {//for cucc ,  consider "3gnet" is the same apn as "wonet"
        RLOGD("[RIL-PS][ps_is_same_apn] The APN Network Identifier 3gnet is same as wonet");
        return TRUE;
    }
    else
    {
        RLOGD("[RIL-PS][ps_is_same_apn] The APN Network Identifier is not same");
        return FALSE;
    }
}


static SINT32 ps_get_idle_netif(char *ifname, int ifname_len)
{

    if(ifname == NULL)
    {
        RLOGD("[RIL-PS][ps_get_idle_netif] ifname error ");
        return ERR_INVALID_PARAM;
    }

    if(ifname_len < IFNAMSIZ)
    {
        RLOGD("[RIL-PS][ps_get_idle_netif] ifname_len error %d", ifname_len);
        return ERR_INVALID_PARAM;
    }

    int ril_id = current_ril_id();

    if(ril_id == 0)
    {
        if(ps_is_idle_netif("lmi40"))
        {
            snprintf(ifname, IFNAMSIZ, "lmi40" );
        }
        else if(ps_is_idle_netif("lmi41"))
        {
            snprintf(ifname, IFNAMSIZ, "lmi41" );
        }
        else
        {
            return ERR_UNKNOWN;
        }
    }
    else if(ril_id == 1)
    {
        if(ps_is_idle_netif("lmi43"))
        {
            snprintf(ifname, IFNAMSIZ, "lmi43" );
        }
        else if(ps_is_idle_netif("lmi44"))
        {
            snprintf(ifname, IFNAMSIZ, "lmi44" );
        }
        else
        {
            return ERR_UNKNOWN;
        }
    }
    else
    {
        return ERR_UNKNOWN;
    }

    RLOGD("[RIL-PS][ps_get_idle_netif] get: %s", ifname);

    return ERR_NONE;
}

static BOOL ps_is_idle_netif(char * ifname)
{
    int i = 0;

    if(ifname==NULL)
    {
        RLOGD("[RIL-PS][ps_is_idle_netif] ifname is  NULL ");
        return FALSE;
    }


    for(i=0; i<PDP_MAX_COUNT; i++)
    {

        if(strlen(pdp_info_st[i].ifname)==0)
        {
            continue;
        }


        if(!strncasecmp(pdp_info_st[i].ifname,ifname,strlen(ifname)))
        {
            RLOGD("[RIL-PS][ps_is_idle_netif] %s is not idle ",ifname);
            return FALSE;
        }

    }

    RLOGD("[RIL-PS][ps_is_idle_netif] found idle netif %s",ifname);

    return TRUE;
}


static SINT32 ps_set_req_pdp_type(UINT8 pdp_cid,UINT8 req_pdp_type)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_req_pdp_type] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        pdp_info_ptr->req_pdp_type = req_pdp_type;
        RLOGD("[RIL-PS][ps_set_req_pdp_type] set pdp info by cid: %d req pdp type to %d", pdp_cid,req_pdp_type);
        return ERR_NONE;
    }
}

static SINT32 ps_set_act_pdp_type(UINT8 pdp_cid,UINT8 act_pdp_type)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_act_pdp_type] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        pdp_info_ptr->act_pdp_type = act_pdp_type;
        RLOGD("[RIL-PS][ps_set_act_pdp_type] set pdp info by cid: %d act pdp type to %d", pdp_cid,act_pdp_type);
        return ERR_NONE;
    }
}

static SINT32 ps_set_reuse_pdp_type(UINT8 pdp_cid,UINT8 reuse_pdp_type)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_reuse_pdp_type] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        pdp_info_ptr->reuse_pdp_type = reuse_pdp_type;
        RLOGD("[RIL-PS][ps_set_reuse_pdp_type] set pdp info by cid: %d reuse pdp type to %d", pdp_cid,reuse_pdp_type);
        return ERR_NONE;
    }
}

static SINT32 ps_get_reuse_pdp_type(UINT8 pdp_cid,UINT8 *reuse_pdp_type)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if((pdp_cid <PDP_MIN_VALUE)||(pdp_cid > S_PDP_MAX_VALUE))
    {
    	return ERR_INVALID_PARAM;
    }

    if(!reuse_pdp_type)
    {
    	return ERR_UNKNOWN;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_reuse_pdp_type] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        *reuse_pdp_type = pdp_info_ptr->reuse_pdp_type;
        RLOGD("[RIL-PS][ps_get_reuse_pdp_type] pdp cid: %d reuse_pdp_type is %d", pdp_cid,*reuse_pdp_type);
        return ERR_NONE;
    }

}


static SINT32 ps_set_lmi_ifname(UINT8 pdp_cid, char *dev_name, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(len < IFNAMSIZ)
        return ERR_INVALID_PARAM;

    if(!dev_name)
        return ERR_INVALID_PARAM;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_lmi_ifname] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        memset(pdp_info_ptr->ifname, 0, IFNAMSIZ);
        strncpy(pdp_info_ptr->ifname, dev_name, IFNAMSIZ);
        RLOGD("[RIL-PS][ps_set_lmi_ifname] set cid: %d ifname to %s", pdp_cid,dev_name);
    }


    return ret;
}


static SINT32 ps_get_addr_ipv4(UINT8 pdp_cid, char *addr_ipv4, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if(len < PDP_IP_ADDR_LENGTH_IPV4)
        return ERR_INVALID_PARAM;

    if(!addr_ipv4)
        return ERR_INVALID_PARAM;


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(addr_ipv4, 0, PDP_IP_ADDR_LENGTH_IPV4);
            strncpy(addr_ipv4, pdp_info_ptr->pdp_network_info.ipv4_addr, PDP_IP_ADDR_LENGTH_IPV4);
        }
    }

    return ERR_NONE;

}

static SINT32 ps_get_addr_link_local_ipv6(UINT8 cid, char *ipaddr_link_local_v6, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if(len < PDP_IP_ADDR_LENGTH_IPV6)
        return ERR_INVALID_PARAM;

    if(!ipaddr_link_local_v6)
        return ERR_INVALID_PARAM;


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_pdp_apn] Can not get pdp info by cid: %d", cid);
        return ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(ipaddr_link_local_v6, 0, PDP_IP_ADDR_LENGTH_IPV6);
            strncpy(ipaddr_link_local_v6, pdp_info_ptr->pdp_network_info.ipv6_link_local_addr, PDP_IP_ADDR_LENGTH_IPV6);
        }
    }

    return ERR_NONE;

}


static SINT32 ps_deactive_link(UINT8 ril_cid)
{
    PDP_INFO_ST *  pdp_info = NULL;

    if((ril_cid >= RIL_CID_MIN_VALUE)&&(ril_cid <= RIL_CID_MAX_VALUE))
    {
        pdp_info = ps_get_pdp_info_by_ril_cid(ril_cid);

        if(!pdp_info)
        {
            return ERR_UNKNOWN;
        }

        pdp_info->ril_cids[ril_cid-1]=RIL_CID_DEACTIVED;

        int i = 0;
        int count =0;
        for(i = RIL_CID_MIN_VALUE; i<=RIL_CID_MAX_VALUE; i++)
        {
            if (pdp_info->ril_cids[i-1]==RIL_CID_ACTIVED)
            {
                count++;
                break;
            }
        }

        if(count == 0)
        {
            RLOGD("[RIL-PS][ps_deactive_link] deactive pdp cid: %d", pdp_info->pdp_cid);
            ps_deactive_pdp(pdp_info->pdp_cid);
        }
        else
        {
            RLOGD("[RIL-PS][ps_deactive_link] pdp cid %d is still using", pdp_info->pdp_cid);
        }

        return ERR_NONE;
    }
    else
    {
        return ERR_INVALID_PARAM;
    }

    return ERR_NONE;
}



static PDP_INFO_ST *ps_get_pdp_info_by_ril_cid( UINT8 ril_cid )
{
    UINT8   i = 0;

    for( i = 0; i < PDP_MAX_COUNT; i++ )
    {
        if( RIL_CID_ACTIVED == pdp_info_st[i].ril_cids[ril_cid-1])
        {
            return &pdp_info_st[i];
        }
    }

    return NULL;
}

void ata_ps_init(void)
{
    int i=0;
    for(i=0; i<PDP_MAX_COUNT; i++)
    {
        ps_reset_pdp_info(&pdp_info_st[i]);
    }
    RLOGD("[RIL-PS][ata_ps_init] [ril%d]",current_ril_id());

    return ;
}

static BOOL ps_is_received_other_cid(UINT8 pdp_cid,UINT8 *other_cid)
{
    char *cmd = NULL;
    char *line = NULL;
    char *p = NULL;
    int err = -1;
    ATResponse *p_response= NULL;
    int commas = -1;
    int skip = 0;
    int at_cid = 0;
    BOOL other_cid_exist = FALSE;

    if((pdp_cid< RIL_CID_MIN_VALUE)||(pdp_cid > RIL_CID_MAX_VALUE))
    {
        goto error;
    }

    asprintf(&cmd, "AT^DQCCO=%d", pdp_cid);
    err = at_send_command_singleline(cmd, "^DQCCO:", &p_response);
    free(cmd);
    if (err < 0 || p_response->success == 0)
    {
        RLOGD("[RIL-PS][ps_is_received_other_cid] AT^DQCCO fail");
        goto error;
    }

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if(err < 0)
    {
        RLOGD("[RIL-PS][ps_is_received_other_cid] AT^DQCCO at_tok_start error");
        goto error;
    }

    commas = 0;
    for (p = line ; *p != '\0' ; p++)
    {
        if (*p == ',') commas++;
    }

    if(commas>0)
    {
        err = at_tok_nextint(&line, &skip);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_is_received_other_cid] AT^DQCCO cid is %d",skip);
            goto error;
        }

        err = at_tok_nextint(&line, &at_cid);
        if (err < 0)
        {
            RLOGD("[RIL-PS][ps_is_received_other_cid] AT^DQCCO other cid is %d",at_cid);
            goto error;
        }
    }

    if((at_cid>= RIL_CID_MIN_VALUE)&&(at_cid <= RIL_CID_MAX_VALUE))
    {
        *other_cid = at_cid;
        other_cid_exist =  TRUE;
    }

error:

    at_response_free(p_response);
    RLOGD("[RIL-PS][ps_is_received_other_cid] return %d",other_cid_exist);
    return other_cid_exist;
}


static BOOL ps_is_reusable_protocol_type(UINT8 pdp_req_type, UINT8 pdp_act_type, UINT8 new_pdp_req_type,BOOL strict_matching,UINT8 * reuse_pdp_type)
{
     BOOL ret = FALSE;

     if(!reuse_pdp_type)
     {
          return FALSE;
     }

     if(pdp_req_type<PROTOCOL_IPV4||pdp_req_type>PROTOCOL_IPV4V6)
     {
          return FALSE;
     }

     if(pdp_act_type<PROTOCOL_IPV4||pdp_act_type>PROTOCOL_IPV4V6)
     {
          return FALSE;
     }

     if(new_pdp_req_type<PROTOCOL_IPV4||new_pdp_req_type>PROTOCOL_IPV4V6)
     {
          return FALSE;
     }

     if(strict_matching)
     {
          RLOGD("[RIL-PS][ps_is_reusable_protocol_type] strict matching ");
/*
�ϸ�ƥ��
--------------------------------------------------------
|ApPdpReqType|LteReqPdpType|LteActPdpType|ReuseStrategy|
--------------------------------------------------------
| v4                | v4                  | v4                 | reuse v4       |
--------------------------------------------------------
| v4                | v6                  | v6                 | Do not reuse |
--------------------------------------------------------
| v4                | v4v6               | v4                 | reuse v4       |
--------------------------------------------------------
| v4                | v4v6               | v6                 | Do not reuse|
-------------------------------------------------------
| v4                | v4v6               | v4v6              | reuse v4      |
--------------------------------------------------------
| v6                | v4                   | v4                 | not reuse     |  
--------------------------------------------------------
| v6                | v6                   | v6                 | reuse v6      | 
--------------------------------------------------------
| v6                | v4v6                | v4                 | not reuse     |
--------------------------------------------------------
| v6                | v4v6                | v6                 | reuse v6      |
--------------------------------------------------------
| v6                | v4v6                | v4v6             | onlyreuse v6 | 
--------------------------------------------------------
| v4v6             | v4                   | v4                 |!!not reuse!!|  
--------------------------------------------------------
| v4v6             | v6                   | v6                 |!!not reuse!!|
--------------------------------------------------------
| v4v6             | v4v6               | v4                 | reuse v4        | 
--------------------------------------------------------
| v4v6             | v4v6               | v6                 | reuse v6        |
--------------------------------------------------------
| v4v6             | v4v6               | v4v6             | reuse v4v6     |
--------------------------------------------------------
*/
          if(new_pdp_req_type == PROTOCOL_IPV4)
          {
                if((pdp_act_type==PROTOCOL_IPV4)||(pdp_act_type==PROTOCOL_IPV4V6))
                {
                    ret = TRUE;
                    *reuse_pdp_type = PROTOCOL_IPV4;
                    RLOGD("[RIL-PS][ps_is_reusable_protocol_type] ipv4");
                }
                else
                {
                    ret = FALSE;
                    RLOGD("[RIL-PS][ps_is_reusable_protocol_type] not reuse");
                }
          }
          else if(new_pdp_req_type == PROTOCOL_IPV6)
          {
                if((pdp_act_type==PROTOCOL_IPV6)||(pdp_act_type==PROTOCOL_IPV4V6))
                {
                    ret = TRUE;
                    *reuse_pdp_type = PROTOCOL_IPV6;
                    RLOGD("[RIL-PS][ps_is_reusable_protocol_type] ipv6");
                }
                else
                {
                    ret = FALSE;
                    RLOGD("[RIL-PS][ps_is_reusable_protocol_type] not reuse");
                }
          }
          else if(new_pdp_req_type == PROTOCOL_IPV4V6)
          {
                if(pdp_req_type == PROTOCOL_IPV4V6)
                {
                    ret = TRUE;
                    *reuse_pdp_type = pdp_act_type;
                    RLOGD("[RIL-PS][ps_is_reusable_protocol_type] reuse act type %d",pdp_act_type);
                }
                else
                {
                    ret = FALSE;
                    RLOGD("[RIL-PS][ps_is_reusable_protocol_type] not reuse");
                }
          }
     }
     else //check_ip_type is TRUE
     {
/*
���ϸ�ƥ��
--------------------------------------------------------
|ApPdpReqType|LteReqPdpType|LteActPdpType|ReuseStrategy|
--------------------------------------------------------
| v4                | v4                  | v4                 | reuse v4       |
--------------------------------------------------------
| v4                | v6                  | v6                 | Do not reuse |
--------------------------------------------------------
| v4                | v4v6               | v4                 | reuse v4        |
--------------------------------------------------------
| v4                | v4v6               | v6                 | Do not reuse|
-------------------------------------------------------
| v4                | v4v6               | v4v6              | reuse v4      |
--------------------------------------------------------
| v6                | v4                   | v4                 | not reuse     |  
--------------------------------------------------------
| v6                | v6                   | v6                 | reuse v6      | 
--------------------------------------------------------
| v6                | v4v6                | v4                 | not reuse     |
--------------------------------------------------------
| v6                | v4v6                | v6                 | reuse v6      |
--------------------------------------------------------
| v6                | v4v6                | v4v6             | onlyreuse v6 | 
--------------------------------------------------------
| v4v6             | v4                   | v4                 |!!reuse v4!!|  
--------------------------------------------------------
| v4v6             | v6                   | v6                 |!!reuse v6!!|
--------------------------------------------------------
| v4v6             | v4v6               | v4                 | reuse v4        | 
--------------------------------------------------------
| v4v6             | v4v6               | v6                 | reuse v6        |
--------------------------------------------------------
| v4v6             | v4v6               | v4v6             | reuse v4v6     |
--------------------------------------------------------
*/
            RLOGD("[RIL-PS][ps_is_reusable_protocol_type] not strict matching ");

	     if(new_pdp_req_type == PROTOCOL_IPV4)
	    {
	        if((pdp_act_type==PROTOCOL_IPV4)||(pdp_act_type==PROTOCOL_IPV4V6))
	        {
	            ret = TRUE;
	            *reuse_pdp_type = PROTOCOL_IPV4;
	            RLOGD("[RIL-PS][ps_is_reusable_protocol_type] ipv4");
	        }
	        else
	        {
	            ret = FALSE;
	            RLOGD("[RIL-PS][ps_is_reusable_protocol_type] not reuse");
	        }
	    }
	    else if(new_pdp_req_type == PROTOCOL_IPV6)
	    {
	        if((pdp_act_type==PROTOCOL_IPV6)||(pdp_act_type==PROTOCOL_IPV4V6))
	        {
	            ret = TRUE;
	            *reuse_pdp_type = PROTOCOL_IPV6;
	            RLOGD("[RIL-PS][ps_is_reusable_protocol_type] ipv6");
	        }
	        else
	        {
	            ret = FALSE;
	            RLOGD("[RIL-PS][ps_is_reusable_protocol_type] not reuse");
	        }
	    }
            else if(new_pdp_req_type == PROTOCOL_IPV4V6)
            {
                ret = TRUE;
                *reuse_pdp_type = pdp_act_type;
                RLOGD("[RIL-PS][ps_is_reusable_protocol_type] reuse act type %d",pdp_act_type);
            }
      }

    return ret;
}


static SINT32 ps_get_pdp_cid_by_ril_cid( UINT8 ril_cid ,UINT8 * pdp_cid)
{
    UINT8   i = 0;

    if(!pdp_cid)
    {
    	return ERR_INVALID_PARAM;
    }

    if((ril_cid <RIL_CID_MIN_VALUE)||(ril_cid > RIL_CID_MAX_VALUE))
    {
    	return ERR_INVALID_PARAM;
    }

    for( i = 0; i < PDP_MAX_COUNT; i++ )
    {
        if( RIL_CID_ACTIVED == pdp_info_st[i].ril_cids[ril_cid-1])
        {
           *pdp_cid  = pdp_info_st[i].pdp_cid;
           RLOGD("[RIL-PS][ps_get_pdp_cid_by_ril_cid] ril cid %d  ---> pdp cid is %d ",ril_cid,*pdp_cid);
           return ERR_NONE;
        }
    }

   RLOGD("[RIL-PS][ps_get_pdp_cid_by_ril_cid] ril cid %d  ---> can't found pdp cid ",ril_cid);
   return ERR_UNKNOWN;
}


static SINT32 ps_get_act_pdp_type_by_ril_cid(UINT8 ril_cid,UINT8 * act_pdp_type)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if(!act_pdp_type)
    {
    	return ERR_INVALID_PARAM;
    }

    pdp_info_ptr = ps_get_pdp_info_by_ril_cid(ril_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_act_pdp_type_by_ril_cid] Can not get pdp info by cid: %d", ril_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        *act_pdp_type =  pdp_info_ptr->act_pdp_type;
        RLOGD("[RIL-PS][ps_get_act_pdp_type_by_ril_cid] ril cid %d  req_pdp_type is %d ",ril_cid,*act_pdp_type);
        return ERR_NONE;
    }

}


static SINT32 ps_get_apn(UINT8 pdp_cid,UINT8 * apn, UINT8 apn_len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if((pdp_cid <PDP_MIN_VALUE)||(pdp_cid > S_PDP_MAX_VALUE))
    {
    	return ERR_INVALID_PARAM;
    }

    if(apn_len < PDP_APN_LENGTH)
    {
        return ERR_INVALID_PARAM;
    }

    if(!apn)
    {
        return ERR_INVALID_PARAM;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_apn] Can not get pdp info by pdp cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        memset(apn, 0, PDP_APN_LENGTH);
        strncpy(apn,pdp_info_ptr->apn, PDP_APN_LENGTH);
        RLOGD("[RIL-PS][ps_set_pdp_apn] pdp cid %d apn is %s", pdp_cid,apn);
        return ERR_NONE;
    }

}


void ata_ps_set_default_apn(const char *apn, const char *protocol)
{
    char    propValue[PROP_VALUE_MAX] = "";

    if(NULL == apn || NULL == protocol)
    {
        RLOGE("[RIL-PS][ata_ps_set_default_apn]: invalid parameter");
        return;
    }

    snprintf(propValue, sizeof(propValue), "%d", ps_convert_protocol_to_numeric(protocol));
    if (__system_property_set("persist.radio.init.apn.type", propValue) == 0)
    {
        RLOGI("[RIL-PS][ata_ps_set_default_apn]set property: [%s]: [%s]", "persist.radio.init.apn.type", propValue);
    }
    else
    {
        RLOGE("[RIL-PS][ata_ps_set_default_apn]set property: [%s]: [%s] failed", "persist.radio.init.apn.type", propValue);
    }

    return;
}

static SINT32 ps_set_interface_id_ipv6(UINT8 pdp_cid, char *ipv6_interface_id, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if(len > PDP_IP_ADDR_LENGTH_IPV6)
        return ERR_UNKNOWN;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_interface_id_ipv6] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(pdp_info_ptr->pdp_network_info.ipv6_interface_id, 0, PDP_IP_ADDR_LENGTH_IPV6);
            strncpy(pdp_info_ptr->pdp_network_info.ipv6_interface_id, ipv6_interface_id, len);
        }
    }

    return ret;
}

static SINT32 ps_get_interface_id_ipv6(UINT8 pdp_cid, char *ipv6_interface_id, UINT8 len)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    if(len < PDP_IP_ADDR_LENGTH_IPV6)
        return ERR_INVALID_PARAM;

    if(!ipv6_interface_id)
        return ERR_INVALID_PARAM;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_get_interface_id_ipv6] Can not get pdp info by cid: %d", pdp_cid);
        return ERR_UNKNOWN;
    }
    else
    {
        if(len > 0)
        {
            memset(ipv6_interface_id, 0, PDP_IP_ADDR_LENGTH_IPV6);
            strncpy(ipv6_interface_id, pdp_info_ptr->pdp_network_info.ipv6_interface_id, PDP_IP_ADDR_LENGTH_IPV6);
        }
    }

    return ERR_NONE;

}


static SINT32 ps_set_cid_ipv6(UINT8 pdp_cid)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;
    SINT32 ret = ERR_NONE;

    if((pdp_cid <PDP_MIN_VALUE)||(pdp_cid > S_PDP_MAX_VALUE))
    {
    	return ERR_INVALID_PARAM;
    }

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_set_cid_ipv6] Can not get pdp info by cid: %d", pdp_cid);
        ret = ERR_UNKNOWN;
    }
    else
    {
        pdp_info_ptr->cid_ipv6 = pdp_cid;
    }

    return ret;
}


static void ps_send_ipv6_info_to_modem(UINT8 pdp_cid)
{
    uint32_t * h1=NULL;
    uint32_t * h2=NULL;
    uint32_t * h3=NULL;
    uint32_t * h4=NULL;
    PDP_INFO_ST *pdp_info_ptr = NULL;
    struct in6_addr ra_addr6 ;
    char    at_cmd_a[100] = "";

    if((pdp_cid <PDP_MIN_VALUE)||(pdp_cid > S_PDP_MAX_VALUE))
    {
        RLOGE("[RIL-PS]%s() invalid parameter", __func__);
    	return;
    }


    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(  pdp_cid );
    if(NULL == pdp_info_ptr) 
    {
        RLOGE("[RIL-PS]%s() invalid parameter", __func__);
        return;
    }

    if((pdp_info_ptr->cid_ipv6 <PDP_MIN_VALUE)||(pdp_info_ptr->cid_ipv6 > S_PDP_MAX_VALUE))
    {
        RLOGE("[RIL-PS]%s() invalid parameter", __func__);
    	return;
    }


    RLOGD("[PS]send ipv6 address to Modem: %s", pdp_info_ptr->pdp_network_info.ipv6_addr);
    inet_pton(AF_INET6, pdp_info_ptr->pdp_network_info.ipv6_addr, &ra_addr6);
    h1 = (uint32_t *) (&ra_addr6);
    h2 = (uint32_t *) (&ra_addr6)+1;
    h3 = (uint32_t *) (&ra_addr6)+2;
    h4 = (uint32_t *) (&ra_addr6)+3;
    snprintf(at_cmd_a, sizeof(at_cmd_a),
            "AT^DUDIA=%d,\"%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d.%d\",\"\",%d",
            pdp_info_ptr->cid_ipv6,
            (*h1 & 0x000000FF), ((*h1 >> 8) & 0x000000FF),
            ((*h1 >> 16) & 0x000000FF), ((*h1 >> 24) & 0x000000FF),
            (*h2 & 0x000000FF), ((*h2 >> 8) & 0x000000FF),
            ((*h2 >> 16) & 0x000000FF), ((*h2 >> 24) & 0x000000FF),
            (*h3 & 0x000000FF), ((*h3 >> 8) & 0x000000FF),
            ((*h3 >> 16) & 0x000000FF), ((*h3 >> 24) & 0x000000FF),
            (*h4 & 0x000000FF), ((*h4 >> 8) & 0x000000FF),
            ((*h4 >> 16) & 0x000000FF), ((*h4 >> 24) & 0x000000FF),
            pdp_info_ptr->pdp_network_info.ipv6_prefix_len);
    at_send_command(at_cmd_a, NULL);
}

void ata_ps_set_ps_switch(BOOL is_ps_switch)
{
	ata_ps_switch = is_ps_switch;
}

BOOL ata_ps_is_ps_switch(void)
{
	return ata_ps_switch;
}


void ps_clean_ipv4_info(UINT8 pdp_cid)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_clean_ipv4_info] Can not get pdp info by cid: %d", pdp_cid);
    }
    else
    {
        memset(pdp_info_ptr->pdp_network_info.ipv4_addr, 0, PDP_IP_ADDR_LENGTH_IPV4);
        memset(pdp_info_ptr->pdp_network_info.ipv4_dns1, 0, PDP_IP_ADDR_LENGTH_IPV4);
        memset(pdp_info_ptr->pdp_network_info.ipv4_dns2, 0, PDP_IP_ADDR_LENGTH_IPV4);
        memset(pdp_info_ptr->pdp_network_info.ipv4_gateway, 0, PDP_IP_ADDR_LENGTH_IPV4);
    }
    return ;
}

void ps_clean_ipv6_info(UINT8 pdp_cid)
{
    PDP_INFO_ST *pdp_info_ptr = NULL;

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(pdp_cid);
    if( !pdp_info_ptr )
    {
        RLOGD("[RIL-PS][ps_clean_ipv4_info] Can not get pdp info by cid: %d", pdp_cid);
    }
    else
    {
        memset(pdp_info_ptr->pdp_network_info.ipv6_addr, 0, PDP_IP_ADDR_LENGTH_IPV6);
        memset(pdp_info_ptr->pdp_network_info.ipv6_dns1, 0, PDP_IP_ADDR_LENGTH_IPV6);
        memset(pdp_info_ptr->pdp_network_info.ipv6_dns2, 0, PDP_IP_ADDR_LENGTH_IPV6);
        memset(pdp_info_ptr->pdp_network_info.ipv6_gateway, 0, PDP_IP_ADDR_LENGTH_IPV6);
        memset(pdp_info_ptr->pdp_network_info.ipv6_link_local_addr, 0, PDP_IP_ADDR_LENGTH_IPV6);
        memset(pdp_info_ptr->pdp_network_info.ipv6_interface_id, 0, PDP_IP_ADDR_LENGTH_IPV6);
        pdp_info_ptr->pdp_network_info.ipv6_prefix_len=0;
    }
    return ;

}

static void *th_ps_ipv6_ra_config(void *param)
{
    UINT32 pdp_cid = (UINT32) param;
    char ipv6_ra_addr[PDP_IP_ADDR_LENGTH_IPV6] = {0};
    int ret = ERR_NONE;

    RLOGD("[RIL-PS][th_ps_ipv6_ra_config] network_op_mutex start");
    pthread_mutex_lock(&network_op_mutex);
    RLOGD("[RIL-PS][th_ps_ipv6_ra_config] network_op_mutex entry ref: %d", network_op_mutex_ref);
    network_op_mutex_ref++;

    RLOGD("[RIL-PS][th_ps_ipv6_ra_config] pdp_cid %d , [ril%d]", pdp_cid,current_ril_id());

    ret = ps_get_ra_ipv6_addr(pdp_cid, ipv6_ra_addr);

    if(ERR_NONE != ret)
    {
        RLOGD("[RIL-PS][th_ps_ipv6_ra_config] get ra ipv6 addr failed" );
        ps_deactive_pdp((UINT8)pdp_cid);
    }
    else
    {
        ret = ps_set_addr_ipv6(pdp_cid,ipv6_ra_addr,PDP_IP_ADDR_LENGTH_IPV6);
        if(ERR_NONE != ret)
        {
            RLOGD("[RIL-PS][th_ps_ipv6_ra_config] ps_set_addr_ipv6 failed" );
            ps_deactive_pdp((UINT8)pdp_cid);
        }
        else
        {
        	ps_send_ipv6_info_to_modem(pdp_cid);
        	ps_update_data_call_list(NULL);    
        }
    }

    network_op_mutex_ref--;
    RLOGD("[RIL-PS][th_ps_ipv6_ra_config] network_op_mutex exit ref: %d", network_op_mutex_ref);
    pthread_mutex_unlock(&network_op_mutex);
    return NULL;

}

/*******************************************************************************
 * Function: ata_ps_start_ppp
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Start a PPP conversation.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type             In/Out  Description
 *     ------------  ---------------  ------  ---------------------------------
 *     cid           UINT8            In      pdp cid
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
SINT32 ata_ps_start_ppp(UINT8 cid)
{
    SINT32  ret_val = ERR_NONE;

    LOG_FUNC();    
    ret_val = start_ppp_with_device(cid);
    return ret_val;
}

/*******************************************************************************
 * Function: ata_ps_stop_ppp
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Stop a PPP conversation.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type             In/Out  Description
 *     ------------  ---------------  ------  ---------------------------------
 *     cid           UINT8            In      pdp cid
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
SINT32 ata_ps_stop_ppp(UINT8 cid)
{
    SINT32          ret_val = ERR_NONE;
    PDP_INFO_ST     *pdp_info_ptr = NULL;

    LOG_FUNC();

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(cid);
    if( !pdp_info_ptr )
    {
		RLOGD("[PS: ata_ps_stop_ppp] Can not get pdp info by cid: %d", cid);
        return ERR_INVALID_PARAM;
    }

    ret_val = stop_pppd(pdp_info_ptr);

    return ret_val;
}

/*******************************************************************************
 * Function: ata_ps_stop_all_ppp
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Stop all PPP conversations.
 *
 * Used variables:
 * ----------------------------
 *     pdp_info_st
 *
 * Params:
 * ----------------------------
 *     Name          Type             In/Out  Description
 *     ------------  ---------------  ------  ---------------------------------
 *     (none)
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
SINT32 ata_ps_stop_all_ppp(void)
{
    SINT32  ret_val = ERR_NONE;
    UINT8   i = 0;

    LOG_FUNC();

    for( i=0; i<PDP_MAX_COUNT; i++ )
    {
        if( pdp_info_st[i].pdp_cid > 0 )
        {
            ret_val = stop_pppd(&pdp_info_st[i]);
        }
    }

    return ERR_NONE;
}

/*******************************************************************************
     * Function: stop_pppd
     * -----------------------------------------------------------------------------
     * Purpose:
     * ----------------------------
     *     Force to delete a ppp device.
     *
     * Used variables:
     * ----------------------------
     *     (None)
     *
     * Params:
     * ----------------------------
     *     Name            Type            In/Out  Description
     *     --------------  --------------  ------  --------------------------------
     *     pdp_info_ptr    PDP_INFO_ST *   In      pdp info
     *
     * Return:
     * ----------------------------
     *     Error code.
     *
     * Note:
     * ----------------------------
     *     (None)
     *
     ******************************************************************************/
    static SINT32 stop_pppd(PDP_INFO_ST *pdp_info_ptr)
    {
        SINT32  ret_val = ERR_NONE;
        FILE    *fp = NULL;
        char    ch;
        UINT8   i = 0;
        char    buf_a[40] = {0};
        const char  *pppd_path_ptr = SYS_PROGRAM_PPPD;
        UINT32  pid = 0;

        LOG_FUNC();

        if( !pdp_info_ptr
            || 0 == pdp_info_ptr->pdp_cid  )
        {
        RLOGD("[PS: stop_pppd] %d, %d", !pdp_info_ptr, (0 == pdp_info_ptr->pdp_cid));
        return ERR_INVALID_PARAM;
    }

    if( pdp_info_ptr->ppp_pid > 0 )
    {
        pid = pdp_info_ptr->ppp_pid;
	    RLOGD("[PS: stop_pppd] cid is %d , pid is %d", pdp_info_ptr->pdp_cid, pid);
    }
    else
    {
        pid = get_pppd_pid(pdp_info_ptr->pdp_cid);
        if( 0 == pid )
        {
           RLOGD("[PS: stop_pppd] get pid is 0");
            return ERR_INVALID_PARAM;
        }
    }

#ifdef OPT_ENABLE_LC_ATA_CONFIG
    if( strlen(lc_ata_cfg_st.m_pppd_path_a) > 0 )
    {
        pppd_path_ptr = (lc_ata_cfg_st.m_pppd_path_a);
    }
#endif

    memset( buf_a, 0x00, sizeof(buf_a) );

    /* Try to get the process command line according to the process id. */

    snprintf( buf_a,
              sizeof(buf_a) - 1,
              "/proc/%ld/cmdline",
              pid );
    fp = fopen(buf_a, "r");
    if( fp )
    {
        memset( buf_a, 0x00, sizeof(buf_a) );

        i = 0;
        ch = getc(fp);
        while( i < (sizeof(buf_a) - 1)
               && ( ('a' <= ch && ch <= 'z')
                    || '/' == ch ) )
        {
            buf_a[i] = ch;
            i++;
            ch = getc(fp);
        }

        fclose(fp);
    }
    else
    {
        ret_val = ERR_UNKNOWN;
        RLOGD( "[PS]file \"%s\" not exist", buf_a);
    }

    /* Kill the process if it is pppd. */
    if( ERR_NONE == ret_val )
    {
        if( strstr(buf_a, pppd_path_ptr) )
        {
            snprintf( buf_a,
                      sizeof(buf_a) - 1,
                      "kill -9 %ld",
                      pid );
			RLOGD("[PS: stop_pppd] try to exec: %s", buf_a);
            ret_val = system(buf_a);
            if( ret_val != 0 )
            {
                RLOGD("[PS: stop_pppd] error(ret = %d) to exec: %s", ret_val, buf_a);
                ret_val = ERR_CALL_C_FUNC;
            }
            else
            {
                RLOGD("[PS: stop_pppd] setp ps_tty_state to free!");
                tty_info_st[0].m_ps_tty_state = TTY_STATE_FREE;
                ret_val = ERR_NONE;
            }
        }
        else
        {
	      RLOGD("[PS: stop_pppd ]pid %d is not ppp: %s", pid, buf_a);
        }
    }

    return ret_val;
}
 /*******************************************************************************

 * Function: start_pppd
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Start external program "pppd" to start ppp conversation.
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name              Type        In/Out  Description
 *     ----------------  ----------  ------  ----------------------------------
 *     cid               UINT8       In      id of the pdp
 *     pppd_device_ptr   char *      In      the device that pppd will use
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
static SINT32 start_pppd(UINT8 cid, char *pppd_device_ptr)
{
    //modified by mabin for Enh00000227
    SINT32      ret_val = ERR_NONE;
    struct stat stat_st;
    const char  *pppd_path_ptr = SYS_PROGRAM_PPPD;
    PDP_INFO_ST *pdp_info_ptr = NULL;
    char cid_a[4];
    LOG_FUNC();
	/*modify start by wangjinjin for PPPD start*/
    char        sys_cmd_a[512] = {0};
    char        pppd_cfg_file_a[16] = {0};
    char        chat_cfg_file_a[16] = {0};
    char        pppd_cfg_file_full_name_a[100] = {0};
    char        chat_cfg_file_full_name_a[100] = {0};
    char        write_data_a[100] = {0};
    const char  *chat_path_ptr = SYS_PROGRAM_CHAT;
    const char  *pppd_config_path_ptr = SYS_PROGRAM_PPPD_CFG_PATH;
    const char  *chat_config_path_ptr = SYS_PROGRAM_CHAT_CFG_PATH;

#if 1//0
    const char  *pppd_cfg_ptr =
        "noauth\n"
        "115200\n"
        "noccp\n"
        "nobsdcomp\n"
        "noaccomp\n"
        "nocrtscts\n"
        "nodeflate\n"
        "usepeerdns\n"
        "local\n"
        "linkname gprs\n"
        "novj\n"
        "user Linux\n"
        "lcp-max-configure 30\n"
        "ipcp-max-configure 50\n"
        //            "lcp-max-failure 30\n"
        //            "nocdtrcts\n"
        //            "defaultroute\n"
        //            "noipdefault\n"
        //            "ipcp-accept-local\n"
        //            "ipcp-accept-remote\n"
        //            "lock\n"
        "debug\n"
        "kdebug 7\n"
        "mru 1400\n"
        "mtu 1400\n";
    /* FIX L1809OG_Bug00001316 2011-05-12 zoufeng end */
#endif

    LOG_FUNC();
    RLOGD("[PS: start_pppd] ENTER start_pppd");

    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid( cid );
    if( !pdp_info_ptr )
    {
        RLOGD("[PS: start_pppd] Can not find pdp_info_ptr");
        ret_val = ERR_UNKNOWN;
    }

    /* Check parameter. */
    if( !pppd_device_ptr )
    {
        /* Error: invalid parameter. */
        RLOGD("[PS: start_pppd] ERR: INVALID_PARAM");
        return ERR_INVALID_PARAM;
    }

    /* Check if the pppd exists. */
    ret_val = stat(pppd_path_ptr, &stat_st);
    if( ret_val != ERR_NONE )
    {
        RLOGD("[PS: start_pppd] error to stat file: %s", pppd_path_ptr);
        ret_val = ERR_CALL_C_FUNC;
    }

	#if 0 //0
	   /* Check if the path of pppd config file exists. */
    if( ERR_NONE == ret_val )
    {
        ret_val = stat(pppd_config_path_ptr, &stat_st);
        if( ret_val != 0 && ENOENT == errno )
        {
            /* Try to make the directory. */
            ret_val = mkdir(pppd_config_path_ptr, S_IRWXU|S_IRWXG|S_IRWXO);
            RLOGD("[PS: start_pppd] mkdir %s", pppd_config_path_ptr);
            if( ret_val != 0 )
            {
                RLOGD("[PS: start_pppd] error to make path: %s", pppd_config_path_ptr);
                ret_val = ERR_CALL_C_FUNC;
            }
        }
        else if( ret_val != 0 )
        {
            RLOGD("[PS: start_pppd] error to stat path: %s", pppd_config_path_ptr);
            ret_val = ERR_CALL_C_FUNC;
        }
    }

	/* Create the config file for pppd. */
    if( ERR_NONE == ret_val )
    {
        int fd = 0;

        snprintf( pppd_cfg_file_a,
                  sizeof(pppd_cfg_file_a) - 1,
                  "provider_%d",
                  cid );

        snprintf( pppd_cfg_file_full_name_a,
                  sizeof(pppd_cfg_file_full_name_a) - 1,
                  "%s/%s",
                  pppd_config_path_ptr,
                  pppd_cfg_file_a );
        RLOGD("[PS: start_pppd] pppd cfg file: %s", pppd_cfg_file_full_name_a);
        fd = open( pppd_cfg_file_full_name_a,
                   (O_WRONLY | O_CREAT | O_TRUNC),
                   (S_IRWXU | S_IRWXG | S_IRWXO) );

        if( fd < 0 )
        {
            LOG_SYS_ERR("open");
			RLOGD( "[PS: start_pppd] open %s ERROR!!!!",pppd_cfg_file_full_name_a);
            ret_val = ERR_CALL_C_FUNC;
        }

        /* Write unit. */
        if( ERR_NONE == ret_val )
        {
            if( 0 == cid )
            {
                RLOGD( "[PS: start_pppd] cid = 0");
            }

            snprintf( write_data_a,
                    sizeof(write_data_a) - 1,
                    "%s\n",
                    pppd_device_ptr);
            RLOGD("[PS: start_pppd] PPP device name: %s", pppd_device_ptr);

            ret_val = write(fd, write_data_a, strlen(write_data_a));
            if( ret_val != (int)strlen(write_data_a) )
            {
                LOG_SYS_ERR("write");
                ret_val = ERR_CALL_C_FUNC;
            }
            else
            {
                ret_val = ERR_NONE;
            }
        }

        if( ERR_NONE == ret_val )
        {
            ret_val = write(fd, pppd_cfg_ptr, strlen(pppd_cfg_ptr));
            if( ret_val != (int)strlen(pppd_cfg_ptr) )
            {
                LOG_SYS_ERR("write");
                ret_val = ERR_CALL_C_FUNC;
            }
            else
            {
                ret_val = ERR_NONE;
            }
        }

        if(fd > 0) close(fd);
    }
#endif

    /* Try to start the pppd in child process */
    if( ERR_NONE == ret_val )
    {

        snprintf( sys_cmd_a,
                  sizeof(sys_cmd_a) - 1,
                  "%s call %s &",
                  pppd_path_ptr,
                  "provider_1" );
        RLOGD("[PS: start_pppd] try to exec: %s",sys_cmd_a);
	    RLOGD("[PS: start_pppd] before star pppd,we sleep 5 seconds here!!!");
	    sleep(5);
	    RLOGD("[PS: start_pppd] after 5 seconds,we are wake up!now we start the pppd !!!");
        ret_val = system(sys_cmd_a);

		 if( -1 == ret_val ){
            RLOGD("[PS: start_pppd] ERR to exec=%s. ",sys_cmd_a);
            ret_val = ERR_CALL_C_FUNC;
        }else{
            RLOGD("[PS: start_pppd] exit status value = 0x%x",ret_val);
            if (WIFEXITED(ret_val)){
                if (0 == WEXITSTATUS(ret_val)){
                    RLOGD("[PS: start_pppd]OK to exec=%s.",sys_cmd_a);
                    ret_val = ERR_NONE;
                }else{
                    RLOGD("[PS: start_pppd]run shell script fail, script exit code: %d\n", WEXITSTATUS(ret_val));
                    ret_val = ERR_CALL_C_FUNC;
                }
            }else{
                RLOGD("[PS: start_pppd]phase 2 faile. exit status = [%d]\n", WEXITSTATUS(ret_val));
                ret_val = ERR_CALL_C_FUNC;
            }
        }
    	}
    /*modify end by wangjinjin for PPPD start*/
    return ret_val;
}


/*******************************************************************************
 * Function: check_ppp_device
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Check if a ppp device is ready.
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name            Type            In/Out  Description
 *     --------------  --------------  ------  --------------------------------
 *     pdp_info_ptr    PDP_INFO_ST *   In      pdp info
 *
 * Return:
 * ----------------------------
 *     ERR_NONE: the PPP device is ready.
 *     (other) : error code
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
static SINT32 check_ppp_device( PDP_INFO_ST *pdp_info_ptr )
{
    SINT32  ret_val = ERR_NONE;
    UINT8   count = 0;
    UINT32  i = 0;
    UINT8   j = 0;
    char    ppp_name_a[10] = {0};
    int     fd = -1;
    struct ifreq    buf[10];
    struct ifconf   ifc;

    LOG_FUNC();

    /* Check parameter. */
    if( !pdp_info_ptr || 0 == pdp_info_ptr->pdp_cid )
    {
        /* Error: invalid parameter. */
	    RLOGD("[PS: check_ppp_device] ERR_INVALID_PARAM");
        return ERR_INVALID_PARAM;
    }

    snprintf( ppp_name_a,
              sizeof(ppp_name_a) - 1,
              "ppp%d",
              (pdp_info_ptr->pdp_cid > 0) ? (pdp_info_ptr->pdp_cid - 1) : pdp_info_ptr->pdp_cid );

    /* The link maybe disconnected when we check the ppp
     * device, so we must check the m_ps_pty_idx here.
     *     AT+CGDATA=...
     *     -> CONNECT
     *     -> checking ppp device 1
     *     -> checking ppp device 2
     *     -> ...
     *     -> link disconnected
     *     -> m_ps_pty_idx will be free
     *     -> exit checking, and return ERROR to user
     */

    ret_val = ERR_NOT_FOUND;
    for( i=0; i<CHECK_PPP_DEVICE_TIMER && !ata_ps_is_ps_switch(); i++ )
    {
        if( ERR_NONE == ret_val
            || 0 == pdp_info_ptr->pdp_cid )
        {
			RLOGD("PS:check_ppp_device CHECK_PPP_DEVICE_TIMER break");
			//wait 10s to next times pdp active
			sleep(10);
			break;
        }

        if( 0 == strlen(pdp_info_ptr->pdp_network_info.ipv4_addr) )
        {
            RLOGD("[PS:check_ppp_device] (%d/%d)checking PPP device %s ... (waiting for IP address of +CGEV)",
                   (i+1), CHECK_PPP_DEVICE_TIMER, ppp_name_a);
            usleep(300*1000);
            continue;
        }

        RLOGD("[PS: check_ppp_device] (%d/%d)checking PPP device %s ,addr %s...",
                (i+1), CHECK_PPP_DEVICE_TIMER, 
                ppp_name_a, 
                pdp_info_ptr->pdp_network_info.ipv4_addr);
        fd = socket(AF_INET, SOCK_DGRAM, 0);
        if( fd >= 0 )
        {
            ifc.ifc_len = sizeof(buf);
            ifc.ifc_buf = (caddr_t)buf;
            if( !ioctl(fd, SIOCGIFCONF, (char *)&ifc) )
            {
                count = ifc.ifc_len / sizeof(struct ifreq);

                for( j=0; j<count; j++ )
                {
                    if( !strcmp(ppp_name_a, buf[j].ifr_name) )
                    {
                        usleep(50000);  //leadcore: add by lifenghua for pdp deactived several times 2010.12.06
                        /** Leadcore: Modify for fix bug00001594, can not receiving mms when beijing external test by lifenghua 20110410 begin**/
                        ret_val = set_dns_info(pdp_info_ptr, ppp_name_a);
                        //ret_val = ERR_NONE;
                        /** Leadcore: Fix bug00001594 end **/
                        break;
                    }
                }
            }
            else
            {
                close(fd);
                LOG_SYS_ERR( "ioctl" );
                break;
            }

            close(fd);
        }
        else
        {
            LOG_SYS_ERR( "socket" );
            break;
        }

        if( ERR_NONE == ret_val
            || 0 == pdp_info_ptr->pdp_cid )
        {
            break;
        }

	      usleep(100*1000);
    }

    if( ERR_NONE == ret_val )
    {

		RLOGD("[PS: check_ppp_device] checking PPP device result: (%s)OK", ppp_name_a);
	    memcpy(pdp_info_ptr->ifname, ppp_name_a, strlen(ppp_name_a));
    }
    else
    {		
    	/*add start to get the pppd pid*/
    	char  buf[40];
    	FILE *fp = popen("pgrep pppd" , "r");
		if(NULL == fp)
		{
			RLOGD("[PS: check_ppp_device]ERR to exec command \"pgrep pppd\" . ");
		}
		else
		{
			fgets(buf,sizeof(buf),fp);
            RLOGD("[PS: check_ppp_device] get the pppd pid:%s",buf);
    		pdp_info_ptr->ppp_pid = atoi(buf);
		}
				
	    RLOGD("[PS]checking PPP device get pppd pid: %d",pdp_info_ptr->ppp_pid);
	    /*add end by wangjinjin to get the pppd pid*/
        RLOGD("[PS]checking PPP device result: (%s)fail", ppp_name_a);
    }
	
    return ret_val;
}

/*******************************************************************************
 * Function: get_pppd_pid
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Get the PID of PPPD according to the PDP cid.
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name            Type      In/Out  Description
 *     --------------  --------  ------  --------------------------------------
 *     cid             UINT8     In      cid of the PDP
 *
 * Return:
 * ----------------------------
 *     PID of the pppd.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
static UINT32 get_pppd_pid( UINT8 cid )
{
    UINT32  pid = 0;
    FILE    *fp = NULL;
    char    ch;
    char    buf_a[40] = {0};
    const char  *pppd_pid_path_ptr = SYS_PROGRAM_PPPD_PID_PATH;

#ifdef OPT_ENABLE_LC_ATA_CONFIG
    if( strlen(lc_ata_cfg_st.m_pppd_pid_path_a) > 0 )
    {
        pppd_pid_path_ptr = (lc_ata_cfg_st.m_pppd_pid_path_a);
    }
#endif
RLOGD("[PS][get_pppd_pid]  cid is :%d",cid);
    if( cid < 1 )
    {
        LOG_ERR( ERR_INVALID_PARAM );
        return 0;
    }

    memset( buf_a, 0x00, sizeof(buf_a) );
#if 0
    /* Try to get the process id of the ppp device. */
    snprintf( buf_a,
              sizeof(buf_a) - 1,
              "%s/ppp%d.pid",
              pppd_pid_path_ptr,
              cid - 1 );
    LOG_INFO(("[PS]try to get pid from file \"%s\"", buf_a));
	RLOGD("[PS]try to get pid from file \"%s\"", buf_a);
    fp = fopen(buf_a, "r");
    if( fp )
    {
        ch = getc(fp);
        while( '0' <= ch && ch <= '9' )
        {
            pid = (pid * 10) + (ch - '0');
            ch = getc(fp);
        }

        fclose(fp);
    }
    else
    {
        pid = 0;
		RLOGD("[PS]file \"%s\" not exist", buf_a);
    }
#endif
	char  buf[40];
	fp=popen("pgrep pppd" , "r");
	if(NULL == fp)
	{
		RLOGD("[PS: check_ppp_device]ERR to exec command \"pgrep pppd\" . ");
	}
	else{
		fgets(buf,sizeof(buf),fp);
		RLOGD("[PS: check_ppp_device] get the pppd pid:%s",buf);
		pid = atoi(buf);
	}

    if( pid > 0 )
    {
        UINT8   i = 0;

        for( i=0; i<PDP_MAX_COUNT; i++ )
        {
            if( pid == pdp_info_st[i].ppp_pid )
            {
                RLOGD( ("[PS]pid %ld to be killed is valid", pid) );
                pid = 0;
                break;
            }
        }
    }
    
    RLOGD("[PS]get pid: %ld", pid);
    return pid;
}

/*******************************************************************************
 * Function: start_ppp_with_device
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Start a PPP conversation which use a MUX device.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name          Type             In/Out  Description
 *     ------------  ---------------  ------  ---------------------------------
 *     cid           UINT8            In      pdp cid
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static SINT32 start_ppp_with_device(UINT8 cid)
{
    SINT32          ret_val = ERR_NONE;
    SINT32          tmp_ret_val = ERR_NONE;
    PDP_INFO_ST     *pdp_info_ptr = NULL;
    char            *pppd_device_ptr = NULL;			
    UINT8           old_pdp_state = PS_STATE_FREE;
	UINT8 index;

    LOG_FUNC();
    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(cid);
	RLOGD("======YAYA after get_pdp_info_by_cid\n");
    if( !pdp_info_ptr )
    {
		RLOGD("[PS:start_ppp_with_device] Can not get pdp info by cid: %d", cid);
        return ERR_INVALID_PARAM;
    }
    pppd_device_ptr = tty_info_st[0].m_ps_tty_name;
    RLOGD("[PS: start_ppp_with_device] pppd_device_ptr is %s", pppd_device_ptr);

    old_pdp_state = pdp_info_ptr->pdp_state;
    pdp_info_ptr->pdp_state = PS_STATE_PPP_ACTIVATING;

    RLOGD("[PS: start_ppp_with_device] try to mapping PPP device: %s <-> ppp%d", pppd_device_ptr, (cid > 0) ? (cid - 1): cid);

    /* Note:
     *     Please pay attention to the flow. It must be:
     *         1. Create the ptm <-> pts.
     *         2. Start pppd(pppd will use the pts to send/receive data).
     *         3. Start the thread to read data from pppd.
     *     If the pppd start after the read thread, it will be blocked at:
     *         if (ioctl(tty_fd, TIOCSETD, &ppp_disc) < 0)
     *     when it try to establish the link.
     */
     
    /* Start pppd. */
    if( ERR_NONE == ret_val )
    {
        ret_val = start_pppd(cid, pppd_device_ptr);
    }
    
    if( ERR_NONE == ret_val )
    {
        /* Waiting for the result of pppd. */
        ret_val = check_ppp_device(pdp_info_ptr);
		RLOGD("[PS: start_ppp_with_device] [check_ppp_device]:ret_val = %d", ret_val);
    }
    if( ERR_NONE == ret_val )
    {
         RLOGD("[PS: start_ppp_with_device] pdp_info_ptr->pdp_state is %d", pdp_info_ptr->pdp_state);
		pdp_info_ptr->pdp_state = PS_STATE_PPP_ACTIVATED;
    }
    else
    {

        tmp_ret_val = stop_pppd( pdp_info_ptr );
		tty_info_st[0].m_ps_tty_state = TTY_STATE_FREE;
        if( pdp_info_ptr->pdp_cid > 0 )
        {
            pdp_info_ptr->pdp_state = old_pdp_state;
        }
    }

    return ret_val;
}

static SINT32 set_dns_info( PDP_INFO_ST *pdp_info_ptr, const char * ppp_device_name_ptr )
{
    SINT32  ret_val = ERR_NONE;
    FILE    *fp = NULL;
    UINT8   line = 0;
    BOOL    is_end = 0;
    UINT32    data_len=0;
    char    buf_a[50];
    char    *param_ptr = NULL;
    char    *value_ptr = NULL;
    char    dns_info_file_a[20] = {0};
    char    sys_cmd[40] = {0};

    LOG_FUNC();

    /* Check parameter. */
    if( !pdp_info_ptr || !ppp_device_name_ptr )
    {
        /* Error: invalid parameter. */
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    snprintf( dns_info_file_a,
            sizeof(dns_info_file_a) - 1,
            "/tmp/%s.tmp",
            ppp_device_name_ptr );
    usleep(80000);  //add for pdp deactived several times 

    fp = fopen(dns_info_file_a, "r");
    if(fp)
    {
        while(!is_end && line < 20)
        {
            ret_val = cfg_get_line( fp, buf_a, sizeof(buf_a), 
                                        &data_len, &is_end);
            if( ERR_NONE == ret_val )
            {
                ret_val = cfg_get_param_and_value(buf_a, &param_ptr, &value_ptr);
            }
            if( ERR_NONE == ret_val
                && param_ptr && strlen(param_ptr) > 0
                && value_ptr && strlen(value_ptr) > 0 )
            {
                if( 0 == strcmp(param_ptr, "DNS1") )
                {
                    strncpy(pdp_info_ptr->pdp_network_info.ipv4_dns1,
                            value_ptr,
                            sizeof(pdp_info_ptr->pdp_network_info.ipv4_dns1) - 1 );
			        RLOGD("[cfg]got DNS1: %s", value_ptr);
                }
                else if( 0 == strcmp(param_ptr, "DNS2") )
                {
                    strncpy(pdp_info_ptr->pdp_network_info.ipv4_dns2, 
                            value_ptr,
                            sizeof(pdp_info_ptr->pdp_network_info.ipv4_dns2) - 1 );
			        RLOGD("[cfg]got DNS2: %s", value_ptr);
                }
                else if( 0 == strcmp(param_ptr, "IPLOCAL") )
                {
                    if( STRNCMPI(pdp_info_ptr->pdp_network_info.ipv4_addr, 
                                 value_ptr, 
                                 strlen(pdp_info_ptr->pdp_network_info.ipv4_addr)) != 0 )
                    {

			            RLOGD("IP mismatch: %s(+CGEV) != %s(ip-up)", 
                        pdp_info_ptr->pdp_network_info.ipv4_addr, 
                        value_ptr);
                    }
                }
                else if( 0 == strcmp(param_ptr, "PPPD_PID") )
                {
                    pdp_info_ptr->ppp_pid = atoi(value_ptr);
                    if( pdp_info_ptr->ppp_pid != 0 )
                    {
			            RLOGD("[cfg]got pid: %ld", pdp_info_ptr->ppp_pid);
                    }
                    else
                    {
				        RLOGD("[cfg]got pid: error(= %s)", value_ptr);
                    }
                }
            }

            line++;
        }

        fclose(fp);

        ret_val = ERR_NONE;
    }
    else
    {
        RLOGD("fail to open file: %s", dns_info_file_a);
        ret_val = ERR_CALL_C_FUNC;
    }
    if( ERR_NONE == ret_val )
    {
        snprintf( sys_cmd,
                  sizeof(sys_cmd) - 1,
                  "rm %s",
                  dns_info_file_a );
        RLOGD("[PS: start_pppd] try to exec: %s",sys_cmd);
        ret_val = system(sys_cmd);
        if( ret_val != 0 )
        {
	     RLOGD("[PS: start_pppd] error to exec: %s", sys_cmd);
            ret_val = ERR_CALL_C_FUNC;
        }
    }
/* Leadcore Add End */
    return ret_val;
}


/*******************************************************************************
 * Function: clean_pppd_device_data
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     If there is any data in a device, clean it(by call read).
 *
 * Used variables:
 * ----------------------------
 *     (None)
 *
 * Params:
 * ----------------------------
 *     Name              Type        In/Out  Description
 *     ----------------  ----------  ------  ----------------------------------
 *     fd                int          In    the file descriptor that to be cleaned
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (None)
 *
 ******************************************************************************/
static SINT32 clean_pppd_device_data(int fd)
{
    SINT32          ret_val = ERR_NONE;
    fd_set          read_fds;
    struct timeval  tv;
    UINT8           buf_a[100];
    int             read_len = 0;

    LOG_FUNC();
    if( fd > 0 )
    {
//        ret_val = pub_util_set_fd_mode( fd, 1 );
//        if( ERR_NONE == ret_val )
//        {
//            read_len = 1;
//            while(read_len > 0)
//            {
//                read_len = read( fd, buf_a, sizeof(buf_a) );
//            }
//        }

        tv.tv_sec = 0;
        tv.tv_usec = 0;
        while(1)
        {
            FD_ZERO(&read_fds);
            FD_SET(fd, &read_fds);

	        ret_val = select(fd+1, &read_fds, NULL, NULL, &tv);
            if( ret_val < 0 )
            {
                LOG_SYS_ERR( "select" );
                break;
            }
            else if( 0 == ret_val )
            {
                LOG_INFO( ( "nothing to be read") );
                break;
            }
            else if( FD_ISSET(fd, &read_fds) )
            {
                read_len = read( fd, buf_a, sizeof(buf_a) );
                if( read_len <= 0 )
                {
                    break;
                }
            }
            else
            {
                break;
            }
        }
        RLOGD("[PS: clean_pppd_device_data] send an AT for testing whether the device is ready or not");
        //fixed by mabin for memory access violation attempt.
        memset(buf_a, 0, 100);
        snprintf(buf_a, sizeof(buf_a) - 1, "AT^DSVER");
        strcat(buf_a,"\r");
        ret_val = write(fd, buf_a, strlen(buf_a));
        RLOGD("[PS: clean_pppd_device_data] ret_val of write DTEST is %d, length of buffer is %d",ret_val,(int)strlen(buf_a));
        if( ret_val != (int)strlen(buf_a) ){
            RLOGD("[PS: clean_pppd_device_data] write fd failed");
            RLOGD("[PS:fail to write AT^DTEST,%d,%s", errno, strerror(errno));

            return ERR_CALL_C_FUNC;
        }

        tv.tv_sec = 1;
        tv.tv_usec = 0;
        FD_ZERO(&read_fds);
        FD_SET(fd, &read_fds);
        ret_val = select(fd+1, &read_fds, NULL, NULL, &tv);

        if( ret_val < 0 )
        {
            LOG_SYS_ERR( "select" );
            return ERR_CALL_C_FUNC;
        }
        else if( 0 == ret_val ) //select time out
        {
            LOG_INFO( ( "nothing to be read") );
            return ERR_UNKNOWN;
        }
        else if( FD_ISSET(fd, &read_fds) )
        {
            read_len = read( fd, buf_a, sizeof(buf_a) );
            if( read_len <= 0 )
            {
                 RLOGD("[PS: clean_pppd_device_data] read fd failed");
                return ERR_UNKNOWN;
            }
            int k=0;
            for(k=0; k< read_len;k++)
            {
                RLOGD("__buf_a[%d] = %c",k,buf_a[k]);
            }
        }
    }
    else
    {
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    return ERR_NONE;
}



static SINT32 start_pdp_with_device(UINT8 cid)
{
    SINT32          ret_val = ERR_NONE;
    PDP_INFO_ST     *pdp_info_ptr = NULL;
    UINT8           old_pdp_state = PS_STATE_FREE;
    SINT32          cme_err = CME_ERROR_NONE;
    SINT32      tmp_ret_val = ERR_NONE;
    char            *pppd_device_ptr = NULL;
    char        write_data_a[100] = {0};
    char        m_buf_write[100] = {0};
    char        m_buf_read[AT_CMD_STR_MAX_LEN+1] = {0};
    UINT8 index;
    UINT32    i = 0;
    int err;
    char *cmd;
    BOOL    ret_val_tmp = FALSE;
    TTY_INFO_ST  *pdp_tty_ptr = NULL;
    LOG_FUNC();
    int fd = -1;
    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid(cid);
    if( !pdp_info_ptr )
    {
        RLOGD("Can not get pdp info by cid: %d", cid);
        return ERR_INVALID_PARAM;
    }

    old_pdp_state = pdp_info_ptr->pdp_state;
    pdp_info_ptr->pdp_state = PS_STATE_PDP_ACTIVATING;
    pdp_tty_ptr = get_idle_tty();

    if (!pdp_tty_ptr)
    {
        RLOGD("Can not get pppd_device_ptr");
        return ERR_INVALID_PARAM;  
    }
	
    pppd_device_ptr = pdp_tty_ptr->m_ps_tty_name;
    RLOGD("pppd_device_ptr is %s",pppd_device_ptr);
    index = get_idle_tty_index(pppd_device_ptr);
	
    RLOGD("after get_idle_tty_index %d\n",  pdp_info_ptr->ps_tty_idx);
		
     if( !pppd_device_ptr)
    {
         RLOGD("can not find pppd_device-ptr");
         ret_val = ERR_UNKNOWN;
    }
/*
    int retry_count = 0;
    do
    {
        fd = open( pppd_device_ptr, O_RDWR| O_NONBLOCK );
        RLOGD("====pppd_device_ptr is %s",pppd_device_ptr);
        RLOGD("fd is %d", fd);
        if (fd > 0)
        {
            if ((ret_val = clean_pppd_device_data(fd)) == ERR_NONE)
            {
                break;
            }
        }
        retry_count ++;       
        RLOGD("can not open pppd_device-ptr or clean device failed, retry count = %d", retry_count);

        if (fd > 0)
        {
            close(fd);
            fd = -1;
        }
        usleep(500 * 1000);
    } while(ret_val != ERR_NONE && retry_count < 10);

    if (fd > 0)
    {
        close(fd);
    }

    sleep(1);
    retry_count = 0;
    fd = -1;
    if(ERR_NONE == ret_val) 
    {   do {
          fd = open( pppd_device_ptr, O_RDWR | O_NONBLOCK);
          if(fd > 0) {
            break;
          } else {
            usleep(500 * 1000);
          }
       } while(ret_val != ERR_NONE && retry_count < 10);
       
        snprintf( m_buf_write, sizeof(m_buf_write) - 1, "AT^DLKS=0");
        strcat(m_buf_write,"\r");      
        ret_val = write(fd, m_buf_write, strlen(m_buf_write));
        if( ret_val != (int)strlen(m_buf_write) )
        {
            RLOGD("write AT^DLKS=0 failed");
            LOG_SYS_ERR("write");
            memset( m_buf_write, 0, strlen(m_buf_write));
            close(fd);
            ret_val = ERR_CALL_C_FUNC;
            tty_info_st[index].m_ps_tty_state = TTY_STATE_FREE;
            return ret_val;
        }
        else
        {
            ret_val = ERR_NONE;
            memset( m_buf_write, 0, strlen(m_buf_write));
            RLOGD("AT^DLKS=0 ===ret_val = ERR_NONE ===");
        }
        usleep(20000);
        for (i = 0; i < CHECK_PPP_CONNECT_TIMER; i++) 
        {
            ret_val = read(fd, m_buf_read, AT_CMD_STR_MAX_LEN); 
            RLOGD("DLKS RESULT read time = %d, ret = ",i, ret_val);
            if(ret_val > 0) 
            {
            	int k=0;
            	for(k=0; k< ret_val;k++) 
            	{
            		RLOGD("____m_buf_read[%d] = %c",k,m_buf_read[k]);
            	}                               
            }
            if( strstr(m_buf_read, "OK") )
            {
                // Stop the timer.
                RLOGD("[PS: start_pdp_with_device] ==strstr(m_buf_read, OK)====");
                memset( m_buf_read, 0, strlen(m_buf_read));
                ret_val = ERR_NONE;
                ret_val_tmp = TRUE;
                break;
            }
            usleep(200*1000);
        }
        if (!ret_val_tmp)  
        {
            if (fd >0)
            {
                close(fd);
                tty_info_st[index].m_ps_tty_state = TTY_STATE_FREE;
            }
            ret_val = ERR_UNKNOWN;		 
        }
    }		
*/
    if( ERR_NONE == ret_val )
    {
        property_set("sys.ps.socat", "0");
        sleep(1);
		property_set("sys.ps.socat", "1");
        sleep(1);
		
        if( 0 == cid )
        {
            RLOGD( "cid = 0" );
        }
/*
		//wy add on 20220705 for pdp ATD test //start 
		asprintf(&cmd, "ATD*98*%d#", cid);
//		err = at_send_command(cmd, NULL);
		err = writeline (cmd, 2);

//		err = at_send_command_full_nolock(cmd, NO_RESULT,NULL, NULL,0, NULL, 2);
            if (err < 0 )
            {
                RLOGD("[RIL-PS][ps_prepare_ATD] +ATD*98*1# fail\n, err = %d", err);
				ret_val = ERR_UNKNOWN;
            }
		
		RLOGD("[wywywywywy]start_pdp_with_device command: at_send_command: %s", cmd);
		//wy add on 20220705 for pdp ATD test //end
*/
		int retry_count = 0;

		do {
          fd = open( pppd_device_ptr, O_RDWR | O_NONBLOCK);
          if(fd > 0) {
            break;
          } else {
            usleep(500 * 1000);
          }
       } while(ret_val != ERR_NONE && retry_count < 10);


        //snprintf( m_buf_write, sizeof(m_buf_write) - 1, "ATD*98*%d#",cid );
        snprintf( m_buf_write, sizeof(m_buf_write) - 1, "ATD*98*%d#\r\n",cid );	 
	   //int len = strlen(m_buf_write);
	   //m_buf_write[len-1] = 0x0a;
	   //m_buf_write[len-2] = 0x0d;
        //strcat(m_buf_write,"\r");
		//asprintf(m_buf_write,"1%s\r\n" , m_buf_write);
		//m_buf_write[0] = 1;
        
        usleep(100*1000);
        RLOGD("PPP command: %s,fd:%d", m_buf_write,fd);
	    RLOGD("write fd is %d", fd);
        ret_val = write(fd, m_buf_write, strlen(m_buf_write));
        if( ret_val != (int)strlen(m_buf_write) )
        {
            LOG_SYS_ERR("write");
            ret_val = ERR_CALL_C_FUNC;
			RLOGD(" ===ret_val = WRITE_ERROR ===");
        }
        else
        {
            ret_val = ERR_NONE;
            RLOGD(" ===ret_val = ERR_NONE ===");
        }
		
        ret_val = ERR_UNKNOWN;
        for (i = 0; i < 100; i++) 
        {
            usleep(20000);
			RLOGD("read fd is %d", fd);
            ret_val = read(fd, m_buf_read, AT_CMD_STR_MAX_LEN);
            RLOGD("ret_val: %d, %d - %s", ret_val, errno, strerror(errno));
            if(ret_val > 0)
            {
                int k=0;
                for(k=0; k< ret_val;k++) 
                {
                    RLOGD("____m_buf_read[%d] = %c",k,m_buf_read[k]);
                }                 
            }
            RLOGD("[PS]PPP command response: %s", m_buf_read);
	        if( strstr(m_buf_read, "CONNECT") )
            {
                // Stop the timer.
                RLOGD("==strstr(m_buf_read, CONNECT) ====");
                pdp_info_ptr->pdp_state = PS_STATE_PDP_ACTIVATED;
   	            pdp_info_ptr->ps_tty_idx = index;
   	            RLOGD("[PS: start_pdp_with_device]  the tty index is %d",pdp_info_ptr->ps_tty_idx);
                memset( m_buf_read, 0x00, strlen(m_buf_read));
     	        ret_val = ERR_NONE;
                break;
            }  
            
            if( strstr(m_buf_read, "\r\nNO CARRIER\r\n")
                || strstr(m_buf_read, "\r\nBUSY\r\n")
                || strstr(m_buf_read, "\r\nNO DIALTONE\r\n")
                || strstr(m_buf_read, "\r\nNO ANSWER\r\n")
                || strstr(m_buf_read, "\r\nNW CONGESTION\r\n")
                || strstr(m_buf_read, "+CME ERROR"))
            {
              // Stop the timer.
              memset( m_buf_read, 0, strlen(m_buf_read));
              ret_val = ERR_UNKNOWN;
              break;
            }
             usleep(100000);
        }

		pdp_info_ptr->pdp_state = PS_STATE_PDP_ACTIVATED;
		pdp_info_ptr->ps_tty_idx = index;
		RLOGD("[PS: start_pdp_with_device]	the tty index is %d",pdp_info_ptr->ps_tty_idx);

        if (fd >0)
        {
            close(fd);
		    //RLOGD("==Close /dev/TTYEMS04_s ====");
			RLOGD("==Close /dev/tt/ptstt ====");
        }       
    }	
    
    usleep(50000);

    if( ret_val != ERR_NONE )
    {
        if( pdp_info_ptr->pdp_cid > 0 )
        {
             pdp_info_ptr->pdp_state = old_pdp_state;
	         tty_info_st[index].m_ps_tty_state = TTY_STATE_FREE;
	         RLOGD("tty index is %d, state is %d", index,
                      tty_info_st[index].m_ps_tty_state);
        }
    }
    RLOGD(" ==start_pdp_with_device return ret_val(%d)====",ret_val);
    return ret_val;
}

static TTY_INFO_ST *get_idle_tty()
{
    UINT8       i = 0;
    UINT8       ps_tty_idx = 0;
    TTY_INFO_ST *tty_info_ptr = NULL;
    int tty_max_count = 1;
    LOG_FUNC();
    
	for(i  = 0;i < 1; i++)
	{
        	if( TTY_STATE_FREE == tty_info_st[i].m_ps_tty_state )
       	 {
           	 	tty_info_ptr = &tty_info_st[i];
           	 	ps_tty_idx = i;
            		break;
        	}
    	}

    if (tty_info_ptr && ps_tty_idx < tty_max_count) {
        tty_info_st[i].m_ps_tty_state = TTY_STATE_USED;
        RLOGD( "[PS] get_idle_tty get an idle tty info idx %d", ps_tty_idx );
    } else {
        RLOGD( "[PS] get_idle_tty can not find a free tty device!");
        tty_info_ptr = NULL;
    }    
    return tty_info_ptr;     
}

static UINT8 get_idle_tty_index(char *tty_device_name)
{
    UINT8 ps_tty_idx = 0;
    int i;
    char *dev_name;
	
    LOG_FUNC();
    for (i = 0; i < 1; i++)
    {
       dev_name = tty_info_st[i].m_ps_tty_name;
	if( strcmp(tty_device_name, dev_name) == 0 )
        {
            ps_tty_idx = i;
            break;
        }
    }
    return ps_tty_idx;
}



SINT32 ata_ps_start_pdp(UINT8 cid)
{
    SINT32      ret_val = ERR_NONE;
    ret_val = start_pdp_with_device(cid);
    return ret_val;
}

int speed_arr[] = {B115200, B38400, B19200, B9600, B4800, B2400, B1200, B300, B38400, B19200, B9600, B4800, B2400, B1200, B300,B4000000};

int name_arr[] = {115200, 38400, 19200, 9600, 4800, 2400, 1200, 300, 38400, 19200, 9600, 4800, 2400, 1200, 300,4000000};

void DisableEcho(int fd) {
         struct termios  ios;
         tcgetattr( fd, &ios );
         ios.c_lflag = 0;  /* disable ECHO, ICANON, etc... */
         tcsetattr( fd, TCSANOW, &ios );
         tcflush(fd, TCIFLUSH);
}

void set_speed(int fd, int speed) 
{
	int i;
	int status;
	struct termios Opt;

	tcgetattr(fd, &Opt);
		for (i=0; i < sizeof(speed_arr)/sizeof(int); i++) {
			if (speed == name_arr[i]) {
				tcflush(fd, TCIOFLUSH);
				cfsetispeed(&Opt, speed_arr[i]);
				cfsetospeed(&Opt, speed_arr[i]);
				status = tcsetattr(fd, TCSANOW, &Opt);
				if (status)
					RLOGD("[CNSS]set baud fail!");

				else
					tcflush(fd,TCIOFLUSH);
				break;
			} 
	}
	RLOGD("[CNSS]set baud success!");
}

SINT32 set_parity(int fd, int databits, int stopbits, int parity,int rts, int fax_or_s) 
{ 
	struct termios options; 

	if (tcgetattr(fd, &options)) {
		RLOGD("[BD]get attr fail");
		return -1;
	}
	options.c_cflag &= ~CSIZE; 
	switch (databits) { 
		case 7: 
		options.c_cflag |= CS7; 
		break;
		case 8: 
		options.c_cflag |= CS8;
		break; 
		default: 
		RLOGD("[BD]set databits fail"); 
		return -1; 
	}
	switch (parity) { 
		case 'n':
		case 'N': 
		options.c_cflag &= ~PARENB;    /* Clear parity enable */
		options.c_iflag &= ~INPCK;    /* Enable parity checking */ 
		break; 
		case 'o': 
		case 'O': 
		options.c_cflag |= (PARODD | PARENB);    /* odd parity*/ 
		options.c_iflag |= INPCK;        /* Disnable parity checking */ 
		break; 
		case 'e': 
		case 'E': 
		options.c_cflag |= PARENB;    /* Enable parity */ 
		options.c_cflag &= ~PARODD;    /* even parity*/ 
		options.c_iflag |= INPCK;    /* Disnable parity checking */
		break;
		case 'S': 
		case 's':    /*as no parity*/ 
		options.c_cflag &= ~PARENB;
		options.c_cflag &= ~CSTOPB;
		break; 
		default: 
		RLOGD("[BD]set parity fail "); 
		return -1; 
	} 

	switch (stopbits) { 
		case 1: 
		options.c_cflag &= ~CSTOPB; 
		break; 
		case 2: 
		options.c_cflag |= CSTOPB; 
		break;
		default: 
		RLOGD("[CNSS]set stopbits fail"); 
		return -1; 
	} 
	/* Set input parity option */ 
	if (parity != 'n') 
		options.c_iflag |= INPCK; 

	if(rts) {
		options.c_cflag |= CRTSCTS;/* enable the RTS/CTS flow control */
	} else {
		options.c_cflag &= ~CRTSCTS;
	}
	//zyh
	//options.c_iflag &= ~IXON;   /* disable start/stop output control */

	tcflush(fd, TCIFLUSH);
	options.c_cc[VTIME] = 150; /* timeout 15 seconds*/ 
	options.c_cc[VMIN] = 0; /* Update the options and do it NOW */
	//options.c_iflag = 0;
	//options.c_oflag = 0;
	//options.c_lflag = 0;
	if (tcsetattr(fd, TCSANOW, &options) != 0) {
		RLOGD("[CNSS]set attr fail!"); 
		return -1; 
	} 
	RLOGD("[CNSS]set parity success! ");
	return 0; 
}

SINT32 cfg_get_line( FILE *fp, char *buf_ptr, UINT32 buf_size, UINT32 *data_len_ptr, BOOL *is_end_ptr )
{
    SINT32  ret_val = 0;
    int     ch;
    UINT32  i = 0;

//    LOG_FUNC();

    if( !fp
        || !buf_ptr
        || !data_len_ptr
        || !is_end_ptr )
    {
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    *data_len_ptr = 0;
    *is_end_ptr = 0;
    memset( buf_ptr, 0x00, buf_size );

    i = 0;
    ch = getc(fp);
    while( 1 )
    {
        if ( '\n' == ch || EOF == ch )
        {
            if( EOF == ch )
            {
                *is_end_ptr = 1;
            }

            break;
        }
        else
        {
            if( i < buf_size )
            {
                buf_ptr[i] = (char )ch;
            }

            i++;
        }

        ch = getc(fp);
    }

    *data_len_ptr = strlen(buf_ptr);

    /* Remove the char '\r'. */
    if( *data_len_ptr > 0 )
    {
        while( '\r' == buf_ptr[*data_len_ptr-1] )
        {
            buf_ptr[*data_len_ptr-1] = 0x00;
            (*data_len_ptr)--;
        }
    }

    return ret_val;
}

SINT32 cfg_get_param_and_value(char *line_ptr, char **param_ptr, char **value_ptr )
{
    char    *p1 = NULL;
    char    *p2 = NULL;
    SINT32    ret_val = ERR_NONE;

//    LOG_FUNC();

    if( !line_ptr || !param_ptr || !value_ptr )
    {
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    while( ' ' == *line_ptr )
        line_ptr++;

    if( '#' == *line_ptr )
    {

        return ERR_NOT_FOUND;
    }

    p1 = strstr(line_ptr, "=");
    if( p1 )
    {
        *p1 = '\0';

        p2 = p1 + 1;
        p1--;

        while( ' ' == *p1 )
        {
            *p1 = '\0';
            p1--;
        }
        *param_ptr = line_ptr;

        while( ' ' == *p2 ) p2++;
        while( strlen(p2) > 0
               && ' ' == p2[strlen(p2)-1] )
        {
            p2[strlen(p2)-1] = '\0';
        }
        *value_ptr = p2;

    }
    else
    {
        ret_val = ERR_NOT_FOUND;
    }

    return ret_val;
}


#undef ATA_PS_IP_C
