/* //device/system/reference-ril/misc.c
**
** Copyright 2006, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#include "misc.h"



static int hexString2Code(const unsigned char *src, char *dst, int len);
static int gsm7bit2Ascii(const unsigned char *src, char *dst, int len);
static int ucs2ToUtf8(const unsigned char *src, char *dst, int len);
/** returns 1 if line starts with prefix, 0 if it does not */
int strStartsWith(const char *line, const char *prefix)
{
    for ( ; *line != '\0' && *prefix != '\0' ; line++, prefix++) {
        if (*line != *prefix) {
            return 0;
        }
    }

    return *prefix == '\0';
}



/* Get the encode type, refer to 3GPP 23.038 "5 CBS Data Coding Scheme" */
int getEncodeType(int dcs) {
    int code_type = CUSD_ENCODE_TYPE_UNKNOWN;

    if(dcs <= 16) {
        //0000xxxx and 00010000
        code_type = CUSD_ENCODE_TYPE_7BIT;
    } else if(dcs == 17) {
        //00010001
        code_type = CUSD_ENCODE_TYPE_16BIT;
    } else if((32 <= dcs) && (dcs <= 63)) {
        //00100000-00111111
        code_type = CUSD_ENCODE_TYPE_7BIT;
    } else if((64 <= dcs) && (dcs <= 127)) {
        if(dcs < 96) {
            //bit 5 is 0, text is uncompressed
            if((dcs & 0x0C)==0) {
                code_type = CUSD_ENCODE_TYPE_7BIT;
            } else if((dcs & 0x08) == 0) {
                code_type = CUSD_ENCODE_TYPE_8BIT;
            } else if((dcs & 0x04) == 0) {
                code_type = CUSD_ENCODE_TYPE_16BIT;
            }
        } else {
            //bit 5 is 1, text is compressed, refer to 23.042, not supported
            }
    } else if((128 <= dcs) && (dcs <= 143)) {
            //reserved, unknown encoding
    } else if((144 <= dcs) && (dcs <= 159)) {
            //with UDH, not supported now
    } else if((160 <= dcs) && (dcs <= 239)) {
            //reserved, unknown encoding
    } else if((240 <= dcs) && (dcs <= 243)) {
            code_type = CUSD_ENCODE_TYPE_7BIT;
    } else if((244 <= dcs) && (dcs <= 247)) {
            code_type = CUSD_ENCODE_TYPE_8BIT;
    }

    return code_type;
}

/* Convert HEX string to byte, e.g. "31" -> 0x31 */
static int hexString2Code(const unsigned char *src, char *dst, int len) {
    int i;
    int out_len = 0;

    if(!src || !dst) {
        return 0;
    }

    for(i=0; i<len/2; i++) {
        if((*src<='9') && (*(src+1)<='9')) {
            *dst++ = ((*src-'0') << 4) | (*(src+1)-'0');
        } else if((*src<='9') && (*(src+1)<='F')) {
            *dst++ = ((*src-'0') << 4) | (*(src+1)-'A'+10);
        } else if((*src<='F') && (*(src+1)<='9')) {
            *dst++ = ((*src-'A'+10) << 4) | (*(src+1)-'0');
        } else if((*src<='F') && (*(src+1)<='F')) {
            *dst++ = ((*src-'A'+10) << 4) | (*(src+1)-'A'+10);
        }
        src +=2;
        out_len++;
    }
    *dst = '\0';

    return out_len;
}

/* Convert GSM 7bit code to Ascii code. */
static int gsm7bit2Ascii(const unsigned char *src, char *dst, int len) {
    int len_src = len;
    int len_src_current = 0;
    int out_len = 0;
    int current_byte = 0;
    unsigned char next_byte = 0;

    if(!src || !dst) {
        return 0;
    }

    current_byte = 0;
    next_byte = 0;
    while(len_src_current < len_src) {
        *dst = ((*src << current_byte) | next_byte) & 0x7f;
        next_byte = *src >> (7-current_byte);
        dst++;
        out_len++;
        current_byte++;

        if(7 == current_byte) {
            *dst = next_byte;
            dst++;
            out_len++;
            current_byte = 0;
            next_byte = 0;
        }
        src++;
        len_src_current++;
    }
    *dst = '\0';

    return out_len;
}

/* Convert GSM 7bit code of HEX string to UTF8. */
int hexGsm7bit2Utf8(const unsigned char *src, char *dst, int len) {
    int     out_len = 0;
    char    data_7bit[MAX_UTF8_LENGTH];

    if(!src || !dst) {
        return 0;
    }

    out_len = hexString2Code(src, data_7bit, len);
    out_len = gsm7bit2Ascii((unsigned char *)data_7bit, dst, out_len);

    return out_len;
}

/* Convert GSM 8bit code of HEX string to UTF8. */
int hexGsm8bit2Utf8(const unsigned char *src, char* dst, int len) {
    int     out_len = 0;

    if(!src || !dst) {
        return 0;
    }

    out_len = hexString2Code(src, dst, len);

    return out_len;
}

/* Convert UCS2 code to UTF8. */
static int ucs2ToUtf8(const unsigned char *src, char *dst, int len) {
    int     i = 0;
    int     out_len = 0;

    if(!src || !dst) {
        return 0;
    }

    for(i=0; i<len/2; i++) {
        if((0x00 == *src) && (*(src+1) < 0x80)) {
            *dst++ = *(src+1);
            src += 2;
            out_len++;
            continue;
        } else if(*src < 0x08) {
            *dst++ = (char)(0xC0 | (char)(*src<<2) | (char)(*(src+1)>>6));
            *dst++ = (char)(0x80 | (*(src+1) & 0x3F));
            src += 2;
            out_len += 2;
            continue;
        } else {
            *dst++ = (char)(0xE0 | (char)(*src>>4));
            *dst++ = (char)(0x80 | (char)((*src & 0x0F) << 2) | (char)(*(src+1) >> 6));
            *dst++ = (char)(0x80 | (*(src+1) & 0x3F));
            src += 2;
            out_len += 3;
        }
    }
    *dst='\0';

    return out_len;
}

/* Convert UCS2 code of HEX string to UTF8. */
int hexUcs2ToUtf8(const unsigned char *src, char *dst, int len) {
    int     out_len = 0;
    char    data_ucs2[MAX_UTF8_LENGTH] = "";

    if(!src || !dst) {
        return 0;
    }

    out_len = hexString2Code(src, data_ucs2, len);
    if(out_len > 0) {
        out_len = ucs2ToUtf8((unsigned char *)data_ucs2, dst, out_len);
    }

    return out_len;
}
