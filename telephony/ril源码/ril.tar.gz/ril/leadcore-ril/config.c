/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : config.c
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#define CONFIG_C



/*---------------------------- include head file -----------------------------*/

#include "config.h"
#include <telephony/ril.h>

#define LOG_TAG                                 "RIL"
#include <utils/Log.h>



/*---------------------- external variable declaration -----------------------*/



/*----------------- external function prototype declaration ------------------*/



/*----------------------- file-local macro definition ------------------------*/



/*----------------- file-local constant and type definition ------------------*/



/*---------------- file-local function prototype declaration -----------------*/



/*--------------------- file-local variables definition ----------------------*/

RIL_CONFIG_ST   ril_config_st = {
    0,                                          /* m_rildCount */
    0,                                          /* m_simSlot */
    CARD_STATUS_UNKNOWN,                        /* m_cardStatus */
    CARD_TYPE_UNKNOWN,                          /* m_cardType */
    CARD_LOCALE_UNKNOWN,                        /* m_cardLocale */
    "",                                         /* m_cardID */
    RADIO_LC_ACT_UNKNOWN,                       /* m_rat */
    0,                                          /* m_actualRat */
    "",                                         /* m_ratDSTMEX */
    0,                                          /* m_enableCs */
    0,                                          /* m_enablePs */
    CARD_STATUS_UNKNOWN,                        /* m_otherCardStatus */
    CARD_LOCALE_UNKNOWN,                        /* m_otherCardLocale */
};

static const CONFIG_OPTION_ST   ril_config_option_a[] = {
    { "rild.count",             TYPE_INT,       &(ril_config_st.m_rildCount),       sizeof(int) },
    { "rild.simSlot",           TYPE_INT,       &(ril_config_st.m_simSlot),         sizeof(int) },
    { "rild.cardStatus",        TYPE_INT,       &(ril_config_st.m_cardStatus),      sizeof(int) },
    { "rild.cardType",          TYPE_INT,       &(ril_config_st.m_cardType),        sizeof(int) },
    { "rild.cardLocale",        TYPE_INT,       &(ril_config_st.m_cardLocale),      sizeof(int) },
    { "rild.cardID",            TYPE_STRING,    (ril_config_st.m_cardID),           sizeof(ril_config_st.m_cardID) },
    { "rild.rat",               TYPE_INT,       &(ril_config_st.m_rat),             sizeof(int) },
    { "rild.actualRat",         TYPE_INT,       &(ril_config_st.m_actualRat),       sizeof(int) },
    { "rild.rat.DSTMEX",        TYPE_STRING,    (ril_config_st.m_ratDSTMEX),        sizeof(ril_config_st.m_ratDSTMEX) },
    { "rild.cs",                TYPE_INT,       &(ril_config_st.m_enableCs),        sizeof(int) },
    { "rild.ps",                TYPE_INT,       &(ril_config_st.m_enablePs),        sizeof(int) },
    { "rild.cardStatus.other",  TYPE_INT,       &(ril_config_st.m_otherCardStatus), sizeof(int) },
    { "rild.cardLocale.other",  TYPE_INT,       &(ril_config_st.m_otherCardLocale), sizeof(int) },
};



/*--------------------------- function definition ----------------------------*/

/*******************************************************************************
 * Function: config_get_line
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Read a line data from a file.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name           Type           In/Out  Description
 *     -------------  -------------  ------  ----------------------------------
 *     fp             FILE *         In      file handle
 *     buf_ptr        char *         Out     buffer that storage the data
 *     buf_size       int            In      size of the buffer
 *     data_len_ptr   int *          Out     len of the data that read
 *     is_end_ptr     int *          Out     if get the end of the file
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     Note of the getc():
 *     If the integer value returned by getc() is stored into a variable of
 *     type char and then compared against the integer constant EOF, the
 *     comparison may never succeed, because sign-extension of a variable of
 *     type char on widening to integer is implementation-defined.
 *
 ******************************************************************************/
int config_get_line( FILE *fp, char *buf_ptr, int buf_size, int *data_len_ptr, int *is_end_ptr )
{
    int     ret_val = 0;
    int     ch;
    int     i = 0;

    if(NULL == fp || NULL == buf_ptr || NULL == data_len_ptr || NULL == is_end_ptr) {
        RLOGE("[RILD config]%s() invalid parameter: %d, %d, %d, %d", __func__, (NULL == fp), (NULL == buf_ptr), (NULL == data_len_ptr), (NULL == is_end_ptr));
        return -1;
    }

    *data_len_ptr = 0;
    *is_end_ptr = 0;
    memset( buf_ptr, 0x00, buf_size );

    i = 0;
    ch = getc(fp);
    while( 1 ) {
        if ( '\n' == ch || EOF == ch ) {
            if( EOF == ch ) {
                *is_end_ptr = 1;
            }

            break;
        } else {
            if( i < buf_size ) {
                buf_ptr[i] = (char )ch;
            }

            i++;
        }

        ch = getc(fp);
    }

    *data_len_ptr = strlen(buf_ptr);

    /* Remove the char '\r'. */
    if( *data_len_ptr > 0 ) {
        while( '\r' == buf_ptr[*data_len_ptr-1] ) {
            buf_ptr[*data_len_ptr-1] = 0x00;
            (*data_len_ptr)--;
        }
    }

    return ret_val;
}

/*******************************************************************************
 * Function: config_get_param_and_value
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the config file of system.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name           Type            In/Out  Description
 *     -------------  --------------  ------  ---------------------------------
 *     line_ptr       char *          In      data to parse
 *     param_ptr      char **         Out     name of the config
 *     value_ptr      char **         Out     value of the config
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     The data in "line_ptr" will be changed.
 *
 ******************************************************************************/
int config_get_param_and_value(char *line_ptr, char **param_ptr, char **value_ptr ) {
    char    *p1 = NULL;
    char    *p2 = NULL;
    int     ret_val = 0;

    if(NULL == line_ptr || NULL == param_ptr || NULL == value_ptr) {
        RLOGE("[RILD config]%s() invalid parameter: %d, %d, %d", __func__, (NULL == line_ptr), (NULL == param_ptr), (NULL == value_ptr));
        return -1;
    }

    while( ' ' == *line_ptr )
        line_ptr++;

    if( '#' == *line_ptr ) {
        return -1;
    }

    p1 = strstr(line_ptr, "=");
    if( p1 ) {
        *p1 = '\0';

        p2 = p1 + 1;
        p1--;

        while( ' ' == *p1 ) {
            *p1 = '\0';
            p1--;
        }
        *param_ptr = line_ptr;

        while( ' ' == *p2 ) p2++;
        while((p2 != NULL && strlen(p2) > 0)
            && ' ' == p2[strlen(p2)-1] ) {
            p2[strlen(p2)-1] = '\0';
        }
        *value_ptr = p2;
    }
    else {
        ret_val = -1;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: config_load_file
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the given config file.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name           Type                 In/Out  Description
 *     -------------  -------------------  ------  -----------------------------
 *     file_ptr       const char *         In      config file to be parsed
 *     configData     CONFIG_OPTION_ST *   Out     data to store the config value
 *     configCount    int                  Out     count of the data
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
int config_load_file(const char *file_ptr, const CONFIG_OPTION_ST *configData, int configCount) {
    int     is_end = 0;
    FILE    *fp = NULL;
    int     data_len=0;
    char    buf_a[256] = "";
    char    *param_ptr = NULL;
    char    *value_ptr = NULL;
    int     ret_val = 0;

    if(NULL == file_ptr || NULL == configData || configCount <= 0) {
        RLOGE("[RILD config]%s() invalid parameter: %d, %d, %d", __func__, (NULL == file_ptr), (NULL == configData), (configCount <= 0));
        return -1;
    }

    RLOGD("[RILD config]config file: \"%s\". %d", file_ptr, configCount);

    if((fp = fopen(file_ptr, "r")) != NULL) {
        while(!is_end) {
            ret_val = config_get_line(fp, buf_a, sizeof(buf_a), &data_len, &is_end);
            if(0 == ret_val) {
                ret_val = config_get_param_and_value(buf_a, &param_ptr, &value_ptr);

                if(0 == ret_val
                    && (param_ptr != NULL && strlen(param_ptr) > 0)
                    && (value_ptr != NULL && strlen(value_ptr) > 0)) {
                    int i = 0;
                    for(i=0; i<configCount; i++) {
                        if(0 == strcmp(configData[i].m_configName, param_ptr) && configData[i].m_value != NULL) {
                            switch(configData[i].m_valueType) {
                                case TYPE_INT:
                                    *((int *)(configData[i].m_value)) = atoi(value_ptr);
                                    RLOGI("[RILD config]%s = %d", configData[i].m_configName, *((int *)(configData[i].m_value)));
                                    break;

                                case TYPE_STRING:
                                    strncpy((char *)(configData[i].m_value), value_ptr, configData[i].m_valueSize-1);
                                    RLOGI("[RILD config]%s = %s", configData[i].m_configName, (char *)(configData[i].m_value));
                                    break;

                                default:
                                    RLOGE("[RILD config]unknown value type: %d", configData[i].m_valueType);
                                    break;
                            }

                            break;
                        }
                    }
                }
            }
        }

        fclose(fp);
        ret_val = 0;
    } else {
        RLOGE("[RILD config]Can not open file \"%s\": %d - %s", file_ptr, errno, strerror(errno));
        ret_val = -1;
    }

    return ret_val;
}

/*******************************************************************************
 * Function: ril_load_config
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the given config file.
 *
 * Used variables:
 * ----------------------------
 *     ril_config_st
 *     ril_config_option_a
 *
 * Params:
 * ----------------------------
 *     Name           Type                 In/Out  Description
 *     -------------  -------------------  ------  -----------------------------
 *     file_ptr       const char *         In      config file to be parsed
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
int ril_load_config(const char *file_ptr) {
    int retVal = config_load_file(file_ptr,
            ril_config_option_a,
            sizeof(ril_config_option_a)/sizeof(ril_config_option_a[0]));

    if(ril_config_st.m_rildCount > RILD_MAX_COUNT) {
        RLOGE("[RILD config]fatal error: invalid count of RILD: m_rildCount=%d(> %d)", ril_config_st.m_rildCount, RILD_MAX_COUNT);
        retVal = -1;
    }

    return retVal;
}



#undef CONFIG_C
