/* //device/system/reference-ril/reference-ril.c
**
** Copyright 2006, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

/******************************************************************************
*
 *          COPYRIGHT Leadcore Technology Co.,Ltd
 *
******************************************************************************/

/******************************************************************************
*
 * FileName :reference-ril.c
 * Version  : 1.0
 * Purpose  : implementation of leadcore ril
 * Authors  : 
 * Date     : 
 * Notes    :
******************************************************************************/
#include <telephony/ril_cdma_sms.h>
#include <telephony/librilutils.h>
#include <telephony/ril.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/cdefs.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <alloca.h>
#include "atchannel.h"
#include "at_tok.h"
#include "misc.h"
#include "config.h"
#include <getopt.h>
#include <sys/socket.h>
#include <cutils/sockets.h>
#include <termios.h>
#include <sys/system_properties.h>

#include "ata-ps.h"

#define LOG_TAG "XT_RIL_S"
#include <utils/Log.h>

static void *noopRemoveWarning( void *a ) { return a; }
#define RIL_UNUSED_PARM(a) noopRemoveWarning((void *)&(a));

//chenchi add for warning
//#include "cutils/properties.h"

#include <sys/queue.h>
#include <sys/un.h>
/* Module name, only used for log. */
#define LOG_MODULE_NAME                     "reference-ril"
#define PORT 8899

#define RESET_PROCESS_SIGNAL    12

//for test nick.
#define RILTEST
#define RILTEST3


//chenchi add
#include "stk.h"/* Leadcore: stk functions defination*/

#ifdef SUPPORT_CTA_TEST
//#include <cutils/properties.h>
extern int property_set(const char *key, const char *value);
extern int property_get(const char *key, char *value, const char *default_value);
char cta_property_value[2];

#define CTA_CHECK(func, data, datalen, t, id) \
property_get(id, cta_property_value, "");   \
if (cta_property_value[0] == '0')   \
    RIL_onRequestComplete(t, RIL_E_REQUEST_NOT_SUPPORTED, NULL, 0); \
else    \
    func(data, datalen, t);    \
cta_property_value[0] = '1';

#else

#define CTA_CHECK(func, data, datalen, t, id) \
func(data, datalen, t);

#endif
/*Leadcore: Fixed Bug00001323, 20110418, chengyuxin, Do not handle "CRING" when VT is incoming*/
#define CRING_TYPE_VOICE    "VOICE"
#define CRING_TYPE_SYNC     "SYNC"


#define MAX_AT_RESPONSE 0x1000




//MCC TEMP Define
#define WORKAROUND_ERRONEOUS_ANSWER 1  
/* Merge leadcore-android-4.0.1_r1 about ussd ,by gaofeng 02-20 begin */
//<UH, 2011-1-4, lifangdong, Add for USSD ./>
#define USSD_STRING_LENGH_MAX                   182
/*================USSD mode================*/
#define USSD_DISABLE_UNSOLICITED_RESULT_CODE    0
#define USSD_ENABLE_UNSOLICITED_RESULT_CODE     1
#define USSD_CANCEL_SESSION                        2
/*================USSD DCS==================*/
#define USSD_DCS_7_BIT                       0x0F  /*7bit default,no message class*/
#define USSD_DCS_8_BIT                       0x44  /* uncompressed, no message class,character set is 8bit*/
#define USSD_DCS_16_BIT                      0x48  /* uncompressed, no message class,character set is UCS2(16bit)  */
#define USSD_DCS_UNKNOWN                     0xff  /* unknown */
/* Merge leadcore-android-4.0.1_r1 about ussd ,by gaofeng 02-20 end */

#define PROPERTY_PERSIST_RADIO_LC_MASTER_CARD   "persist.radio.lc.master.card"

//add by nick for satellite mode.
#define PROPERTY_PERSIST_SYS_XT_MODEM_TYPE      "persist.sys.xt.modem.type"

#ifdef USE_TI_COMMANDS

// Enable a workaround
// 1) Make incoming call, do not answer
// 2) Hangup remote end
// Expected: call should disappear from CLCC line
// Actual: Call shows as "ACTIVE" before disappearing
#define WORKAROUND_ERRONEOUS_ANSWER 1

// Some varients of the TI stack do not support the +CGEV unsolicited
// response. However, they seem to send an unsolicited +CME ERROR: 150
#define WORKAROUND_FAKE_CGEV 1
#endif

#define PROP_VALUE_MAX  92
#define PROP_NAME_MAX   32

#ifdef VT_ENABLE
#define MAX_VTDCI_LENGTH 200 
#endif

#define SIGNAL_STRENGTH_GSM_START   0
#define SIGNAL_STRENGTH_TD_START   100
#define SIGNAL_STRENGTH_LTE_START   200
#define SIGNAL_STRENGTH_LTE_END   300
#define SIGNAL_STRENGTH_GSM_OFFSET   216
#define SIGNAL_STRENGTH_LTE_OFFSET   341     

typedef enum {
    SIM_ABSENT = 0,
    SIM_NOT_READY = 1,
    SIM_READY = 2, /* SIM_READY means the radio state is RADIO_STATE_SIM_READY */
    SIM_PIN = 3,
    SIM_PUK = 4,
    SIM_NETWORK_PERSONALIZATION = 5,
    SIM_BLOCKED = 6,/*9 add PERM_DISABLED*/
} SIM_Status; 


typedef enum {
    NETWORK_NOT_REGISTER = 0,
    NETWORK_REGISTER,
    NETWORK_SEARCHING,
    NETWORK_REGISTER_DENY,
    NETWORK_UNKNOWN,
    NETWORK_REGISTER_ROAMING
} RIL_NETWORK_STATE;

static BOOL fail_check_sim_status = FALSE;


static int is_first_power_on = 0;
static int is_unsol_dusimu = 0;


static int lastNetworktype = 0;   


#define RILD_SERVER_CREG_READY "rild.server.creg.ready"

typedef enum _Rild0StatEnum
{
    RILD0_RESTART = 0,
    RILD0_OFF,
    RILD0_ON_SEARCHING,
    RILD0_UNKNOWN,
}Rild0StatEnum;

/**
* indicating tag of a set of elementary files in 3G Phonebook, 
* e.g. a set of EFemails tag as 202. detail refer to 3GPP 31.102
*/
typedef enum _SCPBSSTORESTYPE
{
    STORES_ABBREVIATED_DIALING_NUMBERS = 192, //192
    STORES_INDEX_OF_ADMIN_PB = 193,//193
    STORES_EXTENSION_DATA = 194,//194
    STORES_NAME_ENTRY = 195,//195
    STORES_ADDITIONAL_NUMBERS = 196,//196
    STORES_CONTROLS_OF_PB = 197,//197
    STORES_GROUPINGS = 198,//198
    STORES_ADDITIONAL_NUMBER_ALPHA = 199,//199
    STORES_GROUPING_INFO_ALPHA = 200,//200
    STORES_UNIQUE_IDENTIFIER = 201,//201
    STORES_EMAIL_ADDRESS = 202,//202
}SCPBSSTORESTYPE;


typedef enum __ICC_SIM_IO_COMMAND {
    COMMAND_READ_BINARY = 0xb0,
    COMMAND_UPDATE_BINARY = 0xd6,
    COMMAND_READ_RECORD = 0xb2,
    COMMAND_UPDATE_RECORD = 0xdc,
    COMMAND_SEEK = 0xa2,
    COMMAND_GET_RESPONSE = 0xc0,
}ICC_SIM_IO_COMMAND;

#define EF_ICCID 0x2fe2


typedef struct {
    char *call_fail_code;
    int call_fail_num;
}CALL_FAIL_CAUSE;

#define CALL_ERROR_UNSPECIFIED 0xffff
CALL_FAIL_CAUSE call_fail_cause_map[]= {
    {"unassigned (unallocated) number", 1},                 //UNOBTAINABLE_NUMBER       = 1
    {"no error information", 16},                           //NO_ERROR_INFORMATION      = 16
    {"normal call clearing", 16},                           //NORMAL_CLEARING           = 16
    {"user busy", 17},                                      //USER_BUSY                 = 17
    {"User alerting,no answer", 19},                        //USER_ALERTING_NO_ANSWER   = 19
    {"number changed", 22},                                 //NUMBER_CHANGED            = 22
    {"response to STATUS ENQUIRY", 30},                     //STATUS_ENQUIRY            = 30
    {"normal, unspecified", 31},                            //NORMAL_UNSPECIFIED        = 31
    {"no circuit/channel available", 34},                   //NO_CIRCUIT_AVAIL          = 34
    {"temporary failure", 41},                              //TEMPORARY_FAILURE         = 41
    {"switching equipment congestion", 42},                 //SWITCHING_CONGESTION      = 42
    {"requested circuit/channel not available", 44},        //CHANNEL_NOT_AVAIL         = 44
    {"quality of service unavailable", 49},                 //QOS_NOT_AVAIL             = 49
    {"bearer capability not presently available", 58},      //BEARER_NOT_AVAIL          = 58
    {"ACM equal to or greater than ACMmax", 68},            //ACM_LIMIT_EXCEEDED        = 68
    {"BDN blocked", 240},                                   //CALL_BARRED               = 240
    {"FDN blocked", 241}                                    //FDN_BLOCKED               = 241
};


static int set_rild0_creg_stat(BOOL stat, Rild0StatEnum rild0_stat);
static int get_rild0_creg_stat(void);


static int is_pb_ready = 0;

static int recv_creg_rild_server(void);
static int deinit_rild_server(void);
static int deinit_rild_client(int rild_index);

static void onRequest (int request, void *data, size_t datalen, RIL_Token t);
static RIL_RadioState currentState();
static int onSupports (int requestCode);
static void onCancel (RIL_Token t);
static const char *getVersion();
static int isRadioOn();
static SIM_Status getSIMStatus();
static int getpuk2error();
static int getCardStatus(RIL_CardStatus_v6 **pp_card_status);
static void freeCardStatus(RIL_CardStatus_v6 *p_card_status);
static void getActiveDataLinkInfo();
static void setUeCapability(void);
static void setAudioTest(void);

int strrpl(char* s, char a, char b);
void requestPrintCardAbsentInfo();
void requestResetModem(void *p);
int onUnsolicitedDsci(char *line);
static void updateVoiceNetworkState();   

// request emergency number begin>
static void  getEmergencyNumber(void *param);
//add for request emergency number end>

static void requestQueryEventReport(void *param);

typedef void (*RIL_TIMER_EXPIRE_FUNC)(union sigval sv);
extern int ril_timer_create(timer_t *timer_id_ptr, RIL_TIMER_EXPIRE_FUNC expire_func, void *expire_para_ptr);
extern int ril_timer_stop(timer_t timer_id);
extern int ril_timer_delete(timer_t timer_id);
extern int ril_timer_start(timer_t timer_id, long interval);

extern SINT32 at_tok_parse_ext( SINT8 **string_ptr, char *type_ptr, ... );
extern SINT32 ata_unsolicited_at_cgev(unsigned char *begin_ptr);
extern void ata_unsolicited_at_pcd(unsigned char *begin_ptr);

extern const char * requestToString(int request);

extern void requestOrSendDataCallList(RIL_Token *t);
extern void requestResetModemCallback(const struct timeval *relativeTime);

extern void ata_ps_close_lmi_in_shutdown(int rilId);

extern void requestStkSendEnvelopeWithStatus(void *data, size_t datalen, RIL_Token t);

unsigned char char_to_hex( char char_data );//add 7bit_to_ascii 

/*** Static Variables ***/
static const RIL_RadioFunctions s_callbacks = {
    RIL_VERSION,
    onRequest,
    currentState,
    onSupports,
    onCancel,
    getVersion
};




#ifdef RIL_SHLIB
static const struct RIL_Env *s_rilenv;

#define RIL_onRequestComplete(t, e, response, responselen) s_rilenv->OnRequestComplete(t,e, response, responselen)
#define RIL_onUnsolicitedResponse(a,b,c) s_rilenv->OnUnsolicitedResponse(a,b,c)
#define RIL_requestTimedCallback(a,b,c) s_rilenv->RequestTimedCallback(a,b,c)
#endif


static int switchModemUnsolicitedCode(int isOn);

/*
*  add these macros for ouput debug info.
*/
#define DB_RIL 1
#define DBBD(l,s) {if (l) s;}

#define RADIO_TURN_OFF 0
#define RADIO_TURN_ON 1
#define RADIO_POWER_UNKNOW 2

static RIL_RadioState sState = RADIO_STATE_UNAVAILABLE;

static SIM_Status sSimState = SIM_NOT_READY;

#define RESET_SIM_ABSENT  0
#define RESET_SIM_EXIST     1
static int g_sim_exist = RESET_SIM_ABSENT;
static int g_val_dist = 0;

static BOOL s_sms_full_notified = FALSE;

#define MAX_SIGNAL_LEVEL                        (1+4)
static const int    defaultSignalBar[MAX_SIGNAL_LEVEL] = {0, 2, 5, 8, 12};
static int          signalBar[MAX_SIGNAL_LEVEL] = {0, 2, 5, 8, 12};

//added for incoming black call
static BOOL bConfigIncomingMT = FALSE;

static int g_signalmap_array[92] = {0};
static int g_signalmap = 0;
static int g_FlagHlsLog = 0;
int g_lose_coverage = 0xff;

int g_modemtype_s = 1;

int g_simStateCheckRetryCount = 120;
/*****
    Default act is 0:GSM
    0:GSM
    2:TD-SCDMA
*****/
static int g_actmode = 2;

#define SIM_PUK2 9  /*add for return puk2 error, by chenchi*/

static pthread_mutex_t s_state_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t s_state_cond = PTHREAD_COND_INITIALIZER;

static int s_port = -1;
static const char * s_device_path = NULL;
static int          s_device_socket = 0;

static BOOL s_record_done = FALSE;

/* trigger change to this with s_state_cond */
static int s_closed = 0;

static int sFD;     /* file desc of AT channel */
static char sATBuffer[MAX_AT_RESPONSE+1];
static char *sATBufferCur = NULL;


static char *slast_lac= NULL;
static int siVoiceTecloType = 0;
static int errNumber = 255;

static RIL_NetworkList *p_NetworkList = NULL;       
static int NetworkList_lenth = 0;                   

/* Set g_sPinEntered to be true when pin
 * has been written into PIN_FILE_PATH, or
 * RIL reset because of Modem exception.
 */
static BOOL g_sPinEntered = FALSE;
// add [by chenshu 2012-04-18] end
BOOL g_singleCardMultiStandby = FALSE;

static BOOL g_pukLock = FALSE;

static const struct timeval TIMEVAL_SIMPOLL = {1,0};
static const struct timeval TIMEVAL_CALLSTATEPOLL = {0,500000};
static const struct timeval TIMEVAL_0 = {0,0};

static int s_ims_registered  = 0;        // 0==unregistered
static int s_ims_services    = 1;        // & 0x1 == sms over ims supported
static int s_ims_format    = 1;          // FORMAT_3GPP(1) vs FORMAT_3GPP2(2);
static int s_ims_cause_retry = 0;        // 1==causes sms over ims to temp fail
static int s_ims_cause_perm_failure = 0; // 1==causes sms over ims to permanent fail
static int s_ims_gsm_retry   = 0;        // 1==causes sms over gsm to temp fail
static int s_ims_gsm_fail    = 0;        // 1==causes sms over gsm to permanent fail

static int s_rilID = 0;


/* Controled by property "ro.ril.auto.plmn":
 *     0: use "AT+COPS=1,..."
 *     1: use "AT+COPS=4,..." */
static int s_is_auto_plmn = 1;


/* Controled by property "ro.ril.resend.sms.full":
 *     0: send RIL_UNSOL_SIM_SMS_STORAGE_FULL only once;
 *     1: send RIL_UNSOL_SIM_SMS_STORAGE_FULL each time when write SMS to (U)SIM; */
static BOOL s_is_resend_sms_full = FALSE;

static BOOL s_is_master_card = FALSE;

extern BOOL g_bDsatref_ok; 

#ifdef WORKAROUND_ERRONEOUS_ANSWER
// Max number of times we'll try to repoll when we think
// we have a AT+CLCC race condition
#define REPOLL_CALLS_COUNT_MAX 4
// Line index that was incoming or waiting at last poll, or -1 for none
static int s_incomingOrWaitingLine = -1;
// Number of times we've asked for a repoll of AT+CLCC
static int s_repollCallsCount = 0;
// Should we expect a call to be answered in the next CLCC?
static int s_expectAnswer = 0;
#endif /* WORKAROUND_ERRONEOUS_ANSWER */

static int s_cell_info_rate_ms = INT_MAX;
static int s_mcc = 0;
static int s_mnc = 0;
static int s_lac = 0;
static int s_cid = 0;

static int  RADIO_LC_ACT_2G = RADIO_LC_ACT_UNKNOWN;
static int  RADIO_LC_ACT_3G = RADIO_LC_ACT_UNKNOWN;
static int  RADIO_LC_ACT_4G = RADIO_LC_ACT_UNKNOWN;

static int s_productVersion = 0;        /*PRODUCTION_VERSION*/
 

static int enable_call_hold(void);
static int onUnsolicitedCallHold(const char *s);

static void pollSIMState (void *param);
static void setRadioState(RIL_RadioState newState);
static int getNetworkType(int);
static int getACTmode();
static void build_signal_map();
static BOOL isSimStateLockOrAbsent(SIM_Status simState);
static void checkSimStatus();
static void requestCheckSimStatus(void *data, size_t datalen, RIL_Token t);
static void onCheckSimStatus(void *param);
static void checkAndPollSimStat();
//<UH convert hex string to asc string./>
int ascToHex(const char *in_str, unsigned short int in_len, char *out_fptr);
int hex_str_to_asc_str(char *input_string, unsigned long int input_len, char *output_string, unsigned long int *output_len);



/* For send or receiver several pieces of mms at the same time, added by */


/* zoufeng for set "app_type" in response data of "RIL_REQUEST_GET_SIM_STATUS" begin */
RIL_AppType simCardType = RIL_APPTYPE_UNKNOWN;
/* zoufeng for set "app_type" in response data of "RIL_REQUEST_GET_SIM_STATUS" end */
pthread_mutex_t network_op_mutex = PTHREAD_MUTEX_INITIALIZER;
int network_op_mutex_ref = 0;

static int  is_radio_power_off = 0;

#define SAVE_FILE_PATH "/data/lc1810.cfg"

#define SYS_PROPERTY_RILD_GET_IMSI_COUNT   "rild.get.imsi.count"

static int  indexOfSmsOnSimCard = -1;
static const struct timeval TIMEVAL_5S = {5, 0};
static const struct timeval PS_TIMEVAL_1S = {1, 0};
#define PS_RETRY   2

/*  vt call log exclude local hangup*/
#define CALL_FAIL_CAUSE_NORMAL_CLEARING     16

#define ERR_NONE 0
#define ERR_CALL_C_FUNC -1
#define ERR_INVALID_PARAM -2
#define ERR_UNKNOWN -3
#define ERR_NOT_FOUND -4
#define SINT32 int
#define UINT8 int
#define SINT16 int

#define LOG_FUNC()
#define LOG_ERR( err_code )
#define LOG_INFO( x )
#define LOG_WARNING( x )
#define LOG_FUNC_PARAM( x )
#define LOG_SYS_ERR( sys_func_name_ptr )
#define LOG_ERR_EXT( err_code, x )

#define MAX_LINE_LEN 256
#define MAX_INI_FILE_SIZE (31*1024)
#define SIM_DCID_FILE_PRE "/data/lc1810_sim_dcid"
#define PROPERTY_PERSIST_SYS_LC_PREF_NET_TYPE   "persist.radio.pref.net.type"

#define MAX_SMS_PDU_LEN 500



timer_t cregTimer_id = 0;
timer_t resetModemTimer_id = 0;
timer_t resendCSQTimer_id = 0;   
static int mNetState = NETWORK_NOT_REGISTER;

static char lastResponseRecords[4][32] = {{'\0'}, {'\0'}, {'\0'}, {'\0'}};
#if defined(OPT_4G)
void strREGstateUnsol(const char *s);
static void requestLTERegistrationState(int request, void *data,size_t datalen, RIL_Token t);
#endif

static void unsolgetSignalStrength();

static void onSignalReceived(const char *s);

static BOOL isNetRegistered(int state) {
    switch(state) {
        case NETWORK_REGISTER:
        case NETWORK_REGISTER_ROAMING:
            return TRUE;
    }
    return FALSE;
}


BOOL check_board(char * ue_id)
{
    int fd = open("/sys/comip/board_info", O_RDONLY);
    char    board_id[20] = "";


    if(!ue_id)
        return false;

    if(strlen(ue_id)==0)
        return false;

    RLOGD("check_board = %s", ue_id);

    if(fd > 0) {
        read(fd, board_id, (sizeof(board_id) - 1));
        close(fd);

        RLOGD("board ID = %s", board_id);
        if(0 == strncasecmp(board_id, ue_id, strlen(ue_id))) {
            return true;
        }
    }

    return false;
}

void onNetworkStateChanged(union sigval sv)
{
    char *timer_ptr = (char *)(sv.sival_ptr);
    RLOGD("onNetworkStateChanged");
    if(timer_ptr)
    {
        RLOGD("for %s, mNetState = %d", timer_ptr, mNetState);
    }
    if(!isNetRegistered(mNetState)) {
        ril_timer_delete(cregTimer_id);
        cregTimer_id = 0;
        RIL_onUnsolicitedResponse(
                RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED,
                NULL, 0);
    }
}

int GetPrivateProfileString(const char *sec, const char *key,
			      const char *defval, char *val, int size,
			      const char *name)
{
	FILE *file;
	char line[MAX_LINE_LEN];
	int isfound;
	char *str;
	int ret;

	isfound = 0;
	if (!(file = fopen(name, "r"))) {
		perror("open file");
		goto defret;
	}

	while (fgets(line, sizeof(line), file)) {
		if (!(ret = strlen(line)) || line[0] != '['
		    || line[ret - 2] != ']')
			continue;
chksec:
		line[ret - 2] = '\000';
		if (strcasecmp(line + 1, sec))
			continue;
		while (fgets(line, sizeof(line), file)) {
			if ((ret = strlen(line)) && line[0] == '['
			    && line[ret - 2] == ']')
				goto chksec;
			if (!(str = strtok(line, " \t=\n"))
			    || (strcasecmp(str, key)))
				continue;
			if (NULL != (str = strtok(NULL, "\t=\n"))) {
				while (*str == ' ' && *str != '\0')
					str ++;				
				ret = (((int)strlen(str)) >= size) ? (size-1) : ((int)strlen(str));
				memcpy(val, str, ret);
				val[ret] = '\0';
				isfound = 1;
				break;
			}
		}
		break;
	}

defret:
	if (!isfound)
		strncpy(val, defval, size);
	if (file)
		fclose(file);
	return strlen(val);
}

int GetPrivateProfileInt(const char *sec, const char *key, int defval,
			   const char *name)
{
	char str[16];
	int ret;
	char *p;

	GetPrivateProfileString(sec, key, "", str, sizeof(str), name);

	if (!str[0])
		return defval;
	ret = strtol(str, &p, 0);
	return *p ? defval : ret;
}
static char* ltrim(char *str)
{
	char *p = str;
	
	while( *p == ' ' )
		p ++;
	return p;
}
char* getlname(char* line, char token)
{
	char* p = NULL;
	char* pt = NULL;
	char* name = NULL;
	int len;
	
	if( *line == '#' )
		return NULL;
	
	pt = ltrim(line);
	p = strchr(pt, token);
	if( p == NULL )
		return NULL;
	len = strlen(pt) - strlen(p) ;
	
	name = (char*)malloc(len + 1);
    if (NULL == name)
        return NULL;

	memset(name, 0, len+1);
	strncpy(name, pt, len);
	name[len] = '\0';
	return name;	
}
int WritePrivateProfileString(const char *sec, const char *key,
				  const char *val, const char *name)
{
	FILE *file = NULL;
	char line[MAX_LINE_LEN];
	size_t len = 0;
	char *p;
	int ret = 0;
	int sec_found = 0;
	int key_found = 0;
	char *newbuff;

	if (NULL == (newbuff = (char*)malloc(MAX_INI_FILE_SIZE))) 
		return 0;
	
	if( (file = fopen(name, "r")) == NULL ) {
		len = 0;
		len += sprintf(newbuff + len, "[%s]\n", sec);
		len += sprintf(newbuff + len, "%s=%s\n", key, val);

		goto WRITEFILE;
	}

	while (1) {
		memset(line, 0, sizeof(MAX_LINE_LEN));
		if (fgets(line, MAX_LINE_LEN, file) == NULL)
			break;
		if (!(ret = strlen(line)) || line[0] != '['
			|| line[ret - 2] != ']') {
			len += sprintf(newbuff + len, "%s", line);
			continue;
		}
		p = strchr(line, ']');
		if (p == NULL)
			continue;
		else
			*p = '\0';
		len += sprintf(newbuff + len, "[%s]\n", line + 1);
		if (strcasecmp(line + 1, sec))
			continue;
		else
			sec_found = 1;
		
		while (1) {
			memset(line, 0, sizeof(MAX_LINE_LEN));
			if (fgets(line, MAX_LINE_LEN, file) == NULL)
				break;

			if(strlen(line) <= 0)
				continue;
			
			if (line[0] == '[' && strchr(line, ']') != NULL) /* another section */
				break;

			p = getlname(line, '=');
			if(p && !strcasecmp(p, key))
			{
				key_found = 1;
				len += sprintf(newbuff + len, "%s=%s\n", key, val);
				free(p);
                p = NULL;
				break;
			}
			
			/*if(strlen(line) >= 0)
				len += sprintf(newbuff + len, "%s", line);*/
			len += sprintf(newbuff + len, "%s", line);

			if(p)
			{
                free(p);
                p = NULL;
			}
		}

		break;
	}
	
	if (sec_found == 1) {
		if (key_found == 0) {
			/* delete the blank line */
			if (newbuff[len-1] == '\n' && newbuff[len-2] == '\n')
				len --;
			len += sprintf(newbuff + len, "%s=%s\n\n", key, val);
			if (strlen(line) > 0)
				len += sprintf(newbuff + len, "%s", line);
		}
	}
	else {
		len += sprintf(newbuff + len, "[%s]\n", sec);
		len += sprintf(newbuff + len, "%s=%s\n", key, val);
	}
	//read the remaining part of ini file
	while (fgets(line, MAX_LINE_LEN, file)) {	
		if(strlen(line) > 0)		
			len += sprintf(newbuff + len, "%s", line);
	}			
	
	fclose(file);
	
WRITEFILE:
	if( (file = fopen(name, "w")) == NULL ) {
		free(newbuff);	
		return 0;
	}
	
	fwrite((void*) newbuff, sizeof(char), len, file);
	
	fflush(file);
	fclose(file);
	free(newbuff);
	return 1;	
}

static SINT32 read_sim_pin_password(char *pinString)
{
    char propString[32] = {0};
    char propValue[10] = {0};
    SINT32 ret_val = ERR_NONE;

    /* Check parameter. */
    if(NULL == pinString)
    {
        RLOGE("read_sim_pin_password(): invalid parameter !!!!!");
        return ERR_INVALID_PARAM;
    }

    sprintf(propString, RIL_SIM_PIN_PASSWORD"%d", s_rilID);
    if (__system_property_get(propString, propValue) > 0)
    {
        strncpy(pinString, propValue, sizeof(propValue));
        RLOGE("read_sim_pin_password(): get property: %s = %s", propString, propValue);
    }
    else
    {
        RLOGE("read_sim_pin_password(): read sim pin password failure, s_rilID = %d, propValue = %s", s_rilID, propValue);
        ret_val = ERR_CALL_C_FUNC;
    }

    return ret_val;
}

static SINT32 write_sim_pin_password(const char *pinString)
{
    char propString[32] = {0};
    SINT32 ret_val = ERR_NONE;

    /* Check parameter. */
    if(NULL == pinString)
    {
        RLOGE("write_sim_pin_password(): invalid parameter !!!!!");
        return ERR_INVALID_PARAM;
    }

    sprintf(propString, RIL_SIM_PIN_PASSWORD"%d", s_rilID);
    __system_property_set(propString, pinString);
    RLOGD("write_sim_pin_password(), set property: %s = %s", propString, pinString);

    return ret_val;
}


/*******************************************************************************
 * Function: cfg_get_param_and_value
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Parse the config file of system.
 *
 * Used variables:
 * ----------------------------
 *     lc_ata_cfg_st
 *
 * Params:
 * ----------------------------
 *     Name           Type            In/Out  Description
 *     -------------  --------------  ------  ---------------------------------
 *     line_ptr       char *          In      data to parse
 *     param_ptr      char **         Out     name of the config
 *     value_ptr      char **         Out     value of the config
 *
 * Return:
 * ----------------------------
 *     Error code.
 *
 * Note:
 * ----------------------------
 *     The data in "line_ptr" will be changed.
 *
 ******************************************************************************/

static SINT32 cfg_get_param_and_value(char *line_ptr, char **param_ptr, char **value_ptr )
{
    char    *p1 = NULL;
    char    *p2 = NULL;
    SINT32    ret_val = ERR_NONE;

//    LOG_FUNC();

    if( !line_ptr || !param_ptr || !value_ptr )
    {
        LOG_ERR( ERR_INVALID_PARAM );
        return ERR_INVALID_PARAM;
    }

    while( ' ' == *line_ptr )
        line_ptr++;

    if( '#' == *line_ptr )
    {
//        LOG_INFO(( "note line: %s", line_ptr ) );
        return ERR_NOT_FOUND;
    }

    p1 = strstr(line_ptr, "=");
    if( p1 )
    {
        *p1 = '\0';

        p2 = p1 + 1;
        p1--;

        while( ' ' == *p1 )
        {
            *p1 = '\0';
            p1--;
        }
        *param_ptr = line_ptr;

        while( ' ' == *p2 ) p2++;
        while( strlen(p2) > 0
               && ' ' == p2[strlen(p2)-1] )
        {
            p2[strlen(p2)-1] = '\0';
        }
        *value_ptr = p2;
    }
    else
    {
        ret_val = ERR_NOT_FOUND;
    }

    return ret_val;
}

static void build_signal_map()
{
    FILE    *fp = NULL;
    char    line_a[256];
    char    *param_ptr = NULL;
    char    *value_ptr = NULL;
    SINT32  ret_val = ERR_NONE;
    int i = 0;
    int value = 0;
    int num = 0;
    
    if((fp = fopen("/system/etc/signalmap.cfg", "r")) != NULL)
    {
        while(!feof(fp))
        {
            memset(line_a, 0x00, sizeof(line_a));
            fgets(line_a, sizeof(line_a) - 1, fp);

            ret_val = cfg_get_param_and_value(line_a, &param_ptr, &value_ptr);
            if(ERR_NONE == ret_val
                && param_ptr && strlen(param_ptr) > 0
                && value_ptr && strlen(value_ptr) > 0)
            {            
                i = atoi(param_ptr);
                if((i >= 0)&&(i <= 91))
                {
                    value = atoi(value_ptr);
                    if((value >= 0)&&(value <= 31))
                    {
                        g_signalmap_array[i] = value;
                        num++;
                    }
                    else
                    {
                        RLOGD("build_signal_map value Error!!param is %d; value is %d", i, value);
                    }
                }
                else
                {
                        RLOGD("build_signal_map param Error!!param is %d; value is %d", i, value);
                }
            }
            else
            {
                if(ERR_NONE == ret_val)
                {
                    if(param_ptr == NULL)
                    {
                        RLOGD("build_signal_map error!param_ptr == NULL");
                    }
                    else if(value_ptr == NULL)
                    {
                        RLOGD("build_signal_map error!value_ptr == NULL");
                    }
                    else
                    {
                        RLOGD("build_signal_map error!param_ptr len is %d; value_ptr len is %d", (int)strlen(param_ptr), (int)strlen(value_ptr));
                    }
                }
                else
                {
                    RLOGD("build_signal_map error!ret_val = %d", ret_val);
                }
            }
        }

        fclose(fp);
        if(num == 92)
        {
            g_signalmap = 1;
        }
    }
    else
    {
        g_signalmap = 0;
    }
     RLOGD("build_signal_map end! g_signalmap = %d, num = %d", g_signalmap, num);
}

static UINT8 signal_td_2_gsm(UINT8 td_signal)
{
    SINT16  dbm = 0;
    UINT8   gsm_signal = 0;
    UINT8   bar0 = 4;
    UINT8   bar1 = 6;
    UINT8   bar2 = 9;
    UINT8   bar3 = 11;
    UINT8   bar4 = 14;

    if( td_signal > 91 )
    {
        LOG_ERR_EXT( ERR_INVALID_PARAM, ("invalid TD signal: %d", td_signal) );
        return 0;
    } 
    if(g_signalmap)
    {
        gsm_signal = g_signalmap_array[td_signal];
        return gsm_signal;
    }  
    dbm = td_signal;
    dbm -= 116;
    if( dbm >= -85 )
    {
        gsm_signal = bar4 + 1;
    }
    else if( dbm >= -90 )
    {
        gsm_signal = bar3 + 1;
    }
    else if( dbm >= -95 )
    {
        gsm_signal = bar2 + 1;
    }
    else if( dbm >= -100 )
    {
        gsm_signal = bar1 + 1;
    }
    else if( dbm >= -105 )
    {
        gsm_signal = bar0 + 1;
    }
    else if( dbm < -105 )
    {
        gsm_signal = 0;
    }
    return gsm_signal;
}


/*******************************************************************************
 * Function: convertNumber
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     For read phonebook, convert 'p' to ',' and 'w' to ';';
 *     for write phonebook, convert ',' to 'p' and ';' to 'w'.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name           Type                 In/Out  Description
 *     -------------  -------------------  ------  ----------------------------
 *     record         RIL_IccCardRecord *  In/Out  phonebook record
 *     isRead         int                  In      for read or write
 *
 * Return:
 * ----------------------------
 *     (none)
 *
 * Note:
 * ----------------------------
 *     Android using ',' for PAUSE and ';' for WAIT, but Modem using 'p' for
 *     PAUSE and 'w'  for WAIT, so it must be converted between them.
 *
 ******************************************************************************/
static void convertNumber(RIL_IccCardRecord *record, int isRead) {
    int findPause, findWait;
    int toPause, toWait;
    int numLen = 0;
    int i = 0;

    if(isRead) {
        findPause = 'p';
        findWait = 'w';
        toPause = ',';
        toWait = ';';
    } else {
        findPause = ',';
        findWait = ';';
        toPause = 'p';
        toWait = 'w';
    }

    if(record != NULL) {
        char    *number[4] = {
            record->num1,
            record->num2,
            record->num3,
            record->num4 };
        int     numCount = 0;

        for(numCount=0; numCount<4; numCount++) {
            if(number[numCount] != NULL) {
                numLen = strlen(number[numCount]);
                for(i=0; i<numLen; i++) {
                    if(tolower(number[numCount][i]) == findPause) {
                        number[numCount][i] = toPause;
                    } else if(tolower(number[numCount][i]) == findWait) {
                        number[numCount][i] = toWait;
                    }
                }
            }
        }
    }

    return;
}

/*******************************************************************************
 * Function: switchModemUnsolicitedCode
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Switch on/off the unsolicited code of Modem.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name           Type                 In/Out  Description
 *     -------------  -------------------  ------  ----------------------------
 *     isOn           int                  In      switch on/off
 *
 * Return:
 * ----------------------------
 *     0        : successfully
 *     other    : unsuccessfully
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static int switchModemUnsolicitedCode(int isOn)
{
    RLOGD("Switch %s the unsolicited code of Modem", (isOn ? "on" : "off"));
	if(isOn)
    {
		at_send_command("AT+CREG=2", NULL);				   /* enable unsolicited result code: +CREG: */
	    at_send_command("AT+CGREG=2", NULL); 			   /* enable unsolicited result code: +CGREG: */
	    at_send_command("AT+CMER=2,0,0,2,0", NULL);		   /* enable unsolicited result code: +CIEV: */
    }
    else
	{
	    at_send_command("AT+CREG=0", NULL);				   /* disable unsolicited result code: +CREG: */
		at_send_command("AT+CGREG=0", NULL); 			   /* disable unsolicited result code: +CGREG: */
		at_send_command("AT+CMER=2,0,0,0,0", NULL);		   /* disable unsolicited result code: +CIEV: */
    }
	
    return 0;
}

/*******************************************************************************
 * Function: checkIfAutoAttachGprs
 * -----------------------------------------------------------------------------
 * Purpose:
 * ----------------------------
 *     Check if enable auto-attach GPRS.
 *
 * Used variables:
 * ----------------------------
 *     (none)
 *
 * Params:
 * ----------------------------
 *     Name           Type                 In/Out  Description
 *     -------------  -------------------  ------  ----------------------------
 *     (none)
 *
 * Return:
 * ----------------------------
 *     0        : successfully
 *     other    : unsuccessfully
 *
 * Note:
 * ----------------------------
 *     (none)
 *
 ******************************************************************************/
static int checkIfAutoAttachGprs(void)
{
    #define PS_CONFIG_FILE_PATH             "/data/etc"
    #define PS_CONFIG_FILE_FULL_PATH        PS_CONFIG_FILE_PATH "/" "psqos.conf"
    ATA_PS_CONFIG_ST    pdp_setting_st;

    /* Ensure the config file exists. Since an APP will read/write this file, so it
     * must can be accessed by everyone. */
    if(0 != access(PS_CONFIG_FILE_FULL_PATH, R_OK))
    {  
        RLOGD("Create PS config file \"" PS_CONFIG_FILE_FULL_PATH "\" ...");
        printf("Create PS config file \"" PS_CONFIG_FILE_FULL_PATH "\" ...");
        system("mkdir " PS_CONFIG_FILE_PATH);

        system("chmod -R 771 " PS_CONFIG_FILE_PATH);
        if(0==system("chown root:system " PS_CONFIG_FILE_PATH)){
            RLOGD("chown PS_CONFIG_FILE_PATH successfully");
        }else{
            RLOGD("chown PS_CONFIG_FILE_PATH failed, errno(%d), strerror(%s)",errno,strerror(errno));
        }

        system("echo \"1 4 0 0\" > " PS_CONFIG_FILE_FULL_PATH);
        if(0==system("chown root:system " PS_CONFIG_FILE_FULL_PATH)){
            RLOGD("1chown PS_CONFIG_FILE_FULL_PATH successfully");
        }else{
            RLOGD("1chown PS_CONFIG_FILE_FULL_PATH failed, errno(%d), strerror(%s)",errno,strerror(errno));
        }
    }
    system("chmod 771 " PS_CONFIG_FILE_FULL_PATH);

    return 0;
}

static int HandlePinRemainAttempt(int *errtime)
{
    ATResponse   *p_response = NULL;
    int remain[4];
    int err;
    char *line;
    DBBD(DB_RIL, RLOGD("==Handle PinRemain Attempt"));

    err = at_send_command_singleline("AT^DRAP", "^DRAP:", &p_response);
    if (err < 0 || p_response->success == 0) {
       RLOGD("___ EER Handle PinRemain Attempt,err=%d",err);
	   at_response_free(p_response);
       return -1; 
    }

    line = p_response->p_intermediates->line;

    at_tok_start(&line);
    at_tok_nextint(&line, &(remain[0]));
    at_tok_nextint(&line, &(remain[1]));
    at_tok_nextint(&line, &(remain[2]));
    at_tok_nextint(&line, &(remain[3]));

    errtime[0] = remain[0];
    errtime[1] = remain[1];
    errtime[2] = remain[2];
    errtime[3] = remain[3];
    DBBD(DB_RIL, RLOGD("===remain:(%d,%d,%d,%d)\n", remain[0], remain[1], remain[2],remain[3]));
    DBBD(DB_RIL, RLOGD("===errtime: (%d,%d,%d,%d)\n", errtime[0], errtime[1], errtime[2],errtime[3]));

    at_response_free(p_response);
    return 0;
}

static int clccStateToRILState(int state, RIL_CallState *p_state)
{
    switch(state) {
        case 0: *p_state = RIL_CALL_ACTIVE;   return 0;
        case 1: *p_state = RIL_CALL_HOLDING;  return 0;
        case 2: *p_state = RIL_CALL_DIALING;  return 0;
        case 3: *p_state = RIL_CALL_ALERTING; return 0;
        case 4: *p_state = RIL_CALL_INCOMING; return 0;
        case 5: *p_state = RIL_CALL_WAITING;  return 0;
        default: return -1;
    }
}

/**
 * Note: directly modified line and has *p_call point directly into
 * modified line
 */
static int callFromCLCCLine(char *line, RIL_Call *p_call)
{
        //+CLCC: 1,0,2,0,0,\"+18005551212\",145
        //     index,isMT,state,mode,isMpty(,number,TOA)?

    int err;
    int state;
    int mode;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(p_call->index));
    if (err < 0) goto error;

    err = at_tok_nextbool(&line, &(p_call->isMT));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &state);
    if (err < 0) goto error;

    err = clccStateToRILState(state, &(p_call->state));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &mode);
    if (err < 0) goto error;

    p_call->isVoice = (mode == 0);

    err = at_tok_nextbool(&line, &(p_call->isMpty));
    if (err < 0) goto error;

    if (at_tok_hasmore(&line)) {
        err = at_tok_nextstr(&line, &(p_call->number));

        /* tolerate null here */
        if (err < 0) return 0;

        // Some lame implementations return strings
        // like "NOT AVAILABLE" in the CLCC line
        /* remark for PCT 13.4.1.27 by guojiayu
        if (p_call->number != NULL
            && 0 == strspn(p_call->number, "+0123456789")
        ) {
            p_call->number = NULL;
        }
        */   //modeified for 20160321-90717

        err = at_tok_nextint(&line, &p_call->toa);
        if (err < 0) goto error;
    }

    return 0;

error:
    RLOGE("invalid CLCC line\n");
    return -1;
}

/** do post-AT+CFUN=1 initialization */
static void onRadioPowerOn()
{
#ifdef USE_TI_COMMANDS
    /*  Must be after CFUN=1 */
    /*  TI specific -- notifications for CPHS things such */
    /*  as CPHS message waiting indicator */

    at_send_command("AT%CPHS=1", NULL);

    /*  TI specific -- enable NITZ unsol notifs */
    at_send_command("AT%CTZV=1", NULL);
#endif
	RLOGD("onRadioPowerOn enter");
	pollSIMState(NULL);
     RLOGD("onRadioPowerOn enter");
	 
}

/** do post- SIM ready initialization */
static void onSIMReady()
{
	/*S mode not support this*/
    //at_send_command_singleline("AT+CSMS=1", "+CSMS:", NULL);//chenchi add
    /*
     * Always send SMS messages directly to the TE
     *
     * mode = 1 // discard when link is reserved (link should never be
     *             reserved)
     * mt = 2   // most messages routed to TE
     * bm = 2   // new cell BM's routed to TE
     * ds = 1   // Status reports routed to TE
     * bfr = 1  // flush buffer
     */
     //add by chenchi 
//    at_send_command("AT+CNMI=1,2,2,1,1", NULL);
}

static void requestDumpModem(void)
{
    int err = 0;
    ATResponse *p_response = NULL;

    RLOGD("Request Dump Modem!");
    err = at_send_command("AT^DSADUMP", &p_response);
    if (err < 0 || p_response->success == 0) {
        RLOGE("requestDumpModem Error,err =%d",err);
    }
	
	at_response_free(p_response);
}
//< add by lierqiang 20120914 for Enh00000210 end >


static void onSimCardAbsent(void *param)
{
    char value[2] = {'\0'};

    //if(property_get("install.usim.log.enable", value, "0"))
    if(property_get("persist.sys.usim.log", value, "0"))
    {
        RLOGD("property_get: value == %s", value);
        if(0 == strcmp(value, "1"))
        {
            requestPrintCardAbsentInfo(NULL);
        }
    }

    /* Fixed Enh00001117, by chenchi ,2011-08-11 */
    RLOGD("SIM state: %d", g_sim_exist);
    g_sim_exist = RESET_SIM_ABSENT;
    s_sms_full_notified = FALSE;
}

int hex2int(int hex)
{
    int ret = 0;

    if(hex >= 'a')      ret = (hex - 'a' + 10);
    else if(hex >= 'A') ret = (hex - 'A' + 10);
    else if(hex >= '0') ret = (hex - '0');

    if(ret > 16)        ret = 0;

    return ret;
}

static int requestReadSmsOnSimCard(char *sms_pdu_ptr, int sms_pdu_size)
{
    ATResponse          *p_response = NULL;
    RIL_SIM_IO_Response sr;
    int                 err = 0;
    char                *cmd = NULL;
    char                *line = NULL;
    int                 sms_pdu_len = 0;

    if(indexOfSmsOnSimCard <= 0 || !sms_pdu_ptr || sms_pdu_size <= 0) {
        return -1;
    }

    memset(sms_pdu_ptr, 0x00, sms_pdu_size);

    memset(&sr, 0, sizeof(sr));

    asprintf(&cmd,
            "AT+CRSM=%d,%d,%d,%d,%d",
            178, 28476,indexOfSmsOnSimCard, 4, 176);
    err = at_send_command_singleline(cmd, "+CRSM:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(sr.sw1));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(sr.sw2));
    if (err < 0) goto error;

    if (at_tok_hasmore(&line)) {
        err = at_tok_nextstr(&line, &(sr.simResponse));
        if (err < 0) goto error;
    }

    if(sr.simResponse != NULL
            && strlen(sr.simResponse) > 0
            && sr.simResponse[0] == '0' && sr.simResponse[1] == '3') {
        int     i = 0;
        char    *tmp_pdu_ptr = NULL;
        char    tmp_a[4] = "";

        strncpy(sms_pdu_ptr, &(sr.simResponse[2]), sms_pdu_size-1);
        sms_pdu_len = strlen(sms_pdu_ptr);
        RLOGD("[class 2 SMS]check: id(%d), pdu len(%d), pdu(%s)", indexOfSmsOnSimCard, sms_pdu_len, sms_pdu_ptr);
        for(i=sms_pdu_len; i-=2; i>1) {
            if(sms_pdu_ptr[i-1] == 'F' && sms_pdu_ptr[i-2] == 'F') {
                sms_pdu_ptr[i-1] = sms_pdu_ptr[i-2] = 0x00;
                sms_pdu_len -= 2;
            } else {
                break;
            }
        }

        tmp_pdu_ptr = sms_pdu_ptr;
        i = (hex2int(*(tmp_pdu_ptr + 0)) * 16 + hex2int(*(tmp_pdu_ptr + 1))) * 2; /* SC number len */
        /* Jump over SC number len */
        tmp_pdu_ptr += (1 * 2);
        /* Jump over SC number */
        tmp_pdu_ptr += i;
        /* Jump over byte 1 */
        tmp_pdu_ptr += (1 * 2);

        i = (hex2int(*(tmp_pdu_ptr + 0)) * 16 + hex2int(*(tmp_pdu_ptr + 1))); /* sender number len */
        if(i % 2 == 1)  i++;
        /* Jump over sender number len */
        tmp_pdu_ptr += (1 * 2);
        /* Jump over sender number type */
        tmp_pdu_ptr += (1 * 2);
        /* Jump over sender number */
        tmp_pdu_ptr += i;
        /* Jump over PID */
        tmp_pdu_ptr += (1 * 2);

        i = (hex2int(*(tmp_pdu_ptr + 0)) * 16 + hex2int(*(tmp_pdu_ptr + 1))); /* DCS */
        /*Conver class 2 to class 1 since Android does not support it. */
        if((i & 0xD3) == 0x12) {
            /* 00X1XX10 */
            i--;
        } else if((i & 0xF3) == 0xF2) {
            /* 1111XX10 */
            i--;
        }
        sprintf(tmp_a, "%02X", i);
        memcpy(tmp_pdu_ptr, tmp_a, 2);
    }

    at_response_free(p_response);
    return sms_pdu_len;

error:
    at_response_free(p_response);
    return -1;
}

static void onCMTI(void *param)
{
    char    sms_pdu[512] = "";
    int     sms_pdu_len = 0;

    sms_pdu_len = requestReadSmsOnSimCard(sms_pdu, sizeof(sms_pdu));
    RLOGD("[class 2 SMS]id(%d), pdu len(%d), pdu(%s)", indexOfSmsOnSimCard, sms_pdu_len, sms_pdu);
    if(sms_pdu_len > 0) {
        RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_NEW_SMS, sms_pdu, sms_pdu_len);
    }
}

static void clearIndexOfSmsOnSimCard(void *param)
{
    RLOGD("[class 2 SMS]clearIndexOfSmsOnSimCard: id(%d -> -1)", indexOfSmsOnSimCard);
    indexOfSmsOnSimCard = -1;
}

static int getLocaleOfSim(const char *imsi) {
    int cardLocale = CARD_LOCALE_UNKNOWN;

    if (NULL == imsi) {
        RLOGE("getLocaleOfSim(): imsi is null");
        return cardLocale;
    }

    if (CMCC_VERSION == s_productVersion) {
        char propStr[32] = "persist.sys.lc.plmn.cmcc";
        char defaultStr[32] = "460,00,02,07,08,20";
        char MNC_CMCC[20][4];
        char propValue[PROP_VALUE_MAX] = "";
        int  arraySize = sizeof(MNC_CMCC) / sizeof(MNC_CMCC[0]);
        char *result = NULL;
        int  i = 0;

        memset(MNC_CMCC, 0x00, sizeof(MNC_CMCC));

        property_get(propStr, propValue, defaultStr);

        result = strtok(propValue, ",");
        while (result != NULL && i < arraySize) {
            snprintf(MNC_CMCC[i], sizeof(MNC_CMCC[i]) - 1, "%s", result);
            i++;
            result = strtok(NULL, ",");
        }

        /* Get the locale info of the (U)SIM card by the IMSI.
         * IMSI = MCC + MNC + MSIN, refer to TS 23.003 Section 2.2 */
        if (strlen(imsi) >= 5) {
            if (strncmp(imsi, MNC_CMCC[0], strlen(MNC_CMCC[0])) == 0) {
                char mnc[4] = {0};

                cardLocale = CARD_LOCALE_CHINA_OTHERS;
                strncpy(mnc, &(imsi[3]), 2);    /* 3: len of MCC, 2: len of MNC */

                for (i = 1; MNC_CMCC[i][0] != '\0' && i< arraySize; i++) {
                    if (strcmp(mnc, MNC_CMCC[i]) == 0) {
                        cardLocale = CARD_LOCALE_CMCC;
                        break;
                    }
                }
            } else {
                cardLocale = CARD_LOCALE_FOREIGN;
            }
        }
    } else if (CUCC_VERSION == s_productVersion) {
        char propStr[32] = "persist.sys.lc.plmn.cucc";
        char defaultStr[32] = "460,01,06,09";
        char MNC_CUCC[20][4];
        char propValue[PROP_VALUE_MAX] = "";
        int arraySize = sizeof(MNC_CUCC) / sizeof(MNC_CUCC[0]);
        char *result = NULL;
        int i = 0;

        memset(MNC_CUCC, 0x00, sizeof(MNC_CUCC));

        property_get(propStr, propValue, defaultStr);

        result = strtok(propValue, ",");
        while (result != NULL && i < arraySize) {
            snprintf(MNC_CUCC[i], sizeof(MNC_CUCC[i]) - 1, "%s", result);
            i++;
            result = strtok(NULL, ",");
        }

        /* Get the locale info of the (U)SIM card by the IMSI.
         * IMSI = MCC + MNC + MSIN, refer to TS 23.003 Section 2.2 */
        if (strlen(imsi) >= 5) {
            cardLocale = CARD_LOCALE_OTHERS;

            if (strncmp(imsi, MNC_CUCC[0], sizeof(MNC_CUCC[0])) == 0) {
                char mnc[4] = {0};

                strncpy(mnc, &(imsi[3]), 2);    /* 3: len of MCC, 2: len of MNC */

                for (i = 1; MNC_CUCC[i][0] != '\0' && i < arraySize; i++) {
                    if (strcmp(mnc, MNC_CUCC[i]) == 0) {
                        cardLocale = CARD_LOCALE_CUCC;
                        break;
                    }
                }
            }
        }
    } else if (OPEN_VERSION == s_productVersion) {
        cardLocale = CARD_LOCALE_ALL;
    }

    RLOGI("getLocaleOfSim(): s_productVersion = %d, cardLocale = %d", s_productVersion, cardLocale);
    return cardLocale;
}
/* FIX 20150107-44932 by zoufeng, 20150112 begin */

void onDataCallListChanged(void *param)
{
    int ret = -1;
    static BOOL current_timer_up = FALSE;
    UINT32  op_code = (UINT32) param;

    //never block in TimedCallback thread!!!
    ret = pthread_mutex_trylock(&network_op_mutex);
    if(0 == ret )
    {
        RLOGD("[RIL-PS][onDataCallListChanged] network_op_mutex entry ref: %d", network_op_mutex_ref);
        network_op_mutex_ref++;
        current_timer_up = FALSE;
        requestOrSendDataCallList(NULL);
        network_op_mutex_ref--;
        RLOGD("[RIL-PS][onDataCallListChanged] network_op_mutex exit ref: %d", network_op_mutex_ref);
        pthread_mutex_unlock(&network_op_mutex);
    }
    else
    {
        if((op_code == PS_RETRY)||(current_timer_up==FALSE))
        {
            RIL_requestTimedCallback (onDataCallListChanged, (void *)PS_RETRY, &PS_TIMEVAL_1S);
            current_timer_up = TRUE;
        }
        else
        {
            RLOGD("[RIL-PS][onDataCallListChanged] nothing todo" );
        }
    }
}

static void requestDataCallList(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    requestOrSendDataCallList(&t);
}

static void requestSetFakeIPv4Addr(void *data, size_t datalen, RIL_Token t)
{
    char *fakeAddr;
    int ril_cid = 0;
    RIL_Fake_IPv4 *p_fake_IPv4;

    ALOGD("requestSetFakeIPv4Addr: Enter ");
    p_fake_IPv4 = (RIL_Fake_IPv4 *)data;
    
    ril_cid = p_fake_IPv4->cid;
    fakeAddr = p_fake_IPv4->fakeAddress;
    ALOGD("requestSetFakeIPv4Addr: cid = %d, fakeAddr = %s ", ril_cid, fakeAddr);

    ata_ps_set_fake_ipv4addr((UINT8)ril_cid, fakeAddr);
    return;
}




static void requestBasebandVersion(int request __unused, void *data __unused,
                                   size_t datalen __unused,  RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    char * response = NULL;
    char* line = NULL;

    RLOGD("=== send cmd for open the Unsolicited AT cmd");
    at_send_command("AT^DUSIMR=1", NULL);
    
    err = at_send_command_singleline("AT+CGMR", "+CGMR:", &p_response);
    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line); /*Fixed Req00000401 , by chenchi 2011-07-22 */
    response = (char *)alloca(sizeof(char *));

    err = at_tok_nextstr(&line, &response);
    RLOGD("baseband version: %s", response);
    if (err < 0) goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(char *));
    at_response_free(p_response);
    return;

error:
    at_response_free(p_response);
    RLOGE("ERROR: requestBasebandVersion failed\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestQueryNetworkSelectionMode(
                void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    int response = 0;
    char *line;

    err = at_send_command_singleline("AT+COPS?", "+COPS:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);

    if (err < 0) {
        goto error;
    }

    err = at_tok_nextint(&line, &response);

    if (err < 0) {
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    RLOGE("requestQueryNetworkSelectionMode must never return error when radio is on");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void sendCallStateChanged(void *param __unused)
{
    RIL_onUnsolicitedResponse (
        RIL_UNSOL_RESPONSE_CALL_STATE_CHANGED,
        NULL, 0);
}

static void deactiveAllLink(void *param)
{
    int ret = -1;
    UINT8 i = 0;
    static BOOL deactive_timer_up = FALSE;
    UINT32 op_code = (UINT32) param;

    //never block in TimedCallback thread!!!
    ret = pthread_mutex_trylock(&network_op_mutex);
    if(0 == ret )
    {
        RLOGD("[RIL-PS][deactiveAllLink] network_op_mutex entry ref: %d", network_op_mutex_ref);
        network_op_mutex_ref++;
        deactive_timer_up = FALSE;
        for (i = RIL_CID_MIN_VALUE; i <= RIL_CID_MAX_VALUE; i++ )
        {
		ata_ps_stop_network(i);
        }
        network_op_mutex_ref--;
        RLOGD("[RIL-PS][deactiveAllLink] network_op_mutex exit ref: %d", network_op_mutex_ref);
        pthread_mutex_unlock(&network_op_mutex);
    }
    else
    {
        if((op_code == PS_RETRY)||(deactive_timer_up==FALSE))
        {
            RIL_requestTimedCallback (deactiveAllLink, (void *)PS_RETRY, &PS_TIMEVAL_1S);
            deactive_timer_up = TRUE;
        }
        else
        {
            RLOGD("[RIL-PS][deactiveAllLink] nothing todo" );
        }
    }
}

static void requestGetSimstatus(void *data, size_t datalen, RIL_Token t)
{
    RIL_CardStatus_v6 *p_card_status;
    char *p_buffer;
    int buffer_size;

    int result = getCardStatus(&p_card_status);

    if (result == RIL_E_SUCCESS) {
        p_buffer = (char *)p_card_status;
        buffer_size = sizeof(*p_card_status);
    } else {
        p_buffer = NULL;
        buffer_size = 0;
    }
	RLOGE("requestGetSimstatus return.");
    RIL_onRequestComplete(t, result, p_buffer, buffer_size);
    freeCardStatus(p_card_status);
}

static void requestGetCurrentCalls(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    int err;
    ATResponse *p_response;
    ATLine *p_cur;
    int countCalls;
    int countValidCalls;
    RIL_Call *p_calls;
    RIL_Call **pp_calls;
    int i;
    int needRepoll = 0;

#ifdef WORKAROUND_ERRONEOUS_ANSWER
    int prevIncomingOrWaitingLine;

    prevIncomingOrWaitingLine = s_incomingOrWaitingLine;
    s_incomingOrWaitingLine = -1;
#endif /*WORKAROUND_ERRONEOUS_ANSWER*/


    err = at_send_command_multiline ("AT+CLCC", "+CLCC:", &p_response);

    if (err != 0 || p_response->success == 0) {
        at_response_free(p_response);
		RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    /* count the calls */
    for (countCalls = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL
            ; p_cur = p_cur->p_next
    ) {
        countCalls++;
    }

    /* yes, there's an array of pointers and then an array of structures */

    pp_calls = (RIL_Call **)alloca(countCalls * sizeof(RIL_Call *));
    p_calls = (RIL_Call *)alloca(countCalls * sizeof(RIL_Call));
    memset (p_calls, 0, countCalls * sizeof(RIL_Call));

    /* init the pointer array */
    for(i = 0; i < countCalls ; i++) {
        pp_calls[i] = &(p_calls[i]);
    }

    for (countValidCalls = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL
            ; p_cur = p_cur->p_next
    ) {
        err = callFromCLCCLine(p_cur->line, p_calls + countValidCalls);

        if (err != 0) {
            continue;
        }

#ifdef WORKAROUND_ERRONEOUS_ANSWER
        if (p_calls[countValidCalls].state == RIL_CALL_INCOMING
            || p_calls[countValidCalls].state == RIL_CALL_WAITING
        ) {
            s_incomingOrWaitingLine = p_calls[countValidCalls].index;
        }
#endif /*WORKAROUND_ERRONEOUS_ANSWER*/

        if (p_calls[countValidCalls].state != RIL_CALL_ACTIVE
            && p_calls[countValidCalls].state != RIL_CALL_HOLDING
        ) {
            needRepoll = 1;
        }

        countValidCalls++;
    }

#ifdef WORKAROUND_ERRONEOUS_ANSWER
    // Basically:
    // A call was incoming or waiting
    // Now it's marked as active
    // But we never answered it
    //
    // This is probably a bug, and the call will probably
    // disappear from the call list in the next poll
    if (prevIncomingOrWaitingLine >= 0
            && s_incomingOrWaitingLine < 0
            && s_expectAnswer == 0
    ) {
        for (i = 0; i < countValidCalls ; i++) {

            if (p_calls[i].index == prevIncomingOrWaitingLine
                    && p_calls[i].state == RIL_CALL_ACTIVE
                    && s_repollCallsCount < REPOLL_CALLS_COUNT_MAX
            ) {
                RLOGI(
                    "Hit WORKAROUND_ERRONOUS_ANSWER case."
                    " Repoll count: %d\n", s_repollCallsCount);
                s_repollCallsCount++;
                goto error;
            }
        }
    }

    s_expectAnswer = 0;
    s_repollCallsCount = 0;
#endif /*WORKAROUND_ERRONEOUS_ANSWER*/

    RIL_onRequestComplete(t, RIL_E_SUCCESS, pp_calls,
            countValidCalls * sizeof (RIL_Call *));

    at_response_free(p_response);

#ifdef POLL_CALL_STATE
    if (countValidCalls) {  // We don't seem to get a "NO CARRIER" message from
                            // smd, so we're forced to poll until the call ends.
#else
    if (needRepoll) {
#endif
        RIL_requestTimedCallback (sendCallStateChanged, NULL, &TIMEVAL_CALLSTATEPOLL);
    }

    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestDial(void *data, size_t datalen __unused, RIL_Token t)
{
    RIL_Dial *p_dial;
    char *cmd;
    const char *clir;

    p_dial = (RIL_Dial *)data;

    switch (p_dial->clir) {
        case 1: clir = "I"; break;  /*invocation*/
        case 2: clir = "i"; break;  /*suppression*/
        default:
        case 0: clir = ""; break;   /*subscription default*/
    }

    asprintf(&cmd, "ATD%s%s;", p_dial->address, clir);

    at_send_command(cmd, NULL);

    free(cmd);

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void requestDialEmergency(void *data, size_t datalen __unused, RIL_Token t)
{
    const char**  strings = (const char**)data;
    char *cmd;

    asprintf(&cmd, "ATDE%s,%s;", strings[0], strings[1]);

    at_send_command(cmd, NULL);

    free(cmd);

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void requestOemHookRaw(void *data, size_t datalen, RIL_Token t)
{
    RIL_onRequestComplete(t, RIL_E_SUCCESS, data, datalen);
}

static void requestOemHookStrings(void *data, size_t datalen, RIL_Token t)
{
    int i;
    const char **cur;

    RLOGD("got OEM_HOOK_STRINGS: 0x%8p %lu", data, (long)datalen);
    for (i = (datalen / sizeof (char *)), cur = (const char **)data ; i > 0 ; cur++, i --) {
        RLOGD("> '%s'", *cur);
    }

    //echo back strings
    RIL_onRequestComplete(t, RIL_E_SUCCESS, data, datalen);

    //RIL_onRequestComplete(t, RIL_E_REQUEST_NOT_SUPPORTED, NULL, 0);
}

static void requestDeleteSmsOnSim(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *cmd;
    ATResponse *p_response = NULL;

    /* FIX L1809OG_Bug00001310 2011-03-23 chenchi begin */
    /*Note: The modification is for the macro FEA_CMCC_SWITCH of leadcore Modem*/
    int val = 0;
    if(0 < ((int *)data)[0]) {
        val = ((int *)data)[0] - 1;
    }

    asprintf(&cmd, "AT+CMGD=%d", val);
    //asprintf(&cmd, "AT+CMGD=%d", ((int *)data)[0]);
    /* FIX L1809OG_Bug00001310 2011-03-23 chenchi end */
    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    } else {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    }
    at_response_free(p_response);
}

static void requestWriteSmsToSim(void *data, size_t datalen __unused, RIL_Token t)
{
    RIL_SMS_WriteArgs *p_args;
    char *cmd;
    int length=0;
    int err;
    ATResponse *p_response = NULL;

    //<UH, 2010-12-31, lifangdong, Add a interface with index returned for MMS ./
    int index = -1;
    char *line = NULL;
    
    // add [by chenshu 2012-12-25] for fix Bug00002424
    if(indexOfSmsOnSimCard > 0) {
        index = indexOfSmsOnSimCard;
        DBBD(DB_RIL, RLOGD("[class 2 SMS]====>requestWriteSmsToSim: [index = %d]", index));
        RIL_onRequestComplete(t, RIL_E_SUCCESS, &index, sizeof(int));

        return;
    }
    // add [by chenshu 2012-12-25] end
    p_args = (RIL_SMS_WriteArgs *)data;

	length = 0;
    if(p_args->pdu != NULL)
        length = strlen(p_args->pdu);

    if(p_args->smsc != NULL)
        length += strlen(p_args->smsc);

	if(length>MAX_SMS_PDU_LEN-3) goto error;

    length = strlen(p_args->pdu)/2;
    asprintf(&cmd, "AT+CMGW=%d,%d", length, p_args->status);

    //<UH, 2010-12-31, lifangdong, Add a interface with index returned for MMS ./
    //err = at_send_command_sms(cmd, p_args->pdu, "+CMGW:", &p_response);


    char pdudata[MAX_SMS_PDU_LEN] = {0};
    if (p_args->smsc != NULL && strlen(p_args->smsc) != 0)
    {
        strcpy(pdudata, p_args->smsc);
        strcpy(pdudata + strlen(p_args->smsc), p_args->pdu);
    }
    else
    {
        strcpy(pdudata, "00");
        strcpy(pdudata+2, p_args->pdu);
    }

    err = at_send_command_sms(cmd, pdudata, "+CMGW:", &p_response);
    if (NULL != cmd)
    {
        free(cmd);
        cmd = NULL;
    }
    
    if (err != 0 || p_response->success == 0) goto error;

    //<UH, 2010-12-31, lifangdong, Add a interface with index returned for MMS ./
    //RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    
    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if(err < 0) goto error;

    err = at_tok_nextint(&line, &index);
    if(err < 0) goto error;
    /* FIX L1809OG_Bug00001310 2011-03-23 chenchi begin */
    /*Note: The modification is for the macro FEA_CMCC_SWITCH of leadcore Modem*/
    index = index + 1;
    /* FIX L1809OG_Bug00001310 2011-03-23 chenchi end */
    DBBD(DB_RIL, RLOGD("====>requestWriteSmsToSim: [index = %d]",index));
    RIL_onRequestComplete(t, RIL_E_SUCCESS, &index, sizeof(int));
    
    at_response_free(p_response);

    return;
error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);

/* FIX 20141216-41218 by zoufeng, 20150104 begin */
    if(TRUE == s_sms_full_notified
        && TRUE == s_is_resend_sms_full) {
        RIL_onUnsolicitedResponse (RIL_UNSOL_SIM_SMS_STORAGE_FULL, NULL, 0);
    }
/* FIX 20141216-41218 by zoufeng, 20150104 end */
}

static void requestHangup(void *data, size_t datalen __unused, RIL_Token t)
{
    int *p_line;
    char *cmd;

    p_line = (int *)data;

    // 3GPP 22.030 6.5.5
    // "Releases a specific active call X"
    asprintf(&cmd, "AT+CHLD=1%d", p_line[0]);

    at_send_command(cmd, NULL);

    free(cmd);

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void requestSetMute(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *cmd;

    assert (datalen >= sizeof(int *));

    asprintf(&cmd, "AT+CMUT=%d", ((int*)data)[0]);

    err = at_send_command(cmd, NULL);
    free(cmd);

    if (err != 0) goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);

    return;

error:
    RLOGE("ERROR: requestSetMute failed");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestGetMute(void *data, size_t datalen, RIL_Token t)
{
    int err, response;
    ATResponse *p_response = NULL;
    char *line;

    err = at_send_command_singleline("AT+CMUT?", "+CMUT:", &p_response);
/* FIX L1809OG_Bug00000407 2011-01-31 zoufeng begin */
//    if (err != 0) goto error;
    if (err != 0 || p_response->success == 0) goto error;
/* FIX L1809OG_Bug00000407 2011-01-31 zoufeng end */

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &response);
    if (err < 0) goto error;

    at_response_free(p_response);
	RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    return;

error:
    RLOGE("ERROR: requestGetMute failed");
	at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestScreenState(void *data, size_t datalen, RIL_Token t)
{
    int screenState;
    char value[2] = {'\0'};//add by zhangfei for L1860_20160301-88031//
    BOOL forProTest = FALSE; //add by zhangfei for L1860_20160301-88031//
    assert (datalen >= sizeof(int *));
    screenState = ((int*)data)[0];


    //add by zhangfei for L1860_20160301-88031//
    if(property_get("persist.radio.ims.ns-iot.test", value, "0"))
    {
		if(value[0]=='1')
			{
			     forProTest = TRUE;
			}

    }

    RLOGE("now the screenState was  %d ",screenState);
    RLOGE("now the forProTest was  %d ",forProTest);
   //add by zhangfei for L1860_20160301-88031//
    if(screenState == 1) {
        switchModemUnsolicitedCode(1);

        RIL_onUnsolicitedResponse (
            RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED,
            NULL, 0);
    } else if(screenState == 0) {
    if(!forProTest){//add by zhangfei for L1860_20160301-88031//
        switchModemUnsolicitedCode(0);
		}//add by zhangfei for L1860_20160301-88031//


/* FIX 20150305-52010 by zoufeng, 20150307 begin */
        //mNetState = NETWORK_NOT_REGISTER;  //modified by jiangxuqin for Bug20160414-93937
        if (cregTimer_id != 0)
        {
            ril_timer_delete(cregTimer_id);
            cregTimer_id = 0;
        }
/* FIX 20150305-52010 by zoufeng, 20150307 end */
    } else {
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RLOGE("ERROR: requestScreenState failed");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestTogglePSStateChangeEvent(void *data, size_t datalen, RIL_Token t)
{
    int error, action;
    char *cmd = NULL;
    ATResponse *p_response = NULL;

    assert (datalen >= sizeof(int *));

    action = ((int *)data)[0];
    asprintf(&cmd, "AT^DEGSI=%d", action);
    error = at_send_command(cmd, &p_response);
    if (NULL != cmd)
    {
        free(cmd);
        cmd = NULL;
    }

    if (error < 0 || p_response->success == 0)
    {
        goto error;
    }

    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    at_response_free(p_response);
    RLOGE("ERROR: requestTogglePSStateChangeEvent failed");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestTogglePSResControlEvent(void *data, size_t datalen, RIL_Token t)
{
    int error, action;
    char *cmd = NULL;
    ATResponse *p_response = NULL;

    assert (datalen >= sizeof(int *));

    action = ((int *)data)[0];
    if (1 == action) {
        int internal = 5;
        asprintf(&cmd, "AT^DPCL=%d,%d", action, internal);
    } else {
        asprintf(&cmd, "AT^DPCL=%d", action);
    }

    error = at_send_command(cmd, &p_response);
    if (NULL != cmd)
    {
        free(cmd);
        cmd = NULL;
    }

    if (error < 0 || p_response->success == 0)
    {
        goto error;
    }

    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    at_response_free(p_response);
    RLOGE("ERROR: requestTogglePSResControlEvent failed");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

#ifdef AT_CHANNEL_UDP  
#define PUB_UTIL_READ_DEVICE(ret_val, fd, read_buf_a, read_buf_size, read_len, sec, msec) \
        do                                                                      \
        {                                                                       \
            fd_set          read_fds;                                           \
            struct timeval  tv_read;                                            \
            struct timespec tp_select;                                          \
            struct timespec tp_now;                                             \
                                                                                \
            ret_val = ERR_NONE;                                                 \
                                                                                \
            if( fd <= 0 )                                                       \
            {                                                                   \
                RLOGD( "fd <= 0 ");                                          \
                ret_val = ERR_UNKNOWN;                                          \
                /* LOG_ERR_EXT( ERR_UNKNOWN, ("invalid fd") );                   */  \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val && sec >= 0 )                               \
            {                                                                   \
                tv_read.tv_sec = sec;                                           \
                tv_read.tv_usec = 0;                                            \
                if( msec >= 0 )                                                 \
                {                                                               \
                    tv_read.tv_usec = msec * 1000;                              \
                }                                                               \
                                                                                \
                while(1)                                                        \
                {                                                               \
                    FD_ZERO( &read_fds );                                       \
                    FD_SET( fd, &read_fds );                                    \
                    clock_gettime(CLOCK_REALTIME, &tp_select);                  \
                    ret_val = select((fd + 1), &read_fds, NULL, NULL, &tv_read);    \
                    if( ret_val < 0 )                                           \
                    {                                                              \
                        RLOGD( "ret_val < 0 ");                                                             \
                        /* LOG_SYS_ERR( "select" );                              */  \
                        ret_val = ERR_CALL_C_FUNC;                              \
                        break;                                                  \
                    }                                                           \
                    else if( 0 == ret_val )                                     \
                    {                                                           \
                        RLOGD( "PUB_UTIL_READ_DEVICE, 0 == ret_val");                                            \
                        clock_gettime(CLOCK_REALTIME, &tp_now);                 \
                        if( tp_now.tv_sec < (tp_select.tv_sec + 1) )            \
                        {                                                       \
                            continue;                                           \
                        }                                                       \
                                                                                \
                        ret_val = ERR_CALL_C_FUNC;                              \
                        /* LOG_ERR_EXT(ERR_UNKNOWN, ("read time out: %ld:%ld -> %ld:%ld", tp_select.tv_sec, tp_select.tv_nsec, tp_now.tv_sec, tp_now.tv_nsec));   */ \
                        break;                                                  \
                    }                                                           \
                    else if( FD_ISSET(fd, &read_fds) )                          \
                    {                                                           \
                        RLOGD( "FD_ISSET(fd, read_fds)");                         \
                        ret_val = ERR_NONE;                                     \
                        break;                                                  \
                    }                                                           \
                    else                                                        \
                    {                                                           \
                       RLOGD( "else");                                          \
                        ret_val = ERR_UNKNOWN;                                  \
                        /* LOG_ERR_EXT(ERR_UNKNOWN, ("select OK, but fd is not ready")); */ \
                        break;                                                  \
                    }                                                           \
                }                                                               \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val )                                           \
            {                                                                      \
                 RLOGD( "ERR_NONE == ret_val");                                         \
                memset( read_buf_a, 0x00, read_buf_size );                      \
                read_len=recv(fd, read_buf_a, read_buf_size - 1,0);           \
                if(read_len < 0)                                              \
                {                                                               \
                    /*LOG_SYS_ERR( "read" );                                     */ \
                    RLOGD("read AT error: %d", errno);                               \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                }                                                               \
                else \
                { \
                    RLOGD("read AT: %s", read_buf_a);                               \
                } \
            }                                                                   \
        } while(0);
#else
#define PUB_UTIL_READ_DEVICE(ret_val, fd, read_buf_a, read_buf_size, read_len, sec, msec) \
        do                                                                      \
        {                                                                       \
            fd_set          read_fds;                                           \
            struct timeval  tv_read;                                            \
            struct timespec tp_select;                                          \
            struct timespec tp_now;                                             \
                                                                                \
            ret_val = ERR_NONE;                                                 \
                                                                                \
            if( fd <= 0 )                                                       \
            {                                                                   \
                RLOGD( "fd <= 0 ");                                          \
                ret_val = ERR_UNKNOWN;                                          \
                /* LOG_ERR_EXT( ERR_UNKNOWN, ("invalid fd") );                   */  \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val && sec >= 0 )                               \
            {                                                                   \
                tv_read.tv_sec = sec;                                           \
                tv_read.tv_usec = 0;                                            \
                if( msec >= 0 )                                                 \
                {                                                               \
                    tv_read.tv_usec = msec * 1000;                              \
                }                                                               \
                                                                                \
                while(1)                                                        \
                {                                                               \
                    FD_ZERO( &read_fds );                                       \
                    FD_SET( fd, &read_fds );                                    \
                    clock_gettime(CLOCK_REALTIME, &tp_select);                  \
                    ret_val = select((fd + 1), &read_fds, NULL, NULL, &tv_read);    \
                    if( ret_val < 0 )                                           \
                    {                                                              \
                        RLOGD( "ret_val < 0 ");                                                             \
                        /* LOG_SYS_ERR( "select" );                              */  \
                        ret_val = ERR_CALL_C_FUNC;                              \
                        break;                                                  \
                    }                                                           \
                    else if( 0 == ret_val )                                     \
                    {                                                           \
                        RLOGD( "PUB_UTIL_READ_DEVICE, 0 == ret_val");                                            \
                        clock_gettime(CLOCK_REALTIME, &tp_now);                 \
                        if( tp_now.tv_sec < (tp_select.tv_sec + 1) )            \
                        {                                                       \
                            continue;                                           \
                        }                                                       \
                                                                                \
                        ret_val = ERR_CALL_C_FUNC;                              \
                        /* LOG_ERR_EXT(ERR_UNKNOWN, ("read time out: %ld:%ld -> %ld:%ld", tp_select.tv_sec, tp_select.tv_nsec, tp_now.tv_sec, tp_now.tv_nsec));   */ \
                        break;                                                  \
                    }                                                           \
                    else if( FD_ISSET(fd, &read_fds) )                          \
                    {                                                           \
                        RLOGD( "FD_ISSET(fd, read_fds)");                         \
                        ret_val = ERR_NONE;                                     \
                        break;                                                  \
                    }                                                           \
                    else                                                        \
                    {                                                           \
                       RLOGD( "else");                                          \
                        ret_val = ERR_UNKNOWN;                                  \
                        /* LOG_ERR_EXT(ERR_UNKNOWN, ("select OK, but fd is not ready")); */ \
                        break;                                                  \
                    }                                                           \
                }                                                               \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val )                                           \
            {                                                                      \
                 RLOGD( "ERR_NONE == ret_val");                                         \
                memset( read_buf_a, 0x00, read_buf_size );                      \
                read_len = read(fd, read_buf_a, read_buf_size - 1);             \
                if( read_len < 0 )                                              \
                {                                                               \
                    /*LOG_SYS_ERR( "read" );                                     */ \
                    RLOGD("read AT error: %d", errno);                               \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                }                                                               \
                else \
                { \
                    RLOGD("read AT: %s", read_buf_a);                               \
                } \
            }                                                                   \
        } while(0);
#endif


static void requestSetupDataCall(void *data, size_t datalen, RIL_Token t)
{
    int ril_cid = 0;
    int i=1;
    int max_retry_times = 1;
    int err = ERR_NONE;
    RIL_Data_Call_Response_v11  response;
    ATA_PS_NETWORK_INFO_ST * network_info = NULL;
    ATA_PS_PDP_REQ_ST * pdp_req = NULL;
    char  *protocol=NULL;

    memset(&response, 0, sizeof(RIL_Data_Call_Response_v11));
    response.suggestedRetryTime = -1;
	RLOGD("[panda_wyy_0728]requestSetupDataCall mNetState = %d",mNetState);
    if (RADIO_STATE_UNAVAILABLE == sState || RADIO_STATE_OFF == sState
            || (isRadioOn() != 1)) {
        response.status = DC_FAIL_RADIO_POWER_OFF;
        RLOGE("[RIL-PS][requestSetupDataCall] err: radio not on");
        goto error;
    } else if(!isNetRegistered(mNetState)) {
        response.status = DC_FAIL_REGISTRATION_FAIL;
        RLOGE("[RIL-PS][requestSetupDataCall] err: network not registerd");
        goto error;
    }

    pdp_req = (ATA_PS_PDP_REQ_ST*) alloca(sizeof(ATA_PS_PDP_REQ_ST));
    pdp_req->radio_technology = ((const char **)data)[0];
    pdp_req->profile = ((const char **)data)[1];
    pdp_req->apn = ((const char **)data)[2];
    pdp_req->user =  ((const char **)data)[3];
    pdp_req->password = ((const char **)data)[4];
    pdp_req->auth_type = ((const char **)data)[5];
    pdp_req->protocol = ((const char **)data)[6];
    pdp_req->check_protocol = TRUE;

	//S mode only support IP protocol
	pdp_req->protocol = "IP";
    max_retry_times = MAX_PDP_RETRY_TIMES;

    for(i=1; i<=max_retry_times; i++) {

        if(i==MAX_PDP_RETRY_TIMES) {
            pdp_req->check_protocol = FALSE;
        }

        if(i!=1) {sleep(1);}
        
        err = ata_ps_start_network(&ril_cid,pdp_req);
        RLOGD("[panda_wyy]ata_ps_start_network res = %d",err);
        if( ERR_NONE != err ) {
            RLOGD("[RIL-PS][requestSetupDataCall]ps_start_network fail %d times",i);
        } else {
            break;
        }
    }

    if( ERR_NONE != err ) {
		RLOGD("[panda_wyy_0727] 1requestSetupDataCall err = %d",err );
        response.status = DC_FAIL_SIGNAL_LOST; //   DcFailCause SIGNAL_LOST(-3)
        goto error;
    }

    network_info = (ATA_PS_NETWORK_INFO_ST*) alloca(sizeof(ATA_PS_NETWORK_INFO_ST));
    memset(network_info,0,sizeof(ATA_PS_NETWORK_INFO_ST));
    err =  ata_ps_get_network_info(ril_cid, network_info);
    if( ERR_NONE != err ) {
		RLOGD("[panda_wyy_0727] 2requestSetupDataCall err = %d",err );
        response.status = DC_FAIL_SIGNAL_LOST; //   DcFailCause SIGNAL_LOST(-3)
        goto error;
    }

    response.suggestedRetryTime = -1;
    response.cid = ril_cid;
    response.active = 2;

    if (PROTOCOL_IPV4 == network_info->pdp_type) {
        response.type =  "IP";
    } else if (PROTOCOL_IPV6 == network_info->pdp_type) {
        response.type = "IPV6";
    } else if (PROTOCOL_IPV4V6 == network_info->pdp_type) {
        response.type = "IPV4V6";
    }else {
        response.status = DC_FAIL_PROTOCOL_ERRORS;
        goto error;
    }


    response.status = 0; //SUCCESS
    response.ifname = network_info->ifname;
    response.addresses = network_info->ip_address;
    response.dnses = network_info->dnses;
    response.gateways = network_info->gateways;
    response.pcscf = NULL;
    response.mtu = 0;
	RLOGD("[panda_wyy_0728]response.ifname = %s,address = %s,dnses = %s,gateways = %s",network_info->ifname,network_info->ip_address,network_info->dnses,network_info->gateways);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(RIL_Data_Call_Response_v11));
    return;

error:

    RLOGE("[RIL-PS][requestSetupDataCall] error status:%d", response.status);
    ata_ps_stop_network(ril_cid);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &response, sizeof(RIL_Data_Call_Response_v11));
    return;
}

void requestEnablePsDomain(void *data, size_t datalen, RIL_Token t)
{
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    return;
}


static void requestSetupDataCallFake(void *data, size_t datalen, RIL_Token t)
{
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    return;
}

static void  requestSIM_IO(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    RIL_SIM_IO_Response sr;
    int err;
    char *cmd = NULL;
    //RIL_SIM_IO *p_args;
    RIL_SIM_IO_v6 *p_args;
    char *line;
    int len;
	
    memset(&sr, 0, sizeof(sr));

    p_args = (RIL_SIM_IO_v6 *)data;

    /* FIXME handle pin2 */
    if(p_args->pin2 != NULL) {
        asprintf(&cmd, "AT^DPIN2=\"%s\"", p_args->pin2);
        DBBD(DB_RIL, RLOGD("SIM_IO FDN, cmd: %s",cmd));

        err = at_send_command(cmd, &p_response);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }

        if (err < 0 || p_response->success == 0) {

            if (!strcmp(p_response->finalResponse, "+CME ERROR: 18")) {//change not found to 22.22meas not found
             // err = RIL_E_SIM_PUK2;
             RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED, NULL, 0);
             sleep(2);
            }
            goto error;
        }

        at_response_free(p_response);
        p_response = NULL;
    }

    if (p_args->data == NULL) {
        asprintf(&cmd, "AT^DRSM=%d,%s%X,%d,%d,%d",
                    p_args->command, p_args->path, p_args->fileid,
                    p_args->p1, p_args->p2, p_args->p3);
    } else {
        asprintf(&cmd, "AT^DRSM=%d,%s%X,%d,%d,%d,%s",
                    p_args->command, p_args->path, p_args->fileid,
                    p_args->p1, p_args->p2, p_args->p3, p_args->data);
    }

    err = at_send_command_singleline(cmd, "^DRSM:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }
	
	#ifndef RILTEST
    if (err < 0 || p_response->success == 0) {
        goto error;
    }
	line = p_response->p_intermediates->line;
	#else
	//char tt[256]="^DRSM: 144,0,621C8202412183026FADA5038001718A01058B036F060180020004880118";
	char tt[256]="^DRSM: 144,0,FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF012014F1FFFFFFFFFFFFFFFF";
	//p_response->p_intermediates->line = "^DRSM: 144,0,621C8202412183026FADA5038001718A01058B036F060180020004880118";
	line = tt;
	RLOGD("set requestSIM_IO ^DRSM: 144,0 for test.--->xt.");
	#endif

    

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(sr.sw1));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(sr.sw2));
    if (err < 0) goto error;

    if (at_tok_hasmore(&line)) {
        err = at_tok_nextstr(&line, &(sr.simResponse));
        if (err < 0) goto error;
    }
    // added by xianglijun 1861_20150709-67063 for leadcore test icccard
    // haven't iccid start
    if ( p_args->command == COMMAND_READ_BINARY && p_args->fileid == EF_ICCID) {
        if (sr.sw1 == 0x90 && sr.simResponse != NULL) {
            int i = 0;
            while(sr.simResponse[i] != '\0' &&
                (sr.simResponse[i] == 'F' || sr.simResponse[i] == 'f'))
                i++;
            if (i >= 2 && sr.simResponse[i] == '\0') {
                memset(sr.simResponse, '0', i);
                U8_2_STR((s_rilID + 1), (&sr.simResponse[i -2]))
                DBBD(DB_RIL, RLOGD("SIM_IO ICCID is empty and overrid it with %s", sr.simResponse));
            }
        }
    }
    // added by xianglijun 1861_20150709-67063 end

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &sr, sizeof(sr));
    at_response_free(p_response);
   // return if no sim toolkit proactive command is ready
    if(sr.sw1 != 0x91)
        return;

fetch:
    asprintf(&cmd, "AT+CSIM=10,\"a0120000%02x\"", sr.sw2);
    err = at_send_command_singleline(cmd, "+CSIM:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto fetch_error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto fetch_error;

    err = at_tok_nextint(&line, &len);
    if (err < 0) goto fetch_error;

    err = at_tok_nextstr(&line, &(sr.simResponse));
    if (err < 0) goto fetch_error;

    sscanf(&(sr.simResponse[len - 4]), "%02x%02x", &(sr.sw1), &(sr.sw2));
    sr.simResponse[len - 4] = '\0';

    //RIL_onUnsolicitedResponse(RIL_UNSOL_STK_PROACTIVE_COMMAND, sr.simResponse, strlen(sr.simResponse));

    goto fetch_error;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);

fetch_error:
    at_response_free(p_response);
    free(cmd);
}

static void  requestSIM_OpenChannel(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    char *cmd = NULL;
    char *line;
    // TODO: dinamically allocate the buffer depending on response length
    int response[257];
    int response_length = 1;

    asprintf(&cmd, "AT+CCHO=\"%s\"", (char *)data);
    err = at_send_command_singleline(cmd, "+CCHO:", &p_response);

    if (err < 0 || p_response->success == 0) {
        if (!strcmp(p_response->finalResponse, "+CME ERROR: 20")) {
            err = RIL_E_MISSING_RESOURCE;
        }
        else if (!strcmp(p_response->finalResponse, "+CME ERROR: 22")) {//change not found to 22.22meas not found
            err = RIL_E_NO_SUCH_ELEMENT;
        }
        else {
            err = RIL_E_GENERIC_FAILURE;
        }
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    // Read channel number
    err = at_tok_nextint(&line, &response[0]);
    if (err < 0) goto error;

    // Read select response (if available)
    while (at_tok_hasmore(&line)) {
        err = at_tok_nextint(&line, &response[response_length]);
        if (err < 0) goto error;
        response_length++;
    }
    // Check that length == 1 (select response not present) or > 3 (valid APDU as select response)
    if (response_length != 1 && response_length < 3) {
        err = RIL_E_GENERIC_FAILURE;
        RLOGE("Invalid select response (length = %d)", response_length - 1);
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, response_length * sizeof(int));
    at_response_free(p_response);
    free(cmd);

    return;
error:
    RIL_onRequestComplete(t, err, NULL, 0);
    at_response_free(p_response);
    free(cmd);
}

static void  requestSIM_OpenChannel_WITH_P2(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    char *cmd = NULL;
    const char**  strings = (const char**)data;;
    char *line;
    // TODO: dinamically allocate the buffer depending on response length
    int response[257];
    int response_length = 1;
    asprintf(&cmd, "AT+CCHP=%s,%s", strings[0], strings[1]);
    err = at_send_command_singleline(cmd, "+CCHP:", &p_response);

    if (err < 0 || p_response->success == 0) {
        if (!strcmp(p_response->finalResponse, "+CME ERROR: 20")) {
            err = RIL_E_MISSING_RESOURCE;
        }
        else if (!strcmp(p_response->finalResponse, "+CME ERROR: 22")) {
            err = RIL_E_NO_SUCH_ELEMENT;
        }
        else {
            err = RIL_E_GENERIC_FAILURE;
        }
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    // Read channel number
    err = at_tok_nextint(&line, &response[0]);
    if (err < 0) goto error;

    // Read select response (if available)
    while (at_tok_hasmore(&line)) {
        err = at_tok_nextint(&line, &response[response_length]);
        if (err < 0) goto error;
        response_length++;
    }
    // Check that length == 1 (select response not present) or > 3 (valid APDU as select response)
    if (response_length != 1 && response_length < 3) {
        err = RIL_E_GENERIC_FAILURE;
        RLOGE("Invalid select response (length = %d)", response_length - 1);
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, response_length * sizeof(int));
    at_response_free(p_response);
    free(cmd);

    return;
error:
    RLOGE("strings error!");
    RIL_onRequestComplete(t, err, NULL, 0);
    at_response_free(p_response);
    free(cmd);
}

static void  requestSIM_CloseChannel(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    char *cmd = NULL;
    char *line;
    int channel;

    asprintf(&cmd, "AT+CCHC=%d", *(int *)data);
    err = at_send_command(cmd, &p_response);

    if (err < 0 || p_response->success == 0) {
        if (!strcmp(p_response->finalResponse, "+CME ERROR: INCORRECT PARAMETERS")) {
            err = RIL_E_INVALID_PARAMETER;
        }
        else {
            err = RIL_E_GENERIC_FAILURE;
        }
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    free(cmd);

    return;
error:
    RIL_onRequestComplete(t, err, NULL, 0);
    at_response_free(p_response);
    free(cmd);
}

static void  requestSIM_TransmitBasic(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    RIL_SIM_IO_Response sr;
    int err;
    char *cmd = NULL;
    RIL_SIM_APDU *p_args;
    char *line;
    int len;

    memset(&sr, 0, sizeof(sr));

    p_args = (RIL_SIM_APDU *) data;

    if ((p_args->data == NULL) || (strlen(p_args->data) == 0)) {
        if (p_args->p3 < 0) {
            asprintf(
                &cmd,
                "AT+CSIM=%d,\"%02x%02x%02x%02x\"",
                8,
                p_args->cla,
                p_args->instruction,
                p_args->p1,
                p_args->p2);
        } else {
            asprintf(
                &cmd,
                "AT+CSIM=%d,\"%02x%02x%02x%02x%02x\"",
                10,
                p_args->cla,
                p_args->instruction,
                p_args->p1,
                p_args->p2,
                p_args->p3);
        }
    } else {
        asprintf(
            &cmd,
            "AT+CSIM=%d,\"%02x%02x%02x%02x%02x%s\"",
            10 + strlen(p_args->data),
            p_args->cla,
            p_args->instruction,
            p_args->p1,
            p_args->p2,
            p_args->p3,
            p_args->data);
    }
    err = at_send_command_singleline(cmd, "+CSIM:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &len);
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &(sr.simResponse));
    if (err < 0) goto error;

    sscanf(&(sr.simResponse[len - 4]), "%02x%02x", &(sr.sw1), &(sr.sw2));
    sr.simResponse[len - 4] = '\0';

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &sr, sizeof(sr));
    at_response_free(p_response);
    free(cmd);

    // end sim toolkit session if 90 00 on TERMINAL RESPONSE
    if((p_args->instruction == 20) && (sr.sw1 == 0x90))
        RIL_onUnsolicitedResponse(RIL_UNSOL_STK_SESSION_END, NULL, 0);

    // return if no sim toolkit proactive command is ready
    if(sr.sw1 != 0x91)
        return;

fetch:
    asprintf(&cmd, "AT+CSIM=10,\"a0120000%02x\"", sr.sw2);
    err = at_send_command_singleline(cmd, "+CSIM:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto fetch_error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto fetch_error;

    err = at_tok_nextint(&line, &len);
    if (err < 0) goto fetch_error;

    err = at_tok_nextstr(&line, &(sr.simResponse));
    if (err < 0) goto fetch_error;

    sscanf(&(sr.simResponse[len - 4]), "%02x%02x", &(sr.sw1), &(sr.sw2));
    sr.simResponse[len - 4] = '\0';

    //RIL_onUnsolicitedResponse(RIL_UNSOL_STK_PROACTIVE_COMMAND, sr.simResponse, strlen(sr.simResponse));

    goto fetch_error;
error:
   RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
fetch_error:
   at_response_free(p_response);
   free(cmd);
}

static void  requestSIM_TransmitChannel(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    RIL_SIM_IO_Response sr;
    int err;
    char *cmd = NULL;
    RIL_SIM_APDU *p_args;
    char *line;
    int len;

    memset(&sr, 0, sizeof(sr));

    p_args = (RIL_SIM_APDU *)data;

    if ((p_args->data == NULL) || (strlen(p_args->data) == 0)) {
        if (p_args->p3 < 0) {
            asprintf(
                &cmd,
                "AT+CGLA=%d,%d,\"%02x%02x%02x%02x\"",
                p_args->sessionid,
                8,
                p_args->cla,
                p_args->instruction,
                p_args->p1,
                p_args->p2);
        } else {
            asprintf(
                &cmd,
                "AT+CGLA=%d,%d,\"%02x%02x%02x%02x%02x\"",
                p_args->sessionid,
                10,
                p_args->cla,
                p_args->instruction,
                p_args->p1,
                p_args->p2,
                p_args->p3);
        }
    } else {
        asprintf(
            &cmd,
            "AT+CGLA=%d,%d,\"%02x%02x%02x%02x%02x%s\"",
            p_args->sessionid,
            10 + strlen(p_args->data),
            p_args->cla,
            p_args->instruction,
            p_args->p1,
            p_args->p2,
            p_args->p3,
            p_args->data);
    }

    err = at_send_command_singleline(cmd, "+CGLA:", &p_response);

    if (err < 0 || p_response->success == 0) {
        if (!strcmp(p_response->finalResponse, "+CME ERROR: INCORRECT PARAMETERS")) {
            err = RIL_E_INVALID_PARAMETER;
        }
        else {
            err = RIL_E_GENERIC_FAILURE;
        }
        goto error;
    }

    line = p_response->p_intermediates->line;

    if (at_tok_start(&line) < 0
            || at_tok_nextint(&line, &len) < 0
            || at_tok_nextstr(&line, &(sr.simResponse)) < 0) {
        err = RIL_E_GENERIC_FAILURE;
        goto error;
    }

    sscanf(&(sr.simResponse[len - 4]), "%02x%02x", &(sr.sw1), &(sr.sw2));
    sr.simResponse[len - 4] = '\0';

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &sr, sizeof(sr));
    at_response_free(p_response);
    free(cmd);

    // end sim toolkit session if 90 00 on TERMINAL RESPONSE
    if((p_args->instruction == 20) && (sr.sw1 == 0x90))
        RIL_onUnsolicitedResponse(RIL_UNSOL_STK_SESSION_END, NULL, 0);

    // return if no sim toolkit proactive command is ready
    if(sr.sw1 != 0x91)
        return;

fetch:
    asprintf(&cmd, "AT+CSIM=10,\"a0120000%02x\"", sr.sw2);
    err = at_send_command_singleline(cmd, "+CSIM:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto fetch_error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto fetch_error;

    err = at_tok_nextint(&line, &len);
    if (err < 0) goto fetch_error;

    err = at_tok_nextstr(&line, &(sr.simResponse));
    if (err < 0) goto fetch_error;

    sscanf(&(sr.simResponse[len - 4]), "%02x%02x", &(sr.sw1), &(sr.sw2));
    sr.simResponse[len - 4] = '\0';

    //RIL_onUnsolicitedResponse(RIL_UNSOL_STK_PROACTIVE_COMMAND, sr.simResponse, strlen(sr.simResponse));

    goto fetch_error;
error:
    RIL_onRequestComplete(t, err, NULL, 0);
fetch_error:
    at_response_free(p_response);
    free(cmd);
}

static void  requestSIM_GetAtr(RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    char *line;
    char *response;

    err = at_send_command_singleline("AT^DATR?","^DATR:", &p_response);

   if (err < 0 || p_response->success == 0) {
        if (!strcmp(p_response->finalResponse, "+CME ERROR: ATR NOT FOUND")) {
            err = RIL_E_MISSING_RESOURCE;
        }
        else {
            err = RIL_E_GENERIC_FAILURE;
        }
        goto error;
    }

    line = p_response->p_intermediates->line;

    if (at_tok_start(&line) < 0) goto error;

    if (at_tok_nextstr(&line, &response) < 0) goto error;
    if (at_tok_nextstr(&line, &response) < 0) goto error;
    if (at_tok_nextstr(&line, &response) < 0) goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, strlen(response));
    at_response_free(p_response);

    return;
error:
    RIL_onRequestComplete(t, err, NULL, 0);
    at_response_free(p_response);
}

static void requestDataRegistrationState(int request, void *data,
        size_t datalen, RIL_Token t)
{
    int err;
    int response[4];
    char * responseStr[4];
    ATResponse *p_response = NULL;
    const char *cmd = "AT+CGREG?";
    const char *prefix = "+CGREG:";
    char *line, *p;
    int commas;
    int skip;
    int i = 0;

    err = at_send_command_singleline_timeout(cmd, prefix, 15000,  &p_response);// modify [by chenshu 2012-10-23] for Enh00000326

    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    /* Ok you have to be careful here
     * The solicited version of the CREG response is
     * +CREG: n, stat, [lac, cid]
     * and the unsolicited version is
     * +CREG: stat, [lac, cid]
     * The <n> parameter is basically "is unsolicited creg on?"
     * which it should always be
     *
     * Now we should normally get the solicited version here,
     * but the unsolicited version could have snuck in
     * so we have to handle both
     *
     * Also since the LAC and CID are only reported when registered,
     * we can have 1, 2, 3, or 4 arguments here
     *
     * finally, a +CGREG: answer may have a fifth value that corresponds
     * to the network type, as in;
     *
     *   +CGREG: n, stat [,lac, cid [,networkType]]
     */

    /* count number of commas */
    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }
    
    switch (commas) {
        case 1: /* +CGREG: <n>, <stat> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            response[1] = -1;
            response[2] = -1;
            response[3] = -1;
            if (err < 0) goto error;
            break;
        case 3: /* +CGREG: <n>, <stat>, <lac>, <cid> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[1]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[2]);
            response[3] = -1;
            if (err < 0) goto error;
            break;
        case 4: /* +CGREG: <n>, <stat>, <lac>, <cid>, <networkType> */
        case 5: /* +CGREG: <n>, <stat>, <lac>, <cid>, <networkType>, <rac> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[1]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[2]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[3]);
            if (err < 0) goto error;
            break;
        default:
            goto error;
    }

    // add [by chenshu 2013-04-04] for L1810_Req00001037
    if(response[0] == 4)
        response[0] = 1;
    // add [by chenshu 2013-04-04] end

    //mNetState = response[0];

    asprintf(&responseStr[0], "%d", response[0]);
    asprintf(&responseStr[1], "%x", response[1]);
    asprintf(&responseStr[2], "%x", response[2]);
    asprintf(&responseStr[3], "%d", getNetworkType(response[3]));

    at_response_free(p_response);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, 4 * sizeof(char*));

    for (i = 0; i < 4; i++) {
        free(responseStr[i]);
    }

    return;
error:
    RLOGE("request DataRegistrationState must never return an error when radio is on");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestVoiceRegistrationState(int request, void *data,
        size_t datalen, RIL_Token t)
{
    int err;
    int response[4];
    char *responseStr[4];
    //FIXME:we asume that every token of creg/cgreg reseponse is less than 31 bytes.
    //static char lastResponseRecords[4][32] = {{'\0'}, {'\0'}, {'\0'}, {'\0'}};
    ATResponse *p_response = NULL;
    const char *cmd = "AT+CREG?";
    const char *prefix = "+CREG";
    char *line, *p;
    int commas;
    int skip;
    int i = 0;

    if (cregTimer_id != 0) {
        /*modify by yuanhaobo for LARN_Bug00001032 @ 2014-1-9 begin*/
        //for (i = 0; i < 3; i++) {
        for (i = 0; i < 4; i++) {
            asprintf(&responseStr[i], "%s", lastResponseRecords[i]);
        }
        //RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, 3*sizeof(char*));
        RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, 4*sizeof(char*));
        //for (i = 0; i < 3; i++) {
        for (i = 0; i < 4; i++) {
            free(responseStr[i]);
            responseStr[i] = NULL;
        }
        /*modify by yuanhaobo for LARN_Bug00001032 @ 2014-1-9 end*/
        RLOGD("%d, return ", request);
        return;
    }

    err = at_send_command_singleline_timeout(cmd, prefix, 15000,  &p_response);// modify [by chenshu 2012-10-23] for Enh00000326
    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;
    /* Ok you have to be careful here
     * The solicited version of the CREG response is
     * +CREG: n, stat, [lac, cid]
     * and the unsolicited version is
     * +CREG: stat, [lac, cid]
     * The <n> parameter is basically "is unsolicited creg on?"
     * which it should always be
     *
     * Now we should normally get the solicited version here,
     * but the unsolicited version could have snuck in
     * so we have to handle both
     *
     * Also since the LAC and CID are only reported when registered,
     * we can have 1, 2, 3, or 4 arguments here
     *
     * finally, a +CGREG: answer may have a fifth value that corresponds
     * to the network type, as in;
     *
     *   +CGREG: n, stat [,lac, cid [,networkType]]
     */

    /* count number of commas */
    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }

    switch (commas) {
        case 1: /* +CREG: <n>, <stat> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            response[1] = -1;
            response[2] = -1;
            response[3] = -1;       /*add by yuanhaobo for LARN_Bug00001032 @ 2014-1-9*/
            if (err < 0) goto error;
            break;

            break;
        case 3: /* +CREG: <n>, <stat>, <lac>, <cid> */
        case 4: /* +CREG: <n>, <stat>, <lac>, <cid>, <ACT> */
            //we intend to ignore <ACT> in CREG request for that we
            //only concern voice state in framework.
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[1]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[2]);
            if (err < 0) goto error;
            /*add by yuanhaobo for LARN_Bug00001032 @ 2014-1-9 begin*/
            err = at_tok_nexthexint(&line, &response[3]);
            if (err < 0) goto error;
            /*add by yuanhaobo for LARN_Bug00001032 @ 2014-1-9 end*/
            break;
        default:
            goto error;
    }

    mNetState = response[0];
	RLOGD("requestVoiceRegistrationState response[0] = %d ,response[1] = %d, response[2] = %d",
		response[0],response[1],response[2]);
   	asprintf(&responseStr[0], "%d", response[0]);
   	asprintf(&responseStr[1], "%d", response[1]);
   	asprintf(&responseStr[2], "%d", response[2]);
   	asprintf(&responseStr[3], "%d", getNetworkType(response[3]));

    at_response_free(p_response);
	
    //RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, 3*sizeof(char*));
    RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, 4*sizeof(char*));

    for (i = 0; i < 4; i ++) {
        memset(lastResponseRecords[i], 0, 32);
        memcpy(lastResponseRecords[i], responseStr[i], strlen(responseStr[i]) + 1);
        free(responseStr[i]);
    }
    return;
error:
    RLOGE("request VoiceRegistrationState must never return an error when radio is on");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestGetIMSI(void *data, size_t datalen, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;

    err = at_send_command_singleline("AT+CIMI", "+CIMI:", &p_response);

    if (err < 0 || p_response->success == 0) {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    } else {
        char *line = p_response->p_intermediates->line;

        err = at_tok_start(&line);
        if (err < 0) {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        } else {
            while( ' ' == *line ) line++;
            RIL_onRequestComplete(t, RIL_E_SUCCESS, line, sizeof(char *));
            RLOGI("requestGetIMSI, get IMSI SUCCESS: line = %s", line);

            if (ril_config_st.m_rildCount > 1) {
                UINT8 imsiCount = 4;
                char propValue[4] = {0};

                if (__system_property_get(SYS_PROPERTY_RILD_GET_IMSI_COUNT, propValue) <= 0) {
                    RLOGE("requestGetIMSI, get system property rild.enter.pin.count error !!!!!");
                }

                RLOGI("requestGetIMSI, imsiCount = %s, ril_config_st.m_cardLocale = %d, s_rilID = %d",
                    propValue, ril_config_st.m_cardLocale, s_rilID);

                imsiCount = (UINT8)(propValue[0] - '0');
                if (imsiCount == 4 || (imsiCount & ((UINT8)0x1 << s_rilID)) == 0 ) {
                    goto done;
                }

                imsiCount &= ~((UINT8)0x1 << s_rilID);
                RLOGI("requestGetIMSI, imsiCount = %d", imsiCount);
                if ((imsiCount & 0x03) == 0) {
                    if ((CARD_STATUS_EXIST == ril_config_st.m_cardStatus && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus)
                        && (CARD_LOCALE_UNKNOWN == ril_config_st.m_cardLocale || CARD_LOCALE_UNKNOWN == ril_config_st.m_otherCardLocale)) {
                        ril_config_st.m_cardLocale = getLocaleOfSim(line);
                        RLOGI("requestGetIMSI, ril_config_st.m_cardLocale = %d", ril_config_st.m_cardLocale);
                        __system_property_set("ctl.restart", "radio_config");
                        RLOGI("restart radio_config for update IMSI, insert two (U)SIM card.");
                    } else if (CARD_LOCALE_UNKNOWN == ril_config_st.m_cardLocale 
                        && ((CARD_STATUS_ABSENT == ril_config_st.m_cardStatus && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus)
                        || (CARD_STATUS_EXIST == ril_config_st.m_cardStatus && CARD_STATUS_ABSENT == ril_config_st.m_otherCardStatus))) {
                        ril_config_st.m_cardLocale = getLocaleOfSim(line);
                        RLOGI("requestGetIMSI, ril_config_st.m_cardLocale = %d", ril_config_st.m_cardLocale);
                        __system_property_set("ctl.restart", "radio_config");
                        RLOGI("restart radio_config for update IMSI, insert one (U)SIM card.");
                    }
                    __system_property_set(SYS_PROPERTY_RILD_GET_IMSI_COUNT, "4");
                } else {
                    if(CARD_LOCALE_UNKNOWN == ril_config_st.m_cardLocale) {
                        ril_config_st.m_cardLocale = getLocaleOfSim(line);
                        RLOGD("requestGetIMSI, ril_config_st.m_cardLocale = %d", ril_config_st.m_cardLocale);
                    }
                    memset(propValue, 0, sizeof(propValue));
                    sprintf(propValue, "%d", imsiCount);
                    __system_property_set(SYS_PROPERTY_RILD_GET_IMSI_COUNT, propValue);
                }
            }
        }
    }
done:
    at_response_free(p_response);
}

static void requestGetIMEI(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *line;
    ATResponse *p_response = NULL;

    err = at_send_command_singleline("AT+CGSN", "+CGSN:",&p_response);

    if (err < 0 || p_response->success == 0) {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    } else {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if(err < 0) {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        } else {
            RIL_onRequestComplete(t, RIL_E_SUCCESS, ++line, sizeof(char *));
        }
    }
    at_response_free(p_response);
}

static void requestGetIMEISV(void *data, size_t datalen, RIL_Token t)
{
    int err, midType;
    char *line;
    ATResponse *p_response = NULL;
    char *sv;

    err = at_send_command_singleline("AT^DCMI=4", "^DCMI:",&p_response);

    if (err < 0 || p_response->success == 0) {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    } else {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if(err < 0) {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        } else {
            err = at_tok_nextint(&line,&midType);
            if (err < 0 || midType != 4) {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
            } else {
                err = at_tok_nextstr(&line,&sv);
                if (err < 0) {
                    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
                } else {
                    RIL_onRequestComplete(t, RIL_E_SUCCESS, sv, sizeof(char *));
                }
            }
        }
    }

    at_response_free(p_response);
}

/*
  * <2012-1-11, lierqiang, add for Bug00005597 request emergency number begin>
  * Get emergency numbers with "AT^DPBE", and store the emergency numbers 
  * in a system property that named "ril.ecclist"
  */
static void getEmergencyNumber(void *param)
{
    int err = 0;
    char *line= NULL;
    char emergency_number_str[200];
    char *ptr1 = NULL;
    char *ptr2 = NULL;
    ATResponse *p_response = NULL;
    ATLine *p_intermediates = NULL;

    err = at_send_command_multiline("AT^DPBE", "^DPBE:",&p_response);

    if(err < 0 || p_response->success == 0)
    {
        RLOGD(("error: at_send_command_multiline()"));
    }
    else
    {
/* FIX L1860_Enh00000040 by zoufeng, 20140326 begin */
        if(p_response == NULL || p_response->p_intermediates == NULL || p_response->p_intermediates->line == NULL)
        {
            goto end;
        }
/* FIX L1860_Enh00000040 by zoufeng, 20140326 end */

        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (0 == err)
        {
            ptr1= line;
            err = at_tok_nextstr(&ptr1, &ptr2);
            err |= at_tok_nextstr(&ptr1, &ptr2);
            if(err < 0)
            {
                goto end;
            }
            strcpy(emergency_number_str, ptr2);
            p_intermediates = p_response->p_intermediates;
            while(p_intermediates->p_next != NULL)
            {
                strcat(emergency_number_str,",");
                p_intermediates = p_intermediates->p_next;
                line = p_intermediates->line;
                err = at_tok_start(&line);
                if(err < 0)
                {
                    goto end;
                }
                else
                {
                    ptr1= line;
                    err = at_tok_nextstr(&ptr1, &ptr2);
                    err |= at_tok_nextstr(&ptr1, &ptr2);
                    if(err < 0)
                    {
                        goto end;
                    }
                    strcat(emergency_number_str, ptr2);
                }
            }
            // modify [by chenshu 2012-08-03] for fix Bug00000964
            /*original code
            err = property_set("ril.ecclist", emergency_number_str);
            */
            //Add by guojing for MIUI requirement 20141121-36736.
            RLOGD(("Check emergency for 110,119,120"));

            if (!strstr(emergency_number_str,"110")) {
                strcat(emergency_number_str, ",110");
            }
            if (!strstr(emergency_number_str,"119")) {
                strcat(emergency_number_str, ",119");
            }
            if (!strstr(emergency_number_str,"120")) {
                strcat(emergency_number_str, ",120");
            }

            RLOGD("linkID = %d", s_rilID);
            if(s_rilID == 0) {
                err = property_set("ril.ecclist", emergency_number_str);
            }else {
                err = property_set("ril.ecclist1", emergency_number_str);
            }
            // modify [by chenshu 2012-08-03] end
            if(err < 0) {
                RLOGD(("set property ril.ecclist error"));
            }
        }
    }

end:
    at_response_free(p_response);
    //return ret;
}
//<2012-1-11, lierqiang, add for request emergency number end>


//<UH, 2011-02-16, lifangdong, convert hex string to asc string./>
int hex_str_to_asc_str(char *input_string, unsigned long int input_len, char *output_string, unsigned long int *output_len)
{
    unsigned long int loop_i;
    char output_char;
    unsigned long int temp_output_len;
    char input_char;

    if (NULL == input_string
     || NULL== output_string
     || NULL == output_len)
    {
        return -1;
    }

    if (0 != input_len % 2)
    {
        return -1;
    }

    temp_output_len = 0;

    while ((0 != input_len) && ('\0' != *input_string))
    {
        output_char = 0;

        for (loop_i = 0; loop_i < 2; loop_i++)
        {
            output_char = output_char << 4;
            input_char = toupper(*input_string);

            if ((input_char >= 'A') && (input_char <= 'F'))
            {
                output_char = output_char + input_char - 'A' + 10;
            }
            else if ((input_char >= '0') && (input_char <= '9'))
            {
                output_char = output_char + input_char - '0';
            }
            else
            {
                return -1;
            }

            input_string++;
        }

        *output_string = output_char;

        output_string++;
        temp_output_len ++;
        input_len = input_len - 2;
    }

    *output_len = temp_output_len;

    return 0;
}

static void requestGetSMSCAddress(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *line;
    char *cscaResult;
    ATResponse *p_response = NULL;

    //<UH, 2011-02-16, lifangdong, convert hex string to asc string./>
    char asc_buf[60] = {0}; /*L1809_Bug00005589,Fixed by chenchi,20120110 */
    unsigned long int asc_len = 0;

    err = at_send_command_singleline("AT+CSCA?", "+CSCA:", &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    } else {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if(err < 0) {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        } else {
            err = at_tok_nextstr(&line, &cscaResult);

        //<UH, 2011-02-16, lifangdong, convert hex string to asc string./>
        hex_str_to_asc_str(cscaResult, strlen(cscaResult), asc_buf, &asc_len);
        cscaResult = asc_buf;

            RIL_onRequestComplete(t, RIL_E_SUCCESS, cscaResult, sizeof(char *));
        }
    }

    at_response_free(p_response);
    p_response = NULL;
    cscaResult = NULL;
    return;

error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}


static void requestSetGps(void *data, size_t datalen, RIL_Token t)
{
    int err;
    const char *gps;
    char *cmd = NULL;
    ATResponse *p_response = NULL;
    RIL_GPS* p_args = NULL;
    p_args = (RIL_GPS*)data;
    RLOGD("=====setgps=modem = %d , %s",p_args->mode, p_args->gpsData);
    asprintf(&cmd,"AT^DGPS=%d,\"%s\"",p_args->mode,p_args->gpsData);
    //<UH, 2011-02-16, lifangdong, convert hex string to asc string./>
    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err != 0 || p_response->success == 0) {
        RLOGD("[gps]set gps err : %d", err) ;
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS,  NULL, 0);
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestSetSMSCAddress(void *data, size_t datalen, RIL_Token t)
{
    int err;
    const char *smsc;
    char *cmd = NULL;
    ATResponse *p_response = NULL;

    //<UH, 2011-02-16, lifangdong, convert hex string to asc string./>    
    char hex_buf[60] = {0}; /*L1809_Bug00005589,Fixed by chenchi,20120110 */

    smsc = (const char *)data;

    //<UH, 2011-02-16, lifangdong, convert hex string to asc string./>
    ascToHex(smsc, strlen(smsc), hex_buf);
    smsc = hex_buf;
    
    asprintf(&cmd, "AT+CSCA=\"%s\"", smsc);
    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err != 0 || p_response->success == 0) {
        RLOGD("[SMSC]set smsc err : %d", err) ;
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS,  NULL, 0);
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestSMSMemoryStatus(void *data, size_t datalen, RIL_Token t)
{
    int ackSuccess;

    ackSuccess = ((int *)data)[0];
    if (ackSuccess == 1) {
        at_send_command("AT^DMMNA=2", NULL);
    } else if (ackSuccess == 0)  {
        at_send_command("AT^DMMNA=3", NULL);
    } else {
        RLOGE("unsupported arg to RIL_REQUEST_REPORT_SMS_MEMORY_STATUS\n");
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;
error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestSMSAcknowledge(void *data, size_t datalen, RIL_Token t)
{
    int ackSuccess;

    ackSuccess = ((int *)data)[0];
    if (ackSuccess == 1) {
        // add [by chenshu 2012-12-25] for fix Bug00002424
        if(indexOfSmsOnSimCard > 0) {
            DBBD(DB_RIL, RLOGD("[class 2 SMS]ignore CNMA [index = %d]", indexOfSmsOnSimCard));
        } else
        // add [by chenshu 2012-12-25] end
        at_send_command("AT+CNMA=1", NULL);
    } else if (ackSuccess == 0)  {
        at_send_command("AT+CNMA=2", NULL);
    } else {
        RLOGE("unsupported arg to RIL_REQUEST_SMS_ACKNOWLEDGE\n");
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestAcknowledgeIncomingGsmSMSWithPdu(void *data, size_t datalen, RIL_Token t)
{
    int ackSuccess;
    const char *ackPdu = NULL;
    char *cmd = NULL;
    ATResponse *p_response = NULL;

    RLOGD("requestAcknowledgeIncomingGsmSMSWithPdu");
    RLOGD("requestAcknowledgeIncomingGsmSMSWithPdu, data[0] = %s", ((const char **)data)[0]);
    ackSuccess = (strcmp(((const char **)data)[0],'1')?1:0);
    RLOGD("requestAcknowledgeIncomingGsmSMSWithPdu, ackSuccess = %d", ackSuccess);
    ackPdu = ((const char **)data)[1];
    RLOGD("requestAcknowledgeIncomingGsmSMSWithPdu, ackPdu = %s", ackPdu);
    if (NULL == ackPdu)
    {
        RLOGE("NULL == ackPdu");
        return requestSMSAcknowledge(data, datalen, t);
    }

    RLOGD("ackPdu = %s", ackPdu);
    if (1 == ackSuccess)
    {
        asprintf(&cmd, "AT+CNMA=1,%d", strlen(ackPdu)/2);
        RLOGD("cmd = %s", cmd);
        at_send_command_sms(cmd, ackPdu, NULL, &p_response);
    }
    else if (0 == ackSuccess)
    {
        asprintf(&cmd, "AT+CNMA=2,%d", strlen(ackPdu)/2);
        RLOGD("cmd = %s", cmd);
        at_send_command_sms(cmd, ackPdu, NULL, &p_response);
    }
    else
    {
        RLOGE("unsupported arg to RIL_REQUEST_ACKNOWLEDGE_INCOMING_GSM_SMS_WITH_PDU");
        goto error;
    }

    if(cmd != NULL)
    {
        free(cmd);
        cmd = NULL;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestCdmaSendSMS(void *data, size_t datalen, RIL_Token t)
{
    int err = 1; // Set to go to error:
    RIL_SMS_Response response;
    RIL_CDMA_SMS_Message* rcsm;

    RLOGD("requestCdmaSendSMS datalen=%d, sizeof(RIL_CDMA_SMS_Message)=%d",
            datalen, sizeof(RIL_CDMA_SMS_Message));

    // verify data content to test marshalling/unmarshalling:
    rcsm = (RIL_CDMA_SMS_Message*)data;
    RLOGD("TeleserviceID=%d, bIsServicePresent=%d, \
            uServicecategory=%d, sAddress.digit_mode=%d, \
            sAddress.Number_mode=%d, sAddress.number_type=%d, ",
            rcsm->uTeleserviceID,  rcsm->bIsServicePresent,
            rcsm->uServicecategory,rcsm->sAddress.digit_mode,
            rcsm->sAddress.number_mode,rcsm->sAddress.number_type);

    if (err != 0) goto error;

    // Cdma Send SMS implementation will go here:
    // But it is not implemented yet.

    memset(&response, 0, sizeof(response));
    response.messageRef = 1;
    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(response));
    return;

error:
    // Cdma Send SMS will always cause send retry error.
    response.messageRef = -1;
    RIL_onRequestComplete(t, RIL_E_SMS_SEND_FAIL_RETRY, &response, sizeof(response));
}

static void requestSendSMS(void *data, size_t datalen, RIL_Token t)
{
    int err;
    const char *smsc;
    const char *pdu;
    int tpLayerLength;
    char *cmd1, *cmd2;
    RIL_SMS_Response response;
    ATResponse *p_response = NULL;
    char *line;
    int retryCount = 3;
    int i;

    smsc = ((const char **)data)[0];
    pdu = ((const char **)data)[1];

    tpLayerLength = strlen(pdu)/2;

    // "NULL for default SMSC"
    if (smsc == NULL) {
        smsc= "00";
    }

    asprintf(&cmd1, "AT+CMGS=%d", tpLayerLength);
    asprintf(&cmd2, "%s%s", smsc, pdu);

    for (i = 0; i < retryCount; i++) {
        err = at_send_command_sms(cmd1, cmd2, "+CMGS:", &p_response);
        if (err != 0 || p_response->success == 0) {
            RLOGD("[SMS]err = %d", err);
            if (i >= retryCount -1) {
                goto error;
            } else {
                continue;
            }
        }

        memset(&response, 0, sizeof(response));

        line = p_response->p_intermediates->line;

        RLOGD("[SMS] RES = %s", line);
        err = at_tok_start(&line); /*add by chenchi , for sms response value*/
        if (err < 0 ) {
            if (i >= retryCount - 1) {
                goto error;
            } else {
                continue;
            }
        }

	    RLOGD("[SMS] err ! = %d", err);
	
        err = at_tok_nextint(&line, &response.messageRef);
        if (err < 0) {
            if (i >= retryCount - 1) {
                goto error;
            } else {
                continue;
            }
        }

        break;
    }
    RLOGD("[SMS]response.messageRef(%d)", response.messageRef);

    if (NULL != cmd1) {
        free(cmd1);
        cmd1 = NULL;
    }
    
    if (NULL != cmd2) {
        free(cmd2);
        cmd2 = NULL;
    }
    response.ackPDU = NULL;
    response.errorCode = 0;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(response));
    at_response_free(p_response);

    return;
error:
//fixed Req00000402 by zhushasha 20110817
//    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    if (NULL != cmd1) {
        free(cmd1);
        cmd1 = NULL;
    }
    
    if (NULL != cmd2) {
        free(cmd2);
        cmd2 = NULL;
    }

    RIL_onRequestComplete(t, RIL_E_SMS_SEND_FAIL_RETRY, NULL, 0); 
//fixed end
    at_response_free(p_response);
}

static void requestImsSendSMS(void *data, size_t datalen, RIL_Token t)
{
    RIL_IMS_SMS_Message *p_args;
    RIL_SMS_Response response;

    memset(&response, 0, sizeof(response));

    RLOGD("requestImsSendSMS: datalen=%d, "
        "registered=%d, service=%d, format=%d, ims_perm_fail=%d, "
        "ims_retry=%d, gsm_fail=%d, gsm_retry=%d",
        datalen, s_ims_registered, s_ims_services, s_ims_format,
        s_ims_cause_perm_failure, s_ims_cause_retry, s_ims_gsm_fail,
        s_ims_gsm_retry);

    // figure out if this is gsm/cdma format
    // then route it to requestSendSMS vs requestCdmaSendSMS respectively
    p_args = (RIL_IMS_SMS_Message *)data;

    if (0 != s_ims_cause_perm_failure ) goto error;

    // want to fail over ims and this is first request over ims
    if (0 != s_ims_cause_retry && 0 == p_args->retry) goto error2;

    if (RADIO_TECH_3GPP == p_args->tech) {
        return requestSendSMS(p_args->message.gsmMessage,
                datalen - sizeof(RIL_RadioTechnologyFamily),
                t);
    } else if (RADIO_TECH_3GPP2 == p_args->tech) {
        return requestCdmaSendSMS(p_args->message.cdmaMessage,
                datalen - sizeof(RIL_RadioTechnologyFamily),
                t);
    } else {
        RLOGE("requestImsSendSMS invalid format value =%d", p_args->tech);
    }

error:
    response.messageRef = -2;
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &response, sizeof(response));
    return;

error2:
    response.messageRef = -1;
    RIL_onRequestComplete(t, RIL_E_SMS_SEND_FAIL_RETRY, &response, sizeof(response));
}

static void requestHangupWaitingOrBackground(void *data, size_t datalen, RIL_Token t)
{
    // 3GPP 22.030 6.5.5
    // "Releases all held calls or sets User Determined User Busy
    //  (UDUB) for a waiting call."
    at_send_command("AT+CHLD=0", NULL);

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void requestHangupForegroudResumeBackground(void *data, size_t datalen, RIL_Token t)
{
    // 3GPP 22.030 6.5.5
    // "Releases all active calls (if any exist) and accepts
    //  the other (held or waiting) call."
    at_send_command("AT+CHLD=1", NULL);

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void requestSwitchWaitingOrHoldingAndActive(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    // 3GPP 22.030 6.5.5
    // "Places all active calls (if any exist) on hold and accepts
    //  the other (held or waiting) call."
    // modify [by chenshu 2012-11-09] for fix [Bug00002035]
    /*original code
    at_send_command("AT+CHLD=2", NULL);
    */
    err = at_send_command("AT+CHLD=2", &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    }
    // modify [by chenshu 2012-11-09] end
#ifdef WORKAROUND_ERRONEOUS_ANSWER
    s_expectAnswer = 1;
#endif /* WORKAROUND_ERRONEOUS_ANSWER */

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    return;
error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestAnswer(void *data, size_t datalen, RIL_Token t)
{
    at_send_command("ATA", NULL);

#ifdef WORKAROUND_ERRONEOUS_ANSWER
    s_expectAnswer = 1;
#endif /* WORKAROUND_ERRONEOUS_ANSWER */

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void requestConference(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    // 3GPP 22.030 6.5.5
    // "Adds a held call to the conversation"
    // modify [by chenshu 2012-11-09] for fix [Bug00002035]
    /*original code
    at_send_command("AT+CHLD=3", NULL);
    */
    err = at_send_command("AT+CHLD=3", &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    }
    // modify [by chenshu 2012-11-09] end
    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    return;
error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestUdub(void *data, size_t datalen, RIL_Token t)
{
    /* user determined user busy */
    /* sometimes used: ATH */
    at_send_command("ATH", NULL);

    /* success or failure is ignored by the upper layer here.
       it will call GET_CURRENT_CALLS and determine success that way */
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void requestSeparateConnection(void *data, size_t datalen, RIL_Token t)
{
    char  cmd[12];
    int   party = ((int*)data)[0];
    ATResponse *p_response = NULL;

    // Make sure that party is in a valid range.
    // (Note: The Telephony middle layer imposes a range of 1 to 7.
    // It's sufficient for us to just make sure it's single digit.)
    if (party > 0 && party < 10) {
        int err;
        sprintf(cmd, "AT+CHLD=2%d", party);
        // modify [by chenshu 2012-11-09] for fix [Bug00002035]
        /*original code
        at_send_command(cmd, NULL);
        */
        err = at_send_command(cmd, &p_response);
        if (err < 0 || p_response->success == 0) {
            goto error;
        }
        // modify [by chenshu 2012-11-09] end
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
        at_response_free(p_response);
        return;
    }
error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestSignalStrength(void *data __unused, size_t datalen __unused, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err;
    char *line;
    int temp;
    int response[14] = {99, 99,-1,-1,-1,-1,-1,99,INT_MAX,INT_MAX,INT_MAX,INT_MAX, INT_MAX, INT_MAX};  //modifed by jiangxuqin1014 for 20150729-69327

    //add by zhangfei for L1860_20160318-90392//
    RIL_SIM_IO_Response sr;
    char *cmd = NULL;
    int len;
    //add by zhangfei for L1860_20160318-90392//

	#ifdef RILTEST1
	response[0] = 50;
	response[13] = 150;
	RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
	RLOGE("requestSignalStrength RILTEST return 50");
	return ;
	#endif

    err = at_send_command_singleline("AT+CSQ", "+CSQ:", &p_response);

    if (err < 0 || p_response->success == 0) {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(temp));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[1]));
    if (err < 0) goto error;

    if(temp >= 400)  temp -= 200;

    RLOGD("Signalstrength=(%d, %d)\n",temp,response[1]);

    if(temp>=SIGNAL_STRENGTH_GSM_START&&temp<SIGNAL_STRENGTH_TD_START){
        response[0] = temp;
        RLOGD("unsolgetSignalStrength response[0] = %d\n",response[0]);
    }
    else if(temp>=SIGNAL_STRENGTH_TD_START&&temp<SIGNAL_STRENGTH_LTE_START){
        response[13] = (SIGNAL_STRENGTH_GSM_OFFSET - temp);
        RLOGD("unsolgetSignalStrength response[13] = %d\n",response[13]);
    }
    else if(temp>=SIGNAL_STRENGTH_LTE_START&&temp<SIGNAL_STRENGTH_LTE_END){
        response[8] = (SIGNAL_STRENGTH_LTE_OFFSET - temp);
        RLOGD("unsolgetSignalStrength response[8] = %d\n",response[8]);
    }
    else{
        response[0] = temp;
        RLOGD("unsolgetSignalStrength response[0] = %d\n",response[0]);
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
    //add by zhangfei for L1860_20160318-90392//
    sim_status:
    err = at_send_command_singleline("AT+CSIM=10,\"a0f2000002\"", "+CSIM:",
            &p_response);

    if (err < 0 || p_response->success == 0) {
        goto sim_error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto sim_error;

    err = at_tok_nextint(&line, &len);
    if (err < 0) goto sim_error;

    err = at_tok_nextstr(&line, &(sr.simResponse));
    if (err < 0) goto sim_error;

    sscanf(&(sr.simResponse[len - 4]), "%02x%02x", &(sr.sw1), &(sr.sw2));
    sr.simResponse[len - 4] = '\0';

    if(sr.sw1 != 0x91)
        goto sim_error;

sim_fetch:
    asprintf(&cmd, "AT+CSIM=10,\"a0120000%02x\"", sr.sw2);
    err = at_send_command_singleline(cmd, "+CSIM:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto sim_error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto sim_error;

    err = at_tok_nextint(&line, &len);
    if (err < 0) goto sim_error;

    err = at_tok_nextstr(&line, &(sr.simResponse));
    if (err < 0) goto sim_error;

    sscanf(&(sr.simResponse[len - 4]), "%02x%02x", &(sr.sw1), &(sr.sw2));
    sr.simResponse[len - 4] = '\0';

    //RIL_onUnsolicitedResponse(RIL_UNSOL_STK_PROACTIVE_COMMAND, sr.simResponse,strlen(sr.simResponse));
sim_error:
    if (cmd != NULL) free(cmd);
//add by zhangfei for L1860_20160318-90392//
    at_response_free(p_response);
    return;

error:
    RLOGE("requestSignalStrength must never return an error when radio is on");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static int getACTmode()
{
	if(g_modemtype_s==0){
	    int err;
	    int actmode = -1;
	    ATResponse *p_response = NULL;
	    const char *cmd;
	    const char *prefix;
	    char *line, *p;
	    int commas = -1;
	    int skip;

	    cmd = "AT^DACTI?";
	    prefix = "^DACTI:";

	    err = at_send_command_singleline(cmd, prefix, &p_response);
	/* FIX L1809OG_Bug00000407 2011-01-31 zoufeng begin */
	//    if (err != 0) goto error;
	    if (err != 0 || p_response->success == 0) goto error;
	/* FIX L1809OG_Bug00000407 2011-01-31 zoufeng end */

	    line = p_response->p_intermediates->line;

	    err = at_tok_start(&line);
	    if (err < 0) goto error;
	    commas = 0;
	    for (p = line ; *p != '\0' ;p++) {
	        if (*p == ',') commas++;
	    }

	    switch (commas) {
	        case 1:
	            err = at_tok_nextint(&line, &skip);
	            if (err < 0) goto error;
	            err = at_tok_nextint(&line, &actmode);
	            if (err < 0) goto error;
	            break;
	        default:
	            goto error;
	    }
	    at_response_free(p_response);
	    //RLOGD("getACTmode: actmode = %d", actmode);
	    return actmode;
	error:
	    at_response_free(p_response);
	    RLOGD("getACTmode: error, return -1, commas = %d", commas);
	    return -1;
	}else {
		RLOGD("getACTmode: In satellite mode, return 2.");
		return 2;
	}
}

static int getNetworkType(int actMode)
{
    int err;
    unsigned char gprs_stat, egprs_stat, hsdpa_stat, hsupa_stat, hspap_stat;
    ATResponse *p_response = NULL;
    const char *cmd;
    const char *prefix;
    char *line;
    int networktype = 0;

    RLOGD("**getNetworkType, actmode = %d", actMode);
    if(actMode < 0 || actMode > 2)
    {
        actMode = getACTmode();
    }
    if(2 == g_actmode) {
        networktype = RADIO_TECH_HSDPA;
    }
    else {
        networktype = RADIO_TECH_EDGE;
    }
	RLOGD("getNetworkType,networktype = %d", networktype);
    return networktype;

}

int inOperatorGetState = 0;

static void requestOperatorLte(void *data, size_t datalen, RIL_Token t)
{
    int err;
    int i, j;
    int skip;
    ATLine *p_cur;
    char *resOper[3];
	if(inOperatorGetState == 1) {
		RLOGD("Already in operator get state!");
		return;
	}
	inOperatorGetState = 1;
    //FIXME:we assume that every token of +COPS response is less than 63 bytes.
    static char lastOperatorRecords[3][64] = {{0}, {0}, {0}};
    char *response[3];

    if (cregTimer_id != 0) {
        RLOGD("requestOperator, return");
        for(i = 0; i < 3; i++) {
            if (!strncmp(lastOperatorRecords[i], "", 1)) {
                resOper[i] = NULL;
            } else {
                asprintf(&resOper[i], "%s", lastOperatorRecords[i]);
            }
        }

        RIL_onRequestComplete(t, RIL_E_SUCCESS, resOper, sizeof(resOper));

        for (i = 0; i < 3; i++) {
            if (NULL != resOper[i]) {
                free(resOper[i]);
                resOper[i] = NULL;
            }
        }

        return;
    }

    memset(response, 0, sizeof(response));

	#ifdef RILTEST3
	resOper[0] = "CHINA LANCE";
	resOper[1] = "TT";
	resOper[2] = "46055";
	RIL_onRequestComplete(t, RIL_E_SUCCESS, resOper, sizeof(resOper));
	RLOGD("requestOperator: return CHINA LANCE,TT,46055");
	#endif

    ATResponse *p_response = NULL;
    err = at_send_command_multiline(
            "AT+COPS=3,0;+COPS?;+COPS=3,1;+COPS?;+COPS=3,2;+COPS?",
            "+COPS:", &p_response);

    if (err != 0 || p_response->success == 0) {
		RLOGD("SNED COPS FAILED");
		goto error;
    }
    for (i = 0, p_cur = p_response->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next, i++)
    {
        char *line = p_cur->line;
		
		RLOGD("P_CUR = %s", line);
		
        err = at_tok_start(&line);
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &skip);
        if (err < 0) goto error;

        // If we're unregistered, we may just get a "+COPS: 0" response
        if (!at_tok_hasmore(&line)) {
            response[i] = NULL;
            continue;
        }

        err = at_tok_nextint(&line, &skip);
        if (err < 0) goto error;

        // a "+COPS: 0, n" response is also possible
        if (!at_tok_hasmore(&line)) {
            response[i] = NULL;
            continue;
        }

        err = at_tok_nextstr(&line, &(response[i]));
        if (err < 0) goto error;

        if (!at_tok_hasmore(&line)) {
            response[i] = NULL;
            continue;
        }

        err = at_tok_nextint(&line, &skip);
        if (err < 0) goto error;

        if (i == 2 && NULL != response[i])
        {
            int plmn_id = atoi(response[i]);
            int ret;

            RLOGD("requestOperator: response[0] = %s, response[1] = %s", response[0], response[1]);
            if (NULL == response[0] || NULL == response[1]) {
                RLOGD("requestOperator: get plmn info from plmn.txt");
                // TODO fix me
                ret = 0/*get_plmn_name(plmn_id, (const char **)(&response[1]), (const char **)(&response[0]))*/;
            } else {
                ret = 0;
                RLOGD("requestOperator: get plmn info from AT command");
            }

            if (0 == ret)
            { //add 46055 by nick for satellite.
                if (46000 == plmn_id || 46002 == plmn_id || 46007 == plmn_id ||46008 == plmn_id ||46055 == plmn_id)//add 46008 by guojing for 20141215-40914,2014-12-16
                {
                    if (skip == 2)
                    {
                    	if(g_modemtype_s == 0){
                        response[0] = "CHINA  MOBILE 3G";
                    		}else {
							response[0] = "CHINA LANCE";
                    			}
                        g_actmode = 2;
                    }
#if defined(OPT_4G)
                    else if (skip == 7)
                    {
                        response[0] = "CHINA  MOBILE 4G";
                        g_actmode = 7;
                    }
#endif
                    else
                    {
                        g_actmode = 0;
                    }
                }            	
				
            }
            else
            {
                RLOGE("requestOperator: fail to get plmn name!!!!!");
                response[0] = response[i];
            }

            if (NULL != response[0])
                RLOGD("long plmn: %s", response[0]);
            else
                RLOGD("requestOperator: response[0] is NULL");

            if (NULL != response[1])
                RLOGD("short plmn: %s", response[1]);
            else
                RLOGD("requestOperator: response[1] is NULL");

            if (NULL != response[2])
                RLOGD("plmn id: %s", response[2]);
            else
                RLOGD("requestOperator: response[2] is NULL");
        }

        RLOGD("===> requestOperator,%s,skip = %d, i =%d\n",response[i],skip,i);
    }

	RLOGD("####requestOperator i = %d", i);
    if (i != 3) {
        /* expect 3 lines exactly */
        goto error;
    }

    for (j = 0; j < 3; j++) {
        if (response[j] == NULL) {
            resOper[j] = NULL;
        } else {
            asprintf(&resOper[j], "%s", response[j]);
        }
        memset(lastOperatorRecords[j], 0, 64);
        memcpy(lastOperatorRecords[j], (resOper[j] == NULL) ? "" : resOper[j], strlen((resOper[j] == NULL) ? "" :resOper[j]) + 1);
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, resOper, sizeof(resOper));
    for (j = 0; j < 3; j++) {
        if (NULL != resOper[j]) {
            free(resOper[j]);
            resOper[j] = NULL;
        }
    }

    at_response_free(p_response);
	inOperatorGetState = 0;
    return;
    
error:
    RLOGE("requestOperator must not return error when radio is on");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
	inOperatorGetState = 0;
}

static int parse_cops(char* line, char** response, int* skip){
	int err = 0;
	err = at_tok_start(&line);
        if (err < 0) return  -1;
        err = at_tok_nextint(&line, skip);
        if (err < 0) return -1;
        // If we're unregistered, we may just get a "+COPS: 0" response
        if (!at_tok_hasmore(&line)) {
            *response = NULL;
            return 0;
        }

        err = at_tok_nextint(&line, skip);
        if (err < 0) return -1;
		
        // a "+COPS: 0, n" response is also possible
        if (!at_tok_hasmore(&line)) {
            *response = NULL;	
            return 0;
        }
        err = at_tok_nextstr(&line, response);
        if (err < 0) return -1;
			
        if (!at_tok_hasmore(&line)) {
            *response = NULL;
            return 0;
        }

        err = at_tok_nextint(&line, skip);
        if (err < 0) {
			RLOGD("####requestOperator at_tok_nextint FAILUE, err= %d", err);
			return  -1;
        }

		RLOGD("parse_cops, Response = %s", *response);
		return 0;
}

static void requestOperatorS(void *data, size_t datalen, RIL_Token t) {
	int err;
    int i, j;
    int skip;
    ATLine *p_cur;
    char *resOper[3];
	//if(inOperatorGetState == 1) {
		//RLOGD("Already in operator get state!");
		//return;
	//}
	inOperatorGetState = 1;
    //FIXME:we assume that every token of +COPS response is less than 63 bytes.
    static char lastOperatorRecords[3][64] = {{0}, {0}, {0}};
    char *response[3];

    if (cregTimer_id != 0) {
        RLOGD("requestOperator, return");
        for(i = 0; i < 3; i++) {
            if (!strncmp(lastOperatorRecords[i], "", 1)) {
                resOper[i] = NULL;
            } else {
                asprintf(&resOper[i], "%s", lastOperatorRecords[i]);
            }
        }

        RIL_onRequestComplete(t, RIL_E_SUCCESS, resOper, sizeof(resOper));

        for (i = 0; i < 3; i++) {
            if (NULL != resOper[i]) {
                free(resOper[i]);
                resOper[i] = NULL;
            }
        }

        return;
    }

    memset(response, 0, sizeof(response));
	ATResponse *p_response = NULL;

	err = at_send_command("AT+COPS=3,0", NULL);
	if(err < 0) {
		RLOGD("send AT+COPS=3,0 ERROR");
		goto error;
	}

	err = at_send_command_singleline("AT+COPS?","+COPS:", &p_response);
	if(err < 0 || p_response->success == 0) {
		RLOGD("query cops:3,0 err = %d", err);
		goto error;
	} else {
		char* line = p_response->p_intermediates->line;
		err = parse_cops(line,&response[0],&skip);
		if(err < 0) {
			RLOGD("query cops:3,0 err = %d", err);
			goto error;
		}		
		at_response_free(p_response);
		p_response = NULL;
	}

	err = at_send_command("AT+COPS=3,1", NULL);
	if(err < 0) {
		goto error;
	} 

	err = at_send_command_singleline("AT+COPS?","+COPS:", &p_response);
	if(err < 0 || p_response->success == 0) {
		goto error;
	} else {
		char* line = p_response->p_intermediates->line;
		err = parse_cops(line,&response[1],&skip);
		if(err < 0) {
			RLOGD("query cops:3,1 err = %d", err);
			goto error;
		}		
		at_response_free(p_response);
		p_response = NULL;
	}

		
	err = at_send_command("AT+COPS=3,2", NULL);
	if(err < 0) {
		goto error;
	} 
	
	err = at_send_command_singleline("AT+COPS?","+COPS:", &p_response);
	if(err < 0 || p_response->success == 0) {
		RLOGD("query cops:3,2 err = %d", err);
		goto error;
	} else {
		char* line = p_response->p_intermediates->line;
		err = parse_cops(line,&response[2],&skip);
		if(err < 0) {
				
			goto error;
		}	
		if(response[2] != NULL){
	        int plmn_id = atoi(response[2]);
	        int ret;
            RLOGD("requestOperator: response[0] = %s, response[1] = %s", response[0], response[1]);
	        if (NULL == response[0] || NULL == response[1]) {
	            RLOGD("requestOperator: get plmn info from plmn.txt");
                // TODO fix me
	            ret = 0/*get_plmn_name(plmn_id, (const char **)(&response[1]), (const char **)(&response[0]))*/;
	        } else {
	            ret = 0;
	            RLOGD("requestOperator: get plmn info from AT command");
	        }

	        if (0 == ret)
	        { //add 46055 by nick for satellite.
	            if (46000 == plmn_id || 46002 == plmn_id || 46007 == plmn_id ||46008 == plmn_id ||46055 == plmn_id)//add 46008 by guojing for 20141215-40914,2014-12-16
	            {
	                if (skip == 2)
	                {
						response[0] = "CHINA LANCE";
	                    g_actmode = 2;
	                }
	                else
	                {
	                    g_actmode = 0;
	                }
	            }            	
	        }
	        else
	        {
	            RLOGE("requestOperator: fail to get plmn name!!!!!");
	            response[0] = response[2];
	        }

	        if (NULL != response[0])
	            RLOGD("long plmn: %s", response[0]);
	        else
	            RLOGD("requestOperator: response[0] is NULL");

	        if (NULL != response[1])
	            RLOGD("short plmn: %s", response[1]);
	        else
	            RLOGD("requestOperator: response[1] is NULL");

	        if (NULL != response[2])
	            RLOGD("plmn id: %s", response[2]);
	        else
	            RLOGD("requestOperator: response[2] is NULL");
       	}
			
		at_response_free(p_response);
		p_response = NULL;
	}

    for (j = 0; j < 3; j++) {
        if (response[j] == NULL) {
            resOper[j] = NULL;
        } else {
            asprintf(&resOper[j], "%s", response[j]);
        }
        memset(lastOperatorRecords[j], 0, 64);
        memcpy(lastOperatorRecords[j], (resOper[j] == NULL) ? "" : resOper[j], strlen((resOper[j] == NULL) ? "" :resOper[j]) + 1);
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, resOper, sizeof(resOper));
    for (j = 0; j < 3; j++) {
        if (NULL != resOper[j]) {
            free(resOper[j]);
            resOper[j] = NULL;
        }
    }
	inOperatorGetState = 0;
    return;	
	
	error:
		RLOGE("requestOperator must not return error when radio is on");
		RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
		if(p_response != NULL) {
			at_response_free(p_response);
		}
		inOperatorGetState = 0;

}

static void requestOperator(void *data, size_t datalen, RIL_Token t) {
	if(g_modemtype_s >= 1) {
		RLOGD("requestOperator: g_modemtype_s is %d, start requestOperatorS",g_modemtype_s);
		requestOperatorS(data, datalen, t);
	} else {
		requestOperatorLte(data,datalen,t);
	}
}

static void requestSIMType(void *p)
{
    int err;
    ATResponse *p_response = NULL;
    int toc = 0;
    char *line;

    err = at_send_command_singleline("AT^DTOC", "^DTOC:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);

    if (err < 0) {
        goto error;
    }
    /*
    <toc>:integer type , the type of (U)SIM card
    1     SIM
    2     USIM
    255  unknown type card
    */
    err = at_tok_nextint(&line, &toc);

    if (err < 0) {
        goto error;
    }

/* zoufeng for set "app_type" in response data of "RIL_REQUEST_GET_SIM_STATUS" begin */
    if(1 == toc) {
        simCardType = RIL_APPTYPE_SIM;
    } else {
        simCardType = RIL_APPTYPE_USIM;
    }
/* zoufeng for set "app_type" in response data of "RIL_REQUEST_GET_SIM_STATUS" end */
	RLOGE("requestSIMType RIL_UNSOL_RESPONSE_SIM_TYPE=%d ,simCardType=%d",toc,simCardType);
	RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_SIM_TYPE, &toc, sizeof(int));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    RLOGE("requestSIMType Error");
    //RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}
 
static void requestRadioPower(void *data, size_t datalen, RIL_Token t)
{
    int onOff;
    int err;
    ATResponse *p_response = NULL;
    static int g_radio_power = RADIO_POWER_UNKNOW;

    assert (datalen >= sizeof(int *));
    onOff = ((int *)data)[0];
    DBBD(DB_RIL, RLOGD("==> requestRadioPower(), onOff=%d, sState=%d, s_rilID=%d, is_first_power_on=%d, is_unsol_dusimu = %d\n",
        onOff, sState, s_rilID, is_first_power_on, is_unsol_dusimu));
    RLOGD("===> g_radio_power: %d\n", g_radio_power);

    if(is_radio_power_off)
    {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
        return;
    }

    if (onOff == 0 && sState != RADIO_STATE_OFF)
    {   /* Radio Turn off */
        int i = 0;
        RLOGD("===> requestRadioPower(): Radio Turn off");
        if (RADIO_TURN_OFF == g_radio_power)
        {
            RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
            return;
        }

        g_radio_power = RADIO_TURN_OFF;

        RIL_requestTimedCallback (deactiveAllLink, NULL, NULL);

        RLOGD("Ready to send AT+CFUN=4 commands");
        err = at_send_command("AT+CFUN=4", &p_response);
        if (err < 0|| (NULL != p_response && p_response->success == 0))
        {
            RLOGE("fail to AT+CFUN=4 !!!!!");
            goto error;
        }
        else
        {
            RLOGD("send to AT+CFUN=4 successful, p_response->finalResponse = %s", p_response->finalResponse);
        }

        property_set("radio.start.state", "started"); //for booting up tt access, cause radio  will turn on from off state

        setRadioState(RADIO_STATE_OFF);

        mNetState = NETWORK_NOT_REGISTER;
        if (cregTimer_id != 0)
        {
            ril_timer_delete(cregTimer_id);
            cregTimer_id = 0;
        }
    }
    else if (onOff > 0 && (sState == RADIO_STATE_OFF || g_radio_power == RADIO_TURN_OFF))
    {   /* Radio Turn on */
        RLOGD("===> requestRadioPower(): Radio Turn on");
        if (RADIO_TURN_ON == g_radio_power)
        {
            RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
            return;
        }

        g_radio_power = RADIO_TURN_ON;

        if (1 == g_FlagHlsLog)
        {
            RLOGI("==> requestRadioPower(), delay +CFUN=1 since the flag of Modem power on log is on");
        }
        else
        {
            if (p_response)
            {
                at_response_free(p_response);
                p_response = NULL;
            }

            RLOGD("===> ril_config_st.m_cardStatus: %d, ril_config_st.m_otherCardStatus : %d\n", ril_config_st.m_cardStatus, ril_config_st.m_otherCardStatus);
            if(0 == is_unsol_dusimu
                && 1 == s_rilID
                && CARD_STATUS_ABSENT == ril_config_st.m_cardStatus
                && CARD_STATUS_ABSENT == ril_config_st.m_otherCardStatus)
            {
                RLOGD("==> requestRadioPower(), don't send CFUN=1 since this slot has not (U)SIM card and the another slot has not (U)SIM card, and this slot is 1!");
            }
            else if(0 == is_unsol_dusimu
                && CARD_STATUS_ABSENT == ril_config_st.m_cardStatus
                && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus)
            {
                RLOGD("==> requestRadioPower(), don't send CFUN=1 since this slot has not (U)SIM card and the another slot has (U)SIM card");
            }
            else if((1 == is_unsol_dusimu && 0 == s_rilID && CARD_STATUS_ABSENT == ril_config_st.m_cardStatus && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus)
                || (1 == is_unsol_dusimu && 1 == s_rilID && CARD_STATUS_ABSENT == ril_config_st.m_cardStatus))
            {
                RLOGD("==> requestRadioPower(), don't send CFUN=1 since this slot has not (U)SIM card!!!");
            }
            else
            {
                RLOGD("==> requestRadioPower(), is_unsol_dusimu : %d, ril_config_st.m_otherCardStatus: %d", is_unsol_dusimu, ril_config_st.m_otherCardStatus);
                if (1 == s_rilID
                    && 0 == is_unsol_dusimu
                    && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus)
                {
                    int waitCount = 0;
                    char propValue[4] = {0};

                    while (waitCount++ < 50)
                    {
                        if (__system_property_get("rild.send.cfun", propValue) > 0 && '1' == propValue[0])
                            break;

                        RLOGD("==> requestRadioPower(), waiting for rild0 send AT+CFUN=1");
                        usleep(200*1000);
                    }
                }

                ata_ps_set_attach();
                ata_ps_set_eps_pdn_parameters();
                setUeCapability();                
                setAudioTest();

                err = at_send_command("AT+CFUN=1", &p_response);
                if (0 == s_rilID)
                {
                    __system_property_set("rild.send.cfun", "1");
                }

                if (err < 0|| (NULL != p_response && p_response->success == 0))
                {
                    RLOGD("fail to AT+CFUN=1 !!!!!");
                    goto error;
                }
                else
                {
                    RLOGD("send to AT+CFUN=1 successful, p_response->finalResponse = %s", p_response->finalResponse);
                }
            }
        }

        //err = at_send_command("AT^DTSER", NULL);
        if ((g_FlagHlsLog == 0) && (err < 0))
        {
            // Some stacks return an error when there is no SIM,
            // but they really turn the RF portion on
            // So, if we get an error, let's check to see if it
            // turned on anyway
            if (isRadioOn() != 1)
            {
                goto error;
            }
        }

        RLOGD("==> requestRadioPower(), s_rilID=%d, is_first_power_on=%d", s_rilID, is_first_power_on);
        if (0 == is_first_power_on)
        {
            requestSIMType(NULL);
        }
//        checkSimStatus();
        setRadioState(RADIO_STATE_ON);
    }

    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);

    /* Since Modem will reset itself when switch on/off fly mode, so the AT settings
     * should be sent again. */ 
    //if(g_FlagHlsLog == 0)
    if(onOff > 0)
    {
        switchModemUnsolicitedCode(1);
    } else if(onOff == 0) {
        switchModemUnsolicitedCode(0);
    }

    return;

error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestShutdown(RIL_Token t)
{
    int err;

    err = at_send_command("AT^DUSIMR=0", NULL);
    err = at_send_command("AT+CFUN=0", NULL);
    //err = at_send_command("AT+CFUN=6", NULL);

    setRadioState(RADIO_STATE_OFF);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;
}

static int getpuk2error()
{
    ATResponse *p_response = NULL;
    int err;
    int ret = 0;
    char *cpinLine;
    char *cpinResult;

    err = at_send_command_singleline("AT+CPIN?", "+CPIN:", &p_response);
    if (err != 0 || p_response->success == 0) goto done;

    cpinLine = p_response->p_intermediates->line;
    err = at_tok_start (&cpinLine);

    err = at_tok_nextstr(&cpinLine, &cpinResult);

    DBBD(1, RLOGD("getpuk2error, cpinResult  = %s", cpinResult));
    if (0 == strcmp (cpinResult, "SIM PUK2")) {
        ret = SIM_PUK2;
        goto done;
    }
done:
    at_response_free(p_response);
    return ret;
}

static void requestQueryPinRemainAttempt(void *data, size_t datalen, RIL_Token t)
{
    ATResponse   *p_response = NULL;
    int remain[4];
    int err;
    char *line;
    DBBD(DB_RIL, RLOGD("___QueryAvailableTimes\n"));

    err = at_send_command_singleline("AT^DRAP", "^DRAP:", &p_response);
    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) {
           goto error;
    }

    err = at_tok_nextint(&line, &(remain[0]));
    if (err < 0) {
           goto error;
    }

    err = at_tok_nextint(&line, &(remain[1]));
    if (err < 0) {
           goto error;
    }

    err = at_tok_nextint(&line, &(remain[2]));
    if (err < 0) {
           goto error;
    }

    err = at_tok_nextint(&line, &(remain[3]));
    if (err < 0) {
           goto error;
    }

    DBBD(DB_RIL, RLOGD("===(%d,%d,%d,%d)\n", remain[0], remain[1], remain[2],remain[3]));

    if (err < 0 || p_response->success == 0) {
error:
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    } else {
           RIL_onRequestComplete(t, RIL_E_SUCCESS, remain, 4*sizeof(int));
           RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    }
    
    at_response_free(p_response);
}

static void requestChangeSimPin(void *data, size_t datalen, RIL_Token t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char*         cmd = NULL;
    const char**  strings = (const char**)data;

    DBBD(DB_RIL, RLOGD("ChangeSimPin old pin:%s , new pin:%s ",strings[0],strings[1]));
    DBBD(DB_RIL, RLOGD("ChangeSimPin datalen=%d ",datalen));

    if ( datalen >= 2*sizeof(char*) ) {
        asprintf(&cmd, "AT+CPWD=\"SC\",\"%s\",\"%s\"", strings[0], strings[1]);

        DBBD(DB_RIL, RLOGD("ChangeSimPin cmd=%s ",cmd));
        err = at_send_command(cmd, &p_response);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }
    }

    int errtime[4];
    int response = -1;
    int val = HandlePinRemainAttempt(errtime);
    if(-1 == val) {
        DBBD(DB_RIL, RLOGD("Handle PinRemainAttempt ERROR."));
        goto error;
    }

    DBBD(DB_RIL, RLOGD("===ChangeSimPin errtime: (%d,%d,%d,%d)\n", errtime[0], errtime[1], errtime[2],errtime[3]));

    response = errtime[0];  /* the number of PIN1 retries remaining*/

    if (err < 0 || p_response->success == 0) {
        if ( response < SIM_PIN1_MAX_REMAINTIMES ) {
            RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &(response), sizeof(int));
        } else {
error:
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &(response), sizeof(int));
        }
    } else {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, &(response), sizeof(int));
        write_sim_pin_password(strings[1]);
    }
    at_response_free(p_response);
}

static void requestChangeSimPin2(void *data, size_t datalen, RIL_Token t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char*         cmd = NULL;
    const char**  strings = (const char**)data;
    int mval;

    DBBD(DB_RIL, RLOGD("===requestChangeSimPin2 old pin2:%s  , new pin2:%s , datalen = %d",strings[0],strings[1], datalen));

    if ( datalen >= 2*sizeof(char*) ) {
        asprintf(&cmd, "AT+CPWD=\"P2\",\"%s\",\"%s\"", strings[0], strings[1]);
        err = at_send_command(cmd, &p_response);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }
    }

    int errtime[4];
    int response = -1;

    int val = HandlePinRemainAttempt(errtime);
    if(-1 == val) {
        DBBD(DB_RIL, RLOGD("Handle PinRemainAttempt ERROR."));
        goto error;
    }

    DBBD(DB_RIL, RLOGD("===ChangeSimPin2 errtime: (%d,%d,%d,%d)\n", errtime[0], errtime[1], errtime[2],errtime[3]));

    response = errtime[1];  /* the number of PIN2 retries remaining*/

    if (err < 0 || p_response->success == 0) {
        mval = getpuk2error();
        DBBD(DB_RIL, RLOGD("The sim status is %d\n", mval));
        if(SIM_PUK2 == mval || response == 0) {
            DBBD(DB_RIL, RLOGD("RIL_E_SIM_PUK2\n"));
            RIL_onRequestComplete(t, RIL_E_SIM_PUK2, &(response), sizeof(int));
            at_response_free(p_response);
            return;
        } else if ( response < SIM_PIN2_MAX_REMAINTIMES ) {
            RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &(response), sizeof(int));
        } else {
error:
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &(response), sizeof(int));
        }
    } else {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, &(response), sizeof(int));
    }
    at_response_free(p_response);
}

static void requestSetFacilityLock(void *data, size_t datalen, RIL_Token t)
{
    char **p_parm;
    char* cmd = NULL;
    int err;
    int count;
    int index;
    ATResponse *p_response = NULL;

    p_parm = (char **)data;
    count = datalen/sizeof(char*);

    for(index = 0;index < count;index++) {
        DBBD(DB_RIL, RLOGD("requestSetFacilityLock, %d:%s",index,p_parm[index]));
    }

    if(memcmp(p_parm[0],"FD",2) == 0) {
        asprintf(&cmd,"AT^DNUMCHECK=0,%s",p_parm[1]);
        RLOGD("requestSetFacilityLock(): parm[1] = %s", p_parm[1]);
        RLOGD("requestSetFacilityLock(): cmd = %s", cmd);
        err = at_send_command(cmd, &p_response);
        RLOGD("requestSetFacilityLock(): err = %d, p_response.finalResponse = %s", err, p_response->finalResponse);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }
		
		at_response_free(p_response);
		p_response = NULL;
        
        asprintf(&cmd,"AT^DSACT=\"%s\",%s,\"%s\"",p_parm[0],p_parm[1],p_parm[2]);
        err = at_send_command(cmd, &p_response);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }
    }   
    /* modify Bug00001382 , by gaofeng 2012-09-20 begin
     * for GCF test , eg: *33*0000*22#, #33*0000*22#,*#33*0000*22# and so on.
    */
    else if(0 == strcmp (p_parm[0], "IR")){
        DBBD(DB_RIL, RLOGD("=====IR===="));
        asprintf(&cmd,"AT+CLCK=\"%s\",%s,\"%s\"",p_parm[0],p_parm[1],p_parm[2]);
        err = at_send_command(cmd, &p_response);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }
    }
    else {
        /* If user doesn't input class, then set it as "voice" by default. */
        if('0' == p_parm[3][0]) {
            RLOGD("requestSetFacilityLock(): change service class from '0' to '1'");
            p_parm[3][0] = '1';
        }
        asprintf(&cmd,"AT+CLCK=\"%s\",%s,\"%s\",%s",p_parm[0],p_parm[1],p_parm[2],p_parm[3]);
        err = at_send_command(cmd, &p_response);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }
    }

    int errtime[4];
    int response = -1;

    int val = HandlePinRemainAttempt(errtime);
    if(-1 == val) {
        DBBD(DB_RIL, RLOGD("Handle PinRemainAttempt ERROR."));
        goto error;
    }

    DBBD(DB_RIL, RLOGD("===requestSetFacilityLock errtime: (%d,%d,%d,%d)\n", errtime[0], errtime[1], errtime[2],errtime[3]));

    if(memcmp(p_parm[0],"FD",2) == 0) {
        response = errtime[1];  /* the number of PIN2 retries remaining*/
    } else {
        response = errtime[0];  /* the number of PIN1 retries remaining*/
    }

    if(err != 0 || p_response->success == 0) {
        if(memcmp(p_parm[0],"FD",2) == 0) {
            int mval = getpuk2error();
            DBBD(DB_RIL, RLOGD("The sim status is %d\n", mval));
            if(SIM_PUK2 == mval || response == 0) {
                DBBD(DB_RIL, RLOGD("RIL_E_SIM_PUK2\n"));
                at_response_free(p_response);
                RIL_onRequestComplete(t, RIL_E_SIM_PUK2, &(response), sizeof(int));
                return;
            } else if ( response < SIM_PIN2_MAX_REMAINTIMES) {
                DBBD(DB_RIL, RLOGD("RIL_E_SIM_PIN2\n"));
                at_response_free(p_response);
                RIL_onRequestComplete(t, RIL_E_SIM_PIN2, &(response), sizeof(int));
                return;
            }
        } else if(response < SIM_PIN1_MAX_REMAINTIMES) {
            DBBD(DB_RIL, RLOGD("RIL_E_SIM_PIN1\n"));
            at_response_free(p_response);
            RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &(response), sizeof(int));
            return;
        }
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &(response), sizeof(int));

    if(memcmp(p_parm[0],"SC",2) == 0){
        RLOGD("requestSetFacilityLock(): write_sim_pin_password!!!");
        write_sim_pin_password(p_parm[2]);
    }
    at_response_free(p_response);
    return;

error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &(response), sizeof(int));
}

static void requestQueryFacilityLock(void *data, size_t datalen, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    char *line;
    char *cmd;
    char **parm;
    int n = 0;
    ATLine *p_cur;
    int facility_lock = 0;
    int temp_status;
    int temp_class;

    parm = (char**)data;
    if(memcmp(parm[0],"FD",2) == 0)
    {    
        if(0/*parm[1]*/) {
            asprintf(&cmd,"AT^DSACT=\"%s\",2,\"%s\"",parm[0],parm[1]);
            err = at_send_command_singleline(cmd, "^DSACT:", &p_response);
        } else {
            asprintf(&cmd,"AT^DSACT=\"%s\",2",parm[0]);
            err = at_send_command_singleline(cmd, "^DSACT:", &p_response);
        }
        DBBD(DB_RIL, RLOGD("QueryFacilityLock,the cmd :%s",cmd));
        if (NULL != cmd){
            free(cmd);
            cmd = NULL;
        }

        if (err < 0 || p_response->success == 0) {
            goto error;
        }
        p_cur = p_response->p_intermediates;
        line = p_cur->line;

        err = at_tok_start(&line);
        if (err < 0)
            goto error;

        err = at_tok_nextint(&line, &temp_status);
        DBBD(DB_RIL, RLOGD("QueryFacilityLock, dsact, status : %u",temp_status));
        if (err < 0)
            goto error;

        facility_lock = temp_status;
    } else {
        /* If user doesn't input class, then set it as "voice" by default. */
        if('0' == parm[2][0]) {
            RLOGD("requestQueryFacilityLock(): change service class from '0' to '1'");
            parm[2][0] = '1';
        }
        asprintf(&cmd,"AT+CLCK=\"%s\",2,\"%s\",%s",parm[0],parm[1],parm[2]);
        DBBD(DB_RIL, RLOGD("QueryFacilityLock, the cmd : %s",cmd));

        err = at_send_command_multiline(cmd, "+CLCK:", &p_response);
        if (NULL != cmd) {
            free(cmd);
            cmd = NULL;
        }

        if (err < 0 || p_response->success == 0) {
            goto error;
        }

        for (p_cur = p_response->p_intermediates; p_cur != NULL;p_cur = p_cur->p_next)
            n++;

        for (p_cur = p_response->p_intermediates; p_cur != NULL;p_cur = p_cur->p_next) {
            line = p_cur->line;

            err = at_tok_start(&line);
            if (err < 0)
                goto error;

            err = at_tok_nextint(&line, &temp_status);
            DBBD(DB_RIL, RLOGD("QueryFacilityLock, clck, status : %u",temp_status));
            facility_lock = facility_lock|temp_status;
            if (err < 0)
                goto error;

            if(!at_tok_hasmore(&line)) {
                continue;
            }
            err = at_tok_nextint(&line, &(temp_class));
            DBBD(DB_RIL, RLOGD("QueryFacilityLock, class:%u",temp_class));
            if (err < 0)
                goto error;
        }
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &facility_lock, sizeof(int));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    RLOGE(" requestQueryFacilityLock , error ");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void  requestChangeCallBarringPassword(void*  data, size_t  datalen, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char*         cmd = NULL;
    const char**  strings = (const char**)data;;

    if (datalen != 3*sizeof(char*)) goto error;

    asprintf(&cmd, "AT+CPWD=\"%s\",\"%s\",\"%s\"", strings[0], strings[1], strings[2]);
    err = at_send_command(cmd, &p_response);
    free(cmd);

    if (err < 0 || p_response->success == 0) {
error:
        RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, NULL, 0);
    } else {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    }
    at_response_free(p_response);
}

static void requestLastCallFailCause(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int err = 0;
    //int response = 0;   //jiangxuqin 0313
    int i = 0;
    int error_num = CALL_ERROR_UNSPECIFIED;
    char *response = NULL;
    char *line = NULL;
   
    err = at_send_command_singleline("AT+CEER", "+CEER:", &p_response);
    if(err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if(err < 0) goto error;

    err = at_tok_nextstr(&line, &response);
    if(err < 0) goto error;
    DBBD(DB_RIL, RLOGD("LastCallFailCause, response info: %s", response));

    for(i; i<sizeof(call_fail_cause_map)/sizeof(CALL_FAIL_CAUSE); i++)  //jiangxuqin 0313-s
    {
        if(0 == strcasecmp(call_fail_cause_map[i].call_fail_code, response))
        {
            DBBD(DB_RIL, RLOGD("LastCallFailCause, call_fail_cause_map[%d].call_fail_num: %d\n",i, call_fail_cause_map[i].call_fail_num));
            RIL_onRequestComplete(t, RIL_E_SUCCESS, &call_fail_cause_map[i].call_fail_num, sizeof(int));
            at_response_free(p_response);
            return;            
        }
    }

    //If not in call_fail_cause_map, return default value.
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, &error_num, sizeof(int));
    return;

error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestQueryClip(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int response[2];
    char *line = NULL;
    int err = 0;

    err = at_send_command_singleline("AT+CLIP?", "+CLIP:", &p_response);
    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[0]));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[1]));
    if (err < 0) goto error;

    RLOGD("QueryClip response=(%d,%d)\n",response[0],response[1]);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, 2*sizeof(int));
    at_response_free(p_response);
    return;

error:
	RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
	at_response_free(p_response);
}

static void requestGetCLIR(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int response[2];
    char *line = NULL;
    int err = 0;

    err = at_send_command_singleline("AT+CLIR?", "+CLIR:", &p_response);
    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[0]));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[1]));
    if (err < 0) goto error;

    DBBD(DB_RIL, RLOGD("GetCLIR response=(%d,%d)\n",response[0],response[1]));
    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, 2*sizeof(int));
    at_response_free(p_response);
    return;

error:
	RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestSetCLIR(void *data, size_t datalen, RIL_Token t)
{
    char *cmd = NULL;
    int err = 0;

    asprintf(&cmd, "AT+CLIR=%d", ((int *)data)[0]);
    err = at_send_command(cmd, NULL);
    free(cmd);

    DBBD(DB_RIL, RLOGD("SetCLIR,err = %d\n",err));
    if(err < 0)
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    else
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void requestGetCOLR(void *data, size_t datalen, RIL_Token t)
{
    int             err;
    ATResponse      *p_response = NULL;
    char *line = NULL;
    int response = 2;

    err = at_send_command_singleline("AT^DTCOLR", "^DTCOLR:", &p_response);
    if (err < 0 || p_response->success == 0) goto error;
    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0 ) goto error;

    err = at_tok_nextint(&line, &response);
    if (err < 0 ) goto error;
    //RLOGD("===>response: ( %d )\n", response);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    at_response_free(p_response);
    return;

error:
	RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestSetCOLR(void *data, size_t datalen, RIL_Token t)
{
    char *cmd = NULL;
    int err = 0;
    ATResponse      *p_response = NULL;
    char *line = NULL;
    int response = 2;

    //RLOGD("===>((int *)data)[0]: ( %d )\n", ((int *)data)[0]);
    asprintf(&cmd, "AT^DTCOLR=%d", ((int *)data)[0]);
    err = at_send_command_singleline(cmd, "^DTCOLR:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) goto error;
    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0 ) goto error;

    err = at_tok_nextint(&line, &response);
    if (err < 0 ) goto error;
    RLOGD("===>response: ( %d )\n", response);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}



static void requestGetCOLP(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int response[2];
    char *line = NULL;
    int err = 0;

    err = at_send_command_singleline("AT+COLP?", "+COLP:", &p_response);
    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[0]));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[1]));
    if (err < 0) goto error;

    DBBD(DB_RIL, RLOGD("GetCOLP response=(%d,%d)\n",response[0],response[1]));
    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, 2*sizeof(int));
    at_response_free(p_response);
    return;

error:
	RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestSetCOLP(void *data, size_t datalen, RIL_Token t)
{
    char *cmd = NULL;
    int err = 0;
    ATResponse   *p_response = NULL;

    asprintf(&cmd, "AT+COLP=%d", ((int *)data)[0]);
    err = at_send_command(cmd, &p_response);
    free(cmd);

    DBBD(DB_RIL, RLOGD("SetCOLP,err = %d\n",err));
    if(err < 0 || p_response->success == 0)
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    else
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    
	at_response_free(p_response);
}

static void requestPlayCallwaitTone(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *cmd;
    char c = ((char *)data)[0];
    int val_tone;

    if( '0' <= c && c <= '9')
        val_tone = c - '0';
    else if('*' == c)
        val_tone = 10;
    else if('#' == c)
        val_tone = 11;
    else
        val_tone = 0;

    asprintf(&cmd, "AT^DAUDPR=0,%d", val_tone);
    err = at_send_command(cmd, NULL);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if(err < 0) goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS,  NULL, 0);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestDtmf(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *cmd;
    char c = ((char *)data)[0];

    asprintf(&cmd, "AT+VTS=\"%c\"", (int)c);
    err = at_send_command(cmd, NULL);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if(err < 0) goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestDtmfStart(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *cmd;

    char c = ((char *)data)[0];

    asprintf(&cmd, "AT+VTS=\"%c\"", c);
    err = at_send_command(cmd, NULL);
    if (cmd != NULL) {
        free(cmd);
        cmd = NULL;
    }

    if(err < 0) goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS,  NULL, 0);
    return;
error:

    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestDtmfStop(void *data, size_t datalen, RIL_Token t)
{
//        int err;

    RIL_onRequestComplete(t, RIL_E_SUCCESS,  NULL, 0);
    return;
error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestSetNetworkSelectionAutomatic(void *data, size_t datalen, RIL_Token t)
{
    int err = 0;
    ATResponse *p_response = NULL;
    
//    err = at_send_command("AT+COPS=0", NULL);
    err = at_send_command("AT+COPS=0", &p_response);
    RLOGD("requestSetNetworkSelectionAutomatic: err = %d", err);
    if(err < 0 ||p_response == NULL || p_response->success == 0)
    {
        RLOGD("requestSetNetworkSelectionAutomatic: RIL_E_GENERIC_FAILURE");
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    }
    else
    {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    }
    at_response_free(p_response);
}

static void requestSetNetworkSelectionManual(void *data, size_t datalen, RIL_Token t)
{
    char *operatorNumeric = NULL;
    char *operatorAlphaLong = NULL;
    char *cmd = NULL;
    int err = 0;
    int act = 0;
    ATResponse *p_response = NULL;
    int i = 0;
    char **strings = (char **)data;
    char value[2] = {'\0'};

    operatorNumeric = strings[0];
    operatorAlphaLong = strings[1];

    if(operatorNumeric == NULL) {
        goto error;
    }
    RLOGD("requestSetNetworkSelectionManual: datalen = %d, operatorNumeric = %s, operatorAlphaLong = %s ", 
    datalen, operatorNumeric, (operatorAlphaLong != NULL) ? operatorAlphaLong : "NULL");

    for (i = 0; i < NetworkList_lenth; i++)
    {
        RLOGD("requestSetNetworkSelectionManual: p_NetworkList.sNetwork = %s; p_NetworkList[i].type = %d; NetworkList_lenth =%d",
            p_NetworkList[i].sNetwork, p_NetworkList[i].type, NetworkList_lenth);

        if (0 == strcmp(p_NetworkList[i].sNetwork, operatorNumeric))
        {
            int plmn_id = atoi(operatorNumeric);
            if (46000 == plmn_id || 46002 == plmn_id ||46007 == plmn_id ||46008 == plmn_id ||46020 == plmn_id || 45412 == plmn_id)
            {
                if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "CHINA  MOBILE"))
                {
                    act = 0;
                    RLOGD("CHINA  MOBILE, set act = %d", act);
                }
                else if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "CHINA  MOBILE 3G"))
                {
                    act = 2;
                    RLOGD("CHINA  MOBILE 3G, set act = %d", act);
                }
#if defined(OPT_4G)
                else if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "CHINA  MOBILE 4G"))
                {
                    act = 7;
                    RLOGD("CHINA  MOBILE 4G, set act = %d", act);
                }
#endif
            }
            else if (46001 == plmn_id || 46006 == plmn_id || 46009 == plmn_id)
            {
                if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "CHN-UNICOM"))
                {
                    act = 0;
                    RLOGD("CHN-UNICOM, set act = %d", act);
                }           
                else if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "CHN-UNICOM 3G"))
                {
                    act = 2;
                    RLOGD("CHN-UNICOM 3G, set act = %d", act);
                }
#if defined(OPT_4G)
                else if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "CHN-UNICOM 4G"))
                {
                    act = 7;
                    RLOGD("CHN-UNICOM 4G, set act = %d", act);
                }
#endif
            }
            else if (46011 == plmn_id)
            {
#if defined(OPT_4G)
                if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "CHINA TELECOM 4G"))
                {
                    act = 7;
                    RLOGD("CHINA TELECOM 4G, set act = %d", act);
                }
#endif
            }
            else if (45403 == plmn_id)
            {
                if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "3 HK"))
                {
                    act = 0;
                    RLOGD("3 HK, set act = %d", act);
                }
                else if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "3 HK 3G"))
                {
                    act = 2;
                    RLOGD("3 HK 3G, set act = %d", act);
                }
#if defined(OPT_4G)
                else if (operatorAlphaLong != NULL && 0 == strcmp(operatorAlphaLong, "3 HK 4G"))
                {
                    act = 7;
                    RLOGD("3 HK 4G, set act = %d", act);
                }
#endif 
            }    //modified by jiangxuqin for 20160506-96209
            else
            {
                act = p_NetworkList[i].type;
                RLOGD("Not China operators, set act = %d", act);
            }

            RLOGD("find operator!!!");
            break;
        }
    }

    if (i >= NetworkList_lenth)
    {
        RLOGD("requestSetNetworkSelectionManual:do not find plmn");
        goto error;
    }

    if (property_get("persist.sys.install.service", value, "1")) {
        RLOGD("protocol test value = %s", value);
        RLOGD("manual/automatic mode for +COPS = %d", s_is_auto_plmn);
        if (0 == strcmp(value,"1") && 1 == s_is_auto_plmn) {
             asprintf(&cmd, "AT+COPS=4,2,\"%s\",%d", operatorNumeric,act);
        } else {
             asprintf(&cmd, "AT+COPS=1,2,\"%s\",%d", operatorNumeric,act);
        }
    } else {
        asprintf(&cmd, "AT+COPS=1,2,\"%s\",%d", operatorNumeric,act);
    }

    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }
    if (err < 0 || p_response->success == 0) {
        RLOGD("set network Fail!!!!!!");
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    return;

error:
    if (p_response)
    {
        at_response_free(p_response);
        p_response = NULL;
    }

    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static const char* networkStatusToRilString(int state)
{
    switch(state) {
        case 0: return("unknown");   break;
        case 1: return("available"); break;
        case 2: return("current");   break;
        case 3: return("forbidden"); break;
        default: return NULL;
    }
}

static const char *networkActToRilString(int act)
{
    switch (act)
    {
    case 0: return("GSM"); break;
    case 2: return("UTRAN"); break;
#if defined(OPT_4G)
    case 7: return("LTE"); break;
#endif
    default: return NULL;
    }

    return NULL;
}

static void requestGetHardwareConfig(void *data, size_t datalen, RIL_Token t)
{
   // TODO - hook this up with real query/info from radio.

   RIL_HardwareConfig hwCfg;

   RIL_UNUSED_PARM(data);
   RIL_UNUSED_PARM(datalen);

   hwCfg.type = -1;

   RIL_onRequestComplete(t, RIL_E_SUCCESS, &hwCfg, sizeof(hwCfg));
}

static void requestQueryAvailableNetworks(void *data, size_t datalen, RIL_Token t)
{
    int err, operators, status, mval;
    ATResponse *p_response = NULL;
    char * c_skip, *line, *p = NULL;
    char **response = NULL;
    char **operReslut = NULL;
    int i = 0, j = 0;

    errNumber = 255;
    RLOGD("requestQueryAvailableNetworks");
    err = at_send_command_singleline_timeout("AT+COPS=?", "+COPS:", 180*1000,  &p_response);

    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    operators = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == '(') operators++;
    }

    response = (char **)alloca(operators * 5 * sizeof(char *));
    operReslut = (char **)malloc(operators * 5 * sizeof(char *));

    if(p_NetworkList != NULL)
    {
        free(p_NetworkList);
        p_NetworkList = NULL;
    }
    
    p_NetworkList = (RIL_NetworkList *)malloc(operators * sizeof(RIL_NetworkList));
    if(p_NetworkList == NULL)
    {
        RLOGD("p_NetworkList memory malloc Fail_2!!!!!!");
        goto error;
    }

    memset(p_NetworkList, 0, operators * sizeof(RIL_NetworkList));
    NetworkList_lenth = 0;

    for (i = 0 ; i < operators ; i++ )
    {
        err = at_tok_nextstr(&line, &c_skip);
        if (err < 0)
            goto error;

        if (strcmp(c_skip,"") == 0)
        {
            operators = i;  /*For the real counts of operator*/
            continue;
        }
        
        status = atoi(&c_skip[1]);
        response[i*5+3] = (char*)networkStatusToRilString(status);

        char *tmpstring;
        int buf_size = 0;

        err = at_tok_nextstr(&line, &response[i * 5 + 0]);
        if (err < 0)
        {
            RLOGD("requestQueryAvailableNetworks: parse error 0");
            goto error;
        }

        err = at_tok_nextstr(&line, &response[i * 5 + 1]);
        if (err < 0)
        {
            RLOGD("requestQueryAvailableNetworks: parse error 1");
            goto error;
        }

        err = at_tok_nextstr(&line, &tmpstring);
        if (err < 0)
        {
            RLOGD("requestQueryAvailableNetworks: parse error 2");
            goto error;
        }

        buf_size = strlen(tmpstring) + 1;

        response[i*5+2] = (char *)alloca(buf_size);
        strncpy(response[i*5+2], tmpstring, buf_size);

        err = at_tok_nextint(&line, &mval);
        if (err < 0)
        {
            RLOGD("requestQueryAvailableNetworks: parse error mval");
            goto error;
        }

        response[i * 5 + 4] = (char *)networkActToRilString(mval);

        strncpy(p_NetworkList[i].sNetwork, response[i * 5 + 2], (strlen(response[i * 5 + 2]) <= 7 ? strlen(response[i * 5 + 2]) : 7));
        p_NetworkList[i].type = mval;
        NetworkList_lenth = i + 1;

        int ret;
        int plmn_id = atoi(response[i * 5 + 2]);
        if (NULL == response[i * 5 + 0] || NULL == response[i * 5 + 1])
        {
            RLOGD("requestQueryAvailableNetworks: get plmn info from plmn.txt");
            // TODO fix me
            ret = 0/*get_plmn_name(plmn_id, (const char **)(&response[i * 5 + 1]), (const char **)(&response[i * 5 + 0]))*/;
        }
        else
        {
            ret = 0;
            RLOGD("requestQueryAvailableNetworks: get plmn info from AT command");
        }

        if (0 == ret)
        {  //add 46008/46020 by guojing for 20141215-40914/20150415-57877,2014-12-16/2015-4-18
        //modifed by jiangxuqin for 20160408-93067
            if (46000 == plmn_id || 46002 == plmn_id ||46007 == plmn_id ||46008 == plmn_id ||46020 == plmn_id || 45412 == plmn_id)
            {
                if (mval == 2)
                { /* 2: TD network */
                    if ((strcmp(response[i * 5 + 1], "TD-SCDMA") == 0))
                        response[i * 5 + 0] = "DA  TANG 3G";
                    else
                        response[i * 5 + 0] = "CHINA  MOBILE 3G";
                }
#if defined(OPT_4G)
                else if (mval == 7)
                { /*7: LTE network*/
                    response[i * 5 + 0] = "CHINA  MOBILE 4G";
                }
#endif
            }
            else if (46001 == plmn_id || 46006 == plmn_id || 46009 == plmn_id)
            {
                if (mval == 2)
                {
                    response[i * 5 + 0] = "CHN-UNICOM 3G";
                }
#if defined(OPT_4G)
                else if (mval == 7)
                {
                    response[i * 5 + 0] = "CHN-UNICOM 4G";
                }
#endif
            }
            else if (46011 == plmn_id)
            {
#if defined(OPT_4G)
                if (mval == 7)
                {
                    response[i * 5 + 0] = "CHINA TELECOM 4G";
                }
#endif
            }
            else if (45403 == plmn_id)
            {
                 if (mval == 2)
                 {
                     response[i * 5 + 0] = "3 HK 3G";
                 }  //modified by jiangxuqin for 20160506-96209
#if defined(OPT_4G)
                else if (mval == 7)
                {
                    response[i * 5 + 0] = "3 HK 4G";
                }
#endif
            }           
        }
        else
        {
            RLOGD("requestQueryAvailableNetworks:fail to get plmn name");
            response[i * 5 + 0] = response[i * 5 + 2];
            response[i * 5 + 1] = response[i * 5 + 2];
        }

        asprintf(&operReslut[i * 5 + 0], "%s", response[i * 5 + 0]);
        asprintf(&operReslut[i * 5 + 1], "%s", response[i * 5 + 1]);
        asprintf(&operReslut[i * 5 + 2], "%s", response[i * 5 + 2]);
        asprintf(&operReslut[i * 5 + 3], "%s", response[i * 5 + 3]);
        asprintf(&operReslut[i * 5 + 4], "%s", response[i * 5 + 4]);
        RLOGD("requestQueryAvailableNetworks: [%d]: %s, %s, %s, %s, %s", i,
            operReslut[i * 5 + 0], operReslut[i * 5 + 1], operReslut[i * 5 + 2], operReslut[i * 5 + 3], operReslut[i * 5 + 4]);
    }

    at_response_free(p_response);
	p_response = NULL;

    RLOGD("requestQueryAvailableNetworks: errNumber = %d,before loop",errNumber);
    for (j = 0; j < 2; j++){
        if (errNumber == 255) {
            usleep(100000);
        } else {
             break;
        }
    }

    RLOGD("requestQueryAvailableNetworks: errNumber = %d",errNumber);

    if (errNumber > 0 && errNumber < 255) {
        RIL_onRequestComplete(t, errNumber, operReslut, (operators * 5 * sizeof(char *)));
    } else {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, operReslut, (operators * 5 * sizeof(char *)));
    }

    for (j = 0; j < operators; j++) {
        for (i = 0; i < 5; i++) {
            if (NULL != operReslut[j * 5 + i])
            {
                free(operReslut[j * 5 + i]);
                operReslut[j * 5 + i];
            }
        }
    }

    if (NULL != operReslut)
    {
        free(operReslut);
        operReslut = NULL;
    }

    errNumber = 255;
    return;

error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestSetCallWaiting(void *data, size_t datalen, RIL_Token t)
{
    char *cmd;
    int err;
    int enable;
    int classx;
    ATResponse *p_response = NULL;

    enable = ((int *)data)[0];
    classx = ((int *)data)[1];
    DBBD(DB_RIL, RLOGD("SetCallWaiting,data is (%d,%d)",enable,classx));

    /* modify Bug00001382 , by gaofeng 2012-09-20 begin
     * for GCF test , eg: *43*10#, #43*10#, *#43*10# and so on.
    */
    //classx = 7;
    //asprintf(&cmd, "AT+CCWA=1,%d,%d",enable, classx); /* n, mode,classx */
     if(classx > 0 ){
        asprintf(&cmd, "AT+CCWA=1,%d,%d",enable, classx); /* n, mode,classx */
    }else{
        asprintf(&cmd, "AT+CCWA=1,%d",enable);
    }
    /* modify Bug00001382 , by gaofeng 2012-09-20 end */

    DBBD(DB_RIL, RLOGD("==> SetCallWaiting , the cmd  is %s",cmd));

    //modify Bug00000865 , by gaofeng 2012-07-26 begin
    err = at_send_command_multiline(cmd, "+CCWA:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) goto error;
    //modify Bug00000865 , by gaofeng 2012-07-26 end

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    return;

error:
    DBBD(DB_RIL, RLOGE("==SetCallWaiting , error "));
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestQueryCallWaiting(void *data, size_t datalen, RIL_Token t)
{
    int err;
    int response[2] = {0,0};
    ATResponse *p_response = NULL;

    /* modify Bug00001382 , by gaofeng 2012-09-20 begin
     * for GCF test , eg: *43*10#, #43*10#, *#43*10# and so on.
    */
    //err = at_send_command_multiline("AT+CCWA=1,2,7", "+CCWA:", &p_response);
    err = at_send_command_multiline("AT+CCWA=1,2", "+CCWA:", &p_response);
    /* modify Bug00001382 , by gaofeng 2012-09-20 end */
    if (err < 0 || p_response->success == 0) goto error;

    ATLine *p_cur;
    int i = 0;
    int tmpresp;

    for (p_cur = p_response->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next, i++) {
        char *line = p_cur->line;

        err = at_tok_start(&line);
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &tmpresp);
        if (err < 0) goto error;
        if(i == 0) response[0] = tmpresp;

        err = at_tok_nextint(&line, &tmpresp);
        if (err < 0) goto error;
        response[1] += tmpresp; // modify [by chenshu 2013-03-22] for 1810_Bug00003512
    }

    DBBD(DB_RIL, RLOGD("QueryCallWaiting Response : (%d,%d)\n", response[0],response[1]));
    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, 2*sizeof(int));
    at_response_free(p_response);
    return;

error:
    DBBD(DB_RIL, RLOGD("===> request QueryCallWaiting ERROR\n"));
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestQueryCallForwardStatus(void *data, size_t datalen, RIL_Token t)
{
    int err = 0;
    int i = 0;
    int n = 0;
    int tmp = 0;
    ATResponse *p_response = NULL;
    ATLine *p_cur;
    RIL_CallForwardInfo **pp_responses = NULL;
    char *cmd;
    char *temp_subnum;
    int serviceClass = 0;/* Leadcore: fix Bug00000534, 20110306, chengyuxin, modification for video phone call forward*/
    RIL_CallForwardInfo *p_args = NULL;
    p_args = (RIL_CallForwardInfo *)data;
    serviceClass = p_args->serviceClass;/* Leadcore: fix Bug00000534, 20110306, chengyuxin, modification for video phone call forward*/
    /* Leadcore: fix Bug00000534, 20110306, chengyuxin, modification for video phone call forward*/
    if((2 == p_args->reason) && (2 == p_args->status)) {
        asprintf(&cmd,"AT+CCFC=%d,%d,,,%d,,,20",p_args->reason,p_args->status,  (serviceClass == 0)?1:serviceClass);
        err = at_send_command_multiline(cmd, "+CCFC:", &p_response);
    } else {
        asprintf(&cmd,"AT+CCFC=%d,%d,,,%d",p_args->reason,p_args->status, (serviceClass == 0)?1:serviceClass);
        err = at_send_command_multiline(cmd, "+CCFC:", &p_response);
    }

    DBBD(DB_RIL, RLOGD("QueryCallForwardStatus cmd is = %s\n",cmd));
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if(err != 0 || p_response->success == 0) {
        DBBD(DB_RIL, RLOGD("Querycallforward, err=%d",err));
        goto error;
    }

    for (p_cur = p_response->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next)
        n++;

    RLOGD("Querycallforward, ATLine count: n=%d", n);
    pp_responses = alloca(n * sizeof(RIL_CallForwardInfo *));

    for(i = 0; i < n; i++) {
        pp_responses[i] = alloca(sizeof(RIL_CallForwardInfo));
        pp_responses[i]->status = 0;
        pp_responses[i]->reason = p_args->reason;
        pp_responses[i]->serviceClass = 0;
        pp_responses[i]->toa = 0;
        pp_responses[i]->number = "";
        pp_responses[i]->timeSeconds = 0;
    }

    for (i = 0, p_cur = p_response->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next, i++) {
        char *line = p_cur->line;

        err = at_tok_start(&line);
        if (err < 0) goto error;

        RLOGD("CallForwardStatus line=%s", line);

        err = at_tok_nextint(&line, &(pp_responses[i]->status));
        if (err < 0) goto error;

        err = at_tok_nextint(&line, &(pp_responses[i]->serviceClass));
        if (err < 0) goto error;

        if(!at_tok_hasmore(&line)) continue;
        err = at_tok_nextstr(&line, &temp_subnum);
        RLOGD("CallForwardStatus temp_subnum=%s", temp_subnum);
        if (err < 0) goto error;
        if (0 != strlen(temp_subnum)) {
            pp_responses[i]->number = alloca(strlen(temp_subnum) + 1);
            strcpy(pp_responses[i]->number, temp_subnum);
        } else {
            continue;
        }

        if(!at_tok_hasmore(&line)) continue;
        err = at_tok_nextint(&line, &(pp_responses[i]->toa));
        if (err < 0) goto error;

        if(!at_tok_hasmore(&line)) continue;
        err = at_tok_nextstr(&line, &(temp_subnum));

        if(!at_tok_hasmore(&line)) continue;
        err = at_tok_nextint(&line,&tmp);

        if(!at_tok_hasmore(&line)) continue;
        err = at_tok_nextint(&line, &(pp_responses[i]->timeSeconds));
        if (err < 0) goto error;
    }

    for(i = 0; i < n; i++) {
        RLOGD("pp_responses[%d]->status = %d\n",i,pp_responses[i]->status);
        RLOGD("pp_responses[%d]->reason = %d\n",i,pp_responses[i]->reason);
        RLOGD("pp_responses[%d]->serviceClass = %d\n",i,pp_responses[i]->serviceClass);
        RLOGD("pp_responses[%d]->toa = %d\n",i,pp_responses[i]->toa);
        RLOGD("pp_responses[%d]->number = %s\n",i,pp_responses[i]->number);
        RLOGD("pp_responses[%d]->timeSeconds = %d\n",i,pp_responses[i]->timeSeconds);
    }

    RLOGD("requestQueryCallForwardStatus responses success\n");
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, pp_responses, n*sizeof(RIL_CallForwardInfo *));
    return;

error:
    at_response_free(p_response);
    RLOGD("requestQueryCallForwardStatus responses fail\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void requestSetCallForward(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char* cmd = NULL;
    RIL_CallForwardInfo* p_args = NULL;
    ATResponse *p_response = NULL;

    p_args = (RIL_CallForwardInfo*)data;

/* FIX 20141204-38961 by zoufeng, 20141206 begin */
    /* If user doesn't input class, then set it as "voice" by default. */
    if(0 == p_args->serviceClass) {
        RLOGD("requestSetCallForward(): change service class from '0' to '1'");
        p_args->serviceClass = 1;
    }
/* FIX 20141204-38961 by zoufeng, 20141206 end */

#if 0
        RLOGD("____status = %d\n",p_args->status);
        RLOGD("____reason = %d\n",p_args->reason);
        RLOGD("____serviceClass = %d\n",p_args->serviceClass);
        RLOGD("____toa = %d\n",p_args->toa);
        RLOGD("____number = %s\n",p_args->number);
        RLOGD("____timeSeconds = %d\n\n",p_args->timeSeconds);
#endif

    if(2 == p_args->status) {
        asprintf(&cmd,"AT+CCFC=%u,%u,%u,%u",p_args->reason,p_args->status,p_args->toa,p_args->serviceClass);
    } else {
        if(0 != p_args->timeSeconds) {
            if(NULL != p_args->number) {
                asprintf(&cmd,"AT+CCFC=%u,%u,\"%s\",%u,%u,,,%u",
                p_args->reason,p_args->status,p_args->number,p_args->toa,p_args->serviceClass,p_args->timeSeconds);
            } else {
                asprintf(&cmd,"AT+CCFC=%u,%u,,%u,%u,,,%u",
                p_args->reason,p_args->status,p_args->toa,p_args->serviceClass,p_args->timeSeconds);
            }
        } else {
            if(NULL != p_args->number) {
                asprintf(&cmd,"AT+CCFC=%u,%u,\"%s\",%u,%u",p_args->reason,p_args->status,p_args->number,p_args->toa,p_args->serviceClass);
            } else {
                /* modify Bug00001382 , by gaofeng 2012-09-20 begin
                 * for GCF test , eg: *002**22#, *21# and so on.
                */
                RLOGD("=====CCFC=serviceClass = %d ",p_args->serviceClass, p_args->reason, p_args->status);
                if(p_args->serviceClass > 1)
                {
                    asprintf(&cmd,"AT+CCFC=%u,%u,,%u,%u",p_args->reason,p_args->status,p_args->toa,p_args->serviceClass);
                }else{
                    asprintf(&cmd,"AT+CCFC=%u,%u",p_args->reason,p_args->status);
                }
                /* modify Bug00001382 , by gaofeng 2012-09-20 end */
            }
        }
    }
    RLOGD("requestSetCallForward send at cmd '%s'", cmd);
    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if(err != 0 || p_response->success == 0) {
        goto error;
    }

    RLOGD("SetCallForward  RIL_E_SUCCESS ");
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    return;

error:
    RLOGE("requestSetCallForward , error ");
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

/* FIX 20140625-17590 by zoufeng, 20141009 begin */
/*modify by yuanhaobo for L1860_Req00000475 @ 2014-05-16 begin*/
static void requestGetPreferredNetworkType(int request __unused, void *data __unused,
                                   size_t datalen __unused, RIL_Token t)
{
    char    propValue[PROP_VALUE_MAX] = "";
    int     prefNetType = PREF_NET_TYPE_4G_3G_2G;

    if (__system_property_get(PROPERTY_PERSIST_SYS_LC_PREF_NET_TYPE, propValue) > 0) {
        RLOGE("get property [%s] : [%s]", PROPERTY_PERSIST_SYS_LC_PREF_NET_TYPE, propValue);
        if(strlen(propValue) > 0) {
            prefNetType = atoi(propValue);
        }
    }

    if (prefNetType != PREF_NET_TYPE_4G_3G_2G
        && prefNetType != PREF_NET_TYPE_3G_2G
        && prefNetType != PREF_NET_TYPE_GSM_ONLY
        && prefNetType != PREF_NET_TYPE_WCDMA
        && prefNetType != PREF_NET_TYPE_GSM_WCDMA) {
        prefNetType = PREF_NET_TYPE_4G_3G_2G;
    }  //jiangxuqin0705 for 20160304-88480

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &prefNetType, sizeof(int));
}

static void requestSetPreferredNetworkType( int request __unused, void *data,
                                            size_t datalen __unused, RIL_Token t )
{
    int     retVal = RIL_E_SUCCESS;
    char    propValue[PROP_VALUE_MAX] = "";
    int     isManualModeRat = 0;
    int     isEnable4G = 1;
    int     prefNetType = PREF_NET_TYPE_4G_3G_2G;
    char    *cmd = NULL;
    ATResponse *p_response = NULL; 
    int     temp_rat = 0x00000000;

    if(PREF_NET_TYPE_4G_3G_2G == ((int *)data)[0]) {
        isEnable4G = 1;
        prefNetType = PREF_NET_TYPE_4G_3G_2G;
        temp_rat = RADIO_LC_ACT_2G |RADIO_LC_ACT_3G |RADIO_LC_ACT_4G;
    } else if(PREF_NET_TYPE_3G_2G == ((int *)data)[0]) {
        isEnable4G = 0;
        prefNetType = PREF_NET_TYPE_3G_2G;
        temp_rat = RADIO_LC_ACT_2G |RADIO_LC_ACT_3G;
    } else if(PREF_NET_TYPE_GSM_WCDMA == ((int *)data)[0]) {
        isEnable4G = 0;
        prefNetType = PREF_NET_TYPE_GSM_WCDMA;
        temp_rat = RADIO_LC_ACT_2G |RADIO_LC_ACT_3G;     //jiangxuqin0705 for 20160304-88480
    } else if(PREF_NET_TYPE_WCDMA == ((int *)data)[0]) {
        isEnable4G = 0;
        prefNetType = PREF_NET_TYPE_WCDMA;
        temp_rat = RADIO_LC_ACT_3G;     //jiangxuqin0705 for 20160304-88480
    } else if(PREF_NET_TYPE_GSM_ONLY == ((int *)data)[0]) {
        prefNetType = PREF_NET_TYPE_GSM_ONLY;
        temp_rat = RADIO_LC_ACT_2G;
    } else {
        RLOGE("Error: unsupport preferred network mode\n");
        retVal = RIL_E_MODE_NOT_SUPPORTED;
        goto error;
    }

    RLOGI("requestSetPreferredNetworkType: temp_rat = %d, ril_config_st.m_rat = %d", temp_rat, ril_config_st.m_rat);
    if((temp_rat & ril_config_st.m_rat) != temp_rat) {
        retVal = RIL_E_MODE_NOT_SUPPORTED;
        RLOGI("requestSetPreferredNetworkType: RIL_E_MODE_NOT_SUPPORTED");
        goto error;
    }   //jiangxuqin0329

    /* If the RAT has been set by APP "LC_Assistant", then do nothing;
     * otherwise change the RAT immediately. */
    isManualModeRat = 0;
    if (__system_property_get("persist.sys.lc.manual.rat", propValue) > 0
        && strlen(propValue) >= 5) {
        isManualModeRat = 1;
    }

    RLOGI("requestSetPreferredNetworkType: isEnable4G = %d, ril_config_st.m_actualRat = %d, prefNetType= %d,  [begin]", isEnable4G, ril_config_st.m_actualRat, prefNetType);
    if(0 == isManualModeRat
        && PREF_NET_TYPE_GSM_ONLY == prefNetType) {
        asprintf(&cmd, "AT^DSTMEX=1,0");
    } else if(0 == isManualModeRat
        && PREF_NET_TYPE_WCDMA == prefNetType) {
        asprintf(&cmd, "AT^DSTMEX=1,2");     //jiangxuqin0705 for 20160304-88480
    } else if(0 == isManualModeRat
        /*&& CARD_TYPE_USIM == ril_config_st.m_cardType*/
        /*&& (CARD_LOCALE_CMCC == ril_config_st.m_cardLocale || CARD_LOCALE_FOREIGN == ril_config_st.m_cardLocale)*/) {
        if(isEnable4G
            && ((ril_config_st.m_actualRat & RADIO_LC_ACT_4G) == 0)) {
            asprintf(&cmd, "AT^DSTMEX=0,7,2,0");
        } else if(0 == isEnable4G
            && (((ril_config_st.m_actualRat & RADIO_LC_ACT_4G) != 0)
                || RADIO_LC_ACT_GSM == ril_config_st.m_actualRat
                || RADIO_LC_ACT_3G == ril_config_st.m_actualRat)) {
            asprintf(&cmd, "AT^DSTMEX=0,2,0");   //modified by jiangxuqin for 20170116-100043
        }
    } else {
        RLOGI("discard DSTMEX since: manualMode(%s), USIM(%s), cardLocale(%d)",
                ((0 == isManualModeRat) ? "no" : "yes"),
                ((CARD_TYPE_USIM == ril_config_st.m_cardType) ? "yes" : "no"), ril_config_st.m_cardLocale);
                /*((CARD_LOCALE_CMCC == ril_config_st.m_cardLocale || CARD_LOCALE_FOREIGN == ril_config_st.m_cardLocale) ? "yes" : "no"));*/
    }

    if (cmd != NULL) {
        int err ;
        BOOL disable_3g_mode = false;

        if(check_board("LTE28047M11")){
            char propValue[PROP_VALUE_MAX] = "";

            if (__system_property_get("persist.sys.lc.3g.disable", propValue) > 0) {
	            RLOGD("persist.sys.lc.3g.disable is %c ",propValue[0]);
	            if(propValue[0]=='1'){
	    		   disable_3g_mode = true;
	            }
            }
        }

        if(disable_3g_mode){
            err = at_send_command("AT^DSTMEX=0,7,0", &p_response);
        }else{
            err = at_send_command(cmd, &p_response);
        }

        if (err < 0 || (NULL != p_response && p_response->success == 0)) {
            at_response_free(p_response);
            free(cmd);
            retVal = RIL_E_GENERIC_FAILURE;
            goto error;
        } else {
            if(PREF_NET_TYPE_GSM_ONLY == prefNetType) {
                ril_config_st.m_actualRat = RADIO_LC_ACT_GSM;
            } else if((PREF_NET_TYPE_3G_2G == prefNetType) || (PREF_NET_TYPE_GSM_WCDMA == prefNetType)) {
                ril_config_st.m_actualRat = RADIO_LC_ACT_GSM | RADIO_LC_ACT_3G;
            } else if(PREF_NET_TYPE_4G_3G_2G == prefNetType) {
                ril_config_st.m_actualRat = RADIO_LC_ACT_GSM | RADIO_LC_ACT_3G | RADIO_LC_ACT_4G;
            } else if(PREF_NET_TYPE_WCDMA == prefNetType) {
                ril_config_st.m_actualRat =  RADIO_LC_ACT_3G;    //jiangxuqin0705 for 20160304-88480
            }
        }

        at_response_free(p_response);
        free(cmd);
    }

    snprintf(propValue, sizeof(propValue), "%d", prefNetType);
    if (__system_property_set(PROPERTY_PERSIST_SYS_LC_PREF_NET_TYPE, propValue) == 0) {
        RLOGI("set property: [%s]: [%s]", PROPERTY_PERSIST_SYS_LC_PREF_NET_TYPE, propValue);
    } else {
        RLOGI("set property: [%s]: [%s] failed", PROPERTY_PERSIST_SYS_LC_PREF_NET_TYPE, propValue);
        retVal = RIL_E_GENERIC_FAILURE;
        goto error;
    }

    RLOGI("requestSetPreferredNetworkType: ril_config_st.m_actualRat = %d, [end]", ril_config_st.m_actualRat);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RIL_onRequestComplete(t, retVal, NULL, 0);
}
/*modify by yuanhaobo for L1860_Req00000475 @ 2014-05-16 end*/
/* FIX 20140625-17590 by zoufeng, 20141009 end */

static void requestDeactivateDataCall(void *data, size_t datalen, RIL_Token t)
{
    int ril_cid;
    int reason;
    ril_cid = atoi( ((const char **)data)[0]);
    reason = atoi( ((const char **)data)[1]);
    if(reason == DEACTIVATE_REASON_PS_SWITCH)
    {
    	RLOGD("[RIL-PS][requestDeactivateDataCall] switch ps, ril_cid = %d", ril_cid);
    	ata_ps_set_ps_switch(TRUE);
    }
    RLOGD("[RIL-PS][requestDeactivateDataCall] , ril_cid = %d", ril_cid);
    ata_ps_stop_network(ril_cid);
    ata_ps_set_ps_switch(FALSE);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;
}

static void requestEnterSimPin(int request, void*  data, size_t  datalen, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char*         cmd = NULL;
    const char**  strings = (const char**)data;;

    /* FIX LARN_Bug00001022 by zoufeng, 20131230 begin */
    if(datalen == 2*sizeof(char*) && strings[1] == NULL) {
        DBBD(DB_RIL, RLOGD("strings[1] is NULL, minus the count of parameter.\n"));
        datalen = sizeof(char*);
    }
    /* FIX LARN_Bug00001022 by zoufeng, 20131230 end */

    if ( datalen == sizeof(char*) ) {
        asprintf(&cmd, "AT+CPIN=\"%s\"", strings[0]);
    }else if (request == RIL_REQUEST_ENTER_SIM_PUK
        && datalen >= 2*sizeof(char*)) {
        asprintf(&cmd, "AT^DMSP=5,\"%s\",\"%s\"", strings[0], strings[1]);
    }else if (request == RIL_REQUEST_ENTER_SIM_PUK2) {
        asprintf(&cmd, "AT^DMSP=52,\"%s\",\"%s\"", strings[0], strings[1]);
    }else if ( datalen == 2*sizeof(char*) ) {
        asprintf(&cmd, "AT+CPIN=\"%s\",\"%s\"", strings[0], strings[1]);
    } else
        goto error;

    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    int errtime[4];
    int response = -1;
    int val = HandlePinRemainAttempt(errtime);
    if(-1 == val) {
        DBBD(DB_RIL, RLOGD("Handle PinRemainAttempt ERROR."));
        goto error;
    }

    DBBD(DB_RIL, RLOGD("===EnterSimPin errtime: (%d,%d,%d,%d)\n", errtime[0], errtime[1], errtime[2],errtime[3]));

    if(request == RIL_REQUEST_ENTER_SIM_PIN) {
        response = errtime[0];
    } else if(request == RIL_REQUEST_ENTER_SIM_PIN2) {
        response = errtime[1];
    } else if(request == RIL_REQUEST_ENTER_SIM_PUK) {
        response = errtime[2];
    } else if(request == RIL_REQUEST_ENTER_SIM_PUK2) {
        response = errtime[3];
    }

    if (err < 0 || p_response->success == 0) {
error:
        RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &(response), sizeof(int));
    } else {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, &(response), sizeof(int));
        checkAndPollSimStat();

        RLOGD("requestEnterSimPin(): sState = %d", sState);
        if (RADIO_STATE_OFF != sState) {
            setRadioState(RADIO_STATE_ON);
        }

        if (datalen == sizeof(char*)) {
            write_sim_pin_password(strings[0]);
        } else if (datalen == 2*sizeof(char*)) {
            write_sim_pin_password(strings[1]);
        }else if ((request == RIL_REQUEST_ENTER_SIM_PUK) && (datalen > 2*sizeof(char*)))
        {
            write_sim_pin_password(strings[1]);
        }
    }

    at_response_free(p_response);
}

/* Merge leadcore-android-4.0.1_r1 about ussd ,by gaofeng 02-20 begin */
//<UH, 2011-1-4, lifangdong, Add for USSD ./>
int ascToHex(const char *in_str, unsigned short int in_len, char *out_fptr)
{
    signed long int i = 0;
    
    /* Check the validity of parameter */
    if ((NULL==in_str) || (NULL==out_fptr))
    {
        return -1;
    }

    /* ASCII string to HEX string */
    for (; i < in_len; i++)
    {
        sprintf(out_fptr+strlen(out_fptr), "%02X", in_str[i]);
    }

    return 0;
}

static void  requestSendUSSD(void *data, size_t datalen, RIL_Token t)
{       
    RIL_Ussd_Info *ussd_info_ptr = (RIL_Ussd_Info *)(data);

    //<UH, 2011-1-4, lifangdong, Add for USSD ./>
    char            *cmd = NULL;
    int             err;
    char            hex_buf[USSD_STRING_LENGH_MAX*2+1] = {0};
    char            asc_buf[USSD_STRING_LENGH_MAX*2+1] = {0};
    ATResponse      *p_response = NULL;
    char            *ussdStr = ussd_info_ptr->ussdStr ;
    int             mode = ussd_info_ptr->mode ;
    int             dcs  = ussd_info_ptr->dcs ;
    
    /*
    AT+CUSD=[<n>[,<str>[,<dcs>]]]
    Parameter:
    <n>
    0 disable the result code presentation in the TA
    1 enable the result code presentation in the TA
    2 ccancel session (not applicable to read command response)
    <str>
    String type USSD-string (when <str> parameter is not given, network is not interrogated).
    <dcs>
    3GPP TS 23.038 [25] Cell Broadcast Data Coding Scheme in integer format (default 15)
    15 7bit
    68 8bit
    72 16bit
    */
    if ((mode != USSD_DISABLE_UNSOLICITED_RESULT_CODE &&
        mode != USSD_ENABLE_UNSOLICITED_RESULT_CODE &&
        mode != USSD_CANCEL_SESSION) ||
        (dcs != USSD_DCS_7_BIT &&
        dcs != USSD_DCS_8_BIT &&
        dcs != USSD_DCS_16_BIT) ||
        ussdStr == NULL)
    {//20150131-48926
        RLOGD("[Before]Invalid parameter mode = %d, dcs = %d, ussdStr = %s", mode, dcs, ussdStr);
        if((mode != USSD_DISABLE_UNSOLICITED_RESULT_CODE &&
            mode != USSD_ENABLE_UNSOLICITED_RESULT_CODE  &&
            mode != USSD_CANCEL_SESSION))
        {
            mode = USSD_ENABLE_UNSOLICITED_RESULT_CODE;
        }

        if(dcs != USSD_DCS_7_BIT && dcs != USSD_DCS_8_BIT && dcs != USSD_DCS_16_BIT)
        {
            dcs = USSD_DCS_7_BIT;
        }
        RLOGD("[after]Invalid parameter mode = %d, dcs = %d, ussdStr = %s", mode, dcs, ussdStr);

        if(ussdStr == NULL)
        {
            goto error;
        }
    }

    ascToHex(ussdStr, strlen(ussdStr), hex_buf);
    asprintf(&cmd, "AT+CUSD=%d,\"%s\",%d", mode, hex_buf, dcs);
    
    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) {
        at_response_free(p_response);
		goto error;
    }
	
	at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}
/* Merge leadcore-android-4.0.1_r1 about ussd ,by gaofeng 02-20 end */

static void  requestCancelUSSD(void *data, size_t datalen, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;

    err = at_send_command_numeric("AT+CUSD=2", &p_response);

    if (err < 0 || p_response->success == 0) {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    } else {
        RIL_onRequestComplete(t, RIL_E_SUCCESS,
            p_response->p_intermediates->line, sizeof(char *));
    }
    at_response_free(p_response);
}

/* FIX "Add preferred plmn list" 2010-12-27 zoufeng begin */
static void  requestSetPreferredPlmnList(void *data, size_t datalen, RIL_Token t)
{
    int         err = 0;
    char        *cmd = NULL;
    ATResponse  *p_response = NULL;
    RIL_PreferredPlmnInfo   *p_args = (RIL_PreferredPlmnInfo *)data;

    /*
        AT+CPOL=[<index>][,<format>[,<oper>[,<GSM_AcT>,<GSM_Compact_AcT>,<UTRAN_AcT>]]]
            If <index> is given but <oper> is left out, entry is deleted.
            If <oper> is given but <index> is left out, <oper> is put in the next free location.
            If only <format> is given, the format of the <oper> in the read command is changed.
    */

    if(p_args
        && p_args->index != 0
        && (p_args->format == 0 || p_args->format == 1)) {
        /* It is not allowed that add/update UPLMN with <format> = 0/1. */
        RLOGI("It is not allowed that save with <format> = 0/1");
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
        return;
    }

    if(p_args->index > 0 && !((p_args->oper) && strlen(p_args->oper) > 0)) {
        /* Delete. */
        asprintf(&cmd, "AT+CPOL=%d", p_args->index);
    }
    else if(p_args->index <= 0 && ((p_args->oper) && strlen(p_args->oper) > 0)) {
        /* Add without special <index>. */
        asprintf(&cmd, "AT+CPOL=,%d,\"%s\",%d,%d,%d,%d",
                p_args->format,
                p_args->oper,
                p_args->gsmAct,
                p_args->gsmCompactAct,
                p_args->utranAct,
                p_args->etranAct);
    }
    else if(p_args->index <= 0 && !((p_args->oper) && strlen(p_args->oper) > 0)) {
        /* Set <format> */
        asprintf(&cmd, "AT+CPOL=,%d", p_args->format);
    }
    else {
        /* Add/Update*/
        asprintf(&cmd, "AT+CPOL=%d,%d,\"%s\",%d,%d,%d,%d",
                p_args->index,
                p_args->format,
                p_args->oper,
                p_args->gsmAct,
                p_args->gsmCompactAct,
                p_args->utranAct,
                p_args->etranAct);
    }

    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0)
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    else
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);

    at_response_free(p_response);
    return;
}

static void  requestGetPreferredPlmnList(void *data, size_t datalen, RIL_Token t)
{
    ATResponse  *p_response;
    ATLine      *p_cur = NULL;
    int         err = 0;
    int         list_count = 0;
    int         i = 0;
    RIL_PreferredPlmnInfo   *response = NULL;
    RIL_PreferredPlmnInfo   *responses = NULL;

    err = at_send_command_multiline ("AT+CPOL?", "+CPOL:", &p_response);
    if (err < 0 || p_response->success == 0) {
        at_response_free(p_response);
		RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    for (p_cur = p_response->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next) {
        list_count++;
    }

    responses = alloca(list_count * sizeof(RIL_PreferredPlmnInfo));
    memset(responses, 0x00, (list_count * sizeof(RIL_PreferredPlmnInfo)));

    i = 0;
    response = responses;
    for(p_cur=p_response->p_intermediates; p_cur != NULL; p_cur=p_cur->p_next) {
        char    *line = p_cur->line;
        char    *out = NULL;

        /* +CPOL: <index1>,<format>,<oper1>[,<GSM_AcT1>,<GSM_Compact_AcT1>,<UTRAN_AcT1>] */

        if(i >= list_count) {
            RLOGE("i(%d) >= list_count(%d)", i, list_count);
            break;
        }

        err = at_tok_start(&line);

        if(err >= 0)
            err = at_tok_nextint(&line, &(response->index));
        if(err >= 0)
            err = at_tok_nextint(&line, &(response->format));
        if(err >= 0) {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->oper = alloca(strlen(out) + 1);
                strcpy(response->oper, out);
            }
        }
        if(err >= 0)
            err = at_tok_nextint(&line, &(response->gsmAct));
        if(err >= 0)
            err = at_tok_nextint(&line, &(response->gsmCompactAct));
        if(err >= 0)
            err = at_tok_nextint(&line, &(response->utranAct));
        if(err >= 0)
            err = at_tok_nextint(&line, &(response->etranAct));

        if (err < 0)
            break;

        response++;
        i++;
    }

    at_response_free(p_response);

    if(err >= 0)
        RIL_onRequestComplete(t, RIL_E_SUCCESS, responses, (list_count * sizeof(RIL_PreferredPlmnInfo)));
    else
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}
/* FIX "Add preferred plmn list" 2010-12-27 zoufeng end */

/*Leadcore: fix Req00000143, 20110223, chengyuxin, Refresh Operation of USAT: RIL_REQUEST_REFRESH_OPERATION*/
void  requestRefreshOperation(void *data, size_t datalen, RIL_Token t)
{
    char *cmd = NULL;
    int err = 0;
    ATResponse  *p_response = NULL;
    RIL_RefreshParam   *p_args = (RIL_RefreshParam *)data;

    if(p_args->ref_mode == 4) {
        /* sim reset */
        asprintf(&cmd, "AT^DSATREF=%d", p_args->ref_mode);
    }
    else if(p_args->ref_mode == 1 && p_args->length > 0 &&  p_args->pRefresh_ef_list) {
        /* File update */
        asprintf(&cmd, "AT^DSATREF=%d,%d,\"%s\"",
                p_args->ref_mode,
                p_args->length,
                p_args->pRefresh_ef_list);
    }
    else {
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return ;
    }

    at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err != 0) {
        RLOGD("Send SIM refresh command fail");
        goto error;
    }
    switch (at_get_cme_error(p_response)) {
        case CME_SUCCESS:
            break;

        case CME_SIM_PIN_REQUIRED:
            {
                char pinString[10];
                if (g_sPinEntered && (read_sim_pin_password(pinString) == ERR_NONE)) {
                    char * cmd;
                    asprintf(&cmd, "AT+CPIN=\"%s\"", pinString);
                    err = at_send_command(cmd, NULL);
                    if (NULL != cmd) {
                        free(cmd);
                        cmd = NULL;
                    }
                    
                    RLOGD("refresh,input PIN: %s", pinString);
                }
            }
            break;
        default:
            goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    return;

error:
    at_response_free(p_response);
    RLOGE("ERROR: requestRefreshOperation failed\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}


//<UH, 2011-02-21, lifangdong, Add ContactsAttribute./
static void requestReadCardRecordNum(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int response[5], scpbs_response[12] = {0}, i, j;
    char *line = NULL;
    int err = 0;
    char *tmp;

    err = at_send_command("AT+CPBS=\"SM\"", NULL); 
    err = at_send_command_singleline("AT+CPBS?", "+CPBS:", &p_response);
    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &tmp);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[0]));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[1]));
    if (err < 0) goto error;

    at_response_free(p_response);
    p_response = NULL;

    #ifdef OPT_MODEM_L1813
    err = at_send_command_singleline("AT^DPBW=?", "^DPBW:", &p_response);
    #else
    err = at_send_command_singleline("AT^SCPBS=?", "^SCPBS:", &p_response);
    #endif
    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &tmp);
    if (err < 0) goto error;

    scpbs_response[0] = 1;
    scpbs_response[1] = atoi(&tmp[3]);

    for (i = 2; i < 12; i++) {
        err = at_tok_nextint(&line, &(scpbs_response[i]));
        if (err < 0) goto error;
    }

    response[2] = scpbs_response[2];
    response[3] = scpbs_response[3];
    response[4] = scpbs_response[11];

    DBBD(DB_RIL, RLOGD("requestReadCardRecordNum response=("));
    for (j = 0; j < 5; j++) {
        DBBD(DB_RIL, RLOGD("%d,",response[j]));
    }
    DBBD(DB_RIL, RLOGD(")\n"));

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, 5*sizeof(int));
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    s_record_done = FALSE;
    at_response_free(p_response);
}

//< Read USIM records with "AT^SCPBR"./
static void  requestGetIccCardRecord(void *data, size_t datalen, RIL_Token t)
{
    ATResponse  *p_response;
    ATLine          *p_cur = NULL;
    char             *cmd;
    int         err = 0;
    int         record_count = 0;
    int         i = 0;
    int         index_min = ((int *)data)[0];
    int         index_max = ((int *)data)[1];
    RIL_IccCardRecord   *response = NULL;
    RIL_IccCardRecord   *responses = NULL;
    
    asprintf(&cmd,"AT^SCPBR=%d,%d", index_min, index_max);
    err = at_send_command_multiline (cmd, "^SCPBR:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) {
        at_response_free(p_response);
		RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    for (p_cur = p_response->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next) {
        record_count++;
    }

    RLOGD("====> requestGetIccCardRecord record_count = %d", record_count);

    responses = alloca(record_count * sizeof(RIL_IccCardRecord));
    memset(responses, 0x00, (record_count * sizeof(RIL_IccCardRecord)));

    i = 0;
    response = responses;
    for(p_cur=p_response->p_intermediates; p_cur != NULL; p_cur=p_cur->p_next) {
        char    *line = p_cur->line;
        char    *out = NULL;

        /*
        [^SCPBR: <index1>,<num1>,<type>,<num2>,<type>,<num3>,<type>,<num4>,<type>,<text>,<coding>[,<email>][[...]
         ^SCPBR: <index2>,<num1>,<type>,<num2>,<type>,<num3>,<type>,<num4>,<type>,<text>],<coding>[,<email>]]]
        */

        if(i >= record_count) {
            RLOGE("====>requestGetIccCardRecord i(%d) >= record_count(%d)", i, record_count);
            break;
        }

        err = at_tok_start(&line);

        //index
        if(err >= 0)
            err = at_tok_nextint(&line, &(response->index));

        //num1
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->num1 = alloca(strlen(out) + 1);
                strcpy(response->num1, out);
            }
        }

        //type1
        err = at_tok_nextint(&line, &(response->type1));
        
        //num2
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->num2 = alloca(strlen(out) + 1);
                strcpy(response->num2, out);
            }
        }

        //type2
        err = at_tok_nextint(&line, &(response->type2));
            
        //num3
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->num3 = alloca(strlen(out) + 1);
                strcpy(response->num3, out);
            }
        }

        //type3
        err = at_tok_nextint(&line, &(response->type3));

        //num4
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->num4 = alloca(strlen(out) + 1);
                strcpy(response->num4, out);
            }
        }

        //type4
        err = at_tok_nextint(&line, &(response->type4));

        //name
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->name = alloca(strlen(out) + 1);
                strcpy(response->name, out);
                RLOGD("====> [scpbr] out = %s",  out);
            }
        }

        //dcs
        err = at_tok_nextint(&line, &(response->dcs));

        //email
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->email = alloca(strlen(out) + 1);
                strcpy(response->email, out);
            }
        }

        convertNumber(response, 1);

        if (err < 0)
            break;

        response++;
        i++;
    }

    at_response_free(p_response);
	p_response = NULL;

    if(responses != NULL)
    {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, responses, (record_count * sizeof(RIL_IccCardRecord)));
        s_record_done = TRUE;
    }
    else
    {
       RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
       s_record_done = FALSE;
    }
}

static void  requestStkServiceReport(void*  data, size_t  datalen, RIL_Token  t)
{
    at_send_command("AT^DTUSAT=1", NULL);
    DBBD(DB_RIL, RLOGD("heroguo send request stk service running"));
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}


static void  testGetIccCardRecord()
{
    ATResponse  *p_response;
    ATLine          *p_cur = NULL;
    char             *cmd;
    int         err = 0;
    int         record_count = 0;
    int         i = 0;
    int         index_min = 1;
    int         index_max = 250;
    RIL_IccCardRecord   *response = NULL;
    RIL_IccCardRecord   *responses = NULL;
    
    asprintf(&cmd,"AT^SCPBR=%d,%d", index_min, index_max);
    err = at_send_command_multiline (cmd, "^SCPBR:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) {
        at_response_free(p_response);
		return;
    }

    for (p_cur = p_response->p_intermediates; p_cur != NULL; p_cur = p_cur->p_next) {
        record_count++;
    }

    RLOGD("====> requestGetIccCardRecord record_count = %d", record_count);

    responses = alloca(record_count * sizeof(RIL_IccCardRecord));
    memset(responses, 0x00, (record_count * sizeof(RIL_IccCardRecord)));

    i = 0;
    response = responses;
    for(p_cur=p_response->p_intermediates; p_cur != NULL; p_cur=p_cur->p_next) {
        char    *line = p_cur->line;
        char    *out = NULL;

        /*
        [^SCPBR: <index1>,<num1>,<type>,<num2>,<type>,<num3>,<type>,<num4>,<type>,<text>,<coding>[,<email>][[...]
         ^SCPBR: <index2>,<num1>,<type>,<num2>,<type>,<num3>,<type>,<num4>,<type>,<text>],<coding>[,<email>]]]
        */

        if(i >= record_count) {
            RLOGE("====>requestGetIccCardRecord i(%d) >= record_count(%d)", i, record_count);
            break;
        }

        err = at_tok_start(&line);

        //index
        if(err >= 0)
            err = at_tok_nextint(&line, &(response->index));

        //num1
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->num1 = alloca(strlen(out) + 1);
                strcpy(response->num1, out);
            }
        }

        //type1
        err = at_tok_nextint(&line, &(response->type1));
        
        //num2
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->num2 = alloca(strlen(out) + 1);
                strcpy(response->num2, out);
            }
        }

        //type2
        err = at_tok_nextint(&line, &(response->type2));
            
        //num3
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->num3 = alloca(strlen(out) + 1);
                strcpy(response->num3, out);
            }
        }

        //type3
        err = at_tok_nextint(&line, &(response->type3));

        //num4
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->num4 = alloca(strlen(out) + 1);
                strcpy(response->num4, out);
            }
        }

        //type4
        err = at_tok_nextint(&line, &(response->type4));

        //name
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->name = alloca(strlen(out) + 1);
                strcpy(response->name, out);
            }
        }

        //dcs
        err = at_tok_nextint(&line, &(response->dcs));
        
        //email
        {
            err = at_tok_nextstr(&line, &out);
            if(err >= 0) {
                response->email = alloca(strlen(out) + 1);
                strcpy(response->email, out);
            }
        }

        if (err < 0)
            break;

        response++;
        i++;
    }

    at_response_free(p_response);
}

static void *cpbr_loop(void *arg)
{
    for (;;) {
            testGetIccCardRecord();
           sleep(1);
           RLOGD("===>sleep 1s...");
    }

    return NULL;
}

static void  startTestSCPBR()
{
    pthread_attr_t attr;
    pthread_t s_tid_cpbr;
    pthread_attr_init (&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    int ret = pthread_create(&s_tid_cpbr, &attr, cpbr_loop, &attr);
    if (ret < 0) {
        perror ("pthread_create");
    }
}

//write record without index.
static int HandleWriteIccCardRecordNoIndex(void *data)
{
    ATResponse *p_response;
    char *cmd;
    int err = 0;
    RIL_IccCardRecord *p_args;
    int value= -1;
    char *line = NULL;

    p_args = (RIL_IccCardRecord *)data;
    RLOGD("===>  HandleWriteIccCardRecordNoIndex AT^DCPBW");

    asprintf(&cmd,"AT^DCPBW=\"%s\",%d,\"%s\",%d,\"%s\",%d,\"%s\",%d,\"%s\",%d,\"%s\"",
                p_args->num1,
                p_args->type1,
                p_args->num2,
                p_args->type2,
                p_args->num3,
                p_args->type3,
                p_args->num4,
                p_args->type4,
                p_args->name,
                p_args->dcs,
                p_args->email);

    err = at_send_command_singleline(cmd, "^DCPBW:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &value);
    if (err < 0) goto error;

    at_response_free(p_response);
    return value;

error:
    at_response_free(p_response);
    return -1;
}

static void  requestWriteIccCardRecord(void *data, size_t datalen, RIL_Token t)
{
    ATResponse              *p_response;
    char                          *cmd;
    int                             err = 0;
    RIL_IccCardRecord    *p_args;

    p_args = (RIL_IccCardRecord *)data;
    int response[1] = {0};

    //Fix Enh00000052 by yangli to add record only with email begin
    if ((p_args->num1 == NULL || strlen(p_args->num1) == 0) &&
         (p_args->num2 == NULL || strlen(p_args->num2) == 0) &&
         (p_args->num3 == NULL || strlen(p_args->num3) == 0) &&
         (p_args->num4 == NULL || strlen(p_args->num4) == 0) &&
         (p_args->name == NULL || strlen(p_args->name) == 0) &&
         (p_args->email == NULL || strlen(p_args->email) == 0))
    {
        asprintf(&cmd,"AT^SCPBW=%d", p_args->index);//delete
    }
	//add record only with email end
    else
    {
        convertNumber(p_args, 0);

        RLOGD("===> [SCPBW] p_args->dcs:%d, p_args->name:%s",p_args->dcs,p_args->name);
            asprintf(&cmd,"AT^SCPBW=%d,\"%s\",%d,\"%s\",%d,\"%s\",%d,\"%s\",%d,\"%s\",%d,\"%s\"",
                        p_args->index,
                        p_args->num1,
                        p_args->type1,
                        p_args->num2,
                        p_args->type2,
                        p_args->num3,
                        p_args->type3,
                        p_args->num4,
                        p_args->type4,
                        p_args->name,
                        p_args->dcs,
                        p_args->email);
    }

    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    //write record without index begin.
    if (err < 0 || p_response->success == 0)
    {
        if (at_get_cme_error(p_response) == CME_CARD_MEMORY_FULL)
        {
            response[0] = HandleWriteIccCardRecordNoIndex(data);
            if (response[0] == -1)
            {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
            }
            else
            {
                RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(int));
            }
        }
        else
        {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        }
    }
    else
    {
        RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(int));
    }

    at_response_free(p_response);

    return;
}

int  send_scpbs(int tag, int index, /*out*/ int *result_response)
{
#ifdef OPT_MODEM_L1813
	return -1;
#else
    char   *cmd;
    int tmp_tag, tmp_index;
    char *line = NULL;
    ATResponse *p_response = NULL;
    int err = 0;

    asprintf(&cmd,"AT^SCPBS=%d,%d", tag, index);
    // ^SCPBS: <tag>,<index>,<used>,<total>	
    err = at_send_command_multiline (cmd, "^SCPBS:", &p_response);
    if (err < 0 || p_response->success == 0)
    {
        goto error;
    }

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if(err < 0) goto error;

    //tag
    err = at_tok_nextint(&line, &(tmp_tag));
    if (err < 0) goto error;

    //index
    err = at_tok_nextint(&line, &(tmp_index));
    if (err < 0) goto error;

    //used
    err = at_tok_nextint(&line, result_response);
    if (err < 0) goto error;

    //total
    err = at_tok_nextint(&line, result_response+1);
    if (err < 0) goto error;
    RLOGD("===> [SCPBS] %d, %d, used[0]:%d, total[1]:%d", tmp_tag, tmp_index, *result_response, *(result_response+1));

    at_response_free(p_response);
	return 0;
	
error:
	at_response_free(p_response);
	return -1;
#endif
}

static void  requestGetAdnStorageInfo(void *data, size_t datalen, RIL_Token t)
{
    int result_response[2] = {0};//<used>,<total>

    int err = 0;
    int i_tag = -1;
    int i_index = 0;

    i_tag = ((int *)data)[0];
    i_index = ((int *)data)[1];

    RLOGD("===> [SCPBS] i_tag:%d, i_index:%d", i_tag, i_index);

    switch (i_tag) {
        case  STORES_ABBREVIATED_DIALING_NUMBERS:
        break;
        case  STORES_INDEX_OF_ADMIN_PB:
        break;
        case  STORES_EXTENSION_DATA:
        break;
        case  STORES_NAME_ENTRY:
        break;
        case  STORES_CONTROLS_OF_PB:
        break;
        case  STORES_GROUPINGS:
        break;
        case  STORES_ADDITIONAL_NUMBER_ALPHA:
        break;
        case  STORES_GROUPING_INFO_ALPHA:
        break;
        case  STORES_UNIQUE_IDENTIFIER:
        break;
        case  STORES_ADDITIONAL_NUMBERS://196
        case  STORES_EMAIL_ADDRESS://202
            //response->total_record .//AT^SCPBS=<tag>,<index>
            err = send_scpbs(i_tag, i_index, result_response);
            if (-1 == err)  goto error;
        break;

        default:
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, result_response, 2*sizeof(int));
    return;

    error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}
//[Req00000178]gaofeng 20140219 end

static void requestGetPhoneBookOperationErrCode(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int response;
    char *line = NULL;
    int err = 0;

    err = at_send_command_singleline("AT^GPBERRNO", "^GPBERRNO:", &p_response);
    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &response);
    if (err < 0) goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

static void requestGetIccPhonebookRecordInfo(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response = NULL;
    int response[12] = {0}, i, j;
    char *line = NULL;
    int err = 0;
    char *tmp;
    #ifdef OPT_MODEM_L1813
    err = at_send_command_singleline("AT^DPBW=?", "^DPBW:", &p_response);
    #else
    err = at_send_command_singleline("AT^SCPBS=?", "^SCPBS:", &p_response);
    #endif
    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &tmp);
    if (err < 0) goto error;

    DBBD(DB_RIL, RLOGD("tmp=%s \n", tmp));
    response[0] = 1;
    response[1] = atoi(&tmp[3]);

    for (i = 2; i < 12; i++) {
        err = at_tok_nextint(&line, &(response[i]));
        if (err < 0) goto error;
    }

    #ifdef OPT_MODEM_L1813
    DBBD(DB_RIL, RLOGD("DPBW response=("));
    #else
    DBBD(DB_RIL, RLOGD("SCPBS response=("));
    #endif
    for (j = 0; j < 12; j++) {
        DBBD(DB_RIL, RLOGD("%d,",response[j]));
    }
    DBBD(DB_RIL, RLOGD(")\n"));

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, 12*sizeof(int));
    at_response_free(p_response);
    return;

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

/* FIX L1809OG_Bug00000405 2011-03-17 zoufeng begin */
static void  requestShutDownRadio(void *data, size_t datalen, RIL_Token t)
{
    int err;

    is_pb_ready = 0;/*L1813 Bug00000579, wangsheng, 2013-07-03*/
    /*FIX L1810_Bug00003646 2013-04-08 by zhongjilei begin*/
    err = at_send_command("AT^DUSIMR=0", NULL);
    err = at_send_command("AT+CFUN=0", NULL);
    
    /* FIX L1860_Enh00000066 2014-04-15 zoufeng begin */
    err = at_send_command("AT+CFUN=6", NULL);
    /* FIX L1860_Enh00000066 2014-04-15 zoufeng end */
    /*FIX L1810_Bug00003646 2013-04-08 by zhongjilei end*/

    is_first_power_on = 0;/*L1813_Enh00000425, wangsheng, 2013-08-19*/
    is_radio_power_off = 1;
    setRadioState(RADIO_STATE_OFF);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}
/* FIX L1809OG_Bug00000405 2011-03-17 zoufeng end */

//added for black incoming call by zhujiadong
static void requestConfirmIncommingCall(void* data, size_t datalen, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    assert (datalen >= 2 * sizeof(int *));
    int cid  = ((int *)data)[0];
    int confirm = ((int *)data)[1];
    char             *cmd = NULL;
	
    if (confirm == 1){
        asprintf(&cmd,"AT^DANS=%d,%d", cid, confirm);
    }else{
        //Modified by guojing for Enh00000568, add the tone of black incoming call. 2012-12-12
        asprintf(&cmd,"AT^DANS=%d,%d,17", cid, confirm);
    }
    err = at_send_command(cmd, &p_response);
    if (cmd != NULL){
        free(cmd);
        cmd = NULL;
    }
    if (err < 0 || p_response->success == 0) goto error;
    
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);

    return;

error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

//Add by guojing for informing Modem the standby of playing the voice. 2012-6-16
static void requestSetStandbyAudioPlaying(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *cmd;
    int linkID;
    ATResponse *p_response = NULL;

    assert (datalen >= sizeof(int *));

    linkID = ((int*)data)[0];
    asprintf(&cmd, "AT^DAUDSIS=%d", linkID);
    err = at_send_command(cmd, &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    if (err < 0 || p_response->success == 0) goto error;
    
	at_response_free(p_response);
	RIL_onRequestComplete(t, RIL_E_SUCCESS, &linkID, sizeof(int));
    return;

error:
    RLOGE("ERROR: requestSetMute failed");
	at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &linkID, sizeof(int));
}
//Add end

// add [by chenshu 2012-07-04] for cmmb
static void  requestMBMSSendauth(void*  data, size_t  datalen, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char         *cmd = NULL;
    char         *line = NULL;
    const char**  strings = (const char**)data;
    
    GBA_RES      *gbaRes = NULL;
    char         *pTmp = NULL;

    if (datalen != 2*sizeof(char*)) goto error;

    asprintf(&cmd, "AT^DAUC=%s,%s", strings[0], strings[1]);
    err = at_send_command_singleline(cmd, "^DAUC:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    gbaRes = (GBA_RES*)malloc(sizeof(GBA_RES));

    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;
    
    err = at_tok_nextint(&line, &(gbaRes->retValue));
    if (err < 0) goto error;

    err = at_tok_nextstr(&line, &pTmp);
    if (err >= 0) {
        gbaRes->retStr = alloca(strlen(pTmp) + 1);
        strcpy(gbaRes->retStr, pTmp);
    }
        
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, gbaRes, sizeof(GBA_RES));
    free(gbaRes);
    return;
error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void  requestMBMSUiccAuth(void*  data, size_t  datalen, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char         *cmd  = NULL;
    char         *line = NULL;
    const char**  strings = (const char**)data;
    char         *pKc   = NULL;
    char         *pSres = NULL;
    char         *pCk = NULL;
    char         *pIk = NULL;
    char         *pRes  = NULL;

    MBMS_UICC_AUTH_RESULT  *uiccRes = NULL;

    if (datalen != 2*sizeof(char*)) goto error;

    if (strings[1] == NULL){
        int i = 0;
        asprintf(&cmd, "AT^MBAU=%s", strings[0]);
        for (i = 0; i < 16; i++){
            RLOGD("CMD = %0x\n", *(strings[0]+i));
        }
    }
    else {
        asprintf(&cmd, "AT^MBAU=%s,%s", strings[0], strings[1]);
    }

    err = at_send_command_singleline(cmd, "^MBAU:", &p_response);
    if (NULL != cmd) {
        free(cmd);
        cmd = NULL;
    }

    uiccRes = (MBMS_UICC_AUTH_RESULT*)malloc(sizeof(MBMS_UICC_AUTH_RESULT));
    uiccRes->kc_ptr = pKc;
    uiccRes->sres_ptr = pSres;
    uiccRes->ck_ptr = pCk;
    uiccRes->ik_ptr = pIk;
    uiccRes->ret_ptr = pRes;

    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;
    
    err = at_tok_nextint(&line, &(uiccRes->status));
    if (err < 0) goto error;

    if (at_tok_hasmore(&line)) {
        if (strings[1] == NULL) {
            err = at_tok_nextstr(&line, &pKc);
            if (err >= 0) {
                uiccRes->kc_ptr = alloca(strlen(pKc) + 1);
                strcpy(uiccRes->kc_ptr, pKc);
            }
            err = at_tok_nextstr(&line, &pSres);
            if (err >= 0) {
                uiccRes->sres_ptr= alloca(strlen(pSres) + 1);
                strcpy(uiccRes->sres_ptr, pSres);
            }
        }else {
            err = at_tok_nextstr(&line, &pCk);
            if (err >= 0) {
                uiccRes->ck_ptr = alloca(strlen(pCk) + 1);
                strcpy(uiccRes->ck_ptr, pCk);
            }
            err = at_tok_nextstr(&line, &pIk);
            if (err >= 0) {
                uiccRes->ik_ptr = alloca(strlen(pIk) + 1);
                strcpy(uiccRes->ik_ptr, pIk);
            }
            err = at_tok_nextstr(&line, &pRes);
            if (err >= 0) {
                uiccRes->ret_ptr = alloca(strlen(pRes) + 1);
                strcpy(uiccRes->ret_ptr, pRes);
            }
        }
    }    
        
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, uiccRes, sizeof(MBMS_UICC_AUTH_RESULT));
    free(uiccRes);
    return;
error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

static void  requestMBMSGetCellID(void*  data, size_t  datalen, RIL_Token  t)
{
    ATResponse   *p_response = NULL;
    int           err;
    char         *cmd = NULL;
    char         *line = NULL;
    int           bdsType;
    GBA_RES      *pRes;
    char         *pTmp = NULL;
    
    assert (datalen >= sizeof(int *));

    bdsType = ((int*)data)[0];

    asprintf(&cmd, "AT^MBCELLID=%d", bdsType);
    err = at_send_command_singleline(cmd, "^MBCELLID:", &p_response);
    free(cmd);

    pRes = (GBA_RES*)malloc(sizeof(GBA_RES));

    if (err < 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err < 0) goto error;
    
    err = at_tok_nextint(&line, &(pRes->retValue));
    if (err < 0) goto error;

    if (at_tok_hasmore(&line)) {
        err = at_tok_nextstr(&line, &pTmp);
        if (err >= 0) {
            pRes->retStr = alloca(strlen(pTmp) + 1);
            strcpy(pRes->retStr, pTmp);
        }
    }else {
        pRes->retStr = NULL;
    }

    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, pRes, sizeof(GBA_RES));
    free(pRes);
    return;
error:
    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}
// add [by chenshu 2012-07-04] end

static void requestGetCellInfoList(void *data, size_t datalen, RIL_Token t)
{
    /*uint64_t curTime = ril_nano_time();
    //RIL_CellInfo ci[1] =
    RIL_CellInfo ci[0] =
    {
        { // ci[0]
            1, // cellInfoType
            1, // registered
            curTime - 1000, // Fake some time in the past
            { // union CellInfo
                {  // RIL_CellInfoGsm gsm
                    {  // gsm.cellIdneityGsm
                        s_mcc, // mcc
                        s_mnc, // mnc
                        s_lac, // lac
                        s_cid, // cid
                        0  // psc
                    },
                    {  // gsm.signalStrengthGsm
                        10, // signalStrength
                        0  // bitErrorRate
                    }
                }
            }
        }
    };

    RIL_onRequestComplete(t, RIL_E_SUCCESS, ci, sizeof(ci));*/
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);       /*add by yuanhaobo L1860_Bug00000805 @ 2014-05-13*/
}

static void requestSetCellInfoListRate(void *data, size_t datalen, RIL_Token t)
{
    // For now we'll save the rate but no RIL_UNSOL_CELL_INFO_LIST messages
    // will be sent.
    assert (datalen == sizeof(int));
    s_cell_info_rate_ms = ((int *)data)[0];

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void onCheckSimStatus(void *param) {
    checkSimStatus();
}

static void requestCheckSimStatus(void *data, size_t datalen, RIL_Token t){
    checkSimStatus();
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

static void checkSimStatus()
{
    int err;
    int loopCount = 0;
    char *cmdLine = NULL;
    char *cmdResult = NULL;
    ATResponse *p_response = NULL;

    while (loopCount++ < 5) {
        err = at_send_command_singleline("AT+CPIN?", "+CPIN:", &p_response);
        if (NULL != p_response) {
            RLOGD("checkSimStatus(), err = %d, p_response->success = %d, p_response->finalResponse = %s", err, p_response->success, p_response->finalResponse);

            if ((err == 0 && p_response->success == 1) || strcmp(p_response->finalResponse, "+CME ERROR: 10") == 0) {
                RLOGD("checkSimStatus(), break while");
                break;
            }
        }

        RLOGE("checkSimStatus(), sleep 1 second, loopCount = %d", loopCount);
        sleep(1);
    }

    if (1 == p_response->success) {
        cmdLine = p_response->p_intermediates->line;
        err = at_tok_start(&cmdLine);
        if (err < 0) goto error;
        err = at_tok_nextstr(&cmdLine, &cmdResult);
        if (err < 0) goto error;

        RLOGD("checkSimStatus(), cmdResult = \"%s\"", cmdResult);
        if (0 == strcmp(cmdResult, "SIM PIN")) {
            char propValue[4] = {0};
            char propString[32] = {0};

            sprintf(propString, RIL_MODEM_EXCEP_FLAG"%d", s_rilID);
            RLOGD("checkSimStatus(), property string = %s", propString);

            if (__system_property_get(propString, propValue) > 0 && propValue[0] == '1') {
                /* if modem excep flag is equal "1", enter PIN */
                char pinString[10] = {0};
                write_flag_file_by_rilId("0", s_rilID);
                RLOGD("checkSimStatus(), set property: %s = 0", propString);

                if (read_sim_pin_password(pinString) == ERR_NONE) {
                    char *cmd = NULL;
                    RLOGD("checkSimStatus(), read_sim_pin_password, pinString = \"%s\"", pinString);
                    asprintf(&cmd, "AT+CPIN=\"%s\"", pinString);
                    err = at_send_command(cmd, NULL);
                    free(cmd);
                    cmd = NULL;
                }
            } else {
                RLOGD("checkSimStatus(), read property: %s = %s, property value isn't equal \"1\"", propString, propValue);
            }
        } else{
            RLOGD("checkSimStatus(), cmdResult is not \"SIM PIN\"");
            write_flag_file_by_rilId("0", s_rilID);
            RLOGD("checkSimStatus(), set property: %s%d = 0", RIL_MODEM_EXCEP_FLAG, s_rilID);
        }
    }

    RLOGD("checkSimStatus(), s_rilID=%d, is_first_power_on=%d", s_rilID, is_first_power_on);
    if (0 == is_first_power_on) {
        requestSIMType(NULL);
    }

    is_first_power_on = 1;
    RLOGD("checkSimStatus(), is_first_power_on = 1, s_rilID = %d", s_rilID);

error:
    RLOGD("checkSimStatus(), cmdResult is error");
    at_response_free(p_response);
    checkAndPollSimStat();
}

static void requestSetSimPower(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *cmd;
    int response = -1;;
    ATResponse *p_response = NULL;

    RLOGD("requestSetSimPower data = %d, datalen = %d", ((int *)data)[0], datalen);
    assert (datalen >= sizeof(int *));

    asprintf(&cmd, "AT+CFUN=%d", ((int *)data)[0]);
    err = at_send_command(cmd, &p_response);
    if (cmd != NULL) {
        free(cmd);
        cmd = NULL;
    }

    if (NULL != p_response) {
		RLOGD("requestSetSimPower err = %d, p_response->success = %d", err, p_response->success);
		RLOGD("requestSetSimPower finalResponse = %s, p_intermediates->line = %s", p_response->finalResponse, p_response->p_intermediates->line);
	}
	
    if (err < 0 || p_response->success == 0)
        goto error;

    response = 0;
    RLOGD("requestSetSimPower success, response = %d", response);
	at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(response));
    return;

error:
    RLOGE("ERROR: requestSetSimPower failed, response = %d", response);
	at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, &response, sizeof(response));
}

static void unsolicitedNitzTime(const char * s)
{
    int err;
    char * response = NULL;
    char * line = NULL;
    char * p = NULL;
    char * str = NULL;
    //modified by mabin for avoiding memory leak
    str = line = strdup(s);

    at_tok_start(&str);

    err = at_tok_nextstr(&str, &response);
    if (err < 0) goto error;

    /* Higher layers expect a NITZ string in this format:
    *  08/10/28,19:08:37-20,1 (yy/mm/dd,hh:mm:ss(+/-)tz,dst)
    * Modem provides string in this format:
    *  08/10/28,19:08:37-20,+1
    * To find DST look for ",+" in the NITZ string 
    */
    for (p = response ; *p != '\0' ;p++) {
        if ((*p == ',') && (*(++p) == '+')) {
            *p=*(p+1);
            *++p = '\0';
        }
    }

    RIL_onUnsolicitedResponse(RIL_UNSOL_NITZ_TIME_RECEIVED, response, strlen(response));
    free(line);
    return;

error:
    free(line);
    RLOGE("Invalid NITZ line %s\n", s);
}

/*add by jiangxuqin, 2015-01-08, for Req20150107-44878 begin*/
static void unsolicitedNitzTimeEx(const char * s)
{
    int err, dst, year, i=0;
    char * line = NULL;
    char * str = NULL;
    char *response[2];   
    char *responseStr = NULL;
    char *timeStr[2];
    char *result = NULL;
    char tempStr[3][5];  

    str = line = strdup(s);

    at_tok_start(&str);
    memset(response, 0, sizeof(response));
    err = at_tok_nextstr(&str, &response[0]);
    if (err < 0) goto error;

    err = at_tok_nextint(&str, &dst);
    if (err < 0) goto error;

    err = at_tok_nextstr(&str, &response[1]);
    if (err < 0) goto error;

    err = at_tok_nextstr(&response[1], &timeStr[0]);
    if (err < 0) goto error;

    err = at_tok_nextstr(&response[1], &timeStr[1]);
    if (err < 0) goto error;

    result = strtok(timeStr[0], "/");
    while(NULL != result && i<3)
    {
        snprintf(tempStr[i], 5, "%s", result);
        i++;
        result = strtok(NULL, "/");
    }
    year = atoi(tempStr[0]) - 2000;
    /* Higher layers expect a NITZ string in this format:
    *  08/10/28,19:08:37-20,1 (yy/mm/dd,hh:mm:ss(+/-)tz,dst)
    * Modem provides string in this format:
    *  08/10/28,19:08:37-20,+1
    * To find DST look for ",+" in the NITZ string
    */
    asprintf(&responseStr, "%d/%s/%s,%s%s,%d", year, tempStr[1], tempStr[2], timeStr[1], response[0], dst);  
    RLOGE("unsolicitedNitzTimeEx   i:%d, responseStr:%s\n", i, responseStr);

    RIL_onUnsolicitedResponse(RIL_UNSOL_NITZ_TIME_RECEIVED, responseStr, strlen(responseStr));
    free(line);
    free(responseStr);
    return;
  
error:
    free(line);    
    RLOGE("Invalid NITZ line %s\n", s);
}
/*add by jiangxuqin, 2015-01-08, for Req20150107-44878 end*/

/*add by huangxianfe, 2017-04-25 for LC1881 start*/
static void requestSendAt(void *data, size_t datalen, RIL_Token t)
{
    int err;
    char *cmd = NULL;
    char *response = NULL;
    ATResponse *p_response = NULL;

    RLOGD("requestSendAt data = %s, datalen = %d, strlen = %d", (char *)data, datalen);
    assert(datalen != 1);

    asprintf(&cmd, "%s", (char *)data);
    response = (char*)data;
    err = at_send_command_multiline(cmd, "", &p_response);

    if(cmd != NULL) {
        free(cmd);
        cmd = NULL;
    }

    RLOGD("requestSendAt err = %d, \n", err);
    if(p_response->p_intermediates == NULL) {
        RLOGD("requestSendAt finalResponse = %s", p_response->finalResponse);
        asprintf(&response, "%s\r\n", p_response->finalResponse);
    }else {
        RLOGD("requestSendAt finalResponse = %s, p_intermediates->line = %s",
            p_response->finalResponse,
            p_response->p_intermediates->line);
        asprintf(&response, "%s,%s\r\n", p_response->p_intermediates->line,
            p_response->finalResponse);
    }
    if(err < 0 || p_response->success == 0) {
        /*Maybe the at command form user is invalid, we also send successful response to user, the result should handle it itself*/
        goto error;
    }
    RLOGD("requestSendAt success, reponse = %s, len = %d", response, strlen(response));
    RIL_onRequestComplete(t,RIL_E_SUCCESS,response,strlen(response));
    free(response);
    return;

error:
    RLOGE("ERROR: requestSendAt failed, response = %d", response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    free(response);
}
/*add by huangxianfe, 2017-04-25 for LC1881 end*/

/**
 * Call from RIL to us to make a RIL_REQUEST
 *
 * Must be completed with a call to RIL_onRequestComplete()
 *
 * RIL_onRequestComplete() may be called from any thread, before or after
 * this function returns.
 *
 * Will always be called from the same thread, so returning here implies
 * that the radio is ready to process another command (whether or not
 * the previous command has completed).
 */
static void
onRequest (int request, void *data, size_t datalen, RIL_Token t)
{
    RLOGD("onRequest: %s", requestToString(request));

    /* Ignore all requests except RIL_REQUEST_GET_SIM_STATUS
     * when RADIO_STATE_UNAVAILABLE.
     */
     
     /*delete by wyy ,reuse later!2020.5.13*/
	/*
    if (sState == RADIO_STATE_UNAVAILABLE
        && request != RIL_REQUEST_GET_SIM_STATUS
    ) {
        if(request == RIL_REQUEST_CHECK_SIM_STATUS){
            fail_check_sim_status = TRUE;
        }
        RIL_onRequestComplete(t, RIL_E_RADIO_NOT_AVAILABLE, NULL, 0);
        return;
    }
    }*/

    /* Ignore all non-power requests when RADIO_STATE_OFF
     * (except RIL_REQUEST_GET_SIM_STATUS)
     */
    if (sState == RADIO_STATE_OFF
        && !(request == RIL_REQUEST_RADIO_POWER
        || request == RIL_REQUEST_SHUT_DOWN_RADIO
        || request == RIL_REQUEST_GET_SIM_STATUS
        || request == RIL_REQUEST_ENTER_SIM_PIN
        || request == RIL_REQUEST_ENTER_SIM_PIN2
        || request == RIL_REQUEST_CHANGE_SIM_PIN
        || request == RIL_REQUEST_CHANGE_SIM_PIN2
        || request == RIL_REQUEST_ENTER_SIM_PUK
        || request == RIL_REQUEST_ENTER_SIM_PUK2
        || request == RIL_REQUEST_SET_FACILITY_LOCK
        || request == RIL_REQUEST_QUERY_FACILITY_LOCK
        || request == RIL_REQUEST_GET_IMEI
        || request == RIL_REQUEST_GET_IMSI
        || request == RIL_REQUEST_GET_IMEISV
        || request == RIL_REQUEST_BASEBAND_VERSION
        || request == RIL_REQUEST_GET_RECORD_NUM
        || request == RIL_REQUEST_STK_SEND_TERMINAL_RESPONSE
        || request == RIL_REQUEST_STK_SEND_ENVELOPE_COMMAND    /* Leadcore: Fix Bug00001623, 20110422, chengyuxin, enter stk submenu when flight is on*/
        || request == RIL_REQUEST_STK_SEND_ENVELOPE_WITH_STATUS
        || request == RIL_REQUEST_GET_ICC_PHONEBOOK_RECORD_INFO
        || request == RIL_REQUEST_SIM_IO
        || request == RIL_REQUEST_READ_ICC_CARD_RECORD
        || request == RIL_REQUEST_WRITE_ICC_CARD_RECORD
        || request == RIL_REQUEST_WRITE_SMS_TO_SIM
        || request == RIL_REQUEST_DELETE_SMS_ON_SIM
        || request == RIL_REQUEST_REPORT_SMS_MEMORY_STATUS
        || request == RIL_REQUEST_REPORT_STK_SERVICE_IS_RUNNING
        || request == RIL_REQUEST_SCPBS_STRUCTURE
        || request == RIL_REQUEST_CHECK_SIM_STATUS
        || request == RIL_REQUEST_SEND_AT)
    ) {
        RIL_onRequestComplete(t, RIL_E_RADIO_NOT_AVAILABLE, NULL, 0);
        return;
    }

    switch (request) {
        /*add by huangxianfe, 2017-04-25 for LC1881 start*/
        case RIL_REQUEST_SEND_AT:
            requestSendAt(data, datalen, t);
            break;
       /*add by huangxianfe, 2017-04-25 for LC1881 end*/ 
        case RIL_REQUEST_GET_SIM_STATUS:
            requestGetSimstatus(data, datalen, t);
            break;

        case RIL_REQUEST_GET_CURRENT_CALLS:
            requestGetCurrentCalls(data, datalen, t);
            break;

        case RIL_REQUEST_DIAL:
            requestDial(data, datalen, t);
            break;

        case RIL_REQUEST_DIAL_EMERGENCY:
            requestDialEmergency(data, datalen, t);
            break;

        case RIL_REQUEST_HANGUP:
            requestHangup(data, datalen, t);
            break;

        case RIL_REQUEST_HANGUP_WAITING_OR_BACKGROUND:
            requestHangupWaitingOrBackground(data, datalen, t);
            break;

        case RIL_REQUEST_HANGUP_FOREGROUND_RESUME_BACKGROUND:
            requestHangupForegroudResumeBackground(data, datalen, t);
            break;

        case RIL_REQUEST_SWITCH_WAITING_OR_HOLDING_AND_ACTIVE:
            requestSwitchWaitingOrHoldingAndActive(data, datalen, t);
            break;

        case RIL_REQUEST_ANSWER:
            requestAnswer(data, datalen, t);
            break;

        case RIL_REQUEST_CONFERENCE:
            requestConference(data, datalen, t);
            break;

        case RIL_REQUEST_UDUB:
            requestUdub(data, datalen, t);
            break;

        case RIL_REQUEST_SEPARATE_CONNECTION:
            requestSeparateConnection(data, datalen, t);
            break;

        case RIL_REQUEST_SIGNAL_STRENGTH:
            requestSignalStrength(data, datalen, t);
            break;

        case RIL_REQUEST_VOICE_REGISTRATION_STATE:
            {
//add by jin for L1860_Enh00000103 begin
#if defined(OPT_4G)
                if (7 == getACTmode())
                {
                    requestLTERegistrationState(request, data, datalen,t);
                }
                else
#endif
//add by jin for L1860_Enh00000103 end
                {
                    requestVoiceRegistrationState(request, data, datalen, t);
                }
            }
            break;

        case RIL_REQUEST_DATA_REGISTRATION_STATE:
            {
//add by jin for L1860_Enh00000103 begin
#if defined(OPT_4G)
                if (7 == getACTmode())
                {
                    requestLTERegistrationState(request, data, datalen,t);
                }
                else
#endif
//add by jin for L1860_Enh00000103 end
                {
                    requestDataRegistrationState(request, data, datalen, t);
                }
            }
            break;

        case RIL_REQUEST_OPERATOR:
            requestOperator(data, datalen, t);
            break;

        case RIL_REQUEST_RADIO_POWER:
            requestRadioPower(data, datalen, t);
            break;
    
        case RIL_REQUEST_DTMF:
            requestDtmf(data, datalen, t);
            break;

        case RIL_REQUEST_SEND_SMS:
        case RIL_REQUEST_SEND_SMS_EXPECT_MORE:
            requestSendSMS(data, datalen, t);
            break;

        case RIL_REQUEST_CDMA_SEND_SMS:
            requestCdmaSendSMS(data, datalen, t);
            break;

        case RIL_REQUEST_IMS_SEND_SMS:
            requestImsSendSMS(data, datalen, t);
            break;

        case RIL_REQUEST_SETUP_DATA_CALL:
            RLOGD("[RIL-PS][REQUEST_SETUP_DATA_CALL:] network_op_mutex start");
            pthread_mutex_lock(&network_op_mutex);
            RLOGD("[RIL-PS][REQUEST_SETUP_DATA_CALL:] network_op_mutex entry ref: %d", network_op_mutex_ref);
            network_op_mutex_ref++;
            requestSetupDataCall(data, datalen, t);
            network_op_mutex_ref--;
            RLOGD("[RIL-PS][REQUEST_SETUP_DATA_CALL:] network_op_mutex exit ref: %d", network_op_mutex_ref);
            pthread_mutex_unlock(&network_op_mutex);
            break;

        case RIL_REQUEST_SETUP_DATA_CALL_FAKE:
            RLOGD("[RIL-PS][REQUEST_SETUP_DATA_CALL_FAKE:] network_op_mutex start");
            pthread_mutex_lock(&network_op_mutex);
            RLOGD("[RIL-PS][REQUEST_SETUP_DATA_CALL_FAKE] network_op_mutex entry ref: %d", network_op_mutex_ref);
            network_op_mutex_ref++;
            requestSetupDataCallFake(data, datalen, t);
            network_op_mutex_ref--;
            RLOGD("[RIL-PS][REQUEST_SETUP_DATA_CALL_FAKE] network_op_mutex exit ref: %d", network_op_mutex_ref);
            pthread_mutex_unlock(&network_op_mutex);
            break;

        case RIL_REQUEST_ENABLE_PS_DOMAIN:
            requestEnablePsDomain(data, datalen, t);
            break;

        case RIL_REQUEST_SMS_ACKNOWLEDGE:
            requestSMSAcknowledge(data, datalen, t);
            break;

        case RIL_REQUEST_ACKNOWLEDGE_INCOMING_GSM_SMS_WITH_PDU:
            requestAcknowledgeIncomingGsmSMSWithPdu(data, datalen, t);
            break;

        case RIL_REQUEST_GET_IMSI:
            requestGetIMSI(data, datalen, t);
            break;

        case RIL_REQUEST_GET_IMEI:
            requestGetIMEI(data, datalen, t);
            break;

        case RIL_REQUEST_GET_IMEISV:
                requestGetIMEISV(data, datalen, t);
            break;
        case RIL_REQUEST_STK_SET_PROFILE:
        case RIL_REQUEST_STK_GET_PROFILE:
        case RIL_REQUEST_STK_HANDLE_CALL_SETUP_REQUESTED_FROM_SIM:
            RIL_onRequestComplete(t, RIL_E_REQUEST_NOT_SUPPORTED, NULL, 0);
            break;
        case RIL_REQUEST_SIM_IO:
            requestSIM_IO(data,datalen,t);
            break;
       case RIL_REQUEST_SIM_TRANSMIT_APDU_BASIC:
           requestSIM_TransmitBasic(data, datalen, t);
           break;

       case RIL_REQUEST_SIM_OPEN_CHANNEL:
           requestSIM_OpenChannel(data, datalen, t);
           break;

       case RIL_REQUEST_SIM_CLOSE_CHANNEL:
           requestSIM_CloseChannel(data, datalen, t);
           break;

       case RIL_REQUEST_SIM_TRANSMIT_APDU_CHANNEL:
           requestSIM_TransmitChannel(data, datalen, t);
           break;

       case RIL_REQUEST_SIM_GET_ATR:
           requestSIM_GetAtr(t);
           break;

       case RIL_REQUEST_SIM_OPEN_CHANNEL_WITH_P2:
           requestSIM_OpenChannel_WITH_P2(data, datalen, t);
           break;
        case RIL_REQUEST_SEND_USSD:
            requestSendUSSD(data, datalen, t);
            break;

        case RIL_REQUEST_CANCEL_USSD:
            requestCancelUSSD(data, datalen, t);
            break;

        case RIL_REQUEST_SET_NETWORK_SELECTION_AUTOMATIC:
            requestSetNetworkSelectionAutomatic(data, datalen, t);
            break;

        case RIL_REQUEST_DATA_CALL_LIST:
            RLOGD("[RIL-PS][REQUEST_DATA_CALL_LIST:] network_op_mutex start");
            pthread_mutex_lock(&network_op_mutex);
            RLOGD("[RIL-PS][REQUEST_DATA_CALL_LIST] network_op_mutex entry ref: %d", network_op_mutex_ref);
            network_op_mutex_ref++;
            requestDataCallList(data, datalen, t);
            network_op_mutex_ref--;
            RLOGD("[RIL-PS][REQUEST_DATA_CALL_LIST] network_op_mutex exit ref: %d", network_op_mutex_ref);
            pthread_mutex_unlock(&network_op_mutex);
            break;

        case RIL_SET_FAKE_IPV4_ADDR_FOR_BIH:
            RLOGD("[RIL-PS][SET_FAKE_IPV4_ADDR_FOR_BIH:] network_op_mutex start");
            pthread_mutex_lock(&network_op_mutex);
            RLOGD("[RIL-PS][SET_FAKE_IPV4_ADDR_FOR_BIH] network_op_mutex entry ref: %d", network_op_mutex_ref);
            network_op_mutex_ref++;
            requestSetFakeIPv4Addr(data, datalen, t);
            network_op_mutex_ref--;
            RLOGD("[RIL-PS][SET_FAKE_IPV4_ADDR_FOR_BIH] network_op_mutex exit ref: %d", network_op_mutex_ref);
            pthread_mutex_unlock(&network_op_mutex);
            break;

        case RIL_REQUEST_QUERY_NETWORK_SELECTION_MODE:
            requestQueryNetworkSelectionMode(data, datalen, t);
            break;

        case RIL_REQUEST_OEM_HOOK_RAW:
            requestOemHookRaw(data, datalen, t);
            break;

        case RIL_REQUEST_OEM_HOOK_STRINGS:
            requestOemHookStrings(data, datalen, t);
            break;

        case RIL_REQUEST_WRITE_SMS_TO_SIM:
            requestWriteSmsToSim(data, datalen, t);
            break;

        case RIL_REQUEST_DELETE_SMS_ON_SIM:
            requestDeleteSmsOnSim(data, datalen, t);
            break;

        case RIL_REQUEST_ENTER_SIM_PIN:
        case RIL_REQUEST_ENTER_SIM_PUK:
        case RIL_REQUEST_ENTER_SIM_PIN2:
        case RIL_REQUEST_ENTER_SIM_PUK2:
            /* FIX L1809OG_Enh00000020 2011-03-24 chenchi begin */
            requestEnterSimPin(request,data, datalen, t);
            /* FIX L1809OG_Enh00000020 2011-03-24 chenchi end */
            break;

        /* Add by Leadcore start */
        case RIL_REQUEST_BASEBAND_VERSION:
            requestBasebandVersion(request,data, datalen, t);
            break;

        case RIL_REQUEST_REPORT_STK_SERVICE_IS_RUNNING:
            requestStkServiceReport(data, datalen, t);
            break;
            
        case RIL_REQUEST_STK_SEND_TERMINAL_RESPONSE:
            requestStkSendTerminalResponse(data, datalen, t);
            break;

        case RIL_REQUEST_STK_SEND_ENVELOPE_COMMAND:
            requestStkSendEnvelopeCommand(data, datalen, t);
            break;

        case RIL_REQUEST_STK_SEND_ENVELOPE_WITH_STATUS:
            requestStkSendEnvelopeWithStatus(data, datalen, t);
            break;

        case RIL_REQUEST_REPORT_SMS_MEMORY_STATUS:
            requestSMSMemoryStatus(data, datalen, t);
            break;

        case RIL_REQUEST_SET_SMSC_ADDRESS:
            requestSetSMSCAddress(data, datalen, t);
            break;

        case RIL_REQUEST_GET_SMSC_ADDRESS:
            requestGetSMSCAddress(data, datalen, t);
            break;

        case RIL_REQUEST_CHANGE_SIM_PIN:
            requestChangeSimPin(data, datalen, t);
            break;

        case RIL_REQUEST_CHANGE_SIM_PIN2:
            requestChangeSimPin2(data, datalen, t);
            break;

        case RIL_REQUEST_IMS_REGISTRATION_STATE: {
            int reply[2];
            //0==unregistered, 1==registered
            reply[0] = s_ims_registered;

            //to be used when changed to include service supporated info
            //reply[1] = s_ims_services;

            // FORMAT_3GPP(1) vs FORMAT_3GPP2(2);
            reply[1] = s_ims_format;

            RLOGD("IMS_REGISTRATION=%d, format=%d ",
                    reply[0], reply[1]);
            if (reply[1] != -1) {
                RIL_onRequestComplete(t, RIL_E_SUCCESS, reply, sizeof(reply));
            } else {
                RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
            }
            break;
        }

        case RIL_REQUEST_QUERY_AVAILABLE_NETWORKS:
            requestQueryAvailableNetworks(data, datalen, t);
            break;

        case RIL_REQUEST_SET_NETWORK_SELECTION_MANUAL:
            requestSetNetworkSelectionManual(data, datalen, t);
            break;

        case RIL_REQUEST_DEACTIVATE_DATA_CALL:
            RLOGD("[RIL-PS][RIL_REQUEST_DEACTIVATE_DATA_CALL] network_op_mutex start");
            //pthread_mutex_lock(&network_op_mutex);
            //RLOGD("[RIL-PS][REQUEST_DEACTIVATE_DATA_CALL] network_op_mutex entry ref: %d", network_op_mutex_ref);
            //network_op_mutex_ref++;
            requestDeactivateDataCall(data, datalen, t);
            //network_op_mutex_ref--;
            //RLOGD("[RIL-PS][REQUEST_DEACTIVATE_DATA_CALL] network_op_mutex exit ref: %d", network_op_mutex_ref);
            //pthread_mutex_unlock(&network_op_mutex);
            break;

        case RIL_REQUEST_SET_PREFERRED_NETWORK_TYPE:
            requestSetPreferredNetworkType(request ,data, datalen, t);
            break;

        case RIL_REQUEST_GET_PREFERRED_NETWORK_TYPE:
            requestGetPreferredNetworkType(request ,data, datalen, t);
            break;

        case RIL_REQUEST_GET_CELL_INFO_LIST:
            requestGetCellInfoList(data, datalen, t);
            break;

        case RIL_REQUEST_SET_UNSOL_CELL_INFO_LIST_RATE:
            requestSetCellInfoListRate(data, datalen, t);
            break;

        case RIL_REQUEST_GET_HARDWARE_CONFIG:
            requestGetHardwareConfig(data, datalen, t);
            break;

        case RIL_REQUEST_SHUTDOWN:
            requestShutdown(t);
            break;

       case RIL_REQUEST_SET_GPS:
           requestSetGps(data, datalen, t);
           break;
        case RIL_REQUEST_SET_CALL_FORWARD:
            /*L1813 Bug00000040, wangsheng, 2013-05-30, don't send CCFC cmd for cta test, start*/
            //CTA_CHECK(requestSetCallForward, data, datalen, t, "install.ccfc.enable");
            CTA_CHECK(requestSetCallForward, data, datalen, t, "persist.sys.install.service");
            /*L1813 Bug00000040, wangsheng, 2013-05-30, don't send CCFC cmd for cta test, end*/
            break;

        case RIL_REQUEST_QUERY_CALL_FORWARD_STATUS:
            /*L1813 Bug00000040, wangsheng, 2013-05-30, don't send CCFC cmd for cta test, start*/
            //CTA_CHECK(requestQueryCallForwardStatus, data, datalen, t, "install.ccfc.enable");
            CTA_CHECK(requestQueryCallForwardStatus, data, datalen, t, "persist.sys.install.service");
            /*L1813 Bug00000040, wangsheng, 2013-05-30, don't send CCFC cmd for cta test, end*/
            break;

        case RIL_REQUEST_QUERY_FACILITY_LOCK:
            requestQueryFacilityLock(data, datalen, t);
            break;

        case RIL_REQUEST_SET_FACILITY_LOCK:
            requestSetFacilityLock(data, datalen, t);
            break;

        case RIL_REQUEST_CHANGE_BARRING_PASSWORD:
            requestChangeCallBarringPassword(data, datalen, t);
            break;

        case RIL_REQUEST_QUERY_CALL_WAITING:
            requestQueryCallWaiting(data, datalen, t);
            break;

        case RIL_REQUEST_SET_CALL_WAITING:
            requestSetCallWaiting(data, datalen, t);
            break;

        case RIL_REQUEST_LAST_CALL_FAIL_CAUSE:
            requestLastCallFailCause(data, datalen, t);
            break;

        case RIL_REQUEST_GET_CLIR:
            requestGetCLIR(data, datalen, t);
            break;

        case RIL_REQUEST_SET_CLIR:
            requestSetCLIR(data, datalen, t);
            break;

        /** Enh00000171, add checkCOL, by gaofeng 2012-08-30 begin */
        case RIL_REQUEST_GET_COLR:
            requestGetCOLR(data, datalen, t);
            break;

        case RIL_REQUEST_GET_COLP:
            requestGetCOLP(data, datalen, t);
            break;

        case RIL_REQUEST_SET_COLP:
            requestSetCOLP(data, datalen, t);
            break;
        /** Enh00000171, add checkCOL, by gaofeng 2012-08-30 end */

        /*Fixed Enh00000958 , by chenchi, 20110720 begin*/
        case RIL_REQUEST_QUERY_CLIP:
            requestQueryClip(data, datalen, t);
            break;

        /* FIX Bug00001626, Use com.android.internal.telephony.Phone interface for mute, by chenchi 2011-03-14*/
        case RIL_REQUEST_SET_MUTE:
            requestSetMute(data, datalen, t);
            break;

        case RIL_REQUEST_GET_MUTE:
            requestGetMute(data, datalen, t);
            break;

        /*Fixed Bug00000657, by zhushasha, 20110426 begin*/
        case RIL_REQUEST_PLAY_CALLWAIT_TONE:
            requestPlayCallwaitTone(data, datalen, t);
            break;
        /*Fixed Bug00000657, by zhushasha, 20110426 end*/

        /* FIX Enh00000058, add screen state, by chenchi 2011-01-07*/
        case RIL_REQUEST_SCREEN_STATE:
            requestScreenState(data, datalen, t);
            break;

        case RIL_REQUEST_PS_STATE_CHANGE_EVENT_TOGGLE:
            requestTogglePSStateChangeEvent(data, datalen, t);
            break;

        case RIL_REQUEST_DTMF_START:
            requestDtmfStart(data, datalen, t);
            break;

        case RIL_REQUEST_DTMF_STOP:
            requestDtmfStop(data, datalen, t);
            break;

/*added for VT feature begin*/
#ifdef VT_ENABLE
        case RIL_REQUEST_VT_DIAL:
            requestVideoTelephonyDial(data, datalen, t);
            break;

        case RIL_REQUEST_VT_HANGUP:
            requestVideoTelephonyHangup(data, datalen, t);
            break;

        case RIL_REQUEST_VT_ANSWER:
            requestVideoTelephonyAnswer(data, datalen, t);
            break;

        case RIL_REQUEST_VT_SEND_STRS:
            requestVideoTelephoneSendStr(data, datalen, t);
            break;

        case RIL_REQUEST_VT_SENDCMD:
            requestVideoTelephoneSendCmd(data, datalen, t);
            break;
#endif
/*added for VT feature begin*/
        /* Add by Leadcore end */

        /* FIX "Add preferred plmn list" 2010-12-27 zoufeng begin */
        case RIL_REQUEST_SET_PREFERRED_PLMN_LIST:
            requestSetPreferredPlmnList(data, datalen, t);
            break;

        case RIL_REQUEST_GET_PREFERRED_PLMN_LIST:
            requestGetPreferredPlmnList(data, datalen, t);
            break;
        /* FIX "Add preferred plmn list" 2010-12-27 zoufeng end */
        
        /*Leadcore: fix Req00000143, 20110223, chengyuxin, Refresh Operation of USAT: RIL_REQUEST_REFRESH_OPERATION*/
        case RIL_REQUEST_REFRESH_OPERATION:
            requestRefreshOperation(data, datalen, t);
            break;

        //<UH, 2011-02-21, lifangdong, Add ContactsAttribute./
        case RIL_REQUEST_GET_RECORD_NUM:
            requestReadCardRecordNum(data, datalen, t);
            break;

        /* FIX L1809OG_Bug00000405 2011-03-17 zoufeng begin */
        case RIL_REQUEST_SHUT_DOWN_RADIO:
            requestShutDownRadio(data, datalen, t);
            break;
        /* FIX L1809OG_Bug00000405 2011-03-17 zoufeng end */

        case RIL_REQUEST_GET_ICC_PHONEBOOK_RECORD_INFO:
            requestGetIccPhonebookRecordInfo(data, datalen, t);
            break;

        //<UH, 2011-07-13, lifangdong, Read USIM records with "AT^SCPBR"./
        case RIL_REQUEST_READ_ICC_CARD_RECORD:
            requestGetIccCardRecord(data, datalen, t);
            break;

        case RIL_REQUEST_WRITE_ICC_CARD_RECORD:
            requestWriteIccCardRecord(data, datalen, t);
            break;
        case RIL_REQUEST_SCPBS_STRUCTURE:
            requestGetAdnStorageInfo(data, datalen, t);
            break;

        //added for black incoming call
        case RIL_REQUEST_COMFIRM_INCOMMING_CALL:
            requestConfirmIncommingCall(data, datalen, t);
            break;

        //Add by guojing for informing Modem the standby of playing the voice. 2012-6-16
        case RIL_REQUEST_SET_STANDBY_ID_PLAY_VOICE:
            requestSetStandbyAudioPlaying(data, datalen, t);
            break;

        // add [by chenshu 2012-07-04] for cmmb
        case RIL_REQUEST_MBMS_SEND_AUTH:
            requestMBMSSendauth(data, datalen, t);
            break;

        case RIL_REQUEST_MBMS_GET_CELLID:
            requestMBMSGetCellID(data, datalen, t);
            break;

        case RIL_REQUEST_MBMS_UICC_AUTN:
            requestMBMSUiccAuth(data, datalen, t);
            break;
		
        case RIL_REQUEST_GET_PHONEBOOK_ERROR_CODE:
            requestGetPhoneBookOperationErrCode(data, datalen, t);
            break;

        case RIL_REQUEST_PS_RES_CONTROL_EVENT_TOGGLE:
            requestTogglePSResControlEvent(data, datalen, t);
            break;

        case RIL_REQUEST_CHECK_SIM_STATUS:
		RLOGD("[panda:wyy]requestCheckSimStatus started!",0);
            requestCheckSimStatus(data, datalen, t);
            break;

        case RIL_REQUEST_SET_SIM_POWER:
            requestSetSimPower(data, datalen, t);
            break;

        default:
            RIL_onRequestComplete(t, RIL_E_REQUEST_NOT_SUPPORTED, NULL, 0);
            break;
    }
}

/**
 * Synchronous call from the RIL to us to return current radio state.
 * RADIO_STATE_UNAVAILABLE should be the initial state.
 */
static RIL_RadioState currentState()
{
    if(sState == RADIO_STATE_ON){
        if(isSimStateLockOrAbsent(sSimState)){
            return RADIO_STATE_SIM_LOCKED_OR_ABSENT;
        } else if(sSimState == SIM_NOT_READY){
            return RADIO_STATE_SIM_NOT_READY;
        } else if(sSimState == SIM_READY){
            return RADIO_STATE_SIM_READY;
        }
    }
    return sState;
}

/**
 * Call from RIL to us to find out whether a specific request code
 * is supported by this implementation.
 *
 * Return 1 for "supported" and 0 for "unsupported"
 */

static int
onSupports (int requestCode)
{
    //@@@ todo
    return 1;
}

static void onCancel (RIL_Token t)
{
    //@@@todo
    RLOGD("onCancel t = %d",(UINT32)t);
    if(t != NULL){
        UINT32 code = (UINT32)t;
        if(code == RADIO_FUN_ONCANCEL_CODE_RESET_MODEM){
            sSimState = SIM_NOT_READY;
            requestResetModem(NULL);
        }
    }
}

static const char * getVersion(void)
{
    return "android reference-ril 1.0";
}

static void
setRadioState(RIL_RadioState newState)
{
    RIL_RadioState oldState;

    pthread_mutex_lock(&s_state_mutex);
    RLOGD("*******setRadioState: sState=%d, newState=%d, s_rilID=%d, s_closed=%d \n", sState, newState, s_rilID, s_closed);

    oldState = sState;
    if (s_closed > 0) {
        // If we're closed, the only reasonable state is
        // RADIO_STATE_UNAVAILABLE
        // This is here because things on the main thread
        // may attempt to change the radio state after the closed
        // event happened in another thread
        newState = RADIO_STATE_UNAVAILABLE;
    }

    if (sState != newState || s_closed > 0) {
        sState = newState;
        pthread_cond_broadcast (&s_state_cond);
    }

    pthread_mutex_unlock(&s_state_mutex);

    /* do these outside of the mutex */
    if (sState != oldState) {
        RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_RADIO_STATE_CHANGED,
                                    NULL, 0);
        // Sim state can change as result of radio state change
       /* RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED,
                                    NULL, 0);*/
    }
    if (RADIO_STATE_UNAVAILABLE == oldState &&
        RADIO_STATE_OFF == sState &&
        fail_check_sim_status) {
        checkAndPollSimStat();
        fail_check_sim_status = FALSE;
        is_first_power_on = 1;
    }
}

static BOOL isSimStateLockOrAbsent(SIM_Status simState){
    if(simState == SIM_ABSENT ||
       simState == SIM_PIN ||
       simState == SIM_PUK ||
       simState == SIM_NETWORK_PERSONALIZATION ||
       simState == SIM_BLOCKED){
       return true;
    }

    return false;
}

static void checkAndPollSimStat(){
    /* FIXME onSimReady() and onRadioPowerOn() cannot be called
     * from the AT reader thread
     * Currently, this doesn't happen, but if that changes then these
     * will need to be dispatched on the request thread
     */
     RLOGD("checkAndPollSimStat enter");
    SIM_Status simstate = getSIMStatus();
    RLOGD("checkAndPollSimStat enter");
    DBBD(DB_RIL, RLOGD("checkAndPollSimStat(%d) !\n", simstate));
    if (simstate == SIM_READY) {
        onSIMReady();
    } else if (simstate == SIM_NOT_READY) {
        onRadioPowerOn();
    }
}

/** Returns SIM_NOT_READY on error */
static SIM_Status getSIMStatus()
{
    ATResponse *p_response = NULL;
    int err;
    int ret;
    char *cpinLine;
    char *cpinResult;

    err = at_send_command_singleline("AT+CPIN?", "+CPIN:", &p_response);

	#if 0  //remove for satellite Modem.
    /*L1813 Bug00000579, wangsheng, 2013-07-03, start*/
    if (0 == is_pb_ready)
    {
        at_send_command("AT^DEWALK=1", NULL);
    }
    /*L1813 Bug00000579, wangsheng, 2013-07-03, end*/
	#endif
    if (err != 0) {
        ret = SIM_NOT_READY;
        goto done;
    }

    switch (at_get_cme_error(p_response)) {
        case CME_SUCCESS:
            break;

        case CME_SIM_NOT_INSERTED:
            ret = SIM_ABSENT;
            goto done;

        case CME_SIM_BLOCKED:/*add PERM_DISABLED*/
            ret = SIM_BLOCKED;
            goto done;

        default:
            ret = SIM_NOT_READY;
            goto done;
    }

    /* CPIN? has succeeded, now look at the result */
    cpinLine = p_response->p_intermediates->line;
    err = at_tok_start (&cpinLine);
    if (err < 0) {
        ret = SIM_NOT_READY;
        goto done;
    }

    err = at_tok_nextstr(&cpinLine, &cpinResult);
    if (err < 0) {
        ret = SIM_NOT_READY;
        goto done;
    }

    DBBD(1, RLOGD("GetSIMStatus, cpinResult = %s", cpinResult));
    if (0 == strcmp (cpinResult, "SIM PIN")) {
        ret = SIM_PIN;
        goto done;
    } else if (0 == strcmp (cpinResult, "SIM PUK")) {
        g_pukLock = TRUE;
        ret = SIM_PUK;
        goto done;
    } else if (0 == strcmp (cpinResult, "PH-NET PIN")) {
        ret = SIM_NETWORK_PERSONALIZATION;
        goto done;
    } else if (0 == strcmp (cpinResult, "SIM PUK2")) {
        ret = SIM_READY;
        goto done;
    } else if (0 != strcmp (cpinResult, "READY"))  {
        /* we're treating unsupported lock types as "sim absent" */
        ret = SIM_ABSENT;
        goto done;
    }
    DBBD(1, RLOGD("GetSIMStatus, ret = %d", ret));
    //added by zhushasha 20110714
    if(g_FlagHlsLog == 1)
    {
        g_FlagHlsLog = 0;

        if(CARD_STATUS_ABSENT == ril_config_st.m_cardStatus
            && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus) {
            RLOGD("do not send CFUN=1 since this slot has not (U)SIM card and the another slot has (U)SIM card");
        } else {

            ata_ps_set_attach();
            ata_ps_set_eps_pdn_parameters();
            setUeCapability();
            setAudioTest();

            at_response_free(p_response);
            p_response = NULL;
            err = at_send_command("AT+CFUN=1", &p_response);
            if((err < 0) ||(p_response->success == 0)) {
                RLOGD("sally_warning: CFUN error!! err=%d",err);
                setRadioState(RADIO_STATE_UNAVAILABLE);
            }
        }
        switchModemUnsolicitedCode(1);
    }
    //add end 20110714

    g_pukLock = FALSE;
    ret = SIM_READY;
    DBBD(1, RLOGD("GetSIMStatus, 1ret = %d", ret));
done:
    at_response_free(p_response);
    p_response = NULL;
    cpinResult = NULL;
    DBBD(1, RLOGD("GetSIMStatus, 1sSimState = %d", sSimState));

    int oldRadioSimState = isSimStateLockOrAbsent(sSimState) ? SIM_ABSENT : sSimState;
    int newRadioSimState = isSimStateLockOrAbsent(ret) ? SIM_ABSENT : ret;
    RLOGD("getSIMStatus: sSimState = %d, ret = %d, oldRadioSimState = %d, newRadioSimState = %d, g_pukLock = %d",
        sSimState, ret, oldRadioSimState, newRadioSimState, g_pukLock);



    sSimState = ret;
    DBBD(1, RLOGD("GetSIMStatus, 2sSimState = %d", sSimState));
    if (oldRadioSimState != newRadioSimState){
        RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_SIM_STATUS_CHANGED, NULL, 0);
        if (sState== RADIO_STATE_ON){
            RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_RADIO_STATE_CHANGED, NULL, 0);
        }
    }

    /*When sim absent or sim ready disable dusimu unsolicited*/
    if(ret == SIM_ABSENT || ret == SIM_READY) {
        at_send_command("AT^DUSIMR=0",NULL);
    }

    return (SIM_Status)ret;
}

/**
 * Get the current card status.
 *
 * This must be freed using freeCardStatus.
 * @return: On success returns RIL_E_SUCCESS
 */
static int getCardStatus(RIL_CardStatus_v6 **pp_card_status) {
    int pinErrTime[4]= {0, 0, 0, 0};
    static RIL_AppStatus app_status_array[] = {
        // SIM_ABSENT = 0
        { RIL_APPTYPE_UNKNOWN, RIL_APPSTATE_UNKNOWN, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // SIM_NOT_READY = 1
        { RIL_APPTYPE_SIM, RIL_APPSTATE_DETECTED, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // SIM_READY = 2
        { RIL_APPTYPE_SIM, RIL_APPSTATE_READY, RIL_PERSOSUBSTATE_READY,
          NULL, NULL, 0, RIL_PINSTATE_UNKNOWN, RIL_PINSTATE_UNKNOWN },
        // SIM_PIN = 3
        { RIL_APPTYPE_SIM, RIL_APPSTATE_PIN, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN },
        // SIM_PUK = 4
        { RIL_APPTYPE_SIM, RIL_APPSTATE_PUK, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_BLOCKED, RIL_PINSTATE_UNKNOWN },
        // SIM_NETWORK_PERSONALIZATION = 5
        { RIL_APPTYPE_SIM, RIL_APPSTATE_SUBSCRIPTION_PERSO, RIL_PERSOSUBSTATE_SIM_NETWORK,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN },
        /*wangsheng, 2013.05.23, L1810 Bug00004049, add PERM_DISABLED, start*/
        // SIM_BLOCKED = 6
        { RIL_APPTYPE_SIM, RIL_APPSTATE_PERM_DISABLED, RIL_PERSOSUBSTATE_UNKNOWN,
          NULL, NULL, 0, RIL_PINSTATE_ENABLED_NOT_VERIFIED, RIL_PINSTATE_UNKNOWN },
        /*wangsheng, 2013.05.23, L1810 Bug00004049, add PERM_DISABLED, end*/
    };

    RIL_CardState card_state;
    int num_apps;

 RLOGD("getCardStatus enter");
    int sim_status = getSIMStatus();
     RLOGD("getCardStatus enter");
    if (sim_status == SIM_ABSENT) {
        card_state = RIL_CARDSTATE_ABSENT;
        num_apps = 0;
    } else {
        card_state = RIL_CARDSTATE_PRESENT;
        num_apps = 1;
    }

    // Allocate and initialize base card status.
    RIL_CardStatus_v6 *p_card_status = malloc(sizeof(RIL_CardStatus_v6));
    p_card_status->card_state = card_state;
    p_card_status->universal_pin_state = RIL_PINSTATE_UNKNOWN;
    p_card_status->gsm_umts_subscription_app_index = RIL_CARD_MAX_APPS;
    p_card_status->cdma_subscription_app_index = RIL_CARD_MAX_APPS;
    p_card_status->ims_subscription_app_index = RIL_CARD_MAX_APPS;
    p_card_status->num_applications = num_apps;

    // Initialize application status
    int i;
    for (i = 0; i < RIL_CARD_MAX_APPS; i++) {
        p_card_status->applications[i] = app_status_array[SIM_ABSENT];
    }

    // Pickup the appropriate application status
    // that reflects sim_status for gsm.
    if (num_apps != 0) {
        // Only support one app, gsm
        p_card_status->num_applications = 1;
        p_card_status->gsm_umts_subscription_app_index = 0;

        // Get the correct app status
        p_card_status->applications[0] = app_status_array[sim_status];
        /* zoufeng for set "app_type" in response data of "RIL_REQUEST_GET_SIM_STATUS" begin */
        p_card_status->applications[0].app_type = simCardType;
        /* zoufeng for set "app_type" in response data of "RIL_REQUEST_GET_SIM_STATUS" end */
        HandlePinRemainAttempt(pinErrTime);
        if(pinErrTime[1] == 0) {
            if(pinErrTime[3] == 0) {
                p_card_status->applications[0].pin2 = RIL_PINSTATE_ENABLED_PERM_BLOCKED;
            } else {
                p_card_status->applications[0].pin2 = RIL_PINSTATE_ENABLED_BLOCKED;
            }
        }
    }

    *pp_card_status = p_card_status;
    return RIL_E_SUCCESS;
}

/**
 * Free the card status returned by getCardStatus
 */
static void freeCardStatus(RIL_CardStatus_v6 *p_card_status) {
    free(p_card_status);
}

/**
 * SIM ready means any commands that access the SIM will work, including:
 *  AT+CPIN, AT+CSMS, AT+CNMI, AT+CRSM
 *  (all SMS-related commands)
 */
static void pollSIMState (void *param)
{
    int simStatus = -1;
    int retry = 1;
    char prop_value[2] = {0};
    if (sSimState != SIM_NOT_READY) {
        // no longer valid to poll
        return;
    }

    if (property_get("persist.sys.check_sim_retry", prop_value, "1") > 0)
    {
        if(prop_value[0] == '0') {
            retry = 0;
        }else {
            retry = 1;
        }
    }

    g_simStateCheckRetryCount--;
    RLOGD("pollSIMState enter");
    simStatus = getSIMStatus();
     RLOGD("pollSIMState enter");
    switch (simStatus) {
        case SIM_NOT_READY:
            if(retry == 1 && g_simStateCheckRetryCount > 0) {
                RIL_requestTimedCallback (pollSIMState, NULL, &TIMEVAL_SIMPOLL);
            }
            break;
        case SIM_READY:
            if(g_modemtype_s == 0) {
                 onSIMReady();
            }
            break;
        default:
            RLOGD("pollSIMState: getSIMStatus() = %d", simStatus);
            break;
    }
}

/** returns 1 if on, 0 if off, and -1 on error */
static int isRadioOn()
{
    ATResponse *p_response = NULL;
    int err;
    char *line;
    char ret;

    err = at_send_command_singleline("AT+CFUN?", "+CFUN:", &p_response);

    if (err < 0 || p_response->success == 0) {
        // assume radio is off
        goto error;
    }

    line = p_response->p_intermediates->line;
    RLOGD("isRadioOn: respone = %s",line);

    err = at_tok_start(&line);
    if (err < 0) goto error;
    RLOGD("isRadioOn: hxf 1");
    err = at_tok_nextbool(&line, &ret);
    if (err < 0) goto error;
    RLOGD("isRadioOn: hxf 2,ret=%d",ret);
    at_response_free(p_response);
	RLOGD("isRadioOn: AT+CFUN? return value = %d", (int)ret);
    return (int)ret;

error:
    at_response_free(p_response);
	RLOGD("isRadioOn: AT+CFUN? return value = -1 on error ");
    return -1;
}

void resetPersistApnName() {
    char simStatus[10];
    char simDcid[30];
    int lastSimStatus = CARD_STATUS_UNKNOWN;
    char SIM_DCID_FILE[30];
    char    propValue[PROP_VALUE_MAX] = "";

    snprintf(SIM_DCID_FILE, 30, "%s%d", SIM_DCID_FILE_PRE, s_rilID);

    GetPrivateProfileString("SIM", "SIMSTATUS", "0", simStatus, 10, SIM_DCID_FILE);
    GetPrivateProfileString("SIM", "SIMDCID", "", simDcid, 30, SIM_DCID_FILE);

    if (strncmp(simStatus, "1", 1) == 0) {
        lastSimStatus = CARD_STATUS_EXIST;
    } else {
        lastSimStatus = CARD_STATUS_ABSENT;
    }

    if ( (lastSimStatus != ril_config_st.m_cardStatus)
            || (strcmp(simDcid, ril_config_st.m_cardID) != 0) ) {
        __system_property_get("persist.radio.init.apn.name", propValue);
        RLOGD("resetPersistApnName: old persist.radio.init.apn.name is:%s", propValue);

        __system_property_set("persist.radio.init.apn.name", "");
    }
}

int initRildConfig(void) {
    int     retVal = 0;
    char    value[2] = {0};
    char    *cmd = NULL;
    char    atCmd[40] = "";
    char    configFile[80] = "";
    char    propValue[PROP_VALUE_MAX] = "";
    BOOL disable_3g_mode = false;

    snprintf(configFile, sizeof(configFile) - 1,
            "%s%d",
            RILD_CONFIG_FILE, s_rilID);

    retVal = ril_load_config(configFile);
    RLOGD("initRildConfig: ril_load_config() return value = %d", retVal);

    if(s_rilID >= ril_config_st.m_rildCount) {
        RLOGE("fatal error: invalid count of RILD: s_rilID=%d(> %d)", s_rilID, ril_config_st.m_rildCount);
        //exit(0);
    }

    if (ril_config_st.m_cardStatus == CARD_STATUS_EXIST) {
       resetPersistApnName();
    }

    if (__system_property_get("ro.sys.lc.proj.target", propValue) > 0) {
        int temp = 0;

        if (strcmp(propValue, "open") == 0) {
            temp = OPEN_VERSION;
        } else if (strcmp(propValue, "cmcc") == 0) {
            temp = CMCC_VERSION;
        } else if (strcmp(propValue, "cucc") == 0) {
            temp = CUCC_VERSION;
        } else if (strcmp(propValue, "ctc") == 0) {
            temp = CTC_VERSION;
        } else {
            RLOGE("%s() error: propValue = %s", __func__, propValue);
        }

        s_productVersion = temp;
    }
    RLOGD("initRildConfig: s_productVersion = %d", s_productVersion);

    if (__system_property_get("ro.sys.lc.proj.rat", propValue) > 0) {
        if(strstr(propValue, "gsm") != NULL) {
            RADIO_LC_ACT_2G |= RADIO_LC_ACT_GSM;
        }
        if(strstr(propValue, "tdscdma") != NULL) {
            RADIO_LC_ACT_3G |= RADIO_LC_ACT_TDSCDMA;
        }
        if(strstr(propValue, "wcdma") != NULL) {
            RADIO_LC_ACT_3G |= RADIO_LC_ACT_WCDMA;
        }
        if(strstr(propValue, "lte_tdd") != NULL) {
            RADIO_LC_ACT_4G |= RADIO_LC_ACT_TDD_LTE;
        }
        if(strstr(propValue, "lte_fdd") != NULL) {
            RADIO_LC_ACT_4G |= RADIO_LC_ACT_FDD_LTE;
        }
    }


if(__system_property_get("persist.sys.lc.manual.rat.pri", propValue) > 0) {
        char    *p = strchr(propValue, ',');

        RLOGD("persist.sys.lc.manual.rat.pri: %s",propValue);


        if(p != NULL) {
            if ((ril_config_st.m_actualRat & RADIO_LC_ACT_4G) != 0
                && '0' <= propValue[0] && propValue[0] <= '9') {
                snprintf(atCmd, sizeof(atCmd)-1, "AT^DLTEM=%c", propValue[0]);
                at_send_command(atCmd, NULL);
            }

            if ((ril_config_st.m_actualRat & RADIO_LC_ACT_3G) != 0
                && '0' <= *(p + 1) && *(p + 1) <= '9') {
                snprintf(atCmd, sizeof(atCmd)-1, "AT^DUSCP=%c", *(p + 1));
                at_send_command(atCmd, NULL);
            }
        }
    }else if(__system_property_get("persist.sys.lc.proj.target", propValue) > 0){

        RLOGD("initRildConfig persist.sys.lc.proj.target: %s",propValue);
		if(g_modemtype_s == 0) {
	        if(strstr(propValue, "cmcc") != NULL) {
	            at_send_command("AT^DUSCP=2", NULL);   //TDD prior
	            at_send_command("AT^DLTEM=0", NULL);   //LTE-TDD prior
	        }else if (strstr(propValue, "cucc") != NULL) {
	            at_send_command("AT^DUSCP=3", NULL);  //WCDMA prior
	            at_send_command("AT^DLTEM=1", NULL);   //LTE-FDD prior
	        }
		}
		
    }

    disable_3g_mode = false;

    if(check_board("LTE28047M11")){
        char propValue[PROP_VALUE_MAX] = "";

        if (__system_property_get("persist.sys.lc.3g.disable", propValue) > 0) {
            RLOGD("persist.sys.lc.3g.disable is %c ",propValue[0]);
            if(propValue[0]=='1'){
    		   disable_3g_mode = true;
            }
        }
    } 

    if(disable_3g_mode){
		if(g_modemtype_s==0) {
        	at_send_command("AT^DSTMEX=0,7,0", NULL);
		}
    }else{
        snprintf(atCmd, sizeof(atCmd)-1, "AT^DSTMEX=%s", ril_config_st.m_ratDSTMEX);
        at_send_command(atCmd, NULL);
    }

    if (__system_property_get("persist.sys.lc.lte.attach", value) > 0) {
        int err;
        RLOGD("persist.sys.lc.lte.attach vlaue = %s", value);
        asprintf(&cmd, "AT+CEMODE=%s", value);
        err = at_send_command(cmd, NULL);
        if (err < 0) {
            RLOGE("send %s failure, err = %d", cmd, err);
        }

        free(cmd);
        cmd = NULL;
    }

    if (ril_config_st.m_rildCount > 1 && 0 == s_rilID) {
        int imsiCount = 4;
        char propStr[4] = {0};

        if (CARD_STATUS_ABSENT == ril_config_st.m_cardStatus && CARD_STATUS_ABSENT == ril_config_st.m_otherCardStatus) {
            imsiCount = 0;
            RLOGD("initRildConfig, not insert (U)SIM card");
        } else if (CARD_STATUS_EXIST == ril_config_st.m_cardStatus && CARD_STATUS_ABSENT == ril_config_st.m_otherCardStatus) {
            imsiCount = 1;
            RLOGD("initRildConfig, insert one (U)SIM card");
        } else if (CARD_STATUS_ABSENT == ril_config_st.m_cardStatus && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus) {
            imsiCount = 2;
        } else if (CARD_STATUS_EXIST == ril_config_st.m_cardStatus && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus) {
            imsiCount = 3;
            RLOGD("initRildConfig, insert two (U)SIM card");
        }

        sprintf(propStr, "%d", imsiCount);
        __system_property_set(SYS_PROPERTY_RILD_GET_IMSI_COUNT, propStr);
        RLOGD("initRildConfig, get IMSI count = %d", imsiCount);
    }

    if (__system_property_get("ro.ril.auto.plmn", propValue) > 0) {
        if(0 == (propValue[0] - '0')) {
            s_is_auto_plmn = 0;
        }
    }
    RLOGD("%s manual/automatic mode for +COPS", (1 == s_is_auto_plmn) ? "enable" : "disable");

    if (__system_property_get("ro.ril.resend.sms.full", propValue) > 0) {
        if(1 == (propValue[0] - '0')) {
            s_is_resend_sms_full = TRUE;
        }
    }
    RLOGD("%s resend SMS full.", (TRUE == s_is_resend_sms_full) ? "enable" : "disable");

    if (__system_property_get(PROPERTY_PERSIST_RADIO_LC_MASTER_CARD, propValue) > 0) {
        if((s_rilID + 1) == (propValue[0] - '0')) {
            s_is_master_card = TRUE;
        }
    }
    RLOGD("This %s master card.", (TRUE == s_is_master_card) ? "is" : "is not");
    return 0;
}

static int checkModemPoweronLog(void) {
    #define PERSIST_PROP        "persist.sys.hls.poweron.log"
    #define TEMP_PROP           "sys.hls.poweron.log"
    char    propValue[PROP_VALUE_MAX] = "";
    char    propName[PROP_NAME_MAX] = "";
    int     ret = 0;
    int     modemPoweronLog = 0;

    memset(propValue, 0x00, PROP_VALUE_MAX);
    snprintf(propName, sizeof(propName), "%s%d", TEMP_PROP, s_rilID);
    ret = property_get(propName, propValue, NULL);
    if(0 == ret) {
        memset(propValue, 0x00, PROP_VALUE_MAX);
        ret = property_get(PERSIST_PROP, propValue, NULL);
        if(ret > 0 && propValue[0] == '1') {
            modemPoweronLog = 1;
            ret = property_set(propName, propValue);
        }
    }

    RLOGI("Modem power on log rildID %d", s_rilID);
    RLOGI("Modem power on log is %s", (modemPoweronLog == 0) ? "disabled" : "enabled");
    return modemPoweronLog;
}

int initForCMCC(void) {
    char    propValue[PROP_VALUE_MAX] = "";
    int     isProtocolTest = 0;

    if (__system_property_get("ro.build.mass.production", propValue) > 0) {
        if(0 != strcmp(propValue, "false")) {
            return 0;
        }
    }

    if (__system_property_get("persist.sys.install.service", propValue) > 0) {
        if('0' == propValue[0]) {
            isProtocolTest = 1;
        }
    }

    if(isProtocolTest) {
        /* Close the assert of (U)SIM hot removed. */
        at_send_command("AT^DDTEST=\"USIMTESTW B0\"", NULL);
        /* Lock MSG3_ACK */
        at_send_command("AT^DMSC=CF000016,00000000", NULL);
    } else {
        /* Unlock MSG3_ACK */
        at_send_command("AT^DMSC=CF000017,00000000", NULL);
    }

    /* Check if it is real battery. */
    {
        char   prop_value[PROP_VALUE_MAX] = "";
        FILE    *fp = fopen("/sys/class/power_supply/battery/online", "r");
        char    buffer[10] = "";

        if(fp != NULL) {
            fread(buffer, 1, 1, fp);
            fclose(fp);

            if('1' == buffer[0]) {
                /* It is real battery. */
                at_send_command("AT^DMSC=CF000019,00000000", NULL);
            } else if('0' == buffer[0]) {
                /* It is fake battery. */
                __system_property_set("sys.lc.virtual.battery", "1");
                at_send_command("AT^DMSC=CF000018,00000000", NULL);

                property_get("persist.sys.pt.logenable", prop_value,"0");
                if('0' == prop_value[0])
                {
                    __system_property_set("sys.lc.stop.logd", "1");
                    __system_property_set("ctl.stop", "lc-mla-manager");
                    system("busybox killall logcat");
                    system("busybox killall tcpdump");
                }
            } else {
                RLOGE("Invalid battery device info: %s", buffer);
            }
        } else {
            RLOGE("Open battery device failed: %d - %s", errno, strerror(errno));
        }
    }
    if (__system_property_get("sys.nsiot", propValue) > 0) {
        if(0 != strcmp(propValue, "1")) {
            at_send_command("AT^DMSC=D000000C,00000001", NULL);
            at_send_command("AT^DMSC=CF00001A,00000000", NULL);
        }
    }

    return 0;
}


/**
 * Initialize everything that can be configured while we're still in
 * AT+CFUN=0
 */
static void initializeCallback(void *param)
{
    char standbyValue[4] = {'\0'};
    char networkSelectMode[2] = {'\0'};
    char preferredNetworkMode[2] = {'\0'};
    char propString[32] = {0};


	//Apr 12, 2017, added by fei.lv@xiaotangtech.com
	RLOGD("XT--->Ready to get Phone Type (0:LTE, 1:Satellite.)");
	//char property_value_a[92] = {0};
	char property_value_a[92] = {1};
	if(property_get(PROPERTY_PERSIST_SYS_XT_MODEM_TYPE, property_value_a, NULL))	{
		g_modemtype_s = property_value_a[0] - '0';
	} else {
		RLOGD("XT--->Read PROPERTY_PERSIST_SYS_XT_MODEM_TYPE Fail.");
	}
	RLOGD("XT--->[ Phone Type is [ %d ](0:LTE, 1:Satellite.)", g_modemtype_s);
	//end
	
    setRadioState (RADIO_STATE_OFF);
    at_handshake();

    if (property_get("ro.lc.msms", standbyValue, "111"))
    {
        RLOGD("ro.lc.msms value == %s", standbyValue);
        if (0 == strcmp(standbyValue, "122"))
        {
             g_singleCardMultiStandby = true;
        }
    }

    sprintf(propString, RIL_EMSD_INIT_COMPLETE_FLAG"%d", s_rilID);
    __system_property_set(propString, "1");
    RLOGD("initializeCallback(), set property: %s = 1", propString);

#if (OPT_SIM_COUNT > 1)
    if (0 == s_rilID)
    {
        set_rild0_creg_stat(FALSE, RILD0_RESTART);
    }
#endif

    at_send_command("AT+CMEE=1", NULL);
    at_send_command("AT+CREG=2", NULL);
    at_send_command("AT+CGREG=2", NULL);	
    at_send_command("AT+CMER=2,0,0,2,0", NULL);
    at_send_command("AT+CGMR", NULL);
	RLOGD("initializeCallback(), enter S Mode.");

    if (g_singleCardMultiStandby) {
        at_send_command("AT^DPST=1", NULL);  //only apply to single_card_multi_standby
        at_send_command("AT^DCSR=1", NULL);

        if(property_get("network.select.mode", networkSelectMode, "1"))
        {
            RLOGD("network.select.mode value == %s", networkSelectMode);
        }
        if(property_get("preferred.network.mode", preferredNetworkMode, "1"))
        {
            RLOGD("preferred.network.mode value == %s", preferredNetworkMode);
        }

        if (0 == s_rilID) {
            at_send_command("AT^DECP=0,1", NULL);

            if (0 == strcmp(networkSelectMode, "1")) { //234G
                if (0 == strcmp(preferredNetworkMode, "1")) {//prefer 4G
                    at_send_command("AT^DSTMEX=0,7,2", NULL);
                } else if (0 == strcmp(preferredNetworkMode, "2")) { //prefer 23G
                    at_send_command("AT^DSTMEX=0,2,7", NULL);
                }
            }
            if (0 == strcmp(networkSelectMode, "2")) { //23G
                at_send_command("AT^DSTMEX=1,2", NULL);
            }

        } else if (1 == s_rilID) {
            at_send_command("AT^DECP=1,0", NULL);
            at_send_command("AT^DSTMEX=1,0", NULL);
        }
    }
if(g_modemtype_s==0) {
#if (OPT_SIM_COUNT > 1)
    at_send_command("AT^DEGSI=1", NULL);
#endif
    #ifdef DOUBLE_MICS
    at_send_command( "AT^DAUDCAPS=1,1,0", NULL);
    #endif
    //added for black incoming call
    char propertyConfirmCall[10] = "";
    property_get("persist.sys.lc.dcrm.config", propertyConfirmCall,"0");
    RLOGD("persist.sys.lc.dcrm.config: %s", propertyConfirmCall);
    if (0 == strcmp (propertyConfirmCall, "1")){
        bConfigIncomingMT = TRUE;
        at_send_command("AT^DCRM=1", NULL);
    }else{
        bConfigIncomingMT = FALSE;
        at_send_command("AT^DCRM=0", NULL);
    }

    char mode[10] = "";
    if(property_get("persist.sys.lc.proj.target", mode,"cmcc")) {
    	RLOGD("persist.sys.lc.dcrm.config mode: %s", mode);
	if(0 == strcmp(mode, "cucc")) {
    	    RLOGD("persist.sys.lc.dcrm.config cucc.");
	    at_send_command("AT^DAMRT=1", NULL);
	}
    }    

#ifdef VT_ENABLE
    if(vt_init() < 0)
    {
        RLOGE("[VP]vt init error");
    }
#endif
}

    ata_ps_init();
    /* assume radio is off on error */
    if (isRadioOn() > 0) {
        setRadioState (RADIO_STATE_ON);
    }
    

    /* Check if enable auto-attach GPRS. */
    checkIfAutoAttachGprs();
	
    {
        char    propertyKey[40] = "";
        char    propertyValue[20] = "";
        char    propertyDefaultValue[8] = "";
        int     i = 0;

        for(i=1; i<MAX_SIGNAL_LEVEL; i++)
        {
            snprintf(propertyKey, sizeof(propertyKey) - 1,
                    "sys.statusbar.signal.level%d",
                    i + 1);
            snprintf(propertyDefaultValue, sizeof(propertyDefaultValue) - 1,
                    "%d",
                    defaultSignalBar[i]);

            memset(propertyValue, 0x00, sizeof(propertyValue));
            if(property_get(propertyKey, propertyValue, propertyDefaultValue))
            {
                signalBar[i] = atoi(propertyValue);
            }
        }
    }
    //initRildConfig();
    g_FlagHlsLog = checkModemPoweronLog();
}

static int enable_call_hold(void)
{
    at_send_command( "AT^DCSSN=1,1",  NULL);

    return 0;
}

void requestCheckPinAfterDsatrefOk(void *p)
{
    char pinString[10];
    RLOGD("[stk]refresh,g_sPinEntered: %d, g_bDsatref_ok = %d", g_sPinEntered, g_bDsatref_ok);
    if (g_bDsatref_ok && g_sPinEntered && (read_sim_pin_password(pinString) == ERR_NONE)) {
         char *cmd = NULL;
         asprintf(&cmd, "AT+CPIN=\"%s\"", pinString);
         at_send_command(cmd, NULL);
         //modified by mabin for memory leak
         free(cmd);
         g_bDsatref_ok = false;
    }
}


void requestGetDcid(void *p)
{
    char simStatus[10];
    char simDcid[30];
    int err;
    char SIM_DCID_FILE[30];
    ATResponse *p_response =NULL;
    int iSimChanged[2];
    char *line;

    snprintf(SIM_DCID_FILE, 30, "%s%d", SIM_DCID_FILE_PRE, s_rilID);
   

    GetPrivateProfileString("SIM", "SIMSTATUS", "0", simStatus, 10, SIM_DCID_FILE); 
    GetPrivateProfileString("SIM", "SIMDCID", "", simDcid, 30, SIM_DCID_FILE); 

    err = at_send_command_singleline("AT^DCID", "^DCID:", &p_response);
    iSimChanged[0] = 0;
    if (err < 0 || p_response->success == 0) {
        WritePrivateProfileString("SIM", "SIMSTATUS", "1", SIM_DCID_FILE);
        WritePrivateProfileString("SIM", "SIMDCID", "", SIM_DCID_FILE);
        if ((simStatus[0] != '1') || strcmp("", simDcid)) {
            iSimChanged[0] = 1;
        }
    } else {
        line = p_response->p_intermediates->line;
        err = at_tok_start(&line);
        if (err < 0) {
            WritePrivateProfileString("SIM", "SIMSTATUS", "1", SIM_DCID_FILE);
            WritePrivateProfileString("SIM", "SIMDCID", "", SIM_DCID_FILE);
            if ((simStatus[0] != '1') || strcmp("", simDcid)) {
                iSimChanged[0] = 1;
            }
        } else {
            if ((simStatus[0] != '1') || strcmp(++line, simDcid)) {
                RLOGD("SimStatus %d %s %s", simStatus[0], line, simDcid);
                WritePrivateProfileString("SIM", "SIMSTATUS", "1", SIM_DCID_FILE);
                WritePrivateProfileString("SIM", "SIMDCID", line, SIM_DCID_FILE);
                iSimChanged[0] = 1;
            }
        }
    }
	#ifdef RILTEST2
	WritePrivateProfileString("SIM", "SIMSTATUS", "1", SIM_DCID_FILE);
	WritePrivateProfileString("SIM", "SIMDCID", "898600E10916F8000449", SIM_DCID_FILE);
	iSimChanged[0] = 1;
	RLOGD("requestGetDcid set SIMDCID = 898600E10916F8000449");
	#endif
    RLOGD("USIMEXITiSimStatus %d", iSimChanged[0]);
    iSimChanged[1] = 1;
    RIL_onUnsolicitedResponse(RIL_UNSOL_USIM_EXIT, &iSimChanged, 2*sizeof(int));
    at_response_free(p_response);
}
//#endif

void onResetModemTimer(union sigval sv)
{
    int ret = -1;
    RLOGD("onResetModemTimer(), killall emsd");
    ret = system("busybox killall emsd");

    if (0 != resetModemTimer_id) {
        ril_timer_delete(resetModemTimer_id);
        resetModemTimer_id = 0;
        RLOGD("onResetModemTimer(), delete RESET MODEM TIMER");
    }


    //ata_ps_close_lmi_in_shutdown(s_rilID);
    RLOGD("onResetModemTimer(), close lmi devices success!!!!!");


    RLOGD("onResetModemTimer(), killed rild%d, ret = %d", s_rilID, ret);
    sleep(1);
    exit(0);
}
void requestResetModemAndDump(void *p)
{
    int err;
    ATResponse *p_response = NULL;
    char property_value_a[4] = {'\0'};
    char property_value[4] = {'\0'};
    //if(property_get("install.modem.reset.enable", property_value_a, "1")


     RLOGI("====== requestResetModemAndDump 1 ======");
     if(property_get("persist.sys.modem.log", property_value_a, "0")
    && ('1' == property_value_a[0]))
    {
          RLOGI("====== requestResetModemAndDump 2 ======");
   // err = at_send_command_singleline("AT^TIMEOUT", "^TIMEOUT:", &p_response);

       if(property_get("persist.sys.poweron.trace_log", property_value, "0")
    && ('1' == property_value[0]))
    {
        property_set("ctl.stop", "lc-poweron-log");
        sleep(1);
    }
        memset(property_value, 0, sizeof(property_value));
       property_set("persist.leadcore.dump.finish", "0");
        system("/system/bin/lc-dump -k 8 &");
    }
    RLOGI("====== requestResetModemAndDump 3 ======");
     memset(property_value_a, 0, sizeof(property_value_a));
    if (property_get("persist.leadcore.dump.finish", property_value_a, "1")
        && ('0' == property_value_a[0]))
    {
        RLOGI("====== Modem reset funtion is enable, but EMSD is dumping call stack ======");
        while (TRUE)
        {
            if (property_get("persist.leadcore.dump.finish", property_value_a, "1")
            && ('1' == property_value_a[0]))
            {
                RLOGI("====== dump is complete ======");
                break;
            }
        }
    }


    RLOGI("====== requestResetModemAndDump 4 ======");
        memset(property_value_a, 0, sizeof(property_value_a));
        if(property_get("persist.sys.modem.reset", property_value_a, "1")
        && ('0' == property_value_a[0]))
    {
        RLOGI("====== Modem reset funtion is disabled in Assistant APP ======");
        return;
    }

    RLOGD("requestResetModem(), property_value_a = %s", property_value_a);
    setRadioState(RADIO_STATE_UNAVAILABLE);

    RLOGD("Reset Modem, cmd wait one second");
    if (0 == resetModemTimer_id) {
        if (0 == ril_timer_create(&resetModemTimer_id, onResetModemTimer, NULL)) {
            RLOGD("requestResetModem(), create and start RESET MODEM TIMER");
            ril_timer_start(resetModemTimer_id, 10*1000);
        } else {
            RLOGE("requestResetModem(), create RESET MODEM TIMER failed!!!!!");
        }
    }

    err = at_send_command_singleline_timeout("AT^DSRST", "^DSRST", 1000, &p_response);
    if (err < 0 || (NULL != p_response && p_response->success == 0)) {
        RLOGE("AT^DSRST Error, err = %d", err);
    }

    if (0 != resetModemTimer_id) {
        ril_timer_delete(resetModemTimer_id);
        resetModemTimer_id = 0;
        RLOGD("requestResetModem(), delete RESET MODEM TIMER success");
    }

	at_response_free(p_response);
}

void requestResetModem(void *p)
{
    int err;
    ATResponse *p_response = NULL;
    char property_value_a[4] = {'\0'};
    if(property_get("persist.sys.modem.reset", property_value_a, "1")
        && ('0' == property_value_a[0]))
    {
        RLOGI("====== Modem reset funtion is disabled in Assistant APP ======");
        return;
    }

    memset(property_value_a, 0, sizeof(property_value_a));
    if (property_get("persist.leadcore.dump.finish", property_value_a, "1")
        && ('0' == property_value_a[0]))
    {
        RLOGI("====== Modem reset funtion is enable, but EMSD is dumping call stack ======");
        while (TRUE)
        {
            if (property_get("persist.leadcore.dump.finish", property_value_a, "1")
            && ('1' == property_value_a[0]))
            {
                RLOGI("====== dump is complete ======");
                break;
            }
        }
    }

    RLOGD("requestResetModem(), property_value_a = %s", property_value_a);
    setRadioState(RADIO_STATE_UNAVAILABLE);

    RLOGD("Reset Modem, cmd wait one second");
    if (0 == resetModemTimer_id) {
        if (0 == ril_timer_create(&resetModemTimer_id, onResetModemTimer, NULL)) {
            RLOGD("requestResetModem(), create and start RESET MODEM TIMER");
            ril_timer_start(resetModemTimer_id, 10*1000);
        } else {
            RLOGE("requestResetModem(), create RESET MODEM TIMER failed!!!!!");
        }
    }

    err = at_send_command_singleline_timeout("AT^DSRST", "^DSRST", 1000, &p_response);
    if (err < 0 || (NULL != p_response && p_response->success == 0)) {
        RLOGE("AT^DSRST Error, err = %d", err);
    }

    if (0 != resetModemTimer_id) {
        ril_timer_delete(resetModemTimer_id);
        resetModemTimer_id = 0;
        RLOGD("requestResetModem(), delete RESET MODEM TIMER success");
    }
	
	at_response_free(p_response);
}

void requestResetModemCallback(const struct timeval *relativeTime) {
     RLOGD("====:%s - %s() - Line:%d  " , __FILE__, __func__, __LINE__ );
    RIL_requestTimedCallback(requestResetModem, NULL, relativeTime);
}

void requestAtTimeOutCallback(const struct timeval *relativeTime) {
    RLOGD("====:%s - %s() - Line:%d  " , __FILE__, __func__, __LINE__ );
    RIL_requestTimedCallback(requestResetModemAndDump, NULL, relativeTime);
}

UINT8 getSimCardType()
{
    return simCardType;
}


#ifdef VT_ENABLE
int vt_init()

    FILE* vtDCIFile = fopen("/system/etc/vtdci.ini", "r");
    char *vtDCIInfo = (char*)malloc(MAX_VTDCI_LENGTH);
    int vtDCILen = 0;

    if (vtDCIInfo != NULL && vtDCIFile != NULL){
        //fixed by mabin for memory access violation attempt.
        memset(vtDCIInfo, 0, MAX_VTDCI_LENGTH);
        vtDCILen = fread(vtDCIInfo, 1, MAX_VTDCI_LENGTH, vtDCIFile);
        RLOGE("vtDCILen: %d", vtDCILen);
        RLOGE("vtDCIInfo: %s", vtDCIInfo);
    } else {
        RLOGE("open file fail or malloc fail");
    }

    at_send_command( "AT^DVTABLE=3,3,1",  NULL);
    at_send_command( "AT^DVTTYPE=3", NULL);
    at_send_command( "AT^DVTVDFORMAT=1",  NULL);

    if (vtDCILen != 0) {
        at_send_command( vtDCIInfo,  NULL); //vtdci read from file
    } else {
        at_send_command( "AT^DVTDCI=\"000001b034000001b2000900ffff0900020200000001b509000001b2000900ffff09000202000000010000000120008440fa282c2090a31f\"",  NULL);
    }

    if (vtDCIInfo != NULL) {
        free(vtDCIInfo);
    }

    if (vtDCIFile != NULL) {
        fclose(vtDCIFile);
        vtDCIFile = NULL;
    }
    //Bug00001298 zhuzhenbin modified end

    int ret;
    
    int fd = open("/dev/TTYEMS08_s", O_RDWR);
    if(fd < 0)
    {
         RLOGE("[VP]invalid VP video device"); 
         return -1;   
    }
       
    ret = write(fd, "AT^DVTCHL=1\r\n", strlen("AT^DVTCHL=1\r\n"));   
    if(ret < 0)
    {
        RLOGE("open data port error!!");    
    }
    close(fd);
   
    return 0;
}
#endif

static void waitForClose()
{
    pthread_mutex_lock(&s_state_mutex);
    //RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__);
    while (s_closed == 0) {
     //RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__);
        pthread_cond_wait(&s_state_cond, &s_state_mutex);
    }
    //RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__);
    pthread_mutex_unlock(&s_state_mutex);
}

static void sendUnsolImsNetworkStateChanged()
{
#if 0 // to be used when unsol is changed to return data.
    int reply[2];
    reply[0] = s_ims_registered;
    reply[1] = s_ims_services;
    reply[1] = s_ims_format;
#endif
    RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_IMS_NETWORK_STATE_CHANGED,
            NULL, 0);
}

static char atReadStorage[1024];

/**
 * Called by atchannel when an unsolicited line appears
 * This is called on atchannel's reader thread. AT commands may
 * not be issued here
 */
static void onUnsolicited (const char *s, const char *sms_pdu)
{
    RLOGD(">>> new onUnsolicited = %s",s);
    char *line = NULL;
    int err;
    int gpsi = 0;
    char broadcastAtLevel[2] = {'\0'};
    char broadcastStr[200] = {0};
    char* temp = NULL;
    int level = 0;

    /* Ignore unsolicited responses until we're initialized.
     * This is OK because the RIL library will poll for initial state
     */
    if (sState == RADIO_STATE_UNAVAILABLE)
    {
        return;
    }

    property_get("sys.xt.broadcast.at.level", broadcastAtLevel,"0");
    level = atoi(broadcastAtLevel);
    // 2 broadcast all onUnsolicited command, 3 only broadcast RSSI command
    if(level != 0 && level != 1) {
        if(strstr(s," ")) {
            temp = strdup(s);
            strrpl(temp, ' ', '!');
        }
        snprintf(broadcastStr,
            sizeof(broadcastStr)-1,
            "am broadcast -a android.intent.action.InfoCommand.result --ei channle_id %d --ei direction %d --es ats %s ",
            0,1,temp == NULL?s:temp);  
        RLOGD("SendBroadCast broadcastStr = %s, broadcastAtLevel = %s",
           broadcastStr, broadcastAtLevel);
        if(level == 2) {
            system(broadcastStr);
        } else if(level == 3 && strStartsWith(s,"RSSI:")){
            system(broadcastStr);
        }
        if(temp != NULL) {
           free(temp);
        }
    }
    
    if (strStartsWith(s, "%CTZV:"))
    {
        /* TI specific -- NITZ time */
        unsolicitedNitzTime(s);
    }
    else if(strStartsWith(s,"+CTZE")){
        unsolicitedNitzTimeEx(s);
    }   
    else if (strStartsWith(s,"+CRING:")
                || strStartsWith(s,"RING")
                || strStartsWith(s,"NO CARRIER")
                || strStartsWith(s,"+CCWA")
                || strStartsWith(s,"^DSCI")/*Fixed for terminated call*/ 
                || strStartsWith(s,"^DCSSU"))/* call hold*/
    {
        /* Add disconnect cuase report */
        if(strStartsWith(s, "^DSCI"))
        {
            line = strdup(s);
            int mval  = onUnsolicitedDsci(line);
            free(line);
            line = NULL;
            if(-1 == mval) return;
        }

        RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_CALL_STATE_CHANGED, NULL, 0);

        //< Add new unsolicited msg for imcoming call ./>
        if (strStartsWith(s,"+CRING:"))
        {
            char *pType = NULL;            
            line = strdup(s);
            char *pLine = line;
            at_tok_start(&line);
            at_tok_nextstr(&line, &(pType));

            if(pType != NULL && strcmp(pType, CRING_TYPE_VOICE) == 0)
                RIL_onUnsolicitedResponse(RIL_UNSOL_CALL_RING, NULL, 0);

            RLOGD("CRING:before free");
            free(pLine);
            pLine = NULL;
            pType = NULL;
            line = NULL;
        } else if(strStartsWith(s,"RING")) {
        	RLOGD("RING: call ring:%s", s);
			RIL_onUnsolicitedResponse(RIL_UNSOL_CALL_RING, NULL, 0);
		}

        if (strStartsWith(s, "^DCSSU"))
        {
            RLOGD("DCSSU: call hold:%s", s);
            onUnsolicitedCallHold(s);
        }

#ifdef WORKAROUND_FAKE_CGEV
        RIL_requestTimedCallback (onDataCallListChanged, NULL, NULL); //TODO use new function
#endif /* WORKAROUND_FAKE_CGEV */
    }
    else if (strStartsWith(s,"+CREG:")
#if defined(OPT_4G)
            || strStartsWith(s,"+CEREG:")
#endif
            || strStartsWith(s,"+CGREG:")
            || strStartsWith(s,"+CSREG:")) //FOR S MODE CS REG STATE ONUNSOLICITED;
    {
        strREGstateUnsol(s);
    } else if (strStartsWith(s, "ALERTING")) {
        snprintf(broadcastStr,
            sizeof(broadcastStr)-1,
            "am broadcast -a android.intent.action.CALL_ALERTING");
        system(broadcastStr);
    } else if (strStartsWith(s, "SIGNAL OFF")) {
        snprintf(broadcastStr,
            sizeof(broadcastStr)-1,
            "am broadcast -a android.intent.action.SIGNAL_OFF");
        system(broadcastStr);
    } else if (strStartsWith(s, "^BACHST:")) {
        char *p;
        int val = 0;
        p = line = strdup(s);
        err = at_tok_start(&p);
        if(err == 0) {
            err = at_tok_nextint(&p, &val);
            if(err == 0) {
                snprintf(broadcastStr,
                    sizeof(broadcastStr)-1,
                    "am broadcast -a android.intent.action.BACHST --ei state %d", val);
                system(broadcastStr);
            }
        }
        free(line);
        line = NULL;
        p = NULL;
    } else if(strStartsWith(s, "^DCINFO:"))
    {
        unsigned char gprs_stat, egprs_stat, hsdpa_stat, hsupa_stat, hspap_stat;
        int commas = 0;
        int networktype = 0;
        line = strdup(s);
        char *pLine = line;

        at_tok_start(&line);
        commas = at_tok_parse_ext((SINT8 **)&line, "UUUUU", &gprs_stat, &egprs_stat, &hsdpa_stat, &hsupa_stat, &hspap_stat);
        if(5 !=  commas)
        {
            RLOGE("error ^DCINFO:,commas = %ld", commas);
        }
        else
        {
            if(hspap_stat == 1)
                networktype = RADIO_TECH_HSPAP;
            else if(hsdpa_stat == 1)
                networktype = RADIO_TECH_HSDPA;
            else if(hsupa_stat == 1)
                networktype = RADIO_TECH_HSUPA;
            else
                networktype = RADIO_TECH_HSPA;

            RLOGE("^DCINFO:,networktype = %d", networktype);
            if(isNetRegistered(mNetState) && lastNetworktype != networktype)
                RIL_requestTimedCallback(updateVoiceNetworkState, NULL, NULL);
        }
        free(pLine);
        pLine = NULL;
        line = NULL;
    }  
    else if (strStartsWith(s, "+CMT:"))
    {
		RLOGD(">>> new CMT SMS + smspdu =%s,  pdulen= ",sms_pdu,strlen(sms_pdu));
        RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_NEW_SMS, sms_pdu, strlen(sms_pdu));
    }
    else if (strStartsWith(s, "+CBM:"))
    {
        RLOGD(">>> new CMB SMS + smspdu =%d",strlen(sms_pdu));
        RLOGD(">>> new CMB SMS + smspdu =%s",sms_pdu);
        RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_NEW_BROADCAST_SMS, sms_pdu, strlen(sms_pdu));
    }
    else if(strStartsWith(s, "^DGPSI:"))
    {
        RLOGD(">>> gpsi coming .....");
        RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_GPSI, &gpsi, sizeof(int));
    }
    else if (strStartsWith(s, "+CMTI:"))
    {
        char value[2] = {'\0'};

        //if(property_get("sys.cta.enable", value, "0")) {
        if (property_get("persist.sys.cta.enable", value, "0")) {
            RLOGD("CTA enable value = %s", value);
            if(0 == strcmp(value,"1")) {
                char    *type = NULL;
                char *p;
                int index = -1;
                indexOfSmsOnSimCard = -1;
                p = line = strdup(s);
                if(p) {
                    err = at_tok_start(&p);
                    if(err >= 0) {
                        err = at_tok_nextstr(&p, &type);
                    }
                    if(err >= 0) {
                        err = at_tok_nextint(&p, &index);
                    }
                    indexOfSmsOnSimCard = index;
                    if(indexOfSmsOnSimCard >= 0) {
                        indexOfSmsOnSimCard++;
                        RLOGD("[class 2 SMS]id = %d", indexOfSmsOnSimCard);
                        RIL_requestTimedCallback(onCMTI, NULL, NULL);
                        RIL_requestTimedCallback(clearIndexOfSmsOnSimCard, NULL, &TIMEVAL_5S);
                    }
                }
                free(line);
            }
        }
    }
    else if (strStartsWith(s, "+CDS:"))
    {
        RIL_onUnsolicitedResponse (RIL_UNSOL_RESPONSE_NEW_SMS_STATUS_REPORT, sms_pdu, strlen(sms_pdu));
    }
    else if (strStartsWith(s, "+CGEV:"))
    {
        /* Really, we can ignore NW CLASS and ME CLASS events here,
         * but right now we don't since extranous
         * RIL_UNSOL_DATA_CALL_LIST_CHANGED calls are tolerated
         */
        /* can't issue AT commands here -- call on main thread */
        ata_unsolicited_at_cgev((unsigned char *)s);

        if (!strstr(s, "ME ACT")) {
            RIL_requestTimedCallback (onDataCallListChanged, NULL, NULL);
        }
#ifdef WORKAROUND_FAKE_CGEV
    }
    else if (strStartsWith(s, "+CME ERROR: 150"))
    {
        RIL_requestTimedCallback (onDataCallListChanged, NULL, NULL);
#endif /* WORKAROUND_FAKE_CGEV */
    } 
    else if(strStartsWith(s, "^DTUSATURC"))
    {
        handleStkProactiveCommand(s, sms_pdu);
    }
    else if ((strStartsWith(s, "^DMRST")) || (strStartsWith(s, "^DEXCEPTINFO")))
    {
        if(strStartsWith(s, "^DEXCEPTINFO")) {
            if(0 == g_val_dist) {
                RLOGD("onUnsolicited: AT^DEXCEPTINFO");
                requestResetModemCallback(NULL);
                g_val_dist = 1;
            }
        } else { /* ^DMRST */
            RLOGD("onUnsolicited: AT^DMRST");
        }
    }
    else if (strStartsWith(s, "+CUSD:"))
    {
        int     mode = -1;
        int     dcs = -1;
        char    ussdStr[USSD_STRING_LENGH_MAX*2+1] = {0};           
        char    *response[3];  
        char    *p;

        memset(response, 0, sizeof(response));
        
        p = line = strdup(s);
        err = at_tok_start(&p);
        
        if(err >= 0)
        {
            err = at_tok_nextint(&p, &mode);
        }
        
        if(err >= 0)
        {
            char *strtmp = NULL;
            err = at_tok_nextstr(&p, &strtmp);
            
            if (strtmp != NULL)
            {
                strcpy(ussdStr, strtmp);
            }
        }

        if(err >= 0)
        {
            err = at_tok_nextint(&p, &dcs);
        }
        
        if (mode != -1)
        {
            asprintf(&response[0], "%d", mode);
        }

        if (ussdStr != NULL && strlen(ussdStr) != 0)
        { 
            response[1] = ussdStr;
        }
        
        if (dcs != -1)
        {
            asprintf(&response[2], "%d", dcs);
        }

        if (response[0] != NULL)
        {
            RLOGD("000response[0]:%s", response[0]);
        }
        
        if (response[1] != NULL)
        {
            RLOGD("111response[1]:%s", response[1]);
        }

        if (response[2] != NULL)
        {
            RLOGD("222response[2]:%s", response[2]);
        }
        if (response[1] != NULL && response[2] != NULL) {
            char    data_utf8[MAX_UTF8_LENGTH] = "";
            int     data_len = 0;

            switch(getEncodeType(atoi(response[2]))) {
                case CUSD_ENCODE_TYPE_7BIT:
                case CUSD_ENCODE_TYPE_8BIT:
                    data_len = hexGsm8bit2Utf8((unsigned char *)response[1], data_utf8, strlen(response[1]));
                    break;
                case CUSD_ENCODE_TYPE_16BIT:
                    data_len = hexUcs2ToUtf8((unsigned char *)response[1], data_utf8, strlen(response[1]));
                    break;
                defalut:
                    strcpy(data_utf8, response[1]);
                    data_len = strlen(response[1]);
                    break;
            }
            response[1] = data_utf8;
        }
        RIL_onUnsolicitedResponse(RIL_UNSOL_ON_USSD, response, sizeof(response));            

        if (NULL != line)
        {
            free(line);
            line = NULL;
        }

        if (NULL != response[0])
        {
            free(response[0]);
            response[0] = NULL;
        }
        
        if (NULL != response[2])
        {
            free(response[2]);
            response[2] = NULL;
        }
    }
    else if(strStartsWith(s, "+CIEV"))
    {
        int ind = 0;
        int value = 0;
        char *p;

        p = line = strdup(s);
        at_tok_start(&p);
        err = at_tok_nextint(&p, &ind);
        if(0 == err) {
            if(2 == ind && at_tok_hasmore(&p)) {
                if (0 != resendCSQTimer_id) {
                    ril_timer_delete(resendCSQTimer_id);
                    resendCSQTimer_id = 0;
                    RLOGD("delete RESEND CSQ TIMER");
                }
                RIL_requestTimedCallback(unsolgetSignalStrength, NULL, NULL);       
            }
            else if(8 == ind && at_tok_hasmore(&p)) {
                err = at_tok_nextint(&p, &value);
                if(0 == err) {
                    DBBD(DB_RIL, RLOGD("===SM memory storage:(%d),g_sim_exist=%d\n",value,g_sim_exist));

                    if(1 !=value)
                        s_sms_full_notified = FALSE;

                    if(1 == value) {
                        if ((RESET_SIM_EXIST == g_sim_exist)&&(FALSE == s_sms_full_notified )) {
                            RIL_onUnsolicitedResponse (RIL_UNSOL_SIM_SMS_STORAGE_FULL, NULL, 0);
                            s_sms_full_notified = TRUE;
                        } else if (RESET_SIM_ABSENT == g_sim_exist) {
                        RIL_onUnsolicitedResponse (RIL_UNSOL_SIM_SMS_STORAGE_AVAILABLE, NULL, 0);
                        }
                    } else if(0 == value){
                        RIL_onUnsolicitedResponse (RIL_UNSOL_SIM_SMS_STORAGE_AVAILABLE, NULL, 0);
                    } else if (255 == value) {
                        RIL_onUnsolicitedResponse(RIL_UNSOL_SIM_SMS_STORAGE_AVAILABLE, NULL, 0);
                    }
                }
            }
        }
        
        free(line);
    }
    else if (strStartsWith(s, "^DEWALKU: PB READY"))
    {
        if (0 == is_pb_ready) {
            is_pb_ready = 1;
            RLOGD("^@^phone_book is ready...");
            RIL_onUnsolicitedResponse(RIL_UNSOL_USIM_RECORD_READY, NULL, 0);
            RIL_requestTimedCallback(requestSIMType, NULL, NULL);
        }
    }
    else if (strStartsWith(s, "^DEWALKU: PB NOT READY"))
    {
        RLOGD("^@^phone_book is not ready...");
        is_pb_ready = 0;/*L1813_Bug00001377, wangsheng, 2013-08-06*/
        RIL_onUnsolicitedResponse(RIL_UNSOL_USIM_RECORD_NOT_READY, NULL, 0);
        RIL_requestTimedCallback(requestSIMType, NULL, NULL);
    }
    else if (strStartsWith(s, "^DADNI:"))
    {
        RLOGD("phon_book chage for FDN");

        int adnStandby;
        int adnCachFlag;
        char *p;
        p = line = strdup(s);
        err = at_tok_start(&p);
        if(err >= 0) {
            err = at_tok_nextint(&p, &adnStandby);
            err = at_tok_nextint(&p, &adnCachFlag);
            RLOGD("adnStandby = %d, adnCachFlag = %d", adnStandby, adnCachFlag);
            RIL_onUnsolicitedResponse (RIL_UNSOL_ADN_UPDATE_FOR_FDN, &adnCachFlag, sizeof(int));
        }
        free(line);
    }
    else if (strStartsWith(s, "^DEGSI:"))
    {
        int psState;
        char *p;
        p = line = strdup(s);
        err = at_tok_start(&p);
        if(err >= 0) {
            err = at_tok_nextint(&p, &psState);
            RLOGD("psState = %d", psState);
            RIL_onUnsolicitedResponse (RIL_UNSOL_PS_SERVICE_STATE_CHANGED, &psState, sizeof(int));
        }
        free(line);
    }
    else if (strStartsWith(s, "^DUSIMU:"))
    {
        int state = -1;
        char section[10];
        char simStatus[10];
        char SIM_DCID_FILE[30];
        int iSimChanged[2];
        snprintf(SIM_DCID_FILE, 30, "%s%d", SIM_DCID_FILE_PRE, s_rilID);
        snprintf(section, 10, "SIM");
        char *p;
        
        p = line = strdup(s);
        err = at_tok_start(&p);
        if(err >= 0) {
            err = at_tok_nextint(&p, &state);
        }

        is_unsol_dusimu = 1;
        
        if(state == 0) {
            RLOGD("====>reset_sim_absent...");
            RIL_onUnsolicitedResponse (RIL_UNSOL_SIM_SMS_STORAGE_AVAILABLE, NULL, 0);
            RIL_requestTimedCallback(onSimCardAbsent, NULL, NULL);
            GetPrivateProfileString(section, "SIMSTATUS", "0", simStatus, 10, SIM_DCID_FILE); 
            if (simStatus[0] != '0') {
                WritePrivateProfileString(section, "SIMSTATUS", "0", SIM_DCID_FILE);
                WritePrivateProfileString(section, "SIMDCID", "", SIM_DCID_FILE);
                iSimChanged[0] = 1;
            } else {
                iSimChanged[0] = 0;
            } 

            iSimChanged[1] = 0;
            RLOGD("USIMEXITiSimStatus %d %d", iSimChanged[0], iSimChanged[1]);
            RIL_onUnsolicitedResponse(RIL_UNSOL_USIM_EXIT, &iSimChanged, 2*sizeof(int));
        } else {
            g_sim_exist = RESET_SIM_EXIST;
            RIL_requestTimedCallback(requestGetDcid, NULL, NULL);
            RIL_requestTimedCallback(requestQueryEventReport, NULL, NULL);
        }
        RLOGD("m_cardStatus = %d; m_otherCardStatus = %d",ril_config_st.m_cardStatus,ril_config_st.m_otherCardStatus);
        //Add by guojing for 20141113-34828, 2014-11-14
        #if 0
        if(CARD_STATUS_ABSENT == ril_config_st.m_cardStatus
            && CARD_STATUS_EXIST == ril_config_st.m_otherCardStatus) 
        #else
		if(g_sim_exist != RESET_SIM_EXIST)
		#endif
        {
            RLOGD("don't getEmergencyNumber() since this slot has not (U)SIM card, and the another slot has (U)SIM card");
        } else {
			if(g_modemtype_s == 0) {
            	RIL_requestTimedCallback(getEmergencyNumber, NULL, NULL);
			}
        }
        free(line);
    }
    else if (strStartsWith(s, "+PCD:"))
    {
        ata_unsolicited_at_pcd((unsigned char *)s);
    }
    else if (strStartsWith(s, "+HLSERROR:"))
    {
        char *p;
        p = line = strdup(s);
        at_tok_start(&p);
        int errType = 255;
        int errCause = 255;
        err = at_tok_nexthexint(&p, &errType);

        RLOGD("HLSERROR: errType = %d",errType);
        if (err == 0 && errType == 14) {
            err = at_tok_nexthexint(&p, &errCause);
        }
         if(0 == err && errCause >= 0 && errCause < 255) {
            //errNumber = (errCause/10) * 16 + (errCause%10) ;
            errNumber = RIL_E_ILLEGAL_SIM_OR_ME + errCause + 1;   //errCause is 0~3
        }
        RLOGD("HLSERROR: errCause = %d,errNumber = %d",errCause,errNumber);

        free(line);
    }
/*add for vt feature begin*/
#ifdef VT_ENABLE
    else if (strStartsWith(s, "^DVTSTRRI"))
    {
        char *p;
        p = line = strdup(s);
        at_tok_start(&p);
        char * strResponse = NULL;
        err = at_tok_nextstr(&p, &strResponse);
        if (err == 0){
            RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VT_STRRI, strResponse, strlen(strResponse));
        }
        free(line);
    }
    else if (strStartsWith(s, "^DVTSENDI"))
    {
        char *p;
        p = line = strdup(s);
        at_tok_start(&p);
        int response[2];
        memset(response, 0, sizeof(response));
        err = at_tok_nextint(&p, &response[0]);
        if (err == 0){
            err = at_tok_nextint(&p, &response[1]);
            if (err == 0){
                RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VT_SENDI, response, sizeof(response));
            }
        }
        free(line);
    }
    else if (strStartsWith(s, "^DVTRECAI"))
    {
        char *p;
        p = line = strdup(s);
        at_tok_start(&p);
        int response = 0;
        err = at_tok_nextint(&p, &response);
        if (err == 0){
            RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VT_RECAI, &response, sizeof(response));
        }
        free(line);
    }
    else if (strStartsWith(s, "^DVTDATA"))
    {
        char *p;
        p = line = strdup(s);
        at_tok_start(&p);
        int response = 0;
        err = at_tok_nextint(&p, &response);
        if (err == 0){
            RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VT_DATA, &response, sizeof(response));
        }
        free(line)
    }
    else if (strStartsWith(s, "^DVTCODEC"))
    {
        //^DVTCODEC: 3,1,0,1,176,144,0,1000,0
        char *p;
        p = line = strdup(s);
        at_tok_start(&p);
        VID_PARAM* vidparam = NULL;
        int type = 0;
        int tmp = 0;
        int imgWidth = 0;
        int imgHeight = 0;
        err = at_tok_nextint(&p, &type);
        if (err == 0){
            if(type == 3){
                err = at_tok_nextint(&p, &tmp);
                if (err == 0) {
                    vidparam = malloc(sizeof(VID_PARAM));
                    memset(vidparam, 0, sizeof(VID_PARAM));
                    //get codecType
                    switch(tmp){
                        case 1: vidparam->codecType = PV_VID_TYPE_H263; break;
                        case 2: vidparam->codecType = PV_VID_TYPE_MPEG4; break;
                        case 3: vidparam->codecType = PV_VID_TYPE_H264; break;
                        default: RLOGE("Error, unsupported codec type");
                    }
                    //get the width and height,skip PostFilter & formattype
                    at_tok_nextint(&p, &tmp);
                    at_tok_nextint(&p, &tmp);
                    err = at_tok_nextint(&p, &imgWidth);
                    if (err == 0){
                        err = at_tok_nextint(&p, &imgHeight);
                        if (err == 0){
                            vidparam->height = imgHeight;
                            vidparam->width = imgWidth;
                            vidparam->bitrate = 48000;
                        }
                    }
                    RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VT_CODEC, vidparam, sizeof(VID_PARAM));
                    free(vidparam);
                }
            }
        }
        free(line);
    }
#endif
/*add for vt feature end*/
    else if (strStartsWith(s, "^DPIRNI:"))
    {
        char *p = NULL;
        int eventType = -1;
        int state = -1;

        p = line = strdup(s);
        at_tok_start(&p);

        err = at_tok_nextint(&p, &eventType);
        if (err < 0) {
            RLOGE("^DPIRNI: err = %d, eventType = %d", err, eventType);
            free(line);
            return;
        }

        err = at_tok_nextint(&p, &state);
        if (err < 0) {
            RLOGE("^DPIRNI: err = %d, state = %d", err, state);
            free(line);
            return;
        }

        RLOGD("^DPIRNI: %s, linkId = %d, eventType = %d, state = %d", p, s_rilID, eventType, state);
        if (0 == err && 0 == eventType && 1 == state) {
            RLOGD("^DPIRNI: RIL_onUnsolicitedResponse RIL_UNSOL_MODEM_POWER_ON_REGISTER_COMPLETE");
            RIL_onUnsolicitedResponse(RIL_UNSOL_MODEM_POWER_ON_REGISTER_COMPLETE, NULL, 0);
        }

        free(line);
    }
    else if (strStartsWith(s, "^DPSTI") && g_singleCardMultiStandby)
    {
         //report to framework, and then send AT^DECP,AT^DETR,  AT+CGDATA on the other standby
         //getActiveDataLinkInfo();
         g_lose_coverage = 1;
    }
    else if (strStartsWith(s, "^DCSR:") && g_singleCardMultiStandby)
    {
          char *p;
          int response[2];
          p = line = strdup(s);
          at_tok_start(&p);

          err = at_tok_nextint(&p, &response[0]);

          if (err == 0) {
              err = at_tok_nextint(&p, &response[1]);
          }
          RLOGD("^DCSR: act = %d, confCamp = %d", response[0], response[1]);

          RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_CAMP_STATUS, response, 2*sizeof(int));
          free(line);
    }
    else if (strStartsWith(s, "+CIREPH:"))   //add by jiangxuqin0703 for Req20150703-66382 -s
    {
        char *p = NULL;
        int status = -1;

        p = line = strdup(s);
        at_tok_start(&p);

        err = at_tok_nextint(&p, &status);
        if (err < 0) {
            RLOGE("+CIREPH: err = %d, status = %d", err, status);
            free(line);
            return;
        }

        RLOGD("RIL_onUnsolicitedResponse RIL_UNSOL_SRVCC_STATE_NOTIFY +CIREPH: %s, linkId = %d, status = %d", p, s_rilID, status);

        RIL_onUnsolicitedResponse(RIL_UNSOL_SRVCC_STATE_NOTIFY, &status, sizeof(int));

        free(line);  //add by jiangxuqin0703 for Req20150703-66382 -e
    }
    else if (strStartsWith(s, "^DGSQU:")
            || strStartsWith(s, "^DSQU:")
            || strStartsWith(s, "^DESQU:")) {
        onSignalReceived(s);
    }
    else if (strStartsWith(s, "^DAMRTI:"))     {
        char *p = NULL;
        int status = -1;

        p = line = strdup(s);
        at_tok_start(&p);

        err = at_tok_nextint(&p, &status);
        if (err < 0) {
            RLOGE("+DAMRT: err = %d, status = %d", err, status);
            free(line);
            return;
        }

        RLOGD("RIL_onUnsolicitedResponse RIL_UNSOL_RESPONSE_CALL_QUALITY +CIREPH: %s, linkId = %d, status = %d", p, s_rilID, status);

        RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_CALL_QUALITY, &status, sizeof(int));

        free(line);
    }  
    else if (strStartsWith(s, "^DAUDZSU:")){
        char *p = NULL;
        int status = -1;

        p = line = strdup(s);
        at_tok_start(&p);

        err = at_tok_nextint(&p, &status);
        if (err < 0) {
            RLOGE("+DAUDZSU: err = %d, status = %d", err, status);
            free(line);
            return;
        }

	if(1==status){
            RLOGD(" open TL420");
            __system_property_set("persist.sys.boot_adsp", "on");
	}
	else if(0==status){
            RLOGD(" close TL420");
            __system_property_set("persist.sys.boot_adsp", "off");
	}

	free(line);
    }
    else if (strStartsWith(s, "^GPS:")) { //add for start GPS info report
    // service;
        char *p = NULL;
        int enable_gps_report = 0;
        char broadcastCommand[200] = {0};

        p = line = strdup(s);
        at_tok_start(&p);

        err = at_tok_nextint(&p,&enable_gps_report);
        if(err < 0) {
         RLOGE("^GPS ERR");
         free(line);
         return;
        }
        snprintf(broadcastCommand,
            sizeof(broadcastCommand)-1,
            "am broadcast -a com.xt.action_LAUNCH_LOCATION_SERVICE --ei mode %d",
            enable_gps_report);
        system(broadcastCommand);
        free(line);
    }
    else if (strStartsWith(s, "^DTIME:")) {
        char *p = NULL;
        char *time = NULL;
        p = line = strdup(s);
        at_tok_start(&p);

        err = at_tok_nextstr(&p, &time);
        if ( err < 0) {
            RLOGE("^DTIME ERR");
            free(line);
            return;
        }
        snprintf(broadcastStr,
            sizeof(broadcastStr)-1,
            "am broadcast -a com.xt.action_UPDATE_TIME --es time %s",
            time);
        RLOGD("DTIME: broadcastStr = %s", broadcastStr);
        system(broadcastStr);
        free(line);
    }
    else
    {
       // LOG_INFO(("Unsolicited LINE:%s, not supported", s));
       char *p = NULL;
       if(s)
       {
            line = strdup(s);
            memset(atReadStorage, 0, 1024);

            strncpy(atReadStorage, line, strlen(line));
            p = atReadStorage + strlen(line);

            if(sms_pdu) {
                strncpy(p, sms_pdu, strlen(sms_pdu));
            }

            RLOGI(":RIL_onUnsolicitedResponse: s%", atReadStorage);
            RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_TUNNEL_AT,
                atReadStorage, strlen(atReadStorage));
            free(line);
       }
    }
    
}

/*added for vt feature begin*/
#ifdef VT_ENABLE
void requestVideoTelephonyDial(void *data, size_t datalen, RIL_Token t)
{
    RIL_Dial *p_dial;
    char *cmd;
    const char *clir;

    p_dial = (RIL_Dial *)data;

    switch (p_dial->clir) {
            case 1: clir = "I"; break;  /*invocation*/
            case 2: clir = "i"; break;  /*suppression*/
            default:
            case 0: clir = ""; break;   /*subscription default*/
    }

    asprintf(&cmd, "AT^DVTDIAL=%s", p_dial->address);
    at_send_command(cmd, NULL);
    free(cmd);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestVideoTelephonyHangup(void *data, size_t datalen, RIL_Token t)
{
    int ret;
    int* pData = (int*)data;
    char* pCmd = NULL;
    RLOGI("[VP] requestVideoTelephonyHangup...");

    if (pData == NULL) {
        RLOGI("requestVideoTelephonyHangup pData = null");
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    /* vt call log exclude local hangup*/
    if (pData[0] == CALL_FAIL_CAUSE_NORMAL_CLEARING)
        ret = at_send_command("AT^DVTEND", NULL);
    else {
        asprintf(&pCmd, "AT^DVTHUP=%d,%d", 1, pData[0]);
        ret = at_send_command(pCmd, NULL);
        free(pCmd);
        pCmd = NULL;
    }

    if (ret != 0) goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RLOGI("[VP] requestVideoTelephonyHangup fail");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

void requestVideoTelephonyAnswer(void *data, size_t datalen, RIL_Token t)
{
    at_send_command("AT^DVTANS", NULL);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

void requestVideoTelephoneSendStr(void *data, size_t datalen, RIL_Token t)
{
    int           ret;
    char*         cmd = NULL;
    char* str = (char *)data;

    asprintf(&cmd, "AT^DVTSTRS=\"%s\"", str);
    ret = at_send_command(cmd, NULL);
    free(cmd);
    if (ret != 0) goto error;
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RLOGI("[VP] requestVideoTelephoneSendStr fail");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

//added for vt porting
void requestVideoTelephoneSendCmd(void *data, size_t datalen, RIL_Token t)
{
   int ret;
    int* pData = (int*)data;
    char* pCmd = NULL;
    ATResponse *p_response = NULL;
    RLOGI("[VP] requestVideoTelephoneSend...");

    if (pData == NULL) {
        RLOGI("requestVideoTelephoneSendCmd pData = null");
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    if (pData[0] == 10) {
        asprintf(&pCmd, "AT^DVTTFLAG=%d", pData[1]);
    } else {
        asprintf(&pCmd, "AT^DVTSEND=%d,%d", pData[0], pData[1]);
    }
 
    ret = at_send_command(pCmd, &p_response);
    free(pCmd);
    pCmd = NULL;

    if (ret != 0 || p_response->success == 0) goto error;

    at_response_free(p_response);
	RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    return;

error:
    RLOGI("[VP] requestVideoTelephoneSend fail");
	at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}
#endif
/*added for vt feature end*/

void requestPrintCardAbsentInfo(void)
{
    int err;
    ATResponse *p_response = NULL;
    char *line = NULL;
    RLOGD("requestPrintCardAbsentInfo");

    err = at_send_command_multiline_1("AT^DDBTRACE=0,1", "^DDBTRACE:", &p_response);
    if (err < 0 || p_response== NULL ||p_response->success == 0) {
        RLOGD("requestPrintCardAbsentInfo_2 err = %d", err);
        goto error;
    }

    line = p_response->p_intermediates->line;
    RLOGD("requestPrintCardAbsentInfo_3. line: %s", line);

    if(strstr(line,"AT^DDBTRACE=0,2"))
    {
        RLOGD("AT^DDBTRACE=0,2");
        err = at_send_command_singleline("AT^DDBTRACE=0,2", "^DDBTRACE:", NULL);
    }
    else if(strstr(line,"AT^DDBTRACE=0,3"))
    {
        RLOGD("AT^DDBTRACE=0,3");
        err = at_send_command_singleline("AT^DDBTRACE=0,3", "^DDBTRACE:", NULL);
    }    
    else
    {
        RLOGE("requestPrintCardAbsentInfo: %s", p_response->p_intermediates->line);
    }
    
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    RLOGE("requestPrintCardAbsentInfo Error");
}
//add end

#ifdef VT_ENABLE
//added for incoming black call
static void requestAutoConfirmVT(void * param){
    char * cmd = NULL;
    int index = (int) param;
    asprintf(&cmd,"AT^DANS=%d,1", index);
    int err = at_send_command(cmd, NULL);
    free(cmd);
    if (err < 0){
        RLOGE("requestAutoConfirmVT failed\n");
    }
}

static void requestClearVTChannel() {
    at_send_command("AT^DVTCHL=0", NULL);
    int fd = open("/dev/TTYEMS08_s", O_RDWR);

    if(fd < 0) {
        RLOGE("[VP]invalid VP video device");
    } else {
        int ret = write(fd, "AT^DVTCHL=1\r\n", strlen("AT^DVTCHL=1\r\n"));
        if(ret < 0) {
            RLOGE("open data port error!!");
        }

        close(fd);
    }
}
#endif

static int onUnsolicitedCallHold(const char *s) {
    int err = -1, response = 0, response1 = 0;
    char *p = NULL, *line = NULL;
    RIL_SuppSvcNotification *notification = NULL;

    RLOGD("onUnsolicitedCallHold, s = %s", s);
    p = line = strdup(s);
    err = at_tok_start(&p);
    if (err < 0) goto error;
    err = at_tok_nextint(&p, &response);
    if (err < 0) goto error;
    err = at_tok_nextint(&p, &response);
    if (err < 0) goto error;
    
    if (NULL == p) {
        //^DCSSU attach 2 param
        RLOGD("onUnsolicitedCallHold, ^DCSSU attach 2 param, unsolicited response: RIL_UNSOL_CALL_HOLD");

        if (0 == err) {
            RLOGD("onUnsolicitedCallHold:[%d]", response);
            notification = malloc(sizeof(RIL_SuppSvcNotification));
            memset(notification, 0, sizeof(RIL_SuppSvcNotification));
            notification->notificationType = 1;
            notification->code = response;
            notification->index = 0;
            notification->type = 0;
            notification->number = NULL;
            RIL_onUnsolicitedResponse(RIL_UNSOL_SUPP_SVC_NOTIFICATION, notification, sizeof(RIL_SuppSvcNotification));
            free(notification);
            //RIL_onUnsolicitedResponse(RIL_UNSOL_CALL_HOLD, &response, sizeof(response));
        }
    } else {
        //^DCSSU attach 3 param
        RLOGD("onUnsolicitedCallHold, ^DCSSU attach 3 param, don't unsolicited response");
        err = at_tok_nextint(&p, &response1);
        if (err < 0) goto error;
    }

    if (NULL != line) {
        free(line);
    }

    RLOGD("onUnsolicitedCallHold: return %d", err);
    return err;

error:
    if (NULL != line) {
        free(line);
    }

    RLOGE("onUnsolicitedCallHold: return %d, error!!!!!", err);
    return err;
}

static void requestRejectVideoCall (void *p)
{
    at_send_command("AT^DANS=1,0,58", NULL);
}
/*L1813_Bug00002331, VT FALLBACK, fuyingli 20130929 end*/

int onUnsolicitedDsci(char *line) {
    // id,idr,stat,type,mpty,number,num_type,bs_type,cause,ti,subaddr,tos
    // ^DSCI: 1,0,6,1,0,"13401001603",129,1,88,128,"",255
    //ret = at_tok_parse_ext((char  **)&line, "UOUUOOOOUOOO", &index, &state, &type, &cause);  
    int index, idr, state, type, cause, err;
    int *response;
    int buffer[256];
    //added for incoming black call [0] index [1]number
    char * responseInComingMT[3];
    memset(responseInComingMT, 0, sizeof(responseInComingMT));
    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &index);
    if (err < 0) goto error;
    
    err = at_tok_nextint(&line, &idr);//&buffer[0]
    if (err < 0) goto error;
    
    err = at_tok_nextint(&line, &state);
    if (err < 0) goto error;
    
    err = at_tok_nextint(&line, &type);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &buffer[0]);

    char * number = NULL;
    err = at_tok_nextstr(&line , &number);
    if (err < 0) goto error;
    //added for black incoming call	
    RLOGE("state=%d;idr=%d;type=%d", state, idr, type);
    if (bConfigIncomingMT) {
        if ((4 == state || 5 == state) && (1 ==idr)) {
            if (type == 0){
                asprintf(&responseInComingMT[0], "%d", index);
                asprintf(&responseInComingMT[1], "%d", type);
                asprintf(&responseInComingMT[2], "%s", number);
                RLOGE("responseInComingMT[0] = %s, responseInComingMT[1] = %s,responseInComingMT[2] = %s", responseInComingMT[0], responseInComingMT[1],responseInComingMT[2]);
                RIL_onUnsolicitedResponse(RIL_UNSOL_INCOMING_MT_CALL, responseInComingMT, sizeof(responseInComingMT));
                free(responseInComingMT[0]);
                free(responseInComingMT[1]);
                free(responseInComingMT[2]);
            }
            else if (type == 1) {
                //reject VT
                RIL_requestTimedCallback(requestRejectVideoCall, NULL, NULL);
            }
            return -1;
        }
    }
    //move discard here for RIL_UNSOL_INCOMING_MT_CALL
    /*MT voice call, discard the first DSCI*/
    if((4 == state) && (1 ==idr))
    {
        return -1;
    }

    err = at_tok_nextint(&line, &buffer[0]);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &buffer[0]);
    if (err < 0) goto error;
    err = at_tok_nextint(&line, &cause);
    if (err < 0) goto error;

    RLOGE("index = %d, idr = %d, state = %d, type = %d, cause = %d", index, idr, state, type, cause);
    if ((6 == state) && (1 == type) && (0 == idr)) {
        int datalen = 2*sizeof(int);
        response = (int*)malloc(datalen);
        if (NULL == response)
            goto error;

        memset(response, 0, datalen);
        response[0] = index;
        response[1] = cause;
        RLOGD("DSCI, RIL_UNSOL_MO_DISCONNECT_CAUSE");
        RLOGD("(index, cause) = (%d, %d) responselen = %d\n", response[0], response[1], datalen);
        RIL_onUnsolicitedResponse(RIL_UNSOL_MO_DISCONNECT_CAUSE, response, datalen);
        free(response);
    }
    
    return 0;
error:
    RLOGE("invalid DSCI line\n");
    return 0;
}

/* Called on command or reader thread */
static void onATReaderClosed()
{
    RLOGI("AT channel closed\n");
    at_close();
    s_closed = 1;

    setRadioState (RADIO_STATE_UNAVAILABLE);
}

/* Called on command thread */
static void onATTimeout()
{
    RLOGI("AT channel timeout; closing\n");
    at_close();

    s_closed = 1;

    /* FIXME cause a radio reset here */

    setRadioState (RADIO_STATE_UNAVAILABLE);
}

/* Called to pass hardware configuration information to telephony
 * framework.
 */
static void setHardwareConfiguration(int num, RIL_HardwareConfig *cfg)
{
   RIL_onUnsolicitedResponse(RIL_UNSOL_HARDWARE_CONFIG_CHANGED, cfg, num*sizeof(*cfg));
}

static void usage(char *s)
{
#ifdef RIL_SHLIB
    fprintf(stderr, "reference-ril requires: -p <tcp port> or -d /dev/tty_device\n");
#else
    fprintf(stderr, "usage: %s [-p <tcp port>] [-d /dev/tty_device]\n", s);
    exit(-1);
#endif
}

int socket_tohost_client_tcp(char* ip , int port, int type)
{
    struct sockaddr_in addr;
    socklen_t alen;
    int s;

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    s = socket(AF_INET, type, 0);
    if(s < 0) return -1;

    if(connect(s, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        close(s);
        return -1;
    }

    return s;

}


void socket_send_test(int fd)
{
     struct sockaddr_in  si_other;
     int  slen=sizeof(si_other);
     char buf[100];
     int s;
     int i=0;
     int   address   = htonl(INADDR_ANY);

	
        memset((char *) &si_other, 0, sizeof(si_other));
        si_other.sin_family = AF_INET;
        si_other.sin_port = htons(5566);
        si_other.sin_addr.s_addr = address;
	 s=fd;
       // printf("UDP client sending packets to %s:%d\n", inet_ntoa(si_other.sin_addr), udpPort);
      while(1)
      	{
	   	RLOGD("panda:sending packet %d\n",i);
		sprintf(buf,"This is packet %d\n",i);
		int res = sendto(s, buf, sizeof(buf), 0, (struct sockaddr *)&si_other, slen);
		if(res == -1)
		{
			RLOGD("panda:sending packet error %d\n",res);
			return;
		}
		i++;
		usleep(10000000);
   	}
       //sendto(s,buf,sizeof(buf),0,(struct sockaddr *)&si_other,slen);
	  /* 
         if(connect(s, (struct sockaddr *) &si_other, sizeof(address)) < 0) {
		 RLOGD("panda:connect socket:s= %d ",s);
		 perror("connect error!");
         	 close(s);
          	 return -1;
        }*/
        
}


int socket_tohost_client_udp(char* ip,int port)
{
     struct sockaddr_in  si_other;
     int  slen=sizeof(si_other);
     char buf[100];
     int s;
     int i;
     int   address   = htonl(INADDR_ANY);

	if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
	{
		perror("create_socket_udp fail!");
		return -1;
	}
        memset((char *) &si_other, 0, sizeof(si_other));
        si_other.sin_family = AF_INET;
        si_other.sin_port = htons(port);
        si_other.sin_addr.s_addr = address;
	    bind(s,(struct sockaddr *)&si_other,sizeof(si_other));
       // printf("UDP client sending packets to %s:%d\n", inet_ntoa(si_other.sin_addr), udpPort);

	/*
       for(i=0;i<10;i++)
   	{
	   	RLOGD("panda:sending packet %d\n",i);
		sprintf(buf,"This is packet %d\n",i);
		int res=sendto(s,buf,sizeof(buf),0,(struct sockaddr *)&si_other,slen);
		if(res==-1)
		{
			RLOGD("panda:sending packet error %d\n",res);
			return -1;
		}
   	}*/

	   
       //sendto(s,buf,sizeof(buf),0,(struct sockaddr *)&si_other,slen);
	  /* 
         if(connect(s, (struct sockaddr *) &si_other, sizeof(address)) < 0) {
		 RLOGD("panda:connect socket:s= %d ",s);
		 perror("connect error!");
         	 close(s);
          	 return -1;
        }*/
        return s;
#if 0
        for (i=0; i<NPACK; i++) {
            printf("Sending packet %d\n", i);
            sprintf(buf, "This is packet %d\n", i);
            if (sendto(s, buf, BUFLEN, 0, (struct sockaddr*)&si_other, slen)==-1)
            diep("sendto()");

        }

        close(s);
        printf("UDP client closing\n");
#endif

}

pthread_t s_tid_socketudptest;



static void * mainLoop(void *param)
{
    int fd;
    int ret;
    char modem_type[2] = "";
    char s_sim_slot_id[2] = "";
    int sim_id = 0;	
    struct sockaddr_in  si_other;
    pthread_attr_t attr;
    int  slen=sizeof(si_other);

    AT_DUMP("== ", "entering mainLoop()", -1 );
    at_set_on_reader_closed(onATReaderClosed);
    at_set_on_timeout(onATTimeout);

    RLOGI("====mainloop, s_port = %d, s_device_socket = %d, s_device_path = %s", s_port, s_device_socket, s_device_path);
    for (;;) {
        fd = -1;
        while (fd < 0) {
            if (s_port > 0) {
               // fd = socket_loopback_client(s_port, SOCK_STREAM);
		  fd = socket_network_client("localhost", s_port, SOCK_STREAM);
            } else if (s_device_socket) {
                if (!strcmp(s_device_path, "/dev/socket/qemud")) {
                    /* Qemu-specific control socket */
                    fd = socket_local_client( "qemud",
                                              ANDROID_SOCKET_NAMESPACE_RESERVED,
                                              SOCK_STREAM );
                    if (fd >= 0 ) {
                        char  answer[2];

                        if ( write(fd, "gsm", 3) != 3 ||
                             read(fd, answer, 2) != 2 ||
                             memcmp(answer, "OK", 2) != 0)
                        {
                            close(fd);
                            fd = -1;
                        }
                   }
                }
                else
							{
								   RLOGD("wyy:communication by socket",5566);
								fd = socket_tohost_client_udp("127.0.0.1",PORT);
										/*
								pthread_attr_init (&attr);
										 pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
										 pthread_create(&s_tid_socketudptest, &attr, socket_send_test, fd);*/
								
							}
#if 0
                    fd = socket_local_client( s_device_path,
                                            ANDROID_SOCKET_NAMESPACE_FILESYSTEM,
                                            SOCK_STREAM );
#endif

            }
            else if (s_device_path != NULL) {
			RLOGD("wyy:communication by tty",s_device_path);
                fd = open (s_device_path, O_RDWR);
                RLOGI("====mainloop, open fd = %d", fd);
                if ( fd >= 0 && !memcmp( s_device_path, "/dev/tcc-uart1", 14 ) ) { //O_RDWR | O_NOCTTY | O_NDELAY
                    /* disable echo on serial ports */
                    struct termios  ios;
                    tcgetattr( fd, &ios );
                    ios.c_lflag = 0;  /* disable ECHO, ICANON, etc... */
                    ios.c_cflag = CRTSCTS| CS8|CREAD|CLOCAL;

                    cfsetispeed(&ios, B115200);
                    cfsetospeed(&ios, B115200);
                    tcsetattr( fd, TCSANOW, &ios );
                }
            }

            if (fd < 0) {
                perror ("opening AT interface. retrying...");
                sleep(1);
                /* never returns */
            }
        }

        s_closed = 0;
        RLOGD("====mainloop, s_rilID =%d",s_rilID);
		
		/*added by wyy begin 2020.04.27*/
		/*int skfd;
		struct sockaddr_in_saddr;
		skfd=socket(AF_INET,SOCK_STREAM,0);
		if(-1==skfd){
			perror("create socket error!");
			return 0;
		}
		saddr.sin_family=AF_INET;
		saddr.sin_port=htons(8888);
		saddr.sin_addr.s_addr=htonl(INADDR_ANY);
		int ret=connect(skfd,(struct sockaddr*)&saddr,sizeof(saddr));
		if(-1==ret){
			perror("socket connect error!");
			return 0;
		}
		
			memset((char *) &si_other, 0, sizeof(si_other));
			si_other.sin_family = AF_INET;
			si_other.sin_port = htons(PORT);
			si_other.sin_addr.s_addr = INADDR_ANY;
		*/
		/*added by wyy end 2020.04.27*/
		
		//	  ret = at_open_ex(fd, onUnsolicited, s_rilID);
		   
			char str_target_ip[PROP_VALUE_MAX] = "";
			char str_target_port[PROP_VALUE_MAX] = "";
			int target_port = 5566;
		
			property_get("persist.sys.net.serverip",str_target_ip,"0.0.0.0");
			property_get("persist.sys.net.serverport",str_target_port,"3000");
		
			target_port = atoi(str_target_port);
		
			RLOGD("====mainloop,at_open_ex serverport = %d serverip = %s",target_port, str_target_ip);
			
			ret = at_open_ex(fd, onUnsolicited, s_rilID, target_port , str_target_ip);

		
//        property_get("sys.xt.modem.type", modem_type, "0"); // 0 LTE mode, 1 Satellite mode;
//        property_get("persist.sys.xt.s_sim_slot_id", s_sim_slot_id, "1");

        RLOGD("====mainloop, modem_type =%s, s_sim_slot_id =%s",modem_type, s_sim_slot_id);
		/*
        if(0 == strcmp(modem_type, "0")) {
            if(atoi(s_sim_slot_id) == 0) {
                sim_id = 0;
            } else {
                sim_id = 0;
            }
        } else {
            sim_id = atoi(s_sim_slot_id);
        }
        RLOGD("====mainloop, sim_id =%d", sim_id);
		sim_id = 0;
		*/


		
    //    ret = at_open_ex(fd, onUnsolicited, sim_id);
        if (ret < 0) {
            RLOGE ("AT error %d on at_open\n", ret);
            return 0;
        }
        RIL_requestTimedCallback(initializeCallback, NULL, &TIMEVAL_0);
        // Give initializeCallback a chance to dispatched, since
        // we don't presently have a cancellation mechanism
        sleep(1);

        waitForClose();
        RLOGI("Re-opening after close");
    }
}

void RIL_handle_exception(void)
{
    is_pb_ready = 0;
    RLOGD("RIL_handle_exception");
}

#ifdef RIL_SHLIB

pthread_t s_tid_mainloop;

const RIL_RadioFunctions *RIL_Init(const struct RIL_Env *env, int argc, char **argv)
{
    int opt;
    pthread_attr_t attr;

    s_rilenv = env;
    s_rilID = atoi(argv[0]);
    RLOGI("==!!!==>s_rilID = %d\n", s_rilID);

    while ( -1 != (opt = getopt(argc, argv, "p:d:s:c:"))) {
        switch (opt) {
            case 'p':
                s_port = atoi(optarg);
                if (s_port == 0) {
                    usage(argv[0]);
                    return NULL;
                }
                RLOGI("Opening loopback port %d\n", s_port);
            break;

            case 'd':
                s_device_path = optarg;
                RLOGI("Opening tty device %s\n", s_device_path);
            break;

            case 's':
                s_device_path   = optarg;
                s_device_socket = 1;
                RLOGI("Opening socket %s\n", s_device_path);
            break;

            case 'c':
                RLOGI("Client id received %s\n", optarg);
            break;

            default:
                RLOGI("error param %c %s\n", opt, optarg);
                usage(argv[0]);
                return NULL;
        }
    }

    if (s_port < 0 && s_device_path == NULL) {
        RLOGI("s_port && s_device_path not set\n");
        usage(argv[0]);
        return NULL;
    }

    /*initialize g_signalmap_array befor communication with modem*/    
    build_signal_map();        //Fix Enh00000888 by zhushasha 20110705

    pthread_attr_init (&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&s_tid_mainloop, &attr, mainLoop, NULL);

    RLOGI("RIL_Init return 0x%p\n", &s_callbacks);
    return &s_callbacks;
}
#else /* RIL_SHLIB */
int main (int argc, char **argv)
{
    int opt;

    while ( -1 != (opt = getopt(argc, argv, "p:d:"))) {
        switch (opt) {
            case 'p':
                s_port = atoi(optarg);
                if (s_port == 0) {
                    usage(argv[0]);
                }
                RLOGI("Opening loopback port %d\n", s_port);
            break;

            case 'd':
                s_device_path = optarg;
                RLOGI("Opening tty device %s\n", s_device_path);
            break;

            case 's':
                s_device_path   = optarg;
                s_device_socket = 1;
                RLOGI("Opening socket %s\n", s_device_path);
            break;

            default:
                usage(argv[0]);
        }
    }

    if (s_port < 0 && s_device_path == NULL) {
        usage(argv[0]);
    }

    RIL_register(&s_callbacks);

    mainLoop(NULL);

    return 0;
}

#endif /* RIL_SHLIB */

static void requestQueryEventReport(void *param)
{
    int err;
    ATResponse *p_response = NULL;
    char *line, *p;
    int commas=0;
    int skip;
    int indicator = -1;

    err = at_send_command_singleline("AT+CMER?", "+CMER:", &p_response);

    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }

    switch (commas) {
        case 4:
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
               err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &indicator);
            if (err < 0) goto error;
         break;
        default:
            goto error;
    }

    RLOGD("getEventReportingEnable: indicator = %d", indicator);

    at_response_free(p_response);

    if(indicator==2)
    {
        /* enable unsolicited result code: +CIEV: */
        at_send_command("AT+CMER=2,0,0,2,0", NULL);
    }
	if(indicator==0)
	{
		/* enable unsolicited result code: +CIEV: */
		at_send_command("AT+CMER=2,0,0,2,0", NULL);
	}
	
    return;
error:
    at_response_free(p_response);
    RLOGD("getEventReportingEnable: error, return -1, commas = %d", commas);
    return ;

}

#ifdef HAVE_PTHREAD_COND_TIMEDWAIT_RELATIVE
#define USE_NP 1
#endif /* HAVE_PTHREAD_COND_TIMEDWAIT_RELATIVE */

#define INTER_RIL_SERV_SOCK_PATH "/data/misc/inter_ril/"
#define INTER_RIL_SERV_SOCK_NAME INTER_RIL_SERV_SOCK_PATH"inter.ril.serv.sock"

#define MAX_RILD_SERVER_REQ_CREG_NUM  10
#define CLIENT_IP_ADDR "127.0.0.1"
typedef struct _SMS_EXTENSION_CHAR_ST_
{
    unsigned char   gsm_code;
    char    ascii_char;
} SMS_EXTENSION_CHAR_ST;

typedef struct _RildServerType
{
	int th_rild_server_running;
	int s_recv_creg_rild_server;
	int is_recv_req_radio_power;
	int listenfd;
	int rild_server_req_creg_num;
	int th_rild_server_req_creg_running;
	timer_t rild_server_creg_timer_id;
	pthread_mutex_t s_rild_server_creg_mutex;
	pthread_cond_t s_rild_server_creg_cond;
	pthread_t s_tid_server;
	pthread_t s_tid_server_req_creg;
}RildServerType;

struct CRildServerConnType
{
	int th_rild_server_conn_running;
	int server_connfd;
	LIST_ENTRY(CRildServerConnType) entry;
};

struct CRildClientConnType
{
	int client_sockfd;
	LIST_ENTRY(CRildClientConnType) entry;
};

LIST_HEAD(RildServerConnList, CRildServerConnType) rild_server_conn_list_;
LIST_HEAD(RildClientConnList, CRildClientConnType) rild_client_conn_list_1;/*one list for one rild client*/

static pthread_mutex_t s_rild_server_conn_list_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t s_rild_client_conn_list_1_mutex = PTHREAD_MUTEX_INITIALIZER;

static RildServerType rild_server = {
	  0,/*th_rild_server_running*/
	  0,/*s_recv_creg_rild_server*/
	  0,/*is_recv_req_radio_power*/
	  0,/*listenfd*/
	  0,/*rild_server_req_creg_num*/
	  0,/*th_rild_server_req_creg_running*/
	  0,/*rild_server_creg_timer_id*/
	  PTHREAD_MUTEX_INITIALIZER,/*s_rild_server_creg_mutex*/
	  PTHREAD_COND_INITIALIZER,/*s_rild_server_creg_cond*/
	  0,/*s_tid_server*/
	  0/*s_tid_server_req_creg*/
};

static int create_rild_server_req_creg(void);

static int set_rild0_creg_stat(BOOL stat, Rild0StatEnum rild0_stat)
{
	static BOOL g_creg_stat = FALSE;

	switch (rild0_stat)
	{
		case RILD0_RESTART:
			g_creg_stat = FALSE;
			property_set(RILD_SERVER_CREG_READY, "0");
		break;
		case RILD0_OFF:
			g_creg_stat = FALSE;
			property_set(RILD_SERVER_CREG_READY, "1");
		break;
		case RILD0_ON_SEARCHING:

			if (TRUE == g_creg_stat)
			{
				return 0;
			}
			else
			{
				if (TRUE == stat)
				{
					g_creg_stat = TRUE;

					property_set(RILD_SERVER_CREG_READY, "2");
				}
				else
				{
					g_creg_stat = FALSE;

					property_set(RILD_SERVER_CREG_READY, "0");
				}
			}

		break;
		default:
			RLOGD("set_rild0_creg_stat:bad status");
		break;

	}

	return 0;
}

static int get_rild0_creg_stat(void)
{
	int max_wait_time = 60 * 1000;//wait at most 60s
	int interval = 200;//interval duration 200ms
	int max_loop = max_wait_time / interval;
	int i = 0;
	char rild_server_creg_value[2] = {'\0'};

	for (i = 0; i < max_loop; i++)
	{
		if(property_get(RILD_SERVER_CREG_READY, rild_server_creg_value, "0"))
		{
			if (0 == strcmp(rild_server_creg_value, "1"))
			{
				return 0;
			}
			else if (0 == strcmp(rild_server_creg_value, "2"))
			{
				return 0;
			}
		}

		usleep(interval * 1000);
	}

	return 0;
}

static void rild_server_requestCreg(void)
{
    int err;
    int response[4];
    char *responseStr[4];
    //FIXME:we asume that every token of creg/cgreg reseponse is less than 31 bytes.
    static char lastResponseRecords[4][32] = {{'\0'}, {'\0'}, {'\0'}, {'\0'}};
    ATResponse *p_response = NULL;
    const char *cmd = "AT+CREG?";
    const char *prefix = "+CREG";
    char *line, *p;
    int commas;
    int skip;
    int i = 0;

    RLOGD("rild_server_requestCreg enter");
	
    err = at_send_command_singleline_timeout(cmd, prefix, 15000,  &p_response);// modify [by chenshu 2012-10-23] for Enh00000326

    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;
    /* Ok you have to be careful here
     * The solicited version of the CREG response is
     * +CREG: n, stat, [lac, cid]
     * and the unsolicited version is
     * +CREG: stat, [lac, cid]
     * The <n> parameter is basically "is unsolicited creg on?"
     * which it should always be
     *
     * Now we should normally get the solicited version here,
     * but the unsolicited version could have snuck in
     * so we have to handle both
     *
     * Also since the LAC and CID are only reported when registered,
     * we can have 1, 2, 3, or 4 arguments here
     *
     * finally, a +CGREG: answer may have a fifth value that corresponds
     * to the network type, as in;
     *
     *   +CGREG: n, stat [,lac, cid [,networkType]]
     */

    /* count number of commas */
    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }

    switch (commas) {
        case 1: /* +CREG: <n>, <stat> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            response[1] = -1;
            response[2] = -1;
            if (err < 0) goto error;
            break;

            break;
        case 3: /* +CREG: <n>, <stat>, <lac>, <cid> */
        case 4: /* +CREG: <n>, <stat>, <lac>, <cid>, <ACT> */
            //we intend to ignore <ACT> in CREG request for that we
            //only concern voice state in framework.
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[1]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[2]);
            if (err < 0) goto error;
            break;
        default:
            goto error;
    }

#if (OPT_SIM_COUNT > 1)
	if (0 == s_rilID)
	{
		if (2 != response[0])
		{
			//RLOGD("allow client to poweron[%s,%d]", p_response->p_intermediates->line, response[0]);
			recv_creg_rild_server();
		}
	}
#endif
  
    asprintf(&responseStr[0], "%d", response[0]);
    asprintf(&responseStr[1], "%x", response[1]);
    asprintf(&responseStr[2], "%x", response[2]);

    at_response_free(p_response);

    for (i = 0; i < 3; i ++) {
        memset(lastResponseRecords[i], 0, 32);
        memcpy(lastResponseRecords[i], responseStr[i], strlen(responseStr[i]) + 1);
        free(responseStr[i]);
        responseStr[i] = NULL;
    }
    return;
	
error:
    at_response_free(p_response);
}
/*L1813 Bug00000347, wangsheng, 2013-06-21, end*/

static int get_rild_server_isrunning();
static int recv_req_radio_power();
static int produce_cmd(char *cmd_buf, int cmd_buf_size, const char *str_rild, const char *str_cmd);

static int add_rild_server_conn(struct CRildServerConnType *pRildServerConn)
{
	pthread_mutex_lock(&s_rild_server_conn_list_mutex);
	LIST_INSERT_HEAD(&rild_server_conn_list_, pRildServerConn, entry);
	pthread_mutex_unlock(&s_rild_server_conn_list_mutex);

	return 0;
}

static int add_rild_client1_conn(struct CRildClientConnType *pRildClientConn)
{
	pthread_mutex_lock(&s_rild_client_conn_list_1_mutex);
	LIST_INSERT_HEAD(&rild_client_conn_list_1, pRildClientConn, entry);
	pthread_mutex_unlock(&s_rild_client_conn_list_1_mutex);

	return 0;
}

static void sleepMsec(long long msec)
{
    struct timespec ts;
    int err;

    ts.tv_sec = (msec / 1000);
    ts.tv_nsec = (msec % 1000) * 1000 * 1000;

    do {
        err = nanosleep (&ts, &ts);
    } while (err < 0 && errno == EINTR);
}

#ifndef USE_NP
static void setTimespecRelative(struct timespec *p_ts, long long msec)
{
    struct timeval tv;

    gettimeofday(&tv, (struct timezone *) NULL);

    /* what's really funny about this is that I know
       pthread_cond_timedwait just turns around and makes this
       a relative time again */
    p_ts->tv_sec = tv.tv_sec + (msec / 1000);
    p_ts->tv_nsec = (tv.tv_usec + (msec % 1000) * 1000L ) * 1000L;
}
#endif /*USE_NP*/

static int recv_creg_rild_server(void)
{
	if (0 == rild_server.s_recv_creg_rild_server)
	{
		pthread_mutex_lock(&(rild_server.s_rild_server_creg_mutex));
		pthread_cond_signal(&(rild_server.s_rild_server_creg_cond));
		pthread_mutex_unlock(&(rild_server.s_rild_server_creg_mutex));
		
		RLOGD("%s(), line%d, allow client power on", __func__, __LINE__);

		if (0 != rild_server.rild_server_creg_timer_id)
		{
			RLOGD("recv_creg_rild_server, del timer");
			
			ril_timer_delete(rild_server.rild_server_creg_timer_id);
			rild_server.rild_server_creg_timer_id = 0;
		}

		rild_server.s_recv_creg_rild_server = 1;
		property_set(RILD_SERVER_CREG_READY, "1");
		rild_server.th_rild_server_req_creg_running = 0;
	}	
       return 0;
}

static int get_rild_server_isrunning()
{
	return rild_server.th_rild_server_running;
}

static int recv_req_radio_power()
{
	return rild_server.is_recv_req_radio_power;
}

static int produce_cmd(char *cmd_buf, int cmd_buf_size, const char *str_rild, const char *str_cmd)
{
	if (NULL == cmd_buf)
		return -1;

	snprintf(cmd_buf, cmd_buf_size, "%s%s", str_rild, str_cmd);

	return 0;
}

static void *th_rild_server_conn(void *param)
{
	struct CRildServerConnType *pRildServerConn = (struct CRildServerConnType *)param;
	char buff[MAX_BUF_SIZE], cmd[MAX_BUF_SIZE], str_rild[MAX_STR_SIZE];;
	char *str_rild_ret = NULL;
	ssize_t read_num = 0;
	struct timeval  tv;
	fd_set          read_fds;
	int ret_val = -1;
	long long timeoutMsec = RILD_SERVER_TIME_OUT * 1000;
       int err = 0;
	int len = 0;
#ifndef USE_NP
       struct timespec ts;
#endif /*USE_NP*/

	if (!pRildServerConn)
	{
		RLOGD("th_rild_server: input param is NULL");
		
		return NULL;
	}

#ifndef USE_NP
	if (timeoutMsec != 0) {
		setTimespecRelative(&ts, timeoutMsec);
	}
#endif /*USE_NP*/
	RLOGD("th_rild_server:enter th_rild_server_conn");

	FD_ZERO(&read_fds);
	FD_SET(pRildServerConn->server_connfd, &read_fds);
	tv.tv_sec = RILD_SERVER_TIME_OUT;
	tv.tv_usec = 0;

	while (pRildServerConn->th_rild_server_conn_running)
	{
		ret_val = select(pRildServerConn->server_connfd+1, &read_fds, NULL, NULL, &tv);

		if (-1 == ret_val)
		{
			RLOGD("server_conn: ret_val -1");

			pRildServerConn->th_rild_server_conn_running = 0;
		}
		else if (ret_val)
		{
			if (FD_ISSET(pRildServerConn->server_connfd, &read_fds))
			{
				if ((read_num = read(pRildServerConn->server_connfd, buff, MAX_BUF_SIZE)) > 0)
				{
					buff[read_num - 1] = '\0';
					RLOGD("server_conn:%s", buff);

					if (NULL != strstr(buff, INTER_RIL_REQ_RADIO_POWER))
					{
						rild_server.is_recv_req_radio_power = 1;
						RLOGD("server_conn: recv INTER_RIL_REQ_RADIO_POWER");

						str_rild_ret = strtok((char *)buff, ":");

						RLOGD("server_conn: [%s]", str_rild_ret);

						if (NULL != str_rild_ret)
						{
							if (0 == rild_server.s_recv_creg_rild_server)
							{
								create_rild_server_req_creg();
							}

							snprintf(str_rild, ARR_SIZE(str_rild), "%s:", str_rild_ret);
							produce_cmd(cmd, ARR_SIZE(cmd), str_rild, INTER_RIL_ACK_RADIO_POWER);

							RLOGD("server_conn: [%s]", cmd);
						}
						else
						{
							pRildServerConn->th_rild_server_conn_running = 0;

							RLOGD("server_conn: can not find rild index");

							break;
						}

						RLOGD("server_conn: wait s_rild_server_creg_cond");
						RLOGD("server_conn: s_recv_creg_rild_server[%d]", rild_server.s_recv_creg_rild_server);

						if (0 == rild_server.s_recv_creg_rild_server)
						{
							pthread_mutex_lock(&(rild_server.s_rild_server_creg_mutex));
							#ifdef USE_NP
							err = pthread_cond_timeout_np(&(rild_server.s_rild_server_creg_cond), &(rild_server.s_rild_server_creg_mutex), timeoutMsec);
							#else
		                                   err = pthread_cond_timedwait(&(rild_server.s_rild_server_creg_cond), &(rild_server.s_rild_server_creg_mutex), &ts);
							#endif
							pthread_mutex_unlock(&(rild_server.s_rild_server_creg_mutex));
						}

						RLOGD("server_conn: get s_rild_server_creg_cond");

						if (ETIMEDOUT == err)
						{
							pRildServerConn->th_rild_server_conn_running = 0;

							RLOGD("%s(), LINE%d, time out and exit th_rild_server_conn", __func__, __LINE__);

							break;
						}

						len = strlen(cmd) + 1;

						if (write(pRildServerConn->server_connfd, cmd, len) != len)
						{
						     pRildServerConn->th_rild_server_conn_running = 0;
					            RLOGD("server_conn:fail to write [%s]", cmd);

						     break;
						}
						else
						{
					            RLOGD("server_conn:write [%s]", cmd);
						}

						 continue;
					}
					else if (NULL != strstr(buff, INTER_RIL_FIN_RADIO_POWER))
					{
						RLOGD("server_conn: recv INTER_RIL_FIN_RADIO_POWER");
					}
				}
				else
				{
					RLOGD("server_conn: read_num == 0");

					pRildServerConn->th_rild_server_conn_running = 0;
				}
			}
		}
		else
		{
			RLOGD("server_conn: time out");

			pRildServerConn->th_rild_server_conn_running = 0;
		}

	}

	close(pRildServerConn->server_connfd);
	
	RLOGD("server_conn:exit th_rild_server_conn successfully");

	return NULL;
}

static void *th_rild_server(void *param)
{
	socklen_t len;

	//struct sockaddr_in serveraddr, cliadrr;
	struct sockaddr_un serveraddr, cliadrr;

    pthread_attr_t attr;
	pthread_t s_tid_server_conn;
    int ret;
	struct CRildServerConnType *pRildServerConn = NULL;
	int server_connfd = 0;

	//RLOGD("th_rild_server:enter th_rild_server");

	rild_server.th_rild_server_running = 1;

	while (rild_server.th_rild_server_running)
	{
		len = sizeof(cliadrr);
		server_connfd = accept(rild_server.listenfd, (struct sockaddr *)&cliadrr, &len);

		pRildServerConn = (struct CRildServerConnType *)malloc(sizeof(struct CRildServerConnType));

		if (!pRildServerConn)
		{
			close(server_connfd);
			
			RLOGD("th_rild_server: fail to malloc pRildServerConn");

			continue;
		}
		else
		{
			pRildServerConn->server_connfd = server_connfd;
			pRildServerConn->th_rild_server_conn_running = 1;
			add_rild_server_conn(pRildServerConn);
		}
		
		
		pthread_attr_init (&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		ret = pthread_create(&s_tid_server_conn, &attr, th_rild_server_conn, (void *)pRildServerConn);
		if (ret)
		{
			RLOGD("th_rild_server: fail to create th_rild_server_conn");

			close(server_connfd);

			pthread_mutex_lock(&s_rild_server_conn_list_mutex);

			LIST_REMOVE(pRildServerConn, entry);

			pthread_mutex_unlock(&s_rild_server_conn_list_mutex);
			if (pRildServerConn)
			{
				free(pRildServerConn);
				pRildServerConn = NULL;
			}

			break;
		}

		RLOGD("th_rild_server: create th_rild_server_conn successfully");
	}

	close(rild_server.listenfd);
	
	RLOGD("th_rild_server:exit th_rild_server successfully");

	return NULL;
}

/*L1813 Bug00000347, wangsheng, 2013-06-21, start*/
static void *th_rild_server_req_creg(void *param)
{
	while (rild_server.rild_server_req_creg_num > 0
		&& 0 == rild_server.s_recv_creg_rild_server
		&& 1 == rild_server.th_rild_server_req_creg_running)
	{
		rild_server_requestCreg();
		
		rild_server.rild_server_req_creg_num--;
		usleep(200000);
	}

	rild_server.th_rild_server_req_creg_running = 0;
	
	RLOGD("th_rild_server_req_creg exit successfully");
	
	return NULL;
}

static int create_rild_server_req_creg(void)
{
    	pthread_attr_t attr;
    	int ret = 0;

	RLOGD("create_rild_server_req_creg:enter");

	if (1 == rild_server.th_rild_server_req_creg_running)
	{
		RLOGD("create_rild_server_req_creg: th_rild_server_req_creg is running");

		return 0;
	}
	
	pthread_attr_init (&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	rild_server.th_rild_server_req_creg_running = 1;
	
	ret = pthread_create(&rild_server.s_tid_server_req_creg, &attr, th_rild_server_req_creg, NULL);

	if (ret)
	{
		RLOGD("create_rild_server_req_creg: fail to create th_rild_server_req_creg");

		return ret;
	}

	RLOGD("create_rild_server_req_creg: create th_rild_server_req_creg successfully");

	return 0;
}

static void onRildServerNetworkStateChanged(union sigval sv)
{
	RLOGD("onRildServerNetworkStateChanged");

	rild_server.s_recv_creg_rild_server = 1;

	property_set(RILD_SERVER_CREG_READY, "1");

	pthread_mutex_lock(&(rild_server.s_rild_server_creg_mutex));
	pthread_cond_signal(&(rild_server.s_rild_server_creg_cond));
	pthread_mutex_unlock(&(rild_server.s_rild_server_creg_mutex));
	
	ril_timer_delete(rild_server.rild_server_creg_timer_id);
	rild_server.rild_server_creg_timer_id = 0;
}

int init_rild_client(int rild_index)
{
	if (1 == rild_index)
	{
		LIST_INIT(&rild_client_conn_list_1);
	}

	return 0;
}

int init_rild_server(void)
{
	socklen_t len;
	//struct sockaddr_in serveraddr, cliadrr;
	struct sockaddr_un serveraddr, cliadrr;
	pthread_attr_t attr;
	int ret;
	ret = system("mkdir -p " INTER_RIL_SERV_SOCK_PATH);

	if (-1 == ret)
	{
		RLOGD("init_rild_server:fail to create INTER_RIL_SERV_SOCK_PATH");

		goto ERR0;
	}

	if (0 == access(INTER_RIL_SERV_SOCK_NAME, F_OK))
	{
		ret = system("rm " INTER_RIL_SERV_SOCK_NAME);

		if (-1 == ret)
		{
			RLOGD("init_rild_server:fail to rm INTER_RIL_SERV_SOCK_NAME");

			goto ERR0;
		}
	}

	rild_server.th_rild_server_running = 0;
	rild_server.s_recv_creg_rild_server = 0;
	property_set(RILD_SERVER_CREG_READY, "0");
	rild_server.is_recv_req_radio_power = 0;
	
	rild_server.rild_server_req_creg_num = MAX_RILD_SERVER_REQ_CREG_NUM;
	rild_server.th_rild_server_req_creg_running = 0;
	rild_server.rild_server_creg_timer_id = 0;

	if (0 == ril_timer_create(&rild_server.rild_server_creg_timer_id, onRildServerNetworkStateChanged, NULL))
	{
		RLOGD("init_rild_server:timer create OK!");
		
		ril_timer_start(rild_server.rild_server_creg_timer_id, RILD_SERVER_TIME_OUT * 1000);
	}
	else
	{
		RLOGD("init_rild_server:timer create failed!");
		
		return -1;
	}
				
	LIST_INIT(&rild_server_conn_list_);

	rild_server.listenfd = socket(PF_UNIX, SOCK_STREAM, 0);

	if (rild_server.listenfd < 0)
	{
		RLOGD("init_rild_server: fail to create socket");

		ret = -1;

		goto ERR1;
	}

	bzero(&serveraddr, sizeof(serveraddr));
	serveraddr.sun_family = AF_UNIX;
	strncpy(serveraddr.sun_path, INTER_RIL_SERV_SOCK_NAME, sizeof(serveraddr.sun_path));

	if (bind(rild_server.listenfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) < 0)
	{
		RLOGD("init_rild_server: fail to bind");

		ret = -2;

		goto ERR2;
	}

	if (listen(rild_server.listenfd, LISTENQ) < 0)
	{
		RLOGD("init_rild_server: fail to listen");

		ret = -3;

		goto ERR3;
	}

	pthread_attr_init (&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	ret = pthread_create(&(rild_server.s_tid_server), &attr, th_rild_server, NULL);

	if (ret)
	{
		RLOGD("init_rild_server: fail to create th_rild_server");

		//return ret;
		ret = -4;

		goto ERR4;
	}

	RLOGD("init_rild_server: exit successfully");

	ret = 0;

	return ret;

ERR4:
ERR3:
ERR2:
	close(rild_server.listenfd);
ERR1:
ERR0:
	return ret;
}

static int deinit_rild_server(void)
{
	struct CRildServerConnType *p_rild_server_conn = NULL;
	int num = 0;

	RLOGD("deinit_rild_server: enter");

	pthread_mutex_lock(&(rild_server.s_rild_server_creg_mutex));
	pthread_cond_signal(&(rild_server.s_rild_server_creg_cond));
	pthread_mutex_unlock(&(rild_server.s_rild_server_creg_mutex));

	rild_server.th_rild_server_running = 0;
	close(rild_server.listenfd);
	
	rild_server.s_recv_creg_rild_server = 0;
	property_set(RILD_SERVER_CREG_READY, "0");
	rild_server.is_recv_req_radio_power = 0;

	rild_server.th_rild_server_req_creg_running = 0;

	if (0 != rild_server.rild_server_creg_timer_id)
	{
		ril_timer_delete(rild_server.rild_server_creg_timer_id);
		rild_server.rild_server_creg_timer_id = 0;
	}

	pthread_mutex_lock(&s_rild_server_conn_list_mutex);

	num = 0;
	
	while (!LIST_EMPTY(&rild_server_conn_list_))
	{
		p_rild_server_conn = LIST_FIRST(&rild_server_conn_list_);

		LIST_REMOVE(p_rild_server_conn, entry);

		if (p_rild_server_conn)
		{
			close(p_rild_server_conn->server_connfd);
			p_rild_server_conn->th_rild_server_conn_running = 0;
			free(p_rild_server_conn);
			p_rild_server_conn = NULL;
		}

		num++;
	}

	pthread_mutex_unlock(&s_rild_server_conn_list_mutex);

	RLOGD("deinit_rild_server: exit,num[%d]", num);
	
	return 0;
}

static int deinit_rild_client(int rild_index)
{
	struct CRildClientConnType *p_rild_client_conn = NULL;
	int num = 0;

	RLOGD("deinit_rild_client: enter");
	
	if (1 == rild_index)
	{
		pthread_mutex_lock(&s_rild_client_conn_list_1_mutex);

		num = 0;
		
		while (!LIST_EMPTY(&rild_client_conn_list_1))
		{
			p_rild_client_conn = LIST_FIRST(&rild_client_conn_list_1);

			LIST_REMOVE(p_rild_client_conn, entry);

			if (p_rild_client_conn)
			{
				close(p_rild_client_conn->client_sockfd);

				free(p_rild_client_conn);
				p_rild_client_conn = NULL;
			}

			num++;
		}

		pthread_mutex_unlock(&s_rild_client_conn_list_1_mutex);

	}
	/*add more rild client here*/

	RLOGD("deinit_rild_client: exit,num[%d]", num);
	
	return 0;
}

static int handle_client_radio_power(int sockfd, int rild_index)
{
	char buff[MAX_BUF_SIZE], cmd[MAX_BUF_SIZE], str_rild[MAX_STR_SIZE];
	fd_set          read_fds;
	struct timeval  tv;
	int ret_val = -1;
	int ret = 0;
	int len = 0;

	snprintf(str_rild, ARR_SIZE(str_rild), "%s%d:", STR_RILD, rild_index);
	/*INTER_RIL_REQ_RADIO_POWER*/
	produce_cmd(cmd, ARR_SIZE(cmd),str_rild, INTER_RIL_REQ_RADIO_POWER);

	RLOGD("handle_client_radio_power:[%s]", cmd);

	len = strlen(cmd) + 1;

	if (write(sockfd, cmd, len) != len)
	{
		RLOGD("handle_client_radio_power:fail to write INTER_RIL_REQ_RADIO_POWER");

		ret = -1;

		goto ERR0;
	}
	else
	{
		RLOGD("handle_client_radio_power:write INTER_RIL_REQ_RADIO_POWER");
	}

        FD_ZERO(&read_fds);
        FD_SET(sockfd, &read_fds);
 	 tv.tv_sec = RILD_CLIENT_TIME_OUT;
 	 tv.tv_usec = 0;

        ret_val = select(sockfd+1, &read_fds, NULL, NULL, &tv);

	 if (-1 == ret_val)
	 {
		RLOGD("handle_client_radio_power: ret_val -1");

		ret = ret_val;
	 }
	 else if (ret_val)
	 {
		 if (FD_ISSET(sockfd, &read_fds))
		 {
		        ssize_t read_num = 0;
		        if ((read_num = read(sockfd, buff, MAX_BUF_SIZE)) > 0)
		        {
				buff[read_num - 1] = '\0';
				RLOGD("handle_client_radio_power:%s", buff);

				if (NULL != strstr(buff, INTER_RIL_ACK_RADIO_POWER))
				{
					RLOGD("handle_client_radio_power: recv INTER_RIL_ACK_RADIO_POWER");

					if (strStartsWith(cmd, str_rild))
					{
						RLOGD("handle_client_radio_power: recv [%sINTER_RIL_ACK_RADIO_POWER]", str_rild);
					}

					produce_cmd(cmd, ARR_SIZE(cmd),str_rild, INTER_RIL_FIN_RADIO_POWER);

					RLOGD("handle_client_radio_power:[%s]", cmd);

					len = strlen(cmd) + 1;

					if (write(sockfd, cmd, len) != len)
					{
						RLOGD("handle_client_radio_power:fail to write [%s]", cmd);

						ret = -1;
					}
					else
					{
						RLOGD("handle_client_radio_power:write [%s]", cmd);

						ret = 0;
					}

				}
		        }
		 }
	 }
	 else
	 {
		RLOGD("handle_client_radio_power: time out");

		ret = -1;
	 }

	close(sockfd);

	RLOGD("exit handle_client_radio_power");

	return ret;

ERR1:
ERR0:
	close(sockfd);	
	return ret;
}

int add_rild_client_conn(int rild_index, INTER_RIL_TYPE type)
{
	//struct sockaddr_in servaddr;
	struct sockaddr_un servaddr;
	
	int ret = 0;
	int loop = 20;
	int client_sockfd;
	struct CRildClientConnType *pRildClientConn = NULL;

	char rild_server_creg_value[2] = {'\0'};

	if(property_get(RILD_SERVER_CREG_READY, rild_server_creg_value, "0"))
	{
		RLOGD("add_rild_client_conn:rild_server_creg_value == %s", rild_server_creg_value);

		if (0 == strcmp(rild_server_creg_value, "1"))
		{
			RLOGD("add_rild_client_conn:rild server has registered network");

			return 0;
		}
	}

	RLOGD("add_rild_client_conn:[%d] enter", rild_server.s_recv_creg_rild_server);

    client_sockfd = socket(PF_UNIX, SOCK_STREAM, 0);

	if (client_sockfd < 0)
	{
		ret = -1;

		goto ERR0;
	}

	bzero(&servaddr, sizeof(servaddr));

	servaddr.sun_family = AF_UNIX;
	strncpy(servaddr.sun_path, INTER_RIL_SERV_SOCK_NAME, sizeof(servaddr.sun_path));

	while (loop > 0)
	{
		ret = connect(client_sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr));

		if (0 == ret)
		{
			RLOGD("add_rild_client_conn: connect server successfully");
			
			break;
		}
		
		loop--;
		sleepMsec(100);
	}

	if (0 == loop)
	{
		RLOGD("add_rild_client_conn:fail to connect server");

		//return -1;
		ret = -2;

		goto ERR1;
	}

	if (1 == rild_index)
	{
		pRildClientConn = (struct CRildClientConnType *)malloc(sizeof(struct CRildClientConnType));

		if (!pRildClientConn)
		{
			//close(client_sockfd);

			RLOGD("add_rild_client_conn:fail to malloc pRildClientConn");

			//return -1;
			ret = -3;

			goto ERR2;
		}
		else
		{
			pRildClientConn->client_sockfd = client_sockfd;

			if (1 == rild_index)
			{
				add_rild_client1_conn(pRildClientConn);
			}
		}
	}
	/*add more rild client here*/
	else
	{
		close(client_sockfd);

		RLOGD("add_rild_client_conn:unsupport rild_index");

		return -1;
	}

	if (INTER_RIL_RADIO_POWER == type)
	{
		handle_client_radio_power(client_sockfd, rild_index);
	}

	return 0;

ERR2:
ERR1:
	close(client_sockfd);
ERR0:
	return ret;
}

#define GUC  0x10
static const unsigned char sc_sms_latin1_gsm_table_a[256] =
{
    /*    0      1     2     3     4     5     6     7 */
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,         /* 0x07 */
    GUC,  GUC,  0x0a, GUC,  GUC,  0x0d, GUC,  GUC,      /* 0x0f */
    GUC,  GUC,  GUC,  GUC,  0x14, GUC,  GUC,  GUC,  /* 0x17*/
    GUC,  GUC,  GUC,  0x1B, GUC,  GUC,  GUC,  GUC,  /* 0x1f*/
    0x20, 0x21, 0x22, 0x23, 0x02, 0x25, 0x26, 0x27, /* 0x27*/
    0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, /* 0x2f*/
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, /* 0x37*/
    0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f, /* 0x3f*/
    0x00, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, /* 0x47*/
    0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f, /* 0x4f*/
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, /* 0x57*/
    0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x11, /* 0x5f*/
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, /* 0x67*/
    0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f, /* 0x6f*/
    0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, /* 0x77*/
    0x78, 0x79, 0x7a, GUC,  GUC,  GUC,  GUC,  GUC,  /* 0x7f*/
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  /* 0x87*/
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  /* 0x8f */
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  /* 0x9f */
    GUC,  0x40, GUC,  0x01, 0x24, 0x03, GUC,  0x5f,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  /* 0xAf */
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,
    GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  GUC,  0x60, /* 0xBf */
    0x41, 0x41, 0x41, 0x41, 0x5b, 0x0e, 0x1c, 0x09,
    0x45, 0x1f, 0x45, 0x45, 0x49, 0x49, 0x49, 0x49, /* 0xcf */
    GUC,  0x5d, 0x4f, 0x4f, 0x4f, 0x4f, 0x5c, GUC,
    0x0b, 0x55, 0x55, 0x55, 0x5e, 0x59, GUC,  0x1e, /* 0xdf */
    0x7f, 0x61, 0x61, 0x61, 0x7b, 0x0f, 0x1d, 0x09,
    0x04, 0x05, 0x65, 0x65, 0x07, 0x69, 0x69, 0x69, /* 0xef */
    GUC,  0x7d, 0x08, 0x6f, 0x6f, 0x6f, 0x7c, GUC,
    0x0c, 0x06, 0x75, 0x75, 0x7e, 0x79, GUC,  0x79  /* 0xff */
};


static const unsigned char sc_sms_static_gsm_latin_table_a[128] =
{
    0x40, 0xa3, 0x24, 0xa5, 0xe8, 0xe9, 0xf9, 0xec,
    0xf2, 0xc7, 0x0a, 0xd8, 0xf8, 0x0d, 0xc5, 0xe5,
    0x20, 0x5f, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
    0x20, 0x20, 0x20, 0x20, 0xc6, 0xe6, 0xdf, 0xc9,
    0x20, 0x21, 0x22, 0x23, 0xa4, 0x25, 0x26, 0x27,
    0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
    0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
    0xa1, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
    0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,
    0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
    0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0xa7,
    0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
    0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
    0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77,
    0x78, 0x79, 0x7a, 0xe4, 0xf6, 0xf1, 0xfc, 0xe0
};

static const SMS_EXTENSION_CHAR_ST sc_sms_ex_gsm_latin1_table_a[] =
{
    { 0x0A, 0x0C }, /* PB */
    { 0x14, 0x5E }, /* ^ */
    { 0x28, 0x7B }, /* { */
    { 0x29, 0x7D }, /* } */
    { 0x2F, 0x5C }, /* \ */
    { 0x3C, 0x5B }, /* [ */
    { 0x3D, 0x7E }, /* ~ */
    { 0x3E, 0x5D }, /* ] */
    { 0x40, 0x7C }, /* | */
    { 0x65, 0xA4 }, /* Euro */
};

unsigned char  tp_gen_util_ex_gsm_to_ascii( unsigned char gsm_code )
{
    unsigned char   ascii_char = 0x20;
    unsigned int  i = 0;
    unsigned int  ex_tbl_size = sizeof(sc_sms_ex_gsm_latin1_table_a)/sizeof(SMS_EXTENSION_CHAR_ST);

    for( i=0; i<ex_tbl_size; i++ )
    {
        if ( sc_sms_ex_gsm_latin1_table_a[i].gsm_code == gsm_code )
        {
            ascii_char = sc_sms_ex_gsm_latin1_table_a[i].ascii_char;
            break;
        }
    }

    return ascii_char;
}

unsigned char g_gen_get_ascii_by_7bit_code(  unsigned char gsm7bit )
{
    RLOGD("====>g_gen_get_ascii_by_7bit_code,gsm7bit:%d", gsm7bit);
    return sc_sms_static_gsm_latin_table_a[gsm7bit];
}

unsigned char g_gen_ascii_to_ex_gsm( unsigned char ascii_char )
{
    unsigned char   gsm_code = 0xff;
    unsigned int   i = 0;
    unsigned int   ex_tbl_size = sizeof(sc_sms_ex_gsm_latin1_table_a)/sizeof(SMS_EXTENSION_CHAR_ST);

    /*Looking at extended GSM7bit code for the input ASCII char,if success,return seconde char of extended GSM7bit code
    of the ASCII char, else if failed,return 0xff*/
    for( i=0; i<ex_tbl_size; i++ )
    {
        if ( sc_sms_ex_gsm_latin1_table_a[i].ascii_char == ascii_char )
        {
            gsm_code = sc_sms_ex_gsm_latin1_table_a[i].gsm_code;

            break;
        }
    }

    return gsm_code;
}

unsigned char tp_gen_util_get_7bit_code( unsigned int ascii_code )
{
    return sc_sms_latin1_gsm_table_a[ascii_code];
}


/*****************************************************************************
* Function: g_gen_gsm7bit2ascii_data
*-----------------------------------------------------------------------------
* Purpose:
* --------
* GSM7bit data transfer to ASCII data
*
* Used variables:
* ---------------
* None
*
* Used functions:
* ----------------
* sc_util_ex_gsm_to_ascii
* g_gen_get_ascii_by_7bit_code
*
* Params:
* ------------------------------------------------------------
*   Name              Type                In/Out      Description
* --------            ----                ------      -----------
* str_ascii_ptr       UINT8 *              Out        ASCII code string
* max_ascii_len       UINT32               IN         max length of ASCII code string
* str_gsm7bit_ptr     CONST UINT8 *        IN         GSM7bit code string
* max_gsm7bit_len     UINT32               IN         max length of GSM7bit code string
*******************************************************************************/
SINT32 g_gen_gsm7bit2ascii_data( unsigned char *str_ascii_ptr,
                                        UINT32 max_ascii_len,
                                        CONST unsigned char *str_gsm7bit_ptr,
                                        UINT32 max_gsm7bit_len )
{
    UINT32 i = 0;
    UINT32 j = 0;

    /*check parameter*/
    if ((!str_gsm7bit_ptr) || (!str_ascii_ptr))
    {
        RLOGD("====> Fail to  g_gen_gsm7bit2ascii_data-input parameter is null!\n");
        return -1;
    }

    RLOGD("====> str_gsm7bit_ptr:%s,max_gsm7bit_len:%lu", str_gsm7bit_ptr,max_gsm7bit_len);

    /*GSM7bit data transfer to ASCII data
      if first char of GSM7bit char is 0x1B, it means this is an extended GSM7bit char,
      and transfer to ASCII char by looking at extended GSM7bit code table*/
    for (i = 0; i<max_gsm7bit_len && j<max_ascii_len; i++,j++)
    {
        if(0xFF == *(str_gsm7bit_ptr+i))
        {
            break;
        }
        else if(0x1B == *(str_gsm7bit_ptr+i))
        {
            i++;
            *(str_ascii_ptr+j) = tp_gen_util_ex_gsm_to_ascii(*(str_gsm7bit_ptr+i));
        }
        else
        {
            *(str_ascii_ptr+j) = g_gen_get_ascii_by_7bit_code(*(str_gsm7bit_ptr+i));
        }
    }
    /*set ASCII string end to be 0x00*/
    *(str_ascii_ptr+j) = 0x00;
    /*return actual length of ASCII string*/
    return j;
}

/*****************************************************************************
* Function: g_gen_ascii2gsm7bit_data
*-----------------------------------------------------------------------------
* Purpose:
* --------
* ASCII data transfer to GSM7bit data
*
* Used variables:
* ---------------
* None
*
* Used functions:
* ----------------
* g_gen_ascii_to_ex_gsm
* g_sc_util_get_7bit_code
*******************************************************************************/
SINT32 g_gen_ascii2gsm7bit_data( unsigned int *str_gsm7bit_ptr,
                                        UINT32 max_gsm7bit_len,
                                        CONST unsigned char *str_ascii_ptr,
                                        UINT32 max_ascii_len )
{
    UINT32 i = 0;
    UINT32 j = 0;
    unsigned char gsm_code = 0;

    /*check parameter*/
    if ((!str_gsm7bit_ptr) || (!str_ascii_ptr))
    {
        RLOGD("====> Fail to  g_gen_ascii2gsm7bit_data-input parameter is null!");
        return -1;
    }

    for (i = 0; i<max_ascii_len && str_ascii_ptr[i] && j<max_gsm7bit_len; i++,j++)
    {
        /*check if this ASCII char response to an extended GSM7bit code*/
        gsm_code = g_gen_ascii_to_ex_gsm(str_ascii_ptr[i]);

        /*this is not an extended GSM7bit code*/
        if(0xff == gsm_code)
        {
            str_gsm7bit_ptr[j] = tp_gen_util_get_7bit_code(str_ascii_ptr[i]);
        }
        else
        {
            /*no space to save two gsm7bit code, return*/
            if(j >= max_gsm7bit_len-1)
            {
                str_gsm7bit_ptr[j] = 0x00;
                return j;
            }

            /*this is an extended GSM7bit code, add 0x1B to be first char of an extended GSM7bit code*/
            str_gsm7bit_ptr[j] = 0x1B;
            j++;

            str_gsm7bit_ptr[j] = gsm_code;
        }
    }

    /*return actual length of GSM7bit string*/
    return j;
}

unsigned char char_to_hex( char char_data )
{
    if ('0' <= char_data && char_data <= '9')
    {
        return (char_data - '0');
    }
    else if ('a' <= char_data && char_data <= 'f')
    {
        return (char_data - 'a' + 10);
    }
    else if ('A' <= char_data && char_data <= 'F')
    {
        return (char_data - 'A' + 10);
    }
    else
    {
        return (0x00);
    }
}

int strrpl(char* s, char a, char b) {
    int N,P,M =0; 
    N= strlen(s);  
    for (;M <= N; M++) {
        if (s[M] == a){
            s[M] = b;    
            P=P+1;   
        } 
    }
    return P;
}

void strREGstateUnsol(const char *s)
{
    int newState;
    char *newlac;
    char *line = NULL;
    char *p = NULL;
    BOOL bIsCreg = FALSE;
    p = line = strdup(s);
    at_tok_start(&p);
    at_tok_nextint(&p, &newState);
    BOOL bIsCereg = FALSE;
    BOOL bIsCgreg = FALSE;

    if (g_singleCardMultiStandby) {
        //if DPSTI has received on 3/4G standby, then do not handle CREG: 0 or CGREG: 0 etc.
        if (1 == g_lose_coverage && (!isNetRegistered(newState))) {
            RLOGD("DPSTI has received, not handle CREG: 0 or CGREG: 0 ");
            goto here;
        } else if (isNetRegistered(newState)) {
            g_lose_coverage = 0xff;
        }
    }

    if (strStartsWith(s,"+CREG:") || strStartsWith(s,"+CSREG:")) {
        bIsCreg = TRUE;

        if (at_tok_hasmore(&p)) {
            char* new_plmn = NULL;
            int new_TecloType = 0;
            at_tok_nextstr(&p, &(newlac));
            at_tok_nextstr(&p, &new_plmn);
            at_tok_nextint(&p, &new_TecloType);

            RLOGD("creg: newlac = %s, new_TecloType = %d, siVoiceTecloType = %d", newlac , new_TecloType, siVoiceTecloType);
            if (NULL == slast_lac) {  /*First onUnsolicited*/
                slast_lac = malloc(strlen(newlac) + 1);
                strcpy(slast_lac, newlac);
                siVoiceTecloType = new_TecloType;  //modeified by jiangxuqin for 20160229-87901
                RLOGD("creg: NULL == slast_lac!!!");
            } else {
                if (0 == strcmp(slast_lac, newlac) && siVoiceTecloType == new_TecloType) {  /* slast_lac  same with newlac*/
                    RLOGD("creg: slast_lac = %s, newlac = %s", slast_lac, newlac);
                    RLOGD("====Filter diff ci");
                    goto here ;
                } else {    /*Update the slast_lac*/
                    free(slast_lac);
                    slast_lac = NULL;
                    slast_lac = malloc(strlen(newlac) + 1);
                    siVoiceTecloType = new_TecloType;
                    strcpy(slast_lac, newlac);
                    RLOGD("====update slast_lac");
                }
            }
        } else {
            free(slast_lac);
            slast_lac = NULL;
            siVoiceTecloType = 0;
            RLOGD("+CREG: at_tok_hasnotmore");
			property_set("sys.ps.csstate", "1");//yao.wang added on 20220901 for CS regist state
			sleep(1);//wy add on 20220901 for CS regist state
			property_set("sys.ps.csstate", "0");//yao.wang added on 20220901 for CS regist state
        }  //modified by jiangxuqin fot 20160329-91938
    } else if (strStartsWith(s,"+CEREG:")) {
        bIsCereg = TRUE;
    } else if (strStartsWith(s,"+CGREG:")) {
        bIsCgreg = TRUE;
    }
        
    RLOGD("creg: mNetState = %d, newState = %d, g_pukLock = %d", mNetState, newState, g_pukLock);

    if (cregTimer_id == 0) {//no timer
        char property_value[2] = {0};

        property_get("persist.sys.install.service", property_value, "1"); 
        if (!g_pukLock && (bIsCreg || bIsCereg) && isNetRegistered(mNetState) && !isNetRegistered(newState) && property_value[0] != '0') {
            static char ptr[10] = "creg4";
            if (0 == ril_timer_create(&cregTimer_id, onNetworkStateChanged, (void *)ptr)) {
                RLOGE("timer create start!!");
                ril_timer_start(cregTimer_id, 35*1000);  // report after 35S
            } else {
                RLOGE("timer create failed!");
                goto here;
            }
            mNetState = newState;
        } else {
            if (bIsCreg) {// || bIsCereg) {
                mNetState = newState;
            }
            RLOGD("not timer: unsolicited");
            RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED, NULL, 0);
        }
    } else {//have a timer, current state is creg 4
        if (bIsCgreg) {//CGREG
            RLOGD("ignore cgreg when timer is running!");
            goto here;
        } else {//CREG|CEREG
            if (!isNetRegistered(newState)) {//CREG:4
                RLOGD("ignore creg:4 when timer is running!");
                goto here;
            } else {//except CREG:4
                // remove timer before being unsolicited
                ril_timer_delete(cregTimer_id);
                cregTimer_id = 0;
                mNetState = newState;
                RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED, NULL, 0);
            }
        }
    }

here:
    free(line);
}

static void updateVoiceNetworkState()
{
    RLOGE("updateVoiceNetworkState, g_actmode = %ld", g_actmode);
    if((2 != g_actmode) || (g_actmode != getACTmode()))
    {
        RLOGE("updateVoiceNetworkState, actmode has not changed!");
    }
    else
    {
        RLOGE("updateVoiceNetworkState, RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED!");
        RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED, NULL, 0);
    }
}   //add by jiangxuqin for 20160819-100672

#if defined(OPT_4G)
static void requestLTERegistrationState(int request, void *data,size_t datalen, RIL_Token t)
{
    int err;
    int response[4];
    char *responseStr[4];
    //FIXME:we asume that every token of cegreg reseponse is less than 31 bytes.
   // static char lastLTEResponseRecords[4][32] = {{'\0'}, {'\0'}, {'\0'}, {'\0'}};
    ATResponse *p_response = NULL;
    const char *cmd = "AT+CEREG?";
    const char *prefix = "+CEREG";
    char *line, *p;
    int commas;
    int skip;
    int i = 0;

    if (cregTimer_id != 0) {
        for (i = 0; i < 4; i++) {
            asprintf(&responseStr[i], "%s", lastResponseRecords[i]);
        }
        RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, 4*sizeof(char*));
        for (i = 0; i < 4; i++) {
            free(responseStr[i]);
            responseStr[i] = NULL;
        }
        RLOGD("%d, return ", request);
        return;
    }

    err = at_send_command_singleline_timeout(cmd, prefix, 15000,  &p_response);
    if (err != 0 || p_response->success == 0) goto error;

    line = p_response->p_intermediates->line;
    RLOGD("%s, return CEREG ", line);
    err = at_tok_start(&line);
    if (err < 0) goto error;

    /* count number of commas */
    commas = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == ',') commas++;
    }

    switch (commas) {
        case 1: /* +CEREG: <n>,<stat> */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            response[1] = -1;
            response[2] = -1;
            response[3] = -1;
            if (err < 0) goto error;
            break;
        case 3: /* +CEREG: <n>,<stat>[,<tac>,<ci>] */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[1]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[2]);
            response[3] = -1;
            if (err < 0) goto error;
            break;
        case 4: /* +CEREG: <n>,<stat>[,<tac>,<ci>[,<AcT>]] */
            err = at_tok_nextint(&line, &skip);
            if (err < 0) goto error;
            err = at_tok_nextint(&line, &response[0]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[1]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[2]);
            if (err < 0) goto error;
            err = at_tok_nexthexint(&line, &response[3]);
            if (err < 0) goto error;
            break;
        default:
            goto error;
    }
  
    asprintf(&responseStr[0], "%d", response[0]);
    asprintf(&responseStr[1], "%x", response[1]);
    asprintf(&responseStr[2], "%x", response[2]);
    asprintf(&responseStr[3], "%d", getNetworkType(response[3]));

    at_response_free(p_response);
    RIL_onRequestComplete(t, RIL_E_SUCCESS, responseStr, 4*sizeof(char*));

    //for (i = 0; i < 3; i ++) {
    for (i = 0; i < 4; i ++) {
        memset(lastResponseRecords[i], 0, 32);
        memcpy(lastResponseRecords[i], responseStr[i], strlen(responseStr[i]) + 1);
        free(responseStr[i]);
        responseStr[i] = NULL;
    }
    return;
error:
    RLOGE("request VoiceRegistrationState must never return an error when radio is on");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

#endif

static void unsolgetSignalStrengthResend()
{
    RLOGD("unsolgetSignalStrengthResend");

    RIL_requestTimedCallback(unsolgetSignalStrength, NULL, NULL);
}

static void unsolgetSignalStrength()
{
    ATResponse *p_response = NULL;
    int err;
    char *line;
    int temp;
    int response[14] = {99, 99,-1,-1,-1,-1,-1,99,INT_MAX,INT_MAX,INT_MAX,INT_MAX, INT_MAX, INT_MAX};  //modifed by jiangxuqin1014 for 20150729-69327

    if(0 != resendCSQTimer_id){
        ril_timer_delete(resendCSQTimer_id);
        resendCSQTimer_id = 0;
        RLOGD("unsolgetSignalStrength(), delete RESEND CSQ TIMER");
    }

	#ifdef RILTEST1
	response[0] = 50;
	response[13] = 150;
	//RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
	RIL_onUnsolicitedResponse (RIL_UNSOL_SIGNAL_STRENGTH,response, sizeof(response));
	RLOGE("unsolgetSignalStrength RILTEST return 50");
	RIL_onUnsolicitedResponse(RIL_UNSOL_RESPONSE_VOICE_NETWORK_STATE_CHANGED, NULL, 0);
	return ;
	#endif

    err = at_send_command_singleline("AT+CSQ", "+CSQ:", &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(temp));
    if (err < 0) goto error;

    err = at_tok_nextint(&line, &(response[1]));
    if (err < 0) goto error;

    if(temp >= 400)  temp -= 200;

    RLOGD("Signalstrength=(%d, %d)\n",temp,response[1]);

    if(temp>=SIGNAL_STRENGTH_GSM_START&&temp<SIGNAL_STRENGTH_TD_START){
        response[0] = temp;
        RLOGD("unsolgetSignalStrength response[0] = %d\n",response[0]);
    }
    else if(temp>=SIGNAL_STRENGTH_TD_START&&temp<SIGNAL_STRENGTH_LTE_START){
        response[13] = (SIGNAL_STRENGTH_GSM_OFFSET - temp);
        RLOGD("unsolgetSignalStrength response[13] = %d\n",response[13]);
    }
    else if(temp>=SIGNAL_STRENGTH_LTE_START&&temp<SIGNAL_STRENGTH_LTE_END){
        response[8] = (SIGNAL_STRENGTH_LTE_OFFSET - temp);
        RLOGD("unsolgetSignalStrength response[8] = %d\n",response[8]);
    }
    else{
        response[0] = temp;
        RLOGD("unsolgetSignalStrength response[0] = %d\n",response[0]);
    }

    RIL_onUnsolicitedResponse (RIL_UNSOL_SIGNAL_STRENGTH,response, sizeof(response));
    at_response_free(p_response);
    return;

error:
    at_response_free(p_response);
    if(AT_ERROR_COMMAND_PENDING == err){
        if (0 == ril_timer_create(&resendCSQTimer_id, unsolgetSignalStrengthResend, NULL)) {
            RLOGD("unsolgetSignalStrength(), create and start RESEND CSQ TIMER");
            ril_timer_start(resendCSQTimer_id, 30*1000);
        } else {
            RLOGE("unsolgetSignalStrength(), create RESEND MODEM TIMER failed!!!!!");
        }
    }
    RLOGE("requestSignalStrength must never return an error when radio is on");
}

static void onSignalReceived(const char *s) {
    char    *line = NULL;
    char    *p = NULL;
    int     value = -1;
    int     ber = -1;
    int     err = 0;
    ATResponse              *p_response = NULL;
    RIL_SignalStrength_v10  signalInfo;
    p = line = strdup(s);
    at_tok_start(&p);
    err = at_tok_nextint(&p, &value);
    if(err >= 0 && at_tok_hasmore(&p)) {
        err = at_tok_nextint(&p, &ber);
    }
    free(line);

    if(err >= 0) {
        signalInfo.GW_SignalStrength.signalStrength     = 99;
        signalInfo.GW_SignalStrength.bitErrorRate       = 99;
        signalInfo.CDMA_SignalStrength.dbm              = -1;
        signalInfo.CDMA_SignalStrength.ecio             = -1;
        signalInfo.EVDO_SignalStrength.dbm              = -1;
        signalInfo.EVDO_SignalStrength.ecio             = -1;
        signalInfo.EVDO_SignalStrength.signalNoiseRatio = -1;
        signalInfo.LTE_SignalStrength.signalStrength    = 99;
        signalInfo.LTE_SignalStrength.rsrp              = INT_MAX;
        signalInfo.LTE_SignalStrength.rsrq              = INT_MAX;
        signalInfo.LTE_SignalStrength.rssnr             = INT_MAX;
        signalInfo.LTE_SignalStrength.cqi               = INT_MAX;
        signalInfo.LTE_SignalStrength.timingAdvance     = INT_MAX;
        signalInfo.TD_SCDMA_SignalStrength.rscp         = INT_MAX;

        if(strStartsWith(s, "^DGSQU:")) {
            if(0 <= value && value <= 31) {
                signalInfo.GW_SignalStrength.signalStrength = value;
                signalInfo.GW_SignalStrength.bitErrorRate = ber;
                RLOGD("report GSM signal: %d -> %d dBm", value, (-113 + (value * 2)));
            }
        } else if(strStartsWith(s, "^DSQU:")) {
            if(0 <= value && value <= 91) {
                signalInfo.TD_SCDMA_SignalStrength.rscp = (-116 + value) * (-1);
                RLOGD("report 3G signal: %d -> %d dBm", value, signalInfo.TD_SCDMA_SignalStrength.rscp);
            }
        } else if(strStartsWith(s, "^DESQU:")) {
            if(0 <= value && value <= 97) {
                signalInfo.LTE_SignalStrength.rsrp = (-141 + value) * (-1);
                RLOGD("report 4G signal: %d -> %d dBm", value, signalInfo.LTE_SignalStrength.rsrp);
            }
        }

        RIL_onUnsolicitedResponse (RIL_UNSOL_SIGNAL_STRENGTH, &signalInfo, sizeof(signalInfo));
        at_response_free(p_response);
    }
}

int current_ril_id(void)
{
	return s_rilID;
}

void ata_ps_set_attach(void)
{
    char    propValue[PROP_VALUE_MAX] = "";
    int     ret = 0;

    ATA_PS_CONFIG_ST    pdp_setting_st;

    ret = ata_ps_read_config(&pdp_setting_st);

    if(ERR_NONE==ret)
    {
	if(pdp_setting_st.m_is_auto_attach_gprs == 0)
	{
		RLOGD("[RIL-PS][ata_ps_set_attach] auto_attach set to off ");
		return;
	}
    }

    ret = property_get("persist.sys.lc.slave.ps.attach", propValue, NULL);

    if((ret<0)||(strlen(propValue)==0))
    {
        RLOGD("[RIL-PS][ata_ps_set_attach] persist.sys.lc.slave.ps.attach is NULL ");
        propValue[0] = '0';
        propValue[1] = '\0';
    }

    RLOGD("[RIL-PS][ata_ps_set_attach] persist.sys.lc.slave.ps.attach is %s ",propValue);


    if(propValue[0] == '1')
    {
        at_send_command("AT^DCTA=1", NULL);
        return;
    }
    else if(propValue[0] == '0')
    {
        if(CARD_STATUS_ABSENT == ril_config_st.m_otherCardStatus)
        {
            RLOGD("[RIL-PS][ata_ps_set_attach]The other Card is absent");
            at_send_command("AT^DCTA=1", NULL);
            return;
        }

        if(s_is_master_card)
        {
            RLOGD("[RIL-PS][ata_ps_set_attach] this is master card!");
            at_send_command("AT^DCTA=1", NULL);
        }
        else
        {
            memset(propValue,0,PROP_VALUE_MAX);
            ret = property_get("persist.radio.main.ps", propValue, NULL);

            if ((ret < 0)||(strlen(propValue) == 0)) {
                at_send_command("AT^DCTA=0", NULL);
            } else {
                int main_ps_id = atoi(propValue);
                RLOGD("[RIL-PS][ata_ps_set_attach] persist.radio.main.ps is %s ril-id is %d", propValue, current_ril_id());

                if(main_ps_id == current_ril_id())
                {
                    at_send_command("AT^DCTA=1", NULL);
                }
                else
                {
                    at_send_command("AT^DCTA=0", NULL);
                }
            }
        }
    }
}


static void setUeCapability(void)
{
    char   prop_value[PROP_VALUE_MAX] = "";
    int     index = 0;
    int     ret = 0;
    char   at_cmd[40] = "";

    if (__system_property_get("persist.sys.lc.ue", prop_value) > 0)
    {
        index = prop_value[0] - '0';
        RLOGD("persist.sys.lc.ue: %s", prop_value);
    }

     switch(index)
     {
	case 1://[R99]
	{
	 	at_send_command("AT^DMCAPW=0,0,0,0,0,0,0,0,0,0,0,0,127,1792,0000000000930003", NULL);
	}
	break;

	case 2://[HSDPA_CAT6_3.6M]
	{
	 	at_send_command("AT^DMCAPW=1,6,0,0,0,0,0,0,0,0,0,0,127,1792,0000000000930003", NULL);
	}
	break;

	case 3://[HSDPA_CAT8_7.2M& HSUPA_CAT5_2M]
	{
	 	at_send_command("AT^DMCAPW=1,8,1,5,0,0,0,0,0,0,0,0,127,1792,0000000000930003", NULL);
	}
	break;

	case 4://[HSDPA CAT10_14.4M& HSUPA_ CAT6_5.76M]
	{
	 	at_send_command("AT^DMCAPW=1,10,1,6,0,0,0,0,0,0,0,0,127,1792,0000000000930003", NULL);
	}
	break;

	default:
	break;
     }

}


static void setAudioTest(void){
    char   prop_value[PROP_VALUE_MAX] = "";

    if (__system_property_get("persist.sys.audiotest.enable", prop_value) > 0){
        if('1' == prop_value[0]){
	 	at_send_command("AT^DAUDIOTEST=1", NULL);
        }else if('0' == prop_value[0]){
	 	at_send_command("AT^DAUDIOTEST=0", NULL);
        }
    }

}
