/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : ata-stk.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef ATA_STK_H
#define ATA_STK_H



/*-------------------------- include external file ---------------------------*/

/* FIX L1809OG_Bug00000200 2011-01-27 zoufeng begin */
////chenchi add
//typedef unsigned char                           UINT8;
//typedef unsigned short int                      UINT16;
//typedef unsigned long int                       UINT32;
//
//typedef signed char                             SINT8;
//typedef signed short int                        SINT16;
//typedef signed long int                         SINT32;
#include "pub-aos.h"
/* FIX L1809OG_Bug00000200 2011-01-27 zoufeng end */



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/

/* Parse the length info for STK data object. The arithmetic refer to:
 *     ts_102.223-Annex C, Table C.1
 */
#define STK_GET_TLV_LEN(pro_cmd_ptr, length)                                    \
        do                                                                      \
        {                                                                       \
            STR_2_U8( pro_cmd_ptr, length );                                    \
            if( 0x81 == length )                                                \
            {                                                                   \
                pro_cmd_ptr += 2;                                               \
                STR_2_U8( pro_cmd_ptr, length );                                \
                pro_cmd_ptr += 2;                                               \
            }                                                                   \
            else                                                                \
            {                                                                   \
                pro_cmd_ptr += 2;                                               \
            }                                                                   \
        } while(0);

/* <CLA>, refer to: ts_102.221-10.1.2 */
#define STK_CMD_HEAD_CLA_80                     0x80

/* <INS>, refer to: ts_102.221-10.1.2 */
#define STK_CMD_HEAD_INS_TERMINAL_PROFILE       0x10
#define STK_CMD_HEAD_INS_FETCH                  0x12
#define STK_CMD_HEAD_INS_TERMINAL_RESPONSE      0x14
#define STK_CMD_HEAD_INS_ENVELOPE               0xC2

/* <P1> */
#define STK_CMD_HEAD_P1                         0x00

/* <P2> */
#define STK_CMD_HEAD_P2                         0x00

/* Max length of APDU <DATA>, refer to: ts_102.221-10.1.4 */
#define STK_APDU_DATA_MAX_LEN                   255

/* Max length of APDU:
 *     field : <CLA> + <INS> + <P1> + <P2> + <Lc> + <DATA> + <Le>
 *     length: 1     + 1     + 1    + 1    + 1    + 255    + 1
 */
#define STK_APDU_MAX_LEN                        261

/* Max length of response APDU <DATA>, refer to: ts_102.221-10.1.6 */
#define STK_RSP_APDU_DATA_MAX_LEN               256

/* Proactive UICC command tag, refer to: ts_102.223-9.2 */
#define STK_TAG_PROACTIVE_UICC                  0xD0

/* COMPREHENSION-TLV tag, used for "Card application toolkit data objects".
 * Refer to: ts_101.220-7.2
 *     0x01 = 0x81
 *     ...
 *     0x79 = 0xF9
 * so
 *     0x01 & 0x7F -> 0x81
 *     ...
 *     0x79 & 0x7F -> 0xF9
 * except: 0x18
 */
#define STK_TAG_BEGIN                           0x80
#define STK_TAG_COMMAND_DETAILS                 0x81
#define STK_TAG_DEVICE_IDENTITY                 0x82
#define STK_TAG_RESULT                          0x83
#define STK_TAG_DURATION                        0x84
#define STK_TAG_ALPHA_ID                        0x85
#define STK_TAG_ADDRESS                         0x86
#define STK_TAG_CAP_CONFIG_PARAM                0x87
#define STK_TAG_SUBADDRESS                      0x88
#define STK_TAG_SS_STRING                       0x89
#define STK_TAG_USSD_STRING                     0x8A
#define STK_TAG_SMS_TPDU                        0x8B
#define STK_TAG_CB_PAGE                         0x8C
#define STK_TAG_TEXT_STRING                     0x8D
#define STK_TAG_TONE                            0x8E
#define STK_TAG_ITEM                            0x8F
#define STK_TAG_ITEM_ID                         0x90
#define STK_TAG_RESPONSE_LENGTH                 0x91
#define STK_TAG_FILE_LIST                       0x92
#define STK_TAG_LOCATION_INFO                   0x93
#define STK_TAG_IMEI                            0x94
#define STK_TAG_HELP_REQUEST                    0x95
#define STK_TAG_NET_MEASUREMENT_RST             0x96
#define STK_TAG_DEFAULT_TEXT                    0x97
#define STK_TAG_ITEMS_NEXT_ACTION               0x18
#define STK_TAG_EVENT_LIST                      0x99
#define STK_TAG_CAUSE                           0x9A
#define STK_TAG_LOCATION_STATUS                 0x9B
#define STK_TAG_TRANSACTION_ID                  0x9C
#define STK_TAG_BCCH_CHANNEL_LIST               0x9D
#define STK_TAG_ICON_ID                         0x9E
#define STK_TAG_ITEM_ICON_ID_LIST               0x9F
#define STK_TAG_CARD_READER_STATUS              0xA0
#define STK_TAG_CARD_ATR                        0xA1
#define STK_TAG_C_PDU                           0xA2
#define STK_TAG_R_PDU                           0xA3
#define STK_TAG_TIMER_ID                        0xA4
#define STK_TAG_TIMER_VALUE                     0xA5
#define STK_TAG_DATE_TIME_ZONE                  0xA6
#define STK_TAG_CALL_CTL_REQ_ACTION             0xA7
#define STK_TAG_AT_COMMAND                      0xA8
#define STK_TAG_AT_RESPONSE                     0xA9
#define STK_TAG_BC_REPEAT_INDICATOR             0xAA
#define STK_TAG_IMMEDIATE_RESPONSE              0xAB
#define STK_TAG_DTMF_STRING                     0xAC
#define STK_TAG_LANGUAGE                        0xAD
#define STK_TAG_TIMING_ADVANCE                  0xAE
#define STK_TAG_AID                             0xAF
#define STK_TAG_BROWSER_IDENTITY                0xB0
#define STK_TAG_URL                             0xB1
#define STK_TAG_BEARER                          0xB2
#define STK_TAG_PROVISIONING_REF_FILE           0xB3
#define STK_TAG_BROWSER_TERM_CAUSE              0xB4
#define STK_TAG_BEARER_DESCRIPTION              0xB5
#define STK_TAG_CHANNEL_DATA                    0xB6
#define STK_TAG_CHANNEL_DATA_LENGTH             0xB7
#define STK_TAG_CHANNEL_STATUS                  0xB8
#define STK_TAG_BUFFER_SIZE                     0xB9
#define STK_TAG_CARD_READER_ID                  0xBA
#define STK_TAG_FILE_UPDATE_INFO                0xBB
#define STK_TAG_INTERFACE_TRANSPORT_LEVEL       0xBC
#define STK_TAG_OTHER_ADDRESS                   0xBE
#define STK_TAG_ACCESS_TECH                     0xBF
#define STK_TAG_DISPLAY_PARAM                   0xC0
#define STK_TAG_SERVICE_RECORD                  0xC1
#define STK_TAG_DEVICE_FILTER                   0xC2
#define STK_TAG_SERVICE_SEARCH                  0xC3
#define STK_TAG_ATTRIBUTE_INFO                  0xC4
#define STK_TAG_SERVICE_AVAILABILITY            0xC5
#define STK_TAG_ESN                             0xC6
#define STK_TAG_NETWORK_ACCESS_NAME             0xC7
#define STK_TAG_CDMA_SMS_TPDU                   0xC8
#define STK_TAG_REMOTE_ENTITY_ADDRESS           0xC9
#define STK_TAG_I_WLAN_IDENTIFIER               0xCA
#define STK_TAG_I_WLAN_ACCESS_STATUS            0xCB
#define STK_TAG_TEXT_ATTRIBUTE                  0xD0
#define STK_TAG_ITEM_TEXT_ATTRIBUTE_LIST        0xD1
#define STK_TAG_PDP_CONTEXT_ACT_PARAM           0xD2
#define STK_TAG_IMEISV                          0xE2
#define STK_TAG_BATTERY_STATE                   0xE3
#define STK_TAG_BROWSING_STATUS                 0xE4
#define STK_TAG_NETWORK_SEARCH_MODE             0xE5
#define STK_TAG_FRAME_LAYOUT                    0xE6
#define STK_TAG_FRAMES_INFO                     0xE7
#define STK_TAG_FRAME_IDENTIFIER                0xE8
#define STK_TAG_UTRAN_MEASUREMENT_QUALIFIERTAG  0xE9
#define STK_TAG_MULTIMEDIA_MSG_REFERENCE        0xEA
#define STK_TAG_MULTIMEDIA_MSG_ID               0xEB
#define STK_TAG_MULTIMEDIA_MSG_TRANSFER_STATUS  0xEC
#define STK_TAG_MEID                            0xED
#define STK_TAG_MULTIMEDIA_MSG_CONTENT_TD       0xEE
#define STK_TAG_MULTIMEDIA_MSG_NOTIFICATION     0xEF
#define STK_TAG_LAST_ENVELOPE                   0xF0
#define STK_TAG_REGISTRY_APPLICATION_DATA       0xF1
#define STK_TAG_PLMNWACT_LIST                   0xF2
#define STK_TAG_ROUTING_AREA_INFO               0xF3
#define STK_TAG_UPDATE_ATTACH_TYPE              0xF4
#define STK_TAG_REJECTION_CAUSE_CODE            0xF5
#define STK_TAG_GEOGRAPHICAL_LOCATION_PARAM     0xF6
#define STK_TAG_GAD_SHAPES                      0xF7
#define STK_TAG_NMEA_SENTENCE                   0xF8
#define STK_TAG_BROADCAST_NETWORK_INFO          0xF9
#define STK_TAG_END                             0xFA

/* Type of command. Refer to ts_102.223-9.4 */
#define STK_CMD_ID_RESERVED                     0x00
#define STK_CMD_ID_REFRESH                      0x01
#define STK_CMD_ID_MORE_TIME                    0x02
#define STK_CMD_ID_POLL_INTERVAL                0x03
#define STK_CMD_ID_POLLING_OFF                  0x04
#define STK_CMD_ID_SET_UP_EVENT_LIST            0x05
#define STK_CMD_ID_SET_UP_CALL                  0x10
#define STK_CMD_ID_SEND_SS                      0x11
#define STK_CMD_ID_SEND_USSD                    0x12
#define STK_CMD_ID_SEND_SMS                     0x13
#define STK_CMD_ID_SEND_DTMF                    0x14
#define STK_CMD_ID_LAUNCH_BROWSER               0x15
#define STK_CMD_ID_PLAY_TONE                    0x20
#define STK_CMD_ID_DISPLAY_TEXT                 0x21
#define STK_CMD_ID_GET_INKEY                    0x22
#define STK_CMD_ID_GET_INPUT                    0x23
#define STK_CMD_ID_SELECT_ITEM                  0x24
#define STK_CMD_ID_SET_UP_MENU                  0x25
#define STK_CMD_ID_PROVIDE_LOCAL_INFO           0x26
#define STK_CMD_ID_TIMER_MANAGEMENT             0x27
#define STK_CMD_ID_SET_UP_IDLE_MODE_TEXT        0x28
#define STK_CMD_ID_PERFORM_CARD_APDU            0x30
#define STK_CMD_ID_POWER_ON_CARD                0x31
#define STK_CMD_ID_POWER_OFF_CARD               0x32
#define STK_CMD_ID_GET_READER_STATUS            0x33
#define STK_CMD_ID_RUN_AT_COMMAND               0x34
#define STK_CMD_ID_LANG_NOTIFICATION            0x35
#define STK_CMD_ID_OPEN_CHANNEL                 0x40
#define STK_CMD_ID_CLOSE_CHANNEL                0x41
#define STK_CMD_ID_RECEIVE_DATA                 0x42
#define STK_CMD_ID_SEND_DATA                    0x43
#define STK_CMD_ID_GET_CHANNEL_STATUS           0x44
#define STK_CMD_ID_SERVICE_SEARCH               0x45
#define STK_CMD_ID_GET_SERVICE_INFO             0x46
#define STK_CMD_ID_DECLARE_SERVICE              0x47
#define STK_CMD_ID_SET_FRAMES                   0x50
#define STK_CMD_ID_GET_FRAMES_STATUS            0x51
#define STK_CMD_ID_RETRIEVE_MULTIMEDIA_MESSAGE  0x60
#define STK_CMD_ID_SUBMIT_MULTIMEDIA_MESSAGE    0x61
#define STK_CMD_ID_DISPLAY_MULTIMEDIA_MESSAGE   0x62
#define STK_CMD_ID_ACTIVATE                     0x70
#define STK_CMD_ID_END_OF_PROACTIVE_SESSION     0x81    /* a special command ID that indicates the end of a proactive command session */

/* General result code. Refer to: ts_102.223-8.12
 *     Results '0X' and '1X' indicate that the command has been performed.
 *     Results '2X' indicate to the UICC that it may be worth re-trying the
 *         command at a later opportunity.
 *     Results '3X' indicate that it is not worth the UICC re-trying with an
 *         identical command, as it will only get the same response. However,
 *         the decision to retry lies with the application.
 */
#define STK_RESULT_00                           0x00    /* Command performed successfully; */
#define STK_RESULT_02                           0x02    //3gpp-31.124[27.22.#.##.#] 20141115
#define STK_RESULT_20                           0x20    /* terminal currently unable to process command; */
#define STK_RESULT_21                           0x21    /* Network currently unable to process command; */
#define STK_RESULT_22                           0x22    /* User did not accept the proactive command; */
#define STK_RESULT_37                           0x37    /* USSD Return Result error code; */

/* Source/Destination device identity, refer to: ts_102.223-8.7 */
#define STK_DEV_KEYPAD                          0x01
#define STK_DEV_DISPLAY                         0x02
#define STK_DEV_EARPIECE                        0x03
#define STK_DEV_UICC                            0x81
#define STK_DEV_TERMINAL                        0x82
#define STK_DEV_NETWORK                         0x83



/*----------------------- constant and type definition -----------------------*/

typedef struct
{
    UINT8                       m_len;
} STK_ADDITIONAL_RESULT_ST;



/*--------------------------- variables definition ---------------------------*/



/*---------------------- function prototype declaration ----------------------*/
#if 0 //chenchi add 
extern SINT32 at_stk_send_csim_sync(
    UINT32      apdu_len,
    UINT8       *apdu_ptr,
    UINT8       mux_port_id,
    AT_BUF_ST   *at_buf_ptr,
    SINT32      *cme_err_ptr,
    UINT8       *rsp_data_ptr,
    UINT32      rsp_data_size,
    UINT32      *rsp_data_len_ptr );
extern SINT8 at_stk_send_terminal_response( AT_MUX_PORT_ST *mux_port_ptr, UINT8 result, STK_ADDITIONAL_RESULT_ST *result_ptr );

extern SINT32 at_stk_jump_over_tlv_data_obj(UINT8 tag, char **pro_cmd_ptr, SINT8 is_mandatory );

extern SINT32 at_stk_check_if_support_stk( AT_MUX_PORT_ST *mux_port_ptr, SINT32 *cme_err_ptr );

extern SINT32 at_stk_pack_apdu_header( UINT8 head_ins, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr );
extern SINT32 at_stk_pack_apdu( UINT8 *apdu_data_ptr, UINT32 data_len, UINT8 head_ins, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr );
extern SINT32 at_stk_pack_tlv_command_details( UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr );
extern SINT32 at_stk_pack_tlv_device_id( UINT8 src_dev, UINT8 dst_dev, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr );
extern SINT32 at_stk_pack_tlv_result( UINT8 result, STK_ADDITIONAL_RESULT_ST *result_ptr, UINT8 *apdu_ptr, UINT32 *apdu_len_ptr, UINT32 *apdu_free_len_ptr );
extern SINT32 at_stk_pack_tlv_data_obj(UINT8 tag, char **pro_cmd_ptr, SINT8 is_mandatory, UINT8 *out_data, UINT32 out_size, UINT32 *out_len );

extern SINT32 at_stk_handle_at_dtusaturc(PTY_INFO_ST *pty_info_ptr, UINT8 **begin_ptr, UINT8 **end_ptr);

#ifdef OPT_ENABLE_SAVE_STK_PROFILE
extern SINT32 at_stk_set_profile(UINT8 *profile_data_ptr, UINT32 profile_len);
extern SINT32 at_stk_get_profile(UINT8 *profile_data_ptr, UINT32 profile_size, UINT32 *profile_len_ptr);
#endif

#endif

#endif /* ATA_STK_H */
