/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : ata-cfg.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef ATA_CFG_H
#define ATA_CFG_H



/*-------------------------- include external file ---------------------------*/

#include "pub-sys.h"
#include "pub-aos.h"
#include "pub-util.h"



#ifdef OPT_ENABLE_LC_ATA_CONFIG



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/



/*----------------------- constant and type definition -----------------------*/

typedef struct
{
    /* Prefix of at channel. */
    char    m_channel_at_prefix_a[28];          /* file: /opl/etc/board.prop; parameter: hw.tty.at */
    /* Prefix of PS data channel. */
    char    m_channel_ps_prefix_a[28];          /* file: /opl/etc/board.prop; parameter: hw.tty.ps */
    /* Prefix of CS data channel. */
    char    m_channel_cs_prefix_a[28];          /* file: /opl/etc/board.prop; parameter: hw.tty.cs */
    /* Audio data channel. */
    char    m_channel_audio_a[28];              /* file: /opl/etc/board.prop; parameter: hw.tty.audio */
    /* Prefix of at channel(for VP only, just used when modem integrate H324M). */
    char    m_channel_vp_at_a[28];              /* file: /opl/etc/board.prop; parameter: hw.tty.vpdevice.at */
    /* Prefix of VP video data channel(for VP only, just used when modem integrate H324M). */
    char    m_channel_vp_video_a[28];           /* file: /opl/etc/board.prop; parameter: hw.tty.vpdevice.video */
    /* Prefix of at channel(for LGE only). */
    char    m_channel_lge_at_prefix_a[28];      /* file: /opl/etc/board.prop; parameter: hw.tty.at.lge */
    /* AT channel name, only for test. */
    char    m_channel_at_test_a[28];            /* file: /opl/etc/board.prop; parameter: hw.tty.at.test */
#ifdef OPT_FACTORY_DEFINED_AT
    /* AT channel name, only for factory test. */
    char    m_channel_at_factory_a[28];         /* file: /opl/etc/board.prop; parameter: hw.tty.at.factory */
#endif

#if (defined OPT_ENABLE_ELOG) && (defined OPT_USER_LGE)
    /* Name of Elog AT channel. */
    char    m_channel_elog_at_a[28];            /* file: /opl/etc/board.prop; parameter: hw.tty.elog.at */
    /* Name of Elog data channel. */
    char    m_channel_elog_data_a[28];          /* file: /opl/etc/board.prop; parameter: hw.tty.elog.data */
#endif

#ifdef OPT_DUAL_PORT_COMMUNICATION
    /* The name of PS data channels that will be used by PPPD.
     * WARNING: they can not be used when [m_channel_ps_prefix_a] is defined. */
    char    m_channel_ps1_a[28];                /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.tty.ps1 */
    char    m_channel_ps2_a[28];                /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.tty.ps2 */
    char    m_channel_ps3_a[28];                /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.tty.ps3 */

    UINT8   m_dual_port_communication;          /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.dual.port */
    SINT8   m_is_enable_power_off_usb;          /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.usb.poweroff */
    ST_PADDING_2(1);
#endif

    /* Specify the access technology for power on. */
    SINT8   m_is_act_valid;
    UINT8   m_act_mode;                         /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.act.mode */
    ST_PADDING_2(2);

    /* If enable log PS data info. */
    SINT8   m_is_ps_log_data_info;              /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.ps.log.data.info */
    /* If enable log CS data info. */
    SINT8   m_is_cs_log_data_info;              /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.cs.log.data.info */
    /* If enable log CS data. */
    SINT8   m_is_cs_log_data;                   /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.cs.log.data */
    /* If enable log VP data info. */
    SINT8   m_is_vp_log_data_info;              /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.vp.log.data.info */
    /* If enable log VP data. */
    SINT8   m_is_vp_log_data;                   /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.vp.log.data */
    /* If enable log aduio data info. */
    SINT8   m_is_audio_log_data_info;           /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.audio.log.data.info */
    /* If enable log aduio data. */
    SINT8   m_is_audio_log_data;                /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.audio.log.data */
    ST_PADDING_1(3);

#ifdef OPT_SOFT_MODEM
    /* If enable log SoftModem data info. */
    SINT8   m_is_sm_log_data_info;              /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.sm.log.data.info */
    /* If enable log SoftModem data. */
    SINT8   m_is_sm_log_data;                   /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.sm.log.data */
    ST_PADDING_2(4);
#endif

#if (defined OPT_ENABLE_ELOG) && (defined OPT_USER_LGE)
    /* If enable log ELog data info. */
    SINT8   m_is_elog_log_data_info;            /* file: /opl/etc/lc-ata.cfg; parameter: lc.elog.log.data.info */
    /* If enable log ELog data. */
    SINT8   m_is_elog_log_data;                 /* file: /opl/etc/lc-ata.cfg; parameter: lc.elog.log.data */
    ST_PADDING_2(5);
#endif

    /* If H324M run on AP side. */
    SINT8   m_is_ap_324;                        /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.h324m.ap */
    ST_PADDING_3(6);

#ifdef OPT_ENABLE_REPORT_RSSI
    /* Report period of RSSI, the unit is second. */
    SINT8   m_rssi_period;                      /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.rssi.period */
    ST_PADDING_3(7);
#endif

    /* The path of the program: pppd. */
    char    m_pppd_path_a[28];                  /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.ppp.path.pppd */
    /* The path of the pppd config file. */
    char    m_pppd_provider_path_a[28];         /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.ppp.path.provider */
    /* The path of the pppd daemon process ID. */
    char    m_pppd_pid_path_a[28];              /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.ppp.path.pid */
    /* MRU [Maximum Receive Unit] value */
    UINT16  m_pppd_mru;                         /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.ppp.mru */
    /* MTU [Maximum Transmit Unit] value */
    UINT16  m_pppd_mtu;                         /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.ppp.mtu */

    SINT8   m_is_for_cta;                       /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.for.cta */
    ST_PADDING_3(8);

    /* The speed of the serial device. */
    UINT32  m_tty_speed;                        /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.tty.speed */

#ifdef OPT_RESET_MODEM
    /* If enable the reset modem mechanism or not. */
    SINT8   m_reset_is_enable;                  /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.reset.enable */
    ST_PADDING_3(9);

    /* Manually reset string, user can dial this string to make a reset. */
    char    m_reset_modem_string_a[28];         /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.reset.modem */
#endif

    /* Max size of the log file(UNIT: byte) */
    UINT32  m_log_size;                         /* file: /opl/etc/lc-oms-ata.cfg; parameter: lc.log.size */

    UINT8   m_rssi_bar0;                        /* file: /opl/etc/system.prop; parameter: sys.statusbar.rssi.bar0 */
    UINT8   m_rssi_bar1;                        /* file: /opl/etc/system.prop; parameter: sys.statusbar.rssi.bar1 */
    UINT8   m_rssi_bar2;                        /* file: /opl/etc/system.prop; parameter: sys.statusbar.rssi.bar2 */
    UINT8   m_rssi_bar3;                        /* file: /opl/etc/system.prop; parameter: sys.statusbar.rssi.bar3 */
    UINT8   m_rssi_bar4;                        /* file: /opl/etc/system.prop; parameter: sys.statusbar.rssi.bar4 */
    ST_PADDING_3(10);

    char    m_machine_name_a[16];               /* file: /opl/etc/board.prop; parameter: hw.machine.name */
    char    m_product_vendor_a[16];             /* file: /opl/etc/system.prop; parameter: apps.setting.product.vendor */
    char    m_product_model_a[16];              /* file: /opl/etc/system.prop; parameter: apps.setting.product.model */
    char    m_hardware_a[16];                   /* file: /proc/cpuinfo; parameter: Hardware */
} LC_ATA_CFG_ST;



/*--------------------------- variables definition ---------------------------*/

extern LC_ATA_CFG_ST   lc_ata_cfg_st;



/*---------------------- function prototype declaration ----------------------*/

extern SINT32 cfg_get_line( FILE *fp, char *buf_ptr, UINT32 buf_size, UINT32 *data_len_ptr, BOOL *is_end_ptr );
extern SINT32 cfg_get_param_and_value(char *line_ptr, char **param_ptr, char **value_ptr );
extern SINT32 cfg_parse_init(void);



#endif /* #ifdef OPT_ENABLE_LC_ATA_CONFIG */



#endif /* ATA_CFG_H */
