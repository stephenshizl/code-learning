/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : pub-cfg.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef PUB_CFG_H
#define PUB_CFG_H



/*-------------------------- include external file ---------------------------*/

#include "pub-sys.h"
#include "pub-aos.h"
#include "pub-util.h"



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/



/*----------------------- constant and type definition -----------------------*/



/*--------------------------- variables definition ---------------------------*/



/*---------------------- function prototype declaration ----------------------*/

extern SINT32 pub_cfg_get_line( FILE *fp, char *buf_ptr, UINT32 buf_size, UINT32 *data_len_ptr, BOOL *is_end_ptr );
extern SINT32 pub_cfg_get_param_and_value( char *line_ptr, char **param_ptr, char **value_ptr );
extern SINT32 pub_cfg_set_remark_char( char ch );
extern SINT32 pub_cfg_set_equal_char( char ch );



#endif /* PUB_CFG_H */
