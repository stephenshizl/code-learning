/*******************************************************************************
 *          COPYRIGHT DATANG MOBILE COMMUNICATIONS EQUIPMENT CO.,LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : pub-aos.h
 * Version  :
 * Purpose  :
 * Authors  :
 * Date     : 2008.09.26
 * Notes    : This file is automatically created, don't edit it!
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef PUB_AOS_H
#define PUB_AOS_H



/*-------------------------- include external file ---------------------------*/

#include "pub-sys.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/

#define TP_OS_ASSERT

#define OS_SUCCESS                              0x00000000
#define OS_FAILURE                              0xffffffff

#define OS_NO_WAIT                              0x00000000
#define OS_WAIT_FOREVER                         0xffffffff

#define OS_QUEUE_INVALID_ID                     0xFFFFFFFF
#define OS_SEMA_INVALID_ID                      0xFFFFFFFF
#define OS_MUTEX_INVALID_ID                     0xFFFFFFFF
#define OS_EVENT_INVALID_ID                     0xFFFFFFFF
#define OS_TIMER_INVALID_ID                     0xFFFFFFFF
#define OS_THREAD_INVALID_ID                    0xFFFFFFFF

#define OS_AUTO_ACTIVATE                        0x01
#define OS_DONT_ACTIVATE                        0x00
#define OS_AUTO_LOAD                            0x02
#define OS_DONT_LOAD                            0x00

#ifndef OS_TRUE
#define OS_TRUE                                 1
#endif

#ifndef OS_FALSE
#define OS_FALSE                                0
#endif

#ifndef NULLPTR
#define NULLPTR                                 (void *)0
#endif

#ifndef NULL
#define NULL                                    0
#endif

#ifndef TRUE
#define TRUE                                    1
#endif
#ifndef FALSE
#define FALSE                                   0
#endif

#ifndef ENUM
#define ENUM                                    enum
#endif

#ifndef UNION
#define UNION                                   union
#endif

#ifndef CONST
#define CONST                                   const
#endif

#ifndef EXTERN 
#define EXTERN                                  extern
#endif

#define TP_PF_TASK_PRI_GET(x)                   x
#define PF_TASK_SC_MUX_RECV                     1
#define PF_TASK_SC_MUX_Q_POLL                   2

#define TP_OS_GET_ERRNO()                       1



/*----------------------- constant and type definition -----------------------*/

typedef void                                    VOID;

typedef char                                    CHAR;
#if !defined(OPT_SFW_EXTERNAL_TYPE_DEF)
typedef signed char                             BOOL;
#endif
typedef signed char                             SINT8;
typedef signed short int                        SINT16;
typedef signed long int                         SINT32;
#ifdef WIN32
typedef double                                  SINT64;
#else
typedef signed long long                        SINT64;
#endif
typedef unsigned char                           UINT8;
typedef unsigned short int                      UINT16;
typedef unsigned long int                       UINT32;
#ifdef WIN32
typedef double                                  UINT64;
#else
typedef unsigned long long                      UINT64;
#endif
typedef float                                   FLOAT32;
typedef double                                  FLOAT64;
typedef double                                  DOUBLE;

#if DISABLE_STATIC

#define STATIC

#else /* #if DISABLE_STATIC */

#ifndef STATIC
#define STATIC                                  static
#endif

#endif /* #if DISABLE_STATIC */

typedef UINT32                                  OS_STATUS;

typedef UINT32                                  OS_TIMER_ID;
typedef UINT32                                  OS_THREAD_ID;
typedef UINT32                                  OS_SEMA_ID;
typedef UINT32                                  OS_EVENT_ID;
typedef UINT32                                  OS_MUTEX_ID;

typedef VOID (*OS_FUNC_ENTRY)(VOID *);
typedef void (*POSIX_TIMER_EXPIRY_FUNC)(union sigval sv);

typedef VOID (*OS_THREAD_ENTRY)(VOID* param);
typedef void *(*POSIX_THREAD_ENTRY)(void*);



/*--------------------------- variables definition ---------------------------*/



/*---------------------- function prototype declaration ----------------------*/

OS_SEMA_ID tp_os_sema_create(CHAR *name,UINT32 init_count);
OS_STATUS tp_os_sema_delete(OS_SEMA_ID sid);
OS_STATUS tp_os_sema_get(OS_SEMA_ID sid, UINT32 timeout);
OS_STATUS tp_os_sema_put(OS_SEMA_ID sid);
OS_STATUS tp_os_sema_get_value(OS_SEMA_ID sid, int *val_ptr);

OS_TIMER_ID tp_os_timer_create(CHAR *name,OS_FUNC_ENTRY expir_func, VOID* expire_para_ptr, UINT32 interval,UINT32 flag);
OS_STATUS tp_os_timer_delete(OS_TIMER_ID id);
OS_STATUS tp_os_timer_start(OS_TIMER_ID id);
OS_STATUS tp_os_timer_restart(OS_TIMER_ID id,UINT32 interval);
OS_STATUS tp_os_timer_stop(OS_TIMER_ID id);

OS_EVENT_ID tp_os_event_create(CHAR *name,BOOL flag);
OS_STATUS tp_os_event_delete(OS_EVENT_ID eid);
OS_STATUS tp_os_event_get(OS_EVENT_ID eid, UINT32 timeout);
OS_STATUS tp_os_event_set(OS_EVENT_ID eid);

OS_THREAD_ID tp_os_thread_create(CHAR *name, OS_THREAD_ENTRY entry, UINT8 pri, UINT32 size, VOID* param);
OS_STATUS tp_os_thread_delete(OS_THREAD_ID tid);
OS_STATUS tp_os_thread_sleep(UINT32 timeout);

VOID *tp_os_mem_malloc(UINT32 bytes);
OS_STATUS tp_os_mem_free(VOID *mem_ptr);
VOID tp_os_mem_cpy(VOID *dest_ptr, VOID *src_ptr, UINT32 copy_len);
VOID tp_os_mem_set(VOID *dest_ptr, UINT8 value, UINT32 len);

OS_MUTEX_ID tp_os_mutex_create(CHAR *name, BOOL flag);
OS_STATUS tp_os_mutex_delete(OS_MUTEX_ID mid);
OS_STATUS tp_os_mutex_get(OS_MUTEX_ID mid, UINT32 timeout);
OS_STATUS tp_os_mutex_put(OS_MUTEX_ID mid);

UINT32 tp_os_current_tick_get(void);

void tp_man_comm_init(void);
SINT32 tp_man_comm_setpara(SINT32 devID, UINT32 baudrate,UINT32 databits,UINT32 paritybits, UINT32 stopbits);
SINT32 tp_man_comm_open( CHAR *devname,UINT32 op_flag );
SINT32 tp_man_comm_close( SINT32 devID );
SINT32 tp_man_comm_send( SINT32 devID, VOID* buff, UINT32 size, UINT32 blocked, SINT32 waitsec );
SINT32 tp_man_comm_recv( SINT32 devID, VOID* buff, UINT32 size, UINT32 blocked, SINT32 waitsec );
SINT32 tp_man_comm_set_device( char *device_name_ptr );

extern SINT32 pub_aos_set_serial_speed(UINT32 speed);



#ifdef __cplusplus
}
#endif



#endif /* PUB_AOS_H */
