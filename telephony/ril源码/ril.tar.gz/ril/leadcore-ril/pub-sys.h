/*******************************************************************************
 *          COPYRIGHT DATANG MOBILE COMMUNICATIONS EQUIPMENT CO.,LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : pub-sys.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     : 2008.06.01
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef PUB_SYS_H
#define PUB_SYS_H



/*-------------------------- include external file ---------------------------*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <stdarg.h>
#include <time.h>
#include <fcntl.h>
#include <signal.h>
#include <ctype.h>
#include <errno.h>
#include <malloc.h>
#include <math.h>
//#include <wchar.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
//#include <sys/timeb.h>

#ifdef WIN32

#include <iostream.h>
#include <conio.h>
#include <direct.h>
#include <io.h>
#include <STDDEF.H>

#else /* #ifdef WIN32 */

#include <dlfcn.h>
#include <unistd.h>
#include <semaphore.h>
#include <termios.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/param.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/vfs.h>
#include <linux/prctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/in.h>
#include <net/if_arp.h>
#include <sys/select.h>

#ifdef OPT_FOR_ANDROID
#include <private/android_filesystem_config.h>
#endif

#endif /* #ifdef WIN32 */



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/



/*----------------------- constant and type definition -----------------------*/



/*--------------------------- variables definition ---------------------------*/



/*---------------------- function prototype declaration ----------------------*/



#endif /* PUB_SYS_H */
