/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : ata-ps.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef ATA_PS_H
#define ATA_PS_H



/*-------------------------- include external file ---------------------------*/

#include "pub-aos.h"
#include <sys/resource.h>
#include <sys/time.h>
#include <telephony/ril.h>




/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/
#define DEACTIVATE_REASON_PS_SWITCH 3

/*----------------------- constant and type definition -----------------------*/

typedef struct
{
    int                 m_is_auto_attach_gprs;  /* if auto attach GPRS */
    int                 m_traffic_class;        /* (Qos)traffic class */
    int                 m_max_bit_ul;           /* (Qos)Maximum bitrate UL */
    int                 m_max_bit_dl;           /* (Qos)Maximum bitrate L */
} ATA_PS_CONFIG_ST;


typedef struct
{
    char                *radio_technology;
    char                *profile;
    char                *apn;
    char                *user;
    char                *password;
    char                *auth_type;
    char                *protocol;
    BOOL                check_protocol;
} ATA_PS_PDP_REQ_ST;

typedef struct
{
    UINT8 pdp_type;
    char  apn[PDP_APN_LENGTH];
    char  ifname[IFNAMSIZ+1];
    char  ip_address[PDP_IP_ADDR_LENGTH_IPV4 + PDP_IP_ADDR_LENGTH_IPV6 + 2];
    char  dnses[PDP_IP_ADDR_LENGTH_IPV4*2 + PDP_IP_ADDR_LENGTH_IPV6*2 + 2*2];
    char  gateways[PDP_IP_ADDR_LENGTH_IPV4 + PDP_IP_ADDR_LENGTH_IPV6 + 2];
} ATA_PS_NETWORK_INFO_ST;


typedef struct
{
    char                m_addr_a[20];           /* IP address */
    char                m_gateway_a[20];        /* gateway */
    char                m_dns1_a[20];           /* DNS1 */
    char                m_dns2_a[20];           /* DNS2 */
} ATA_PS_ADDRESS_INFO_ST;

#ifdef OPT_PS_PPP
#define SYS_PROGRAM_PPPD                        "/system/bin/pppd"
#define SYS_PROGRAM_CHAT                        "/system/xbin/chat"
#define SYS_PROGRAM_PPPD_CFG_PATH               "/etc/ppp/peers"
#define SYS_PROGRAM_PPPD_PID_PATH               "/etc/ppp/var"
#define SYS_PROGRAM_CHAT_CFG_PATH               "/tmp"
#define CHECK_PPP_DEVICE_TIMER                200 //200
#define TTY_MAX_COUNT                           1
#define AT_CMD_STR_MAX_LEN                 	2048
#define CHECK_PPP_CONNECT_TIMER               60

typedef struct
{
    UINT8               m_ps_tty_state;        /* TTY state */
	char                m_ps_tty_name[16];     /* TTY Name */
} TTY_INFO_ST;

typedef enum
{
    TTY_STATE_FREE = 0,                        /* idle TTY info */
	TTY_STATE_USED,                            /* TTY has been used */	
} TTY_STATE_EN;


static TTY_INFO_ST tty_info_st[TTY_MAX_COUNT] =
{
    /* m_state, m_name */
	//{  0, "/dev/TTYEMS04_s" },
	//wy test 20220713 socat pts<->udp
	{  0, "/tmp/ptstt" },
};
#endif




/*--------------------------- variables definition ---------------------------*/
#ifdef OPT_PS_PPP

static SINT32 ata_ps_set_qos(UINT8 cid);
static SINT32 ata_ps_start_ppp(UINT8 cid);
static SINT32 ata_ps_start_pdp(UINT8 cid);
static SINT32 ata_ps_stop(UINT8 cid);
static SINT32 ata_ps_stop_pdp(UINT8 cid);
static SINT32 ata_ps_stop_ppp(UINT8 cid);
static BOOL ata_ps_is_app_used(UINT8 cid);
static SINT32 ata_ps_put_idle_pdp_for_pc(UINT8 cid);
static UINT16 ata_ps_get_rild_id(void);
static SINT32 start_ppp_with_device(UINT8 cid);
static UINT32 get_pppd_pid( UINT8 cid );
static SINT32 check_ppp_device( PDP_INFO_ST *pdp_info_ptr );
static SINT32 start_pppd(UINT8 cid, char *pppd_device_ptr);
static SINT32 stop_pppd(PDP_INFO_ST *pdp_info_ptr);
static SINT32 ata_ps_stop_all_ppp(void);
static SINT32 ata_ps_stop_ppp(UINT8 cid);
static SINT32 ata_ps_start_ppp(UINT8 cid);
static SINT32 set_dns_info( PDP_INFO_ST *pdp_info_ptr, 
                            const char * ppp_device_name_ptr );
static SINT32 ata_ps_start_pdp(UINT8 cid);
static SINT32 start_pdp_with_device(UINT8 cid);




extern void RIL_onRequestComplete(RIL_Token t, RIL_Errno e,
                           void *response, size_t responselen);
extern void RIL_onUnsolicitedResponse(int unsolResponse, const void *data,
                                size_t datalen);

#endif




/*---------------------- function prototype declaration ----------------------*/
extern SINT32 ata_ps_start_network(UINT8 * ril_cid, ATA_PS_PDP_REQ_ST * pdp_req); 
extern SINT32 ata_ps_stop_network(UINT8 ril_cid);
extern void ata_ps_save_default_ps_card(int ril_id);
extern SINT32 ata_ps_get_network_info(UINT8 ril_cid, ATA_PS_NETWORK_INFO_ST *address_ptr);
extern void ata_ps_set_attach(void);
extern void ata_ps_close_lmi_in_shutdown(int ril_id);
extern void ata_ps_set_default_apn(const char *apn, const char *protocol); //no use
extern void ata_ps_set_eps_pdn_parameters(void);
extern void ata_ps_set_fake_ipv4addr(UINT8 ril_cid, char *fake_addr);
extern SINT32 ata_unsolicited_at_cgev(unsigned char *begin_ptr);
extern void ata_unsolicited_at_pcd(unsigned char *begin_ptr);
extern void ata_ps_init(void);
extern void ata_ps_close_lmi_in_shutdown(int ril_id);
extern void onDataCallListChanged(void *param);
extern void ata_ps_set_ps_switch(BOOL is_ps_switch);
extern BOOL ata_ps_is_ps_switch(void);
extern SINT32 ata_ps_read_config(ATA_PS_CONFIG_ST *pdp_setting_ptr);





#endif /* ATA_PS_H */
