/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : config.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef CONFIG_H
#define CONFIG_H



/*-------------------------- include external file ---------------------------*/

#include <stdio.h>



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/

/* Config file of all RILDs, it is created by "radio_config". */
#define RILD_CONFIG_FILE                        "/data/leadcore/radio/rild.cfg"

/* max count of the RILD. */
#define RILD_MAX_COUNT                          5

#define CONFIG_NAME_MAX_LEN                     24

typedef enum {
    TYPE_INT                                    = 1,
    TYPE_STRING                                 = 2,
} RIL_CONFIG_VALUE_TYPE;

/* It is same as it defined in radio_config. */
typedef enum {
    CARD_STATUS_ABSENT                          = 0,
    CARD_STATUS_EXIST                           = 1,
    CARD_STATUS_UNKNOWN                         = 255,
} RIL_CARD_STATUS;

/* It is same as it defined in radio_config. */
typedef enum {
    CARD_TYPE_SIM                               = 1,
    CARD_TYPE_USIM                              = 2,
    CARD_TYPE_UNKNOWN                           = 255,
} RIL_CARD_TYPE;

/* It is same as it defined in radio_config. */
typedef enum {
    CARD_LOCALE_CMCC                            = 1,
    CARD_LOCALE_CUCC                            = 2,
    CARD_LOCALE_CHINA_OTHERS                    = 3,
    CARD_LOCALE_FOREIGN                         = 4,
    CARD_LOCALE_OTHERS                          = 5,    /* except oneself, the other sim cards called OTHERS, inclue CHINA_OTHERS and FOREIGN*/
    CARD_LOCALE_ALL                             = 6,    /* include all of locale*/
    CARD_LOCALE_UNKNOWN                         = 255,
} RIL_CARD_LOCALE;

/* It is same as it defined in radio_config. */
typedef enum {
    RAT_234G_2G                                 = 1,
    RAT_2G_234G                                 = 2,
    RAT_234G_2G_O                               = 3,
} RIL_STANDBY_RAT_CAPABILITY;

/* It is same as it defined in radio_config. */
typedef enum {
    ACTUAL_RAT_234G_2G                          = 1,
    ACTUAL_RAT_234G_2G_O                        = 2,
    ACTUAL_RAT_23G_2G                           = 3,
    ACTUAL_RAT_23G_2G_O                         = 4,
    ACTUAL_RAT_2G_234G                          = 5,
    ACTUAL_RAT_2G_23G                           = 6,
    ACTUAL_RAT_2G_2G                            = 7,
} RIL_STANDBY_ACTUAL_RAT;

typedef enum {
    OPEN_VERSION                                = 1,    /* non customized version */
    CMCC_VERSION                                = 2,    /* CMCC customized version */
    CUCC_VERSION                                = 3,    /* CUCC customized version */
    CTC_VERSION                                 = 4,    /* CTC customized version */
    CSCC_VERSION                                = 5,    /* CSCC customized version */
    UNKNOWN_VERSION                             = 6,
} PRODUCTION_VERSION;


/*----------------------- constant and type definition -----------------------*/

typedef struct {
    char                m_configName[CONFIG_NAME_MAX_LEN];
    int                 m_valueType;
    void                *m_value;
    int                 m_valueSize;
} CONFIG_OPTION_ST;

/* The parameters that radio_config passed by file RILD_CONFIG_FILE. */
typedef struct {
    /* Count of the RILD that is running. */
    int                 m_rildCount;
    /* Which the SIM card that the RILD is using. */
    int                 m_simSlot;
    /* Status of (U)SIM. Refer to "RIL_CARD_STATUS". */
    int                 m_cardStatus;
    /* What's the type of the (U)SIM that the RILD is using, refer to "RIL_CARD_TYPE". */
    int                 m_cardType;
    /* Locale of (U)SIM. Refer to "RIL_CARD_LOCALE". */
    int                 m_cardLocale;
    /* UICC ID of the (U)SIM card. */
    char                m_cardID[40];
    /* The capability of Radio Access Technology that the RILD supports.
     * Refer to "RIL_RadioLcTechnology". */
    int                 m_rat;
    /* The Radio Access Technology that the RILD using actually.
     * Refer to "RIL_RadioLcTechnology". */
    int                 m_actualRat;
    /* The parameter of AT "^DSTMEX" that RILD will send to Modem. */
    char                m_ratDSTMEX[20];
    /* If the RILD supports CS registeration. */
    int                 m_enableCs;
    /* If the RILD supports PS registeration. */
    int                 m_enablePs;
    /* Status of (U)SIM in other SIM slot. Refer to "RIL_CARD_STATUS". */
    int                 m_otherCardStatus;
    /* Local of (U)SIM in other SIM slot. Refer to "RIL_CARD_LOCALE". */
    int                 m_otherCardLocale;
} RIL_CONFIG_ST;



/*--------------------------- variables definition ---------------------------*/

extern RIL_CONFIG_ST    ril_config_st;



/*---------------------- function prototype declaration ----------------------*/

extern int config_get_line( FILE *fp, char *buf_ptr, int buf_size, int *data_len_ptr, int *is_end_ptr );
extern int config_get_param_and_value(char *line_ptr, char **param_ptr, char **value_ptr );
extern int config_load_file(const char *file_ptr, const CONFIG_OPTION_ST *configData, int configCount);

extern int ril_load_config(const char *file_ptr);



#endif /* CONFIG_H */
