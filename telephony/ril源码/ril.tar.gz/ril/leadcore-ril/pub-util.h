/*******************************************************************************
 *          COPYRIGHT DATANG MOBILE COMMUNICATIONS EQUIPMENT CO.,LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : pub-util.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     : 2009.02.13
 * Notes    : (none)
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef PUB_UTIL_H
#define PUB_UTIL_H



/*-------------------------- include external file ---------------------------*/

#include "pub-sys.h"
#include "pub-aos.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/

/* Since Android does not support pthread_cancel(), so we use signal to inform
 * the thread exit. */
#define PUB_UTIL_THREAD_END_SIGNAL              SIGUSR1 /* = 10 */

/* Signal that used to inform the process to reset. */
#define PUB_UTIL_RESET_PROCESS_SIGNAL           SIGUSR2 /* = 12 */

/* Padding to ensure the structure is 4-byte boundary. */
#define ST_PADDING_1(n)                         UINT8   m_pad_ ## n
#define ST_PADDING_2(n)                         UINT8   m_pad_ ## n[2]
#define ST_PADDING_3(n)                         UINT8   m_pad_ ## n[3]

#define ST_PADDING_VALUE_1                      0
#define ST_PADDING_VALUE_2                      {0, 0}
#define ST_PADDING_VALUE_3                      {0, 0, 0}

/* Convert UINT8 data to string, example:
 *     0x12 -> "12"
 */
#define U8_2_STR( u8, str )                                                     \
        do                                                                      \
        {                                                                       \
            if( str )                                                           \
            {                                                                   \
                const char  ascii_table_a[16] =                                 \
                        { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',     \
                          'A', 'B', 'C', 'D', 'E', 'F' };                       \
                                                                                \
                str[0] = ascii_table_a[(u8 >> 4) & 0x0F];                       \
                str[1] = ascii_table_a[u8 & 0x0F];                              \
            }                                                                   \
        } while(0);

/* Convert string to UINT8 data, example:
 *     "12" -> 0x12
 */
#define STR_2_U8( str, u8 )                                                     \
        do                                                                      \
        {                                                                       \
            if( str )                                                           \
            {                                                                   \
                if( '0' <= str[0] && str[0] <= '9' )                            \
                    u8 = (str[0] - '0') * 16;                                   \
                else if( 'A' <= str[0] && str[0] <= 'F' )                       \
                    u8 = (str[0] - 'A' + 10) * 16;                              \
                else if( 'a' <= str[0] && str[0] <= 'f' )                       \
                    u8 = (str[0] - 'a' + 10) * 16;                              \
                                                                                \
                if( '0' <= str[1] && str[1] <= '9' )                            \
                    u8 += (str[1] - '0');                                       \
                else if( 'A' <= str[1] && str[1] <= 'F' )                       \
                    u8 += (str[1] - 'A' + 10);                                  \
                else if( 'a' <= str[1] && str[1] <= 'f' )                       \
                    u8 += (str[1] - 'a' + 10);                                  \
             }                                                                  \
        } while(0);

#define PUB_UTIL_U8_ARRAY_2_STR(u8, u8_len, str, str_len)                       \
        do                                                                      \
        {                                                                       \
            UINT32  i = 0;                                                      \
            UINT8   *u8_ptr = (UINT8 *)u8;                                      \
            char    *str_ptr = (char *)str;                                     \
                                                                                \
            str_len = 0;                                                        \
            for( i=0; i<u8_len; i++ )                                           \
            {                                                                   \
                U8_2_STR( (*u8_ptr), str_ptr );                                 \
                u8_ptr++;                                                       \
                str_ptr += 2;                                                   \
                str_len += 2;                                                   \
            }                                                                   \
        } while(0);

#define PUB_UTIL_STR_2_U8_ARRAY(str, str_len, u8, u8_len)                       \
        do                                                                      \
        {                                                                       \
            UINT32  i = 0;                                                      \
            UINT8   *u8_ptr = (UINT8 *)u8;                                      \
            char    *str_ptr = (char *)str;                                     \
                                                                                \
            u8_len = 0;                                                         \
            for( i=0; i<(UINT32)str_len; i++ )                                  \
            {                                                                   \
                STR_2_U8( str_ptr, (*u8_ptr) );                                 \
                u8_ptr++;                                                       \
                u8_len++;                                                       \
                str_ptr += 2;                                                   \
            }                                                                   \
        } while(0);

/* Do memcpy() according to the free space. */
#define CHECK_MEMCPY( dst_ptr, src_ptr, src_len, dst_free_len )                 \
        do                                                                      \
        {                                                                       \
            if( dst_free_len >= src_len )                                       \
            {                                                                   \
                memcpy( dst_ptr, src_ptr, src_len );                            \
                dst_free_len -= src_len;                                        \
            }                                                                   \
            else                                                                \
            {                                                                   \
                memcpy( dst_ptr, src_ptr, dst_free_len );                       \
                dst_free_len = 0;                                               \
            }                                                                   \
        } while(0);

#define IS_PHONE_NUMBER(num)                                                    \
        ( ('0' <= num && num <= '9')                                            \
          || '+' == num                                                         \
          || 'p' == num || 'P' == num                                           \
          || 'w' == num || 'W' == num )

#define WRITE_DEVICE(ret_val, fd, buf_a, buf_len, write_len, sec)               \
        do                                                                      \
        {                                                                       \
            fd_set          write_fds;                                          \
            struct timeval  tv;                                                 \
                                                                                \
            ret_val = ERR_NONE;                                                 \
                                                                                \
            if( fd <= 0 )                                                       \
            {                                                                   \
                ret_val = ERR_UNKNOWN;                                          \
                LOG_ERR_EXT( ERR_UNKNOWN, ("invalid fd") );                     \
            }                                                                   \
                                                                                \
            if( ERR_NONE != ret_val && sec >= 0 )                               \
            {                                                                   \
                FD_ZERO(&write_fds);                                            \
                FD_SET(fd, &write_fds);                                         \
                tv.tv_sec = sec;                                                \
                tv.tv_usec = 0;                                                 \
                                                                                \
                ret_val = select(fd+1, NULL, &write_fds, NULL, &tv);            \
                if( ret_val > 0 && FD_ISSET(fd, &write_fds) )                   \
                {                                                               \
                    ret_val = ERR_NONE;                                         \
                }                                                               \
                else if( ret_val < 0 )                                          \
                {                                                               \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                    LOG_SYS_ERR( "select" );                                    \
                }                                                               \
                else if( 0 == ret_val )                                         \
                {                                                               \
                    ret_val = ERR_TIMEOUT;                                      \
                    if( sec > 0 )                                               \
                    {                                                           \
                        ret_val = ERR_TIMEOUT;                                  \
                        LOG_ERR_EXT( ERR_TIMEOUT, ("wait %d seconds to write time out", sec) ); \
                    }                                                           \
                    else                                                        \
                    {                                                           \
                        ret_val = ERR_UNKNOWN;                                  \
                        LOG_ERR_EXT( ERR_UNKNOWN, ("Can not write") );          \
                    }                                                           \
                }                                                               \
                else                                                            \
                {                                                               \
                    ret_val = ERR_UNKNOWN;                                      \
                }                                                               \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val )                                           \
            {                                                                   \
                write_len = write(fd, buf_a, buf_len);                          \
                if( write_len < 0 )                                             \
                {                                                               \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                    LOG_SYS_ERR( "write" );                                     \
                }                                                               \
                else if( write_len != buf_len )                                 \
                {                                                               \
                    ret_val = ERR_WRITE_NOT_COMPLETEDLY;                        \
                    LOG_WARNING( ("write not completed: to write(%d) != written(%d)", buf_len, write_len) ); \
                }                                                               \
            }                                                                   \
        } while(0);

/* Maybe the timer of select() is wrong, so here we check if it is really timeout. */
#define READ_DEVICE(ret_val, fd, read_buf_a, read_buf_size, read_len, sec)      \
        do                                                                      \
        {                                                                       \
            fd_set          read_fds;                                           \
            struct timeval  tv_read;                                            \
            struct timespec tp_select;                                          \
            struct timespec tp_now;                                             \
                                                                                \
            ret_val = ERR_NONE;                                                 \
                                                                                \
            if( fd <= 0 )                                                       \
            {                                                                   \
                ret_val = ERR_UNKNOWN;                                          \
                LOG_ERR_EXT( ERR_UNKNOWN, ("invalid fd") );                     \
            }                                                                   \
                                                                                \
            if( ERR_NONE != ret_val && sec >= 0 )                               \
            {                                                                   \
                tv_read.tv_sec = sec;                                           \
                tv_read.tv_usec = 0;                                            \
                                                                                \
                while(1)                                                        \
                {                                                               \
                    FD_ZERO( &read_fds );                                       \
                    FD_SET( fd, &read_fds );                                    \
                    clock_gettime(CLOCK_REALTIME, &tp_select);                  \
                    ret_val = select((fd + 1), &read_fds, NULL, NULL, &tv_read);    \
                    if( ret_val < 0 )                                           \
                    {                                                           \
                        LOG_SYS_ERR( "select" );                                \
                        ret_val = ERR_CALL_C_FUNC;                              \
                        break;                                                  \
                    }                                                           \
                    else if( 0 == ret_val )                                     \
                    {                                                           \
                        clock_gettime(CLOCK_REALTIME, &tp_now);                 \
                        if( tp_now.tv_sec < (tp_select.tv_sec + 1) )            \
                        {                                                       \
                            continue;                                           \
                        }                                                       \
                                                                                \
                        ret_val = ERR_CALL_C_FUNC;                              \
                        LOG_ERR_EXT(ERR_UNKNOWN, ("read time out: %ld:%ld -> %ld:%ld", tp_select.tv_sec, tp_select.tv_nsec, tp_now.tv_sec, tp_now.tv_nsec));    \
                        break;                                                  \
                    }                                                           \
                    else if( FD_ISSET(fd, &read_fds) )                          \
                    {                                                           \
                        ret_val = ERR_NONE;                                     \
                        break;                                                  \
                    }                                                           \
                    else                                                        \
                    {                                                           \
                        ret_val = ERR_UNKNOWN;                                  \
                        LOG_ERR_EXT(ERR_UNKNOWN, ("select OK, but fd is not ready")); \
                        break;                                                  \
                    }                                                           \
                }                                                               \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val )                                           \
            {                                                                   \
                memset( read_buf_a, 0x00, read_buf_size );                      \
                read_len = read(fd, read_buf_a, read_buf_size - 1);             \
                if( read_len < 0 )                                              \
                {                                                               \
                    LOG_SYS_ERR( "read" );                                      \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                }                                                               \
            }                                                                   \
        } while(0);

/* Description:
 *     Try to wirte data to device.
 * Parameter:
 *     ret_val          : out, result, "ERR_NONE" means OK
 *     fd               : in,  device description
 *     buf_a            : in,  data buffer
 *     buf_len          : in,  length of the data
 *     write_len        : out, length of the data that be written to device successfully
 *     sec              : in,  timeout(second) to check if the device can write
 *                             < 0 means do not check.
 *     msec             : in,  timeout(millisecond) to check if the device can write
 * Example:
 *     PUB_UTIL_WRITE_DEVICE( ret_val, fd, buf_a, buf_len, write_len, 10, 0 );
 *     PUB_UTIL_WRITE_DEVICE( ret_val, fd, buf_a, buf_len, write_len, -1, 0 );
 */
#define PUB_UTIL_WRITE_DEVICE(ret_val, fd, buf_a, buf_len, write_len, sec, msec) \
        do                                                                      \
        {                                                                       \
            fd_set          write_fds;                                          \
            struct timeval  tv_write;                                           \
                                                                                \
            ret_val = ERR_NONE;                                                 \
                                                                                \
            if( fd <= 0 )                                                       \
            {                                                                   \
                ret_val = ERR_UNKNOWN;                                          \
                LOG_ERR_EXT( ERR_UNKNOWN, ("invalid fd") );                     \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val && sec >= 0 )                               \
            {                                                                   \
                FD_ZERO(&write_fds);                                            \
                FD_SET(fd, &write_fds);                                         \
                tv_write.tv_sec = sec;                                          \
                tv_write.tv_usec = 0;                                           \
                if( msec >= 0 )                                                 \
                {                                                               \
                    tv_write.tv_usec = msec * 1000;                             \
                }                                                               \
                                                                                \
                ret_val = select(fd+1, NULL, &write_fds, NULL, &tv_write);      \
                if( ret_val > 0 && FD_ISSET(fd, &write_fds) )                   \
                {                                                               \
                    ret_val = ERR_NONE;                                         \
                }                                                               \
                else if( ret_val < 0 )                                          \
                {                                                               \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                    LOG_SYS_ERR( "select" );                                    \
                }                                                               \
                else if( 0 == ret_val )                                         \
                {                                                               \
                    ret_val = ERR_TIMEOUT;                                      \
                    if( sec > 0 )                                               \
                    {                                                           \
                        ret_val = ERR_TIMEOUT;                                  \
                        LOG_ERR_EXT( ERR_TIMEOUT, ("wait %d seconds to write time out", sec) ); \
                    }                                                           \
                    else                                                        \
                    {                                                           \
                        ret_val = ERR_UNKNOWN;                                  \
                        LOG_ERR_EXT( ERR_UNKNOWN, ("Can not write") );          \
                    }                                                           \
                }                                                               \
                else                                                            \
                {                                                               \
                    ret_val = ERR_UNKNOWN;                                      \
                }                                                               \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val )                                           \
            {                                                                   \
                write_len = write(fd, buf_a, buf_len);                          \
                if( write_len < 0 )                                             \
                {                                                               \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                    LOG_SYS_ERR( "write" );                                     \
                }                                                               \
                else if( (SINT32)write_len != (SINT32)buf_len )                 \
                {                                                               \
                    ret_val = ERR_WRITE_NOT_COMPLETEDLY;                        \
                    LOG_WARNING( ("write not completed: to write(%d) != written(%d)", buf_len, write_len) ); \
                }                                                               \
            }                                                                   \
        } while(0);

/* Description:
 *     Try to read data from device.
 * Parameter:
 *     ret_val          : out, result, "ERR_NONE" means OK
 *     fd               : in,  device description
 *     read_buf_a       : in,  buffer to store the data read from device
 *     read_buf_size    : in,  size of the data
 *     read_len         : out, length of the data that read from the device
 *     sec              : in,  timeout(second) to check if the device can read
 *                             < 0 means do not check.
 *     msec             : in,  timeout(millisecond) to check if the device can read
 * Example:
 *     PUB_UTIL_READ_DEVICE( ret_val, fd, read_buf_a, read_buf_size, read_len, 10, 0 );
 *     PUB_UTIL_READ_DEVICE( ret_val, fd, read_buf_a, read_buf_size, read_len, -1, 0 );
 * Note:
 *     Maybe the timer of select() is wrong, so here we check if it is really timeout by
 *     compare the time.
 */
/*#define PUB_UTIL_READ_DEVICE(ret_val, fd, read_buf_a, read_buf_size, read_len, sec, msec) \
        do                                                                      \
        {                                                                       \
            fd_set          read_fds;                                           \
            struct timeval  tv_read;                                            \
            struct timespec tp_select;                                          \
            struct timespec tp_now;                                             \
                                                                                \
            ret_val = ERR_NONE;                                                 \
                                                                                \
            if( fd <= 0 )                                                       \
            {                                                                   \
                ret_val = ERR_UNKNOWN;                                          \
                LOG_ERR_EXT( ERR_UNKNOWN, ("invalid fd") );                     \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val && sec >= 0 )                               \
            {                                                                   \
                tv_read.tv_sec = sec;                                           \
                tv_read.tv_usec = 0;                                            \
                if( msec >= 0 )                                                 \
                {                                                               \
                    tv_read.tv_usec = msec * 1000;                              \
                }                                                               \
                                                                                \
                while(1)                                                        \
                {                                                               \
                    FD_ZERO( &read_fds );                                       \
                    FD_SET( fd, &read_fds );                                    \
                    clock_gettime(CLOCK_REALTIME, &tp_select);                  \
                    ret_val = select((fd + 1), &read_fds, NULL, NULL, &tv_read);    \
                    if( ret_val < 0 )                                           \
                    {                                                           \
                        LOG_SYS_ERR( "select" );                                \
                        ret_val = ERR_CALL_C_FUNC;                              \
                        break;                                                  \
                    }                                                           \
                    else if( 0 == ret_val )                                     \
                    {                                                           \
                        clock_gettime(CLOCK_REALTIME, &tp_now);                 \
                        if( tp_now.tv_sec < (tp_select.tv_sec + 1) )            \
                        {                                                       \
                            continue;                                           \
                        }                                                       \
                                                                                \
                        ret_val = ERR_CALL_C_FUNC;                              \
                        LOG_ERR_EXT(ERR_UNKNOWN, ("read time out: %ld:%ld -> %ld:%ld", tp_select.tv_sec, tp_select.tv_nsec, tp_now.tv_sec, tp_now.tv_nsec));    \
                        break;                                                  \
                    }                                                           \
                    else if( FD_ISSET(fd, &read_fds) )                          \
                    {                                                           \
                        ret_val = ERR_NONE;                                     \
                        break;                                                  \
                    }                                                           \
                    else                                                        \
                    {                                                           \
                        ret_val = ERR_UNKNOWN;                                  \
                        LOG_ERR_EXT(ERR_UNKNOWN, ("select OK, but fd is not ready")); \
                        break;                                                  \
                    }                                                           \
                }                                                               \
            }                                                                   \
                                                                                \
            if( ERR_NONE == ret_val )                                           \
            {                                                                   \
                memset( read_buf_a, 0x00, read_buf_size );                      \
                read_len = read(fd, read_buf_a, read_buf_size - 1);             \
                if( read_len < 0 )                                              \
                {                                                               \
                    LOG_SYS_ERR( "read" );                                      \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                }                                                               \
            }                                                                   \
        } while(0);
*/
/* Description:
 *     Try to wirte data to device.
 * Parameter:
 *     fd               : in,  device description
 *     buf_ptr          : in,  data buffer
 *     buf_len          : in,  length of the data
 *     write_len        : out, length of the data that be written to device successfully
 *     try_count        : in,  if write not completedly, then try again
 *     interval         : in,  sleep time between writing, unit is millisecond
 * Example:
 *     PUB_UTIL_TRY_WRITE_DEVICE( fd, buf_ptr, buf_len, write_len, 5, 50, 0, 0 );
 */
#define PUB_UTIL_TRY_WRITE_DEVICE(fd, buf_ptr, buf_len, write_len, try_count, interval, sec, msec) \
        do                                                                      \
        {                                                                       \
            int     my_write_len = 0;                                           \
            int     i = 0;                                                      \
            long    sleep_time = interval * 1000;                               \
                                                                                \
            write_len = 0;                                                      \
            for( i=0; i<try_count; i++ )                                        \
            {                                                                   \
                my_write_len = write( fd, &buf_ptr[write_len], buf_len-write_len ); \
                if( my_write_len > 0 )                                          \
                {                                                               \
                    write_len += my_write_len;                                  \
                }                                                               \
                                                                                \
                if( (int)write_len >= (int)buf_len )                            \
                {                                                               \
                    break;                                                      \
                }                                                               \
                                                                                \
                if( sleep_time > 0 && i < try_count )                           \
                {                                                               \
                    LOG_INFO(("[sm info]sleep(%d)", i+1))                       \
                    usleep(sleep_time);                                         \
                }                                                               \
            }                                                                   \
                                                                                \
            if( write_len == buf_len )                                          \
            {                                                                   \
            }                                                                   \
            else if( write_len > 0 )                                            \
            {                                                                   \
                LOG_ERR_EXT( ERR_CALL_C_FUNC, ("write not completed: to write(%d) != written(%d)", buf_len, write_len) );   \
            }                                                                   \
            else                                                                \
            {                                                                   \
                LOG_SYS_ERR( "write" );                                         \
                write_len = -1;                                                 \
            }                                                                   \
        } while(0);

#define PUB_UTIL_READ_INT_FROM_FILE(ret_val, file_ptr, value)                   \
        do                                                                      \
        {                                                                       \
            FILE    *fp = NULL;                                                 \
                                                                                \
            ret_val = ERR_NONE;                                                 \
                                                                                \
            fp = fopen(file_ptr, "r");                                          \
            if( fp != NULL )                                                    \
            {                                                                   \
                ret_val = fscanf( fp, "%d", (int *)&value );                    \
                if( 1 == ret_val )                                              \
                {                                                               \
                    ret_val = ERR_NONE;                                         \
                }                                                               \
                else                                                            \
                {                                                               \
                    LOG_ERR_EXT( ERR_CALL_C_FUNC, ("fscanf() return: %d; %d - %s", ret_val, errno, strerror(errno)) ); \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                }                                                               \
                                                                                \
                fclose(fp);                                                     \
            }                                                                   \
            else                                                                \
            {                                                                   \
                LOG_ERR_EXT( ERR_CALL_C_FUNC, ("Open file \"%s\" fail: %d - %s", file_ptr, errno, strerror(errno)) ); \
                ret_val = ERR_CALL_C_FUNC;                                      \
            }                                                                   \
        }while(0);

#define PUB_UTIL_WRITE_INT_TO_FILE(ret_val, file_ptr, value)                    \
        do                                                                      \
        {                                                                       \
            FILE    *fp = NULL;                                                 \
                                                                                \
            ret_val = ERR_NONE;                                                 \
                                                                                \
            fp = fopen(file_ptr, "w");                                          \
            if( fp != NULL )                                                    \
            {                                                                   \
                ret_val = fprintf( fp, "%d", (int)value );                      \
                if( ret_val > 0 )                                               \
                {                                                               \
                    ret_val = ERR_NONE;                                         \
                }                                                               \
                else                                                            \
                {                                                               \
                    LOG_ERR_EXT( ERR_CALL_C_FUNC, ("fprintf() return: %d; %d - %s", ret_val, errno, strerror(errno)) ); \
                    ret_val = ERR_CALL_C_FUNC;                                  \
                }                                                               \
                                                                                \
                fclose(fp);                                                     \
            }                                                                   \
            else                                                                \
            {                                                                   \
                LOG_ERR_EXT( ERR_CALL_C_FUNC, ("Open file \"%s\" fail: %d - %s", file_ptr, errno, strerror(errno)) ); \
                ret_val = ERR_CALL_C_FUNC;                                      \
            }                                                                   \
        }while(0);

#define PUB_UTIL_SWAP_UINT32_LOW_HIGH(value)                                    \
        do                                                                      \
        {                                                                       \
            value = ((value << 24) & 0xFF000000)                                \
                    | ((value << 8) & 0x00FF0000)                               \
                    | ((value >> 8) & 0x0000FF00)                               \
                    | ((value >> 24) & 0x000000FF);                             \
        } while(0);

#define PUB_UTIL_SWAP_LOW_HIGH(value, len)                                      \
        do                                                                      \
        {                                                                       \
            UINT8   tmp_value = 0;                                              \
            UINT32  i = 0;                                                      \
            UINT8   *low_ptr = NULL;                                            \
            UINT8   *high_ptr = NULL;                                           \
                                                                                \
            for( i=0; i<len/2; i++ )                                            \
            {                                                                   \
                low_ptr = ((UINT8 *)(&value)) + len - i - 1;                    \
                high_ptr = ((UINT8 *)(&value)) + i;                             \
                memcpy( &tmp_value, low_ptr, 1 );                               \
                memcpy( low_ptr, high_ptr, 1 );                                 \
                memcpy( high_ptr, &tmp_value, 1 );                              \
            }                                                                   \
        } while(0);

#define PUB_UTIL_CALL_SYSTEM(ret_val, sys_cmd_a)                                \
        do                                                                      \
        {                                                                       \
            ret_val = system(sys_cmd_a);                                        \
            if( 0 == ret_val )                                                  \
            {                                                                   \
                ret_val = ERR_NONE;                                             \
            }                                                                   \
            else                                                                \
            {                                                                   \
                LOG_ERR_EXT(ERR_CALL_C_FUNC, ("error(%d) to exec: %s", ret_val, sys_cmd_a)); \
                ret_val = ERR_CALL_C_FUNC;                                      \
            }                                                                   \
        } while(0);

#ifdef WIN32
    #define STRNCMPI                            _strnicmp
    #define SNPRINTF                            _snprintf
#else
    #define STRNCMPI                            strncasecmp
    #define SNPRINTF                            snprintf
#endif



/*----------------------- constant and type definition -----------------------*/

typedef struct
{
    UINT32      m_total;                        /* total size(KB) */
    UINT32      m_used;                         /* used size(KB) */
    UINT32      m_available;                    /* available size(KB) */
} PUB_UTIL_DISK_INFO_ST;

typedef struct
{
    UINT8   m_month;
    UINT8   m_day;
    UINT8   m_hour;
    UINT8   m_min;
    UINT8   m_sec;
    ST_PADDING_3(1);
    UINT16  m_msec;
    UINT16  m_year;
} PUB_UTIL_DATE_TIME_ST;



/*--------------------------- variables definition ---------------------------*/



/*---------------------- function prototype declaration ----------------------*/

extern SINT32 pub_util_kill_thread(pthread_t *tid_ptr);
extern void pub_util_handle_thread_signal(int param);
extern SINT32 pub_util_set_fd_mode( int fd, BOOL is_nonblock_mode );
extern void pub_util_raise_process_priority( void );
extern const char *pub_util_get_sys_signal_info( int signal );
extern SINT32 pub_util_get_mount_fs_info( const char *disk_ptr, PUB_UTIL_DISK_INFO_ST *info_ptr );
extern SINT32 pub_util_send_at_and_wait_ok(int fd, const char *at_ptr, BOOL *is_ok_ptr);
extern SINT32 pub_util_set_serial_dev_attr( int fd, UINT32 speed );
extern SINT32 pub_util_get_pid_and_check_run(const char *pid_file_ptr, const char *name_ptr, BOOL *is_run_ptr, pid_t *pid_ptr);
//extern SINT32 pub_util_try_to_open_device(int *fd_ptr, const char *device_ptr, int flags, UINT32 try_count, UINT32 try_interval);
extern SINT32 pub_util_get_cmd_line(pid_t pid, char *cmd_line_ptr, UINT32 cmd_line_size);
extern SINT32 pub_util_get_process_path(char *cmd_path_ptr, UINT32 cmd_path_size);
extern void pub_util_print_at( const char *prompt_ptr, UINT8 *buf_ptr, UINT32 buf_len, BOOL is_end, BOOL is_time );
extern void pub_util_print_data( const char *prompt_ptr, UINT8 *buf_ptr, UINT32 buf_len, BOOL is_end, BOOL is_time );
extern SINT32 pub_util_create_pid_file(const char *name_ptr);
extern char *pub_util_get_hardware_name(void);
extern SINT32 pub_util_get_date_time(PUB_UTIL_DATE_TIME_ST *date_time_ptr);



#ifdef __cplusplus
}
#endif



#endif /* PUB_UTIL_H */
