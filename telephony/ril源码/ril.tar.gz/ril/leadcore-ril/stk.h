#ifndef __STK_H__
#define __STK_H__

#include "atchannel.h"
#include <telephony/ril.h>
#include <utils/Log.h>

#include "ata-stk.h"

#define STK_UNSOL_CMD_DEL_COUNT               6
#define STK_UNSOL_CMD_HEAD_COUNT              2
#define BUFFER_DATA_LEN                       400
#define ERROR_RETURN                          -1
#define CME_ERROR_NONE                        -1
#define SIM_RESET_RETURN                      1

//Add by guolei2@leadcoretech.com for L1811_Bug00001048   SIM/USIM CLA error START
#define CARD_CLASS_SIM              0xA0
#define CARD_CLASS_USIM         0x80
#define CARD_CLASS_OTHER        0x00
//Add by guolei2@leadcoretech.com for L1811_Bug00001048    SIM/USIM CLA error END

#define APDU_HEADER_TYPE_STR_LENGTH           2
#define TP_MR_STR_LENGTH                      2
#define DESTINATION_ADDRESS_OFFSET_INDEX      4
#define DESTINATION_ADDRESS_META_STR_LENGTH   4
#define TP_PID_STR_LENGTH                     2
#define TP_DCS_STR_LENGTH                     2

#define TP_VP_NOT_PRESENT                     0

#define TP_VP_RELATIVE_FORMAT                 2
#define TP_VP_RELATIVE_FORMAT_STR_OFFSET      2

#define TP_VP_ENHANCED_FORMAT                 1
#define TP_VP_ENHANCED_FORMAT_STR_OFFSET      14

#define TP_VP_ABSOLUTE_FORMAT                 3
#define TP_VP_ABSOLUTE_FORMAT_STR_OFFSET      14

typedef struct _SC_SMS_SUB_BYTE1_
{
    /* Bits 0,1 */
    UINT8   v_mti : 2;
    /* Bit 2 */
    UINT8   v_rd : 1;
    /* Bits 3,4 */
    UINT8   v_vpf : 2;
    /* Bit 5 */
    UINT8   v_srr : 1;
    /* Bit 6 */
    UINT8   v_udhi : 1;
    /* Bit 7 */
    UINT8   v_rp : 1;
} SC_SMS_SUB_BYTE1;

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
extern void requestStkSendTerminalResponse(void *data, size_t datalen, RIL_Token t);/* Leadcore: RIL_REQUEST_STK_SEND_TERMINAL_RESPONSE */
extern void requestStkSendEnvelopeCommand(void *data, size_t datalen, RIL_Token t);/* Leadcore: RIL_REQUEST_STK_SEND_ENVELOPE_COMMAND */
extern void handleStkProactiveCommand(const char *s, const char *sms_pdu);/* Leadcore: handle RIL_UNSOL_STK_PROACTIVE_COMMAND */
#ifdef __cplusplus
}
#endif

//Add by guolei2@leadcoretech.com START sim refresh for modem
SINT8 stk_send_terminal_response(UINT8 result, UINT8* rspData);
void  sendModemRefresh(void);
//Add by guolei2@leadcoretech.com END sim refresh for modem
#endif //__STK_H__
