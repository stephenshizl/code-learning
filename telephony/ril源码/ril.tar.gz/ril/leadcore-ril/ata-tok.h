/*******************************************************************************
 *                   COPYRIGHT LeadCore Technology CO., LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : ata-tok.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     :
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef ATA_TOK_H
#define ATA_TOK_H



/*-------------------------- include external file ---------------------------*/

#include "pub-sys.h"
#include "pub-aos.h"



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/



/*----------------------- constant and type definition -----------------------*/



/*--------------------------- variables definition ---------------------------*/



/*---------------------- function prototype declaration ----------------------*/

extern char *at_tok_req_end_str( void );
extern char *at_tok_rsp_begin_str( void );
extern char *at_tok_rsp_end_str( void );
extern char *at_tok_rsp_ok_str( void );

extern SINT32 at_tok_get_a_cmd_line( char *buf_ptr, UINT32 buf_len, char **begin_ptr, char **end_ptr, SINT8 is_first );
extern SINT32 at_tok_get_a_rsp_line( char *buf_ptr, UINT32 buf_len, char **begin_ptr, char **end_ptr, UINT32 *len_ptr );

extern SINT32 at_tok_parse( SINT8 **string_ptr, const char *type_ptr, va_list varpars );
extern SINT32 at_tok_parse_ext( SINT8 **string_ptr, char *type_ptr, ... );
extern SINT32 at_tok_parse_param_count( const char *buf_ptr, UINT32 buf_len );

extern SINT8 at_tok_is_final_rsp(const char *at_ptr);



#endif /* ATA_TOK_H */
