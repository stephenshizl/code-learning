#include <errno.h>
#define LOG_TAG "RIL"
#include <utils/Log.h>
#include <signal.h>
#include <time.h>
#include <string.h>
 
typedef void (*RIL_TIMER_EXPIRE_FUNC)(union sigval sv);
int ril_timer_create(timer_t *timer_id_ptr, RIL_TIMER_EXPIRE_FUNC expire_func, void *expire_para_ptr)
{
    int     ret_val = 0;
    struct sigevent ev;
 
    if(timer_id_ptr == NULL)
    {
        return -1;
    }
 
    memset(&ev, 0, sizeof(ev));
    ev.sigev_notify = SIGEV_THREAD;
    ev.sigev_signo = 0;
    ev.sigev_value.sival_ptr = expire_para_ptr;
    ev.sigev_notify_function = expire_func;
 
    ret_val = timer_create(CLOCK_REALTIME, &ev, timer_id_ptr);
    if( ret_val != 0 )
    {
        RLOGE("timer_create(): errno = %d(%s)", errno, strerror(errno));
        return -1;
    }
 
    return 0;
}

int ril_timer_stop(timer_t timer_id)
{
    struct itimerspec ts, ots;
    int ret_val = 0;
 
    ts.it_value.tv_sec     =  0;
    ts.it_value.tv_nsec    =  0;
    ts.it_interval.tv_sec  =  0;
    ts.it_interval.tv_nsec =  0;
 
    ret_val = timer_settime(timer_id, CLOCK_REALTIME, &ts, &ots);
    if( 0 == ret_val )
    {
        return 0;
    }
    else
    {
        RLOGE("timer_settime(): errno = %d(%s)", errno, strerror(errno));
        return -1;
    }
}
 
int ril_timer_delete(timer_t timer_id)
{
    int ret_val = 0;
 
    ril_timer_stop(timer_id);
 
    ret_val = timer_delete(timer_id);
    if( 0 == ret_val )
    {
        RLOGD("ril_timer_delete success!");
        return 0;
    }
    else
    {
        RLOGE("timer_delete(): errno = %d(%s)", errno, strerror(errno));
        return -1;
    }
}
 
int ril_timer_start(timer_t timer_id, long interval)
{
    struct itimerspec ts, ots;
    int     ret_val = 0;
 
    ts.it_value.tv_sec  = interval/1000;
    ts.it_value.tv_nsec = (interval%1000)*1000*1000;
    ts.it_interval.tv_sec  = 0;
    ts.it_interval.tv_nsec = 0;
 
    ret_val = timer_settime(timer_id, CLOCK_REALTIME, &ts, &ots);
    if( 0 == ret_val )
    {
        RLOGD("ril_timer_start success!");
        return 0;
    }
    else
    {
        RLOGE("timer_settime(): errno = %d(%s)", errno, strerror(errno));
        return -1;
    }
} 
