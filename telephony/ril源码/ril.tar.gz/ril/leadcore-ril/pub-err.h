/*******************************************************************************
 *          COPYRIGHT DATANG MOBILE COMMUNICATIONS EQUIPMENT CO.,LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : pub-err.h
 * Version  :
 * Purpose  :
 * Authors  :
 * Date     : 2008.09.26
 * Notes    : This file is automatically created, don't edit it!
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef PUB_ERR_H
#define PUB_ERR_H



#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */



typedef enum
{
    ERR_NONE                                                            = 0,       /* No error */
                                                                   
    ERR_BEGIN                                                           = -100,
    ERR_UNKNOWN                                                         = -100,    /* Unknown error */
    ERR_INVALID_PARAM                                                   = -101,    /* Invalid parameter */
    ERR_PARAM_POINTER_NULL                                              = -102,    /* Parameter pointer is null */
    ERR_INVALID_PARAM_VALUE                                             = -103,    /* Invalid parameter value */
    ERR_NOT_FOUND                                                       = -104,    /* Not found */
    ERR_NOT_READY                                                       = -111,    /* Not ready */
    ERR_TIMEOUT                                                         = -113,    /* Timeout */
    ERR_UNKNOWN_OPER                                                    = -116,    /* Unknown operation */
    ERR_EXCEED_MAX_SIZE                                                 = -117,    /* Exceed max size */
    ERR_CALL_C_FUNC                                                     = -118,    /* Call C function unsuccessfully */
    ERR_WRITE_NOT_COMPLETEDLY                                           = -119,    /* Write() not completedly */
    ERR_IPV4V6_PDP_NOT_SUPPORT                               = -121,  /*IPv4v6 is not recognized by network*/
    ERR_SERVICE_NOT_SUBSCRIBED                               =-122,    /*requested service option not subscribed*/

    AT_ERR_BEGIN                                                        = -600,
    AT_ERR_MUX                                                          = -600,    /* for "\r\nERROR\r\n" */
    AT_ERR_INIT_MUX_FAILED                                              = -601,    /* can not initialize mux */
    AT_ERR_DEINIT_MUX_FAILED                                            = -602,    /* can not de-initialize mux */
    AT_ERR_OPEN_MUX_PORT_FAILED                                         = -603,    /* can not open mux port */
    AT_ERR_CLOSE_MUX_PORT_FAILED                                        = -604,    /* can not close mux port */
    AT_ERR_NO_IDLE_MUX_PORT                                             = -605,    /* No idle mux port */
    AT_ERR_MUX_RSP_TIMEOUT                                              = -606,    /* mux response timeout */
} ASP_ERR_CODE_EN;



#ifdef __cplusplus
}
#endif



#endif /* PUB_ERR_H */
