#include "ata-ps-util.h"

#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netpacket/packet.h>
#include <net/if_arp.h>
#include <netinet/in.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <telephony/ril.h>
#include "pub-log.h"
#include <utils/Log.h>
#include "netutils/ifc.h"


#define MFLAG_ON                128
#define OFLAG_ON                64
#define AUTOCONF_ON             1
#define AUTOCONF_OFF            0
#define DEFAULT_PREFIX_LEN      64
#define DEFAULT_PREFIX_COLON_LEN  5
#define EXPAND_PREFIX_LEN       128
#define NDP_RA_PRO              "sys.ndp_ra"

#define ATA_PS_IPV6_RA_RETRY_MAX_COUNT		15

static const int NAP_TIME = 50;

extern PDP_INFO_ST *ps_get_pdp_info_by_pdp_cid( UINT8 pdp_cid );
extern SINT32 ps_get_pdp_state(UINT8 pdp_cid);

extern int property_set(const char *key, const char *value);
extern int property_get(const char *key, char *value, const char *default_value);

typedef struct NetlinkList
{
    struct NetlinkList *m_next;
    struct nlmsghdr *m_data;
    unsigned int m_size;
} NetlinkList;




static SINT32 char_count(const char * str,char c)
{
	int i=0;
	int str_len=0;
	int count=0;
	if((NULL == str) || (!strlen(str))) return 0;
	str_len = strlen(str);
	for(i=0;i < str_len;i++)
	{
		if(c == str[i]) count++;
											
	}
	return count;
}	
static SINT32 get_ipv6_prefix_addr(char * ra_addr,char * prefix_addr,int len)
{
       uint32_t * h1=NULL;
       uint32_t * h2=NULL;
       uint32_t * h3=NULL;
       uint32_t * h4=NULL;

	struct in6_addr ra_addr6 ;

       if(!ra_addr||!prefix_addr)
       		return -1;

       if(len < PDP_IP_ADDR_LENGTH_IPV6)
       		return -1;

	inet_pton(AF_INET6, ra_addr, &ra_addr6);
	
       h1 = (uint32_t *) (&ra_addr6);
       h2 = (uint32_t *) (&ra_addr6)+1;
       h3 = (uint32_t *) (&ra_addr6)+2;
       h4 = (uint32_t *) (&ra_addr6)+3;
	
       *h3 = 0;
       *h4 = 0;
	
	inet_ntop(AF_INET6, &ra_addr6, prefix_addr, PDP_IP_ADDR_LENGTH_IPV6);
	RLOGD("[RIL-PS][get_ipv6_prefix_addr] ra_addr %s  prefix_addr is  %s", ra_addr,prefix_addr);
       return 0;
}


static SINT32 ril_wait_for_ra_propery(const char *name,const char *desired_value,int maxwait)
{
    char value[256] = {'\0'};
    int maxnaps = (maxwait * 1000) / NAP_TIME;

    if (maxnaps < 1)
    {
        maxnaps = 1;
    }

    while (maxnaps-- > 0)
    {
        if (property_get(name, value, NULL))
        {
            if (desired_value == NULL)
            {
                if (value != NULL && strcmp(value, "obtaining"))
                    return 0;
            }
            else if (strcmp(value, desired_value) == 0)
            {
                return 0;
            }
        }
        usleep(NAP_TIME * 1000);
    }
    return -1;
}


static void set_lmi_ipv6_accept_ra(char *iface,int flag)
{
    char cmdline[128] = {0};
    if(NULL == iface) return ;
    snprintf(cmdline,sizeof(cmdline),"echo %d > /proc/sys/net/ipv6/conf/%s/accept_ra",flag,iface);
    system(cmdline);
}


static void set_lmi_ipv6_autoconf(char *iface,int flag)
{
    char cmdline[256] = {0};
    if(NULL == iface) return ;
    snprintf(cmdline,sizeof(cmdline),"echo %d > /proc/sys/net/ipv6/conf/%s/autoconf",flag,iface);
    system(cmdline);
}


static void del_lmi_ipv6_addr(char *iface,char *addr,int len)
{
    char cmdline[256] = {0};
    if((NULL == iface) || (NULL == addr)) return ;
    snprintf(cmdline,sizeof(cmdline),"ip -6 addr del %s/%d dev %s",addr,len,iface);
    RLOGD("[RIL-PS]MIFI del ipv6 add =%s",cmdline);
    system(cmdline);
}


static void del_lmi_ipv6_route(char *iface,char *route,int prefix)
{
    char cmdline[256] = {0};
    if((NULL == iface) || (NULL == route)) return ;
    snprintf(cmdline,sizeof(cmdline),"ip -6 route del %s/%d dev %s",route,prefix,iface);
    RLOGD("[RIL-PS]MIFI del route %s",cmdline);
    system(cmdline);
}



static void get_ra_flag(int *mflag,int *oflag)
{
    char cmdbuf[256] = {0};
    char cmdvalue[256] = {0};
    if((NULL == mflag) || (NULL == oflag)) return ;
    snprintf(cmdbuf,sizeof(cmdbuf),"%s.mflag",NDP_RA_PRO);
    property_get(cmdbuf,cmdvalue,NULL);
    *mflag = atoi(cmdvalue);
    memset(cmdbuf,0,sizeof(cmdbuf));
    snprintf(cmdbuf,sizeof(cmdbuf),"%s.oflag",NDP_RA_PRO);
    property_get(cmdbuf,cmdvalue,NULL);
    *oflag = atoi(cmdvalue);
}



static int get_pdp_interface_id(char *interface_id,char *interface_len,char *iface)
{
    char cmd[128] = {0};
    if(NULL == interface_id) return -1;
    snprintf(cmd,sizeof(cmd),"%s.pdp.interface_id",iface);
    property_get(cmd,interface_id,NULL);
    memset(cmd,0,sizeof(cmd));
    snprintf(cmd,sizeof(cmd),"%s.pdp.interface_len",iface);
    property_get(cmd,interface_len,NULL);
    return 0;
}


static void set_inteface_static_ipv6_addr(char *value,char *iface,int prefix_len)
{
    char cmd[256] = {0};
    if((NULL == value) || (NULL == iface)) return ;
    snprintf(cmd,sizeof(cmd),"ip -6 addr add %s/%d dev %s",value,prefix_len,iface);
    system(cmd);
    RLOGD("[RIL-PS] 1860_MIFI set lmi40 IPV6 addr  %s",cmd);
}



static int netlink_socket(void)
{
    int l_socket = socket(PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    if(l_socket < 0)
    {
        return -1;
    }

    struct sockaddr_nl l_addr;
    memset(&l_addr, 0, sizeof(l_addr));
    l_addr.nl_family = AF_NETLINK;
    if(bind(l_socket, (struct sockaddr *)&l_addr, sizeof(l_addr)) < 0)
    {
        close(l_socket);
        return -1;
    }

    return l_socket;
}

static int netlink_send(int p_socket, int p_request)
{
    struct
    {
        struct nlmsghdr m_hdr;
        struct rtgenmsg m_msg;
    } l_data;

    memset(&l_data, 0, sizeof(l_data));

    l_data.m_hdr.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtgenmsg));
    l_data.m_hdr.nlmsg_type = p_request;
    l_data.m_hdr.nlmsg_flags = NLM_F_ROOT | NLM_F_MATCH | NLM_F_REQUEST;
    l_data.m_hdr.nlmsg_pid = 0;
    l_data.m_hdr.nlmsg_seq = p_socket;
    l_data.m_msg.rtgen_family = AF_UNSPEC;

    struct sockaddr_nl l_addr;
    memset(&l_addr, 0, sizeof(l_addr));
    l_addr.nl_family = AF_NETLINK;
    return (sendto(p_socket, &l_data.m_hdr, l_data.m_hdr.nlmsg_len, 0, (struct sockaddr *)&l_addr, sizeof(l_addr)));
}

static int netlink_recv(int p_socket, void *p_buffer, size_t p_len)
{
    struct msghdr l_msg;
    struct iovec l_iov = { p_buffer, p_len };
    struct sockaddr_nl l_addr;

    for(;;)
    {
        l_msg.msg_name = (void *)&l_addr;
        l_msg.msg_namelen = sizeof(l_addr);
        l_msg.msg_iov = &l_iov;
        l_msg.msg_iovlen = 1;
        l_msg.msg_control = NULL;
        l_msg.msg_controllen = 0;
        l_msg.msg_flags = 0;
        int l_result = recvmsg(p_socket, &l_msg, 0);

        if(l_result < 0)
        {
            if(errno == EINTR)
            {
                continue;
            }
            return -2;
        }

        if(l_msg.msg_flags & MSG_TRUNC)
        {
            // buffer was too small
            return -1;
        }
        return l_result;
    }
}

static struct nlmsghdr *getNetlinkResponse(int p_socket, int *p_size, int *p_done)
{
    size_t l_size = 4096;
    void *l_buffer = NULL;

    for(;;)
    {
        free(l_buffer);
        l_buffer = malloc(l_size);
        if (l_buffer == NULL)
        {
            return NULL;
        }

        int l_read = netlink_recv(p_socket, l_buffer, l_size);
        *p_size = l_read;
        if(l_read == -2)
        {
            free(l_buffer);
            return NULL;
        }
        if(l_read >= 0)
        {
            pid_t l_pid = getpid();
            struct nlmsghdr *l_hdr;
            for(l_hdr = (struct nlmsghdr *)l_buffer; NLMSG_OK(l_hdr, (unsigned int)l_read); l_hdr = (struct nlmsghdr *)NLMSG_NEXT(l_hdr, l_read))
            {
                if((pid_t)l_hdr->nlmsg_pid != l_pid || (int)l_hdr->nlmsg_seq != p_socket)
                {
                    continue;
                }

                if(l_hdr->nlmsg_type == NLMSG_DONE)
                {
                    *p_done = 1;
                    break;
                }

                if(l_hdr->nlmsg_type == NLMSG_ERROR)
                {
                    free(l_buffer);
                    return NULL;
                }
            }
            return l_buffer;
        }

        l_size *= 2;
    }
}

static NetlinkList *newListItem(struct nlmsghdr *p_data, unsigned int p_size)
{
    NetlinkList *l_item = malloc(sizeof(NetlinkList));
    if (l_item == NULL)
    {
        return NULL;
    }

    l_item->m_next = NULL;
    l_item->m_data = p_data;
    l_item->m_size = p_size;
    return l_item;
}

static void freeResultList(NetlinkList *p_list)
{
    NetlinkList *l_cur;
    while(p_list)
    {
        l_cur = p_list;
        p_list = p_list->m_next;
        free(l_cur->m_data);
        free(l_cur);
    }
}

static NetlinkList *getResultList(int p_socket, int p_request)
{
    if(netlink_send(p_socket, p_request) < 0)
    {
        return NULL;
    }

    NetlinkList *l_list = NULL;
    NetlinkList *l_end = NULL;
    int l_size;
    int l_done = 0;
    while(!l_done)
    {
        struct nlmsghdr *l_hdr = getNetlinkResponse(p_socket, &l_size, &l_done);
        if(!l_hdr)
        {
            // error
            freeResultList(l_list);
            return NULL;
        }

        NetlinkList *l_item = newListItem(l_hdr, l_size);
        if (!l_item)
        {
            freeResultList(l_list);
            return NULL;
        }
        if(!l_list)
        {
            l_list = l_item;
        }
        else
        {
            l_end->m_next = l_item;
        }
        l_end = l_item;
    }
    return l_list;
}

static size_t maxSize(size_t a, size_t b)
{
    return (a > b ? a : b);
}

static size_t calcAddrLen(sa_family_t p_family, int p_dataSize)
{
    switch(p_family)
    {
    case AF_INET:
        return sizeof(struct sockaddr_in);
    case AF_INET6:
        return sizeof(struct sockaddr_in6);
    case AF_PACKET:
        return maxSize(sizeof(struct sockaddr_ll), offsetof(struct sockaddr_ll, sll_addr) + p_dataSize);
    default:
        return maxSize(sizeof(struct sockaddr), offsetof(struct sockaddr, sa_data) + p_dataSize);
    }
}

static void makeSockaddr(sa_family_t p_family, struct sockaddr *p_dest, void *p_data, size_t p_size)
{
    switch(p_family)
    {
    case AF_INET:
        memcpy(&((struct sockaddr_in *)p_dest)->sin_addr, p_data, p_size);
        break;
    case AF_INET6:
        memcpy(&((struct sockaddr_in6 *)p_dest)->sin6_addr, p_data, p_size);
        break;
    case AF_PACKET:
        memcpy(((struct sockaddr_ll *)p_dest)->sll_addr, p_data, p_size);
        ((struct sockaddr_ll *)p_dest)->sll_halen = p_size;
        break;
    default:
        memcpy(p_dest->sa_data, p_data, p_size);
        break;
    }
    p_dest->sa_family = p_family;
}

static void addToEnd(struct ifaddrs **p_resultList, struct ifaddrs *p_entry)
{
    if(!*p_resultList)
    {
        *p_resultList = p_entry;
    }
    else
    {
        struct ifaddrs *l_cur = *p_resultList;
        while(l_cur->ifa_next)
        {
            l_cur = l_cur->ifa_next;
        }
        l_cur->ifa_next = p_entry;
    }
}

static int interpretLink(struct nlmsghdr *p_hdr, struct ifaddrs **p_resultList)
{
    struct ifinfomsg *l_info = (struct ifinfomsg *)NLMSG_DATA(p_hdr);

    size_t l_nameSize = 0;
    size_t l_addrSize = 0;
    size_t l_dataSize = 0;

    size_t l_rtaSize = NLMSG_PAYLOAD(p_hdr, sizeof(struct ifinfomsg));
    struct rtattr *l_rta;
    for(l_rta = IFLA_RTA(l_info); RTA_OK(l_rta, l_rtaSize); l_rta = RTA_NEXT(l_rta, l_rtaSize))
    {
        void *l_rtaData = RTA_DATA(l_rta);
        size_t l_rtaDataSize = RTA_PAYLOAD(l_rta);
        switch(l_rta->rta_type)
        {
        case IFLA_ADDRESS:
        case IFLA_BROADCAST:
            l_addrSize += NLMSG_ALIGN(calcAddrLen(AF_PACKET, l_rtaDataSize));
            break;
        case IFLA_IFNAME:
            l_nameSize += NLMSG_ALIGN(l_rtaSize + 1);
            break;
        case IFLA_STATS:
            l_dataSize += NLMSG_ALIGN(l_rtaSize);
            break;
        default:
            break;
        }
    }

    struct ifaddrs *l_entry = malloc(sizeof(struct ifaddrs) + sizeof(int) + l_nameSize + l_addrSize + l_dataSize);
    if (l_entry == NULL)
    {
        return -1;
    }
    memset(l_entry, 0, sizeof(struct ifaddrs));
    l_entry->ifa_name = "";

    char *l_index = ((char *)l_entry) + sizeof(struct ifaddrs);
    char *l_name = l_index + sizeof(int);
    char *l_addr = l_name + l_nameSize;
    char *l_data = l_addr + l_addrSize;

    // save the interface index so we can look it up when handling the addresses.
    memcpy(l_index, &l_info->ifi_index, sizeof(int));

    l_entry->ifa_flags = l_info->ifi_flags;

    l_rtaSize = NLMSG_PAYLOAD(p_hdr, sizeof(struct ifinfomsg));
    for(l_rta = IFLA_RTA(l_info); RTA_OK(l_rta, l_rtaSize); l_rta = RTA_NEXT(l_rta, l_rtaSize))
    {
        void *l_rtaData = RTA_DATA(l_rta);
        size_t l_rtaDataSize = RTA_PAYLOAD(l_rta);
        switch(l_rta->rta_type)
        {
        case IFLA_ADDRESS:
        case IFLA_BROADCAST:
        {
            size_t l_addrLen = calcAddrLen(AF_PACKET, l_rtaDataSize);
            makeSockaddr(AF_PACKET, (struct sockaddr *)l_addr, l_rtaData, l_rtaDataSize);
            ((struct sockaddr_ll *)l_addr)->sll_ifindex = l_info->ifi_index;
            ((struct sockaddr_ll *)l_addr)->sll_hatype = l_info->ifi_type;
            if(l_rta->rta_type == IFLA_ADDRESS)
            {
                l_entry->ifa_addr = (struct sockaddr *)l_addr;
            }
            else
            {
                l_entry->ifa_broadaddr = (struct sockaddr *)l_addr;
            }
            l_addr += NLMSG_ALIGN(l_addrLen);
            break;
        }
        case IFLA_IFNAME:
            strncpy(l_name, l_rtaData, l_rtaDataSize);
            l_name[l_rtaDataSize] = '\0';
            l_entry->ifa_name = l_name;
            break;
        case IFLA_STATS:
            memcpy(l_data, l_rtaData, l_rtaDataSize);
            l_entry->ifa_data = l_data;
            break;
        default:
            break;
        }
    }

    addToEnd(p_resultList, l_entry);
    return 0;
}

static struct ifaddrs *findInterface(int p_index, struct ifaddrs **p_links, int p_numLinks)
{
    int l_num = 0;
    struct ifaddrs *l_cur = *p_links;
    while(l_cur && l_num < p_numLinks)
    {
        char *l_indexPtr = ((char *)l_cur) + sizeof(struct ifaddrs);
        int l_index;
        memcpy(&l_index, l_indexPtr, sizeof(int));
        if(l_index == p_index)
        {
            return l_cur;
        }

        l_cur = l_cur->ifa_next;
        ++l_num;
    }
    return NULL;
}

static int interpretAddr(struct nlmsghdr *p_hdr, struct ifaddrs **p_resultList, int p_numLinks)
{
    struct ifaddrmsg *l_info = (struct ifaddrmsg *)NLMSG_DATA(p_hdr);
    struct ifaddrs *l_interface = findInterface(l_info->ifa_index, p_resultList, p_numLinks);

    if(l_info->ifa_family == AF_PACKET)
    {
        return 0;
    }

    size_t l_nameSize = 0;
    size_t l_addrSize = 0;

    int l_addedNetmask = 0;

    size_t l_rtaSize = NLMSG_PAYLOAD(p_hdr, sizeof(struct ifaddrmsg));
    struct rtattr *l_rta;
    for(l_rta = IFA_RTA(l_info); RTA_OK(l_rta, l_rtaSize); l_rta = RTA_NEXT(l_rta, l_rtaSize))
    {
        void *l_rtaData = RTA_DATA(l_rta);
        size_t l_rtaDataSize = RTA_PAYLOAD(l_rta);

        switch(l_rta->rta_type)
        {
        case IFA_ADDRESS:
        case IFA_LOCAL:
            if((l_info->ifa_family == AF_INET || l_info->ifa_family == AF_INET6) && !l_addedNetmask)
            {
                // make room for netmask
                l_addrSize += NLMSG_ALIGN(calcAddrLen(l_info->ifa_family, l_rtaDataSize));
                l_addedNetmask = 1;
            }
        case IFA_BROADCAST:
            l_addrSize += NLMSG_ALIGN(calcAddrLen(l_info->ifa_family, l_rtaDataSize));
            break;
        case IFA_LABEL:
            l_nameSize += NLMSG_ALIGN(l_rtaSize + 1);
            break;
        default:
            break;
        }
    }

    struct ifaddrs *l_entry = malloc(sizeof(struct ifaddrs) + l_nameSize + l_addrSize);
    if (l_entry == NULL)
    {
        return -1;
    }
    memset(l_entry, 0, sizeof(struct ifaddrs));
    l_entry->ifa_name = (l_interface ? l_interface->ifa_name : "");

    char *l_name = ((char *)l_entry) + sizeof(struct ifaddrs);
    char *l_addr = l_name + l_nameSize;

    l_entry->ifa_flags = l_info->ifa_flags;
    if(l_interface)
    {
        l_entry->ifa_flags |= l_interface->ifa_flags;
    }

    l_rtaSize = NLMSG_PAYLOAD(p_hdr, sizeof(struct ifaddrmsg));
    for(l_rta = IFA_RTA(l_info); RTA_OK(l_rta, l_rtaSize); l_rta = RTA_NEXT(l_rta, l_rtaSize))
    {
        void *l_rtaData = RTA_DATA(l_rta);
        size_t l_rtaDataSize = RTA_PAYLOAD(l_rta);
        switch(l_rta->rta_type)
        {
        case IFA_ADDRESS:
        case IFA_BROADCAST:
        case IFA_LOCAL:
        {
            size_t l_addrLen = calcAddrLen(l_info->ifa_family, l_rtaDataSize);
            makeSockaddr(l_info->ifa_family, (struct sockaddr *)l_addr, l_rtaData, l_rtaDataSize);
            if(l_info->ifa_family == AF_INET6)
            {
                if(IN6_IS_ADDR_LINKLOCAL((struct in6_addr *)l_rtaData) || IN6_IS_ADDR_MC_LINKLOCAL((struct in6_addr *)l_rtaData))
                {
                    ((struct sockaddr_in6 *)l_addr)->sin6_scope_id = l_info->ifa_index;
                }
            }

            if(l_rta->rta_type == IFA_ADDRESS)
            {
                // apparently in a point-to-point network IFA_ADDRESS contains the dest address and IFA_LOCAL contains the local address
                if(l_entry->ifa_addr)
                {
                    l_entry->ifa_dstaddr = (struct sockaddr *)l_addr;
                }
                else
                {
                    l_entry->ifa_addr = (struct sockaddr *)l_addr;
                }
            }
            else if(l_rta->rta_type == IFA_LOCAL)
            {
                if(l_entry->ifa_addr)
                {
                    l_entry->ifa_dstaddr = l_entry->ifa_addr;
                }
                l_entry->ifa_addr = (struct sockaddr *)l_addr;
            }
            else
            {
                l_entry->ifa_broadaddr = (struct sockaddr *)l_addr;
            }
            l_addr += NLMSG_ALIGN(l_addrLen);
            break;
        }
        case IFA_LABEL:
            strncpy(l_name, l_rtaData, l_rtaDataSize);
            l_name[l_rtaDataSize] = '\0';
            l_entry->ifa_name = l_name;
            break;
        default:
            break;
        }
    }

    if(l_entry->ifa_addr && (l_entry->ifa_addr->sa_family == AF_INET || l_entry->ifa_addr->sa_family == AF_INET6))
    {
        unsigned l_maxPrefix = (l_entry->ifa_addr->sa_family == AF_INET ? 32 : 128);
        unsigned l_prefix = (l_info->ifa_prefixlen > l_maxPrefix ? l_maxPrefix : l_info->ifa_prefixlen);
        char l_mask[16] = {0};
        unsigned i;
        for(i = 0; i < (l_prefix / 8); ++i)
        {
            l_mask[i] = 0xff;
        }
        if(l_prefix % 8)
        {
            l_mask[i] = 0xff << (8 - (l_prefix % 8));
        }

        makeSockaddr(l_entry->ifa_addr->sa_family, (struct sockaddr *)l_addr, l_mask, l_maxPrefix / 8);
        l_entry->ifa_netmask = (struct sockaddr *)l_addr;
    }

    addToEnd(p_resultList, l_entry);
    return 0;
}

static int interpretLinks(int p_socket, NetlinkList *p_netlinkList, struct ifaddrs **p_resultList)
{
    int l_numLinks = 0;
    pid_t l_pid = getpid();
    for(; p_netlinkList; p_netlinkList = p_netlinkList->m_next)
    {
        unsigned int l_nlsize = p_netlinkList->m_size;
        struct nlmsghdr *l_hdr;
        for(l_hdr = p_netlinkList->m_data; NLMSG_OK(l_hdr, l_nlsize); l_hdr = NLMSG_NEXT(l_hdr, l_nlsize))
        {
            if((pid_t)l_hdr->nlmsg_pid != l_pid || (int)l_hdr->nlmsg_seq != p_socket)
            {
                continue;
            }

            if(l_hdr->nlmsg_type == NLMSG_DONE)
            {
                break;
            }

            if(l_hdr->nlmsg_type == RTM_NEWLINK)
            {
                if(interpretLink(l_hdr, p_resultList) == -1)
                {
                    return -1;
                }
                ++l_numLinks;
            }
        }
    }
    return l_numLinks;
}

static int interpretAddrs(int p_socket, NetlinkList *p_netlinkList, struct ifaddrs **p_resultList, int p_numLinks)
{
    pid_t l_pid = getpid();
    for(; p_netlinkList; p_netlinkList = p_netlinkList->m_next)
    {
        unsigned int l_nlsize = p_netlinkList->m_size;
        struct nlmsghdr *l_hdr;
        for(l_hdr = p_netlinkList->m_data; NLMSG_OK(l_hdr, l_nlsize); l_hdr = NLMSG_NEXT(l_hdr, l_nlsize))
        {
            if((pid_t)l_hdr->nlmsg_pid != l_pid || (int)l_hdr->nlmsg_seq != p_socket)
            {
                continue;
            }

            if(l_hdr->nlmsg_type == NLMSG_DONE)
            {
                break;
            }

            if(l_hdr->nlmsg_type == RTM_NEWADDR)
            {
                if (interpretAddr(l_hdr, p_resultList, p_numLinks) == -1)
                {
                    return -1;
                }
            }
        }
    }
    return 0;
}

int getifaddrs(struct ifaddrs **ifap)
{
    if(!ifap)
    {
        return -1;
    }
    *ifap = NULL;

    int l_socket = netlink_socket();
    if(l_socket < 0)
    {
        return -1;
    }

    NetlinkList *l_linkResults = getResultList(l_socket, RTM_GETLINK);
    if(!l_linkResults)
    {
        close(l_socket);
        return -1;
    }

    NetlinkList *l_addrResults = getResultList(l_socket, RTM_GETADDR);
    if(!l_addrResults)
    {
        close(l_socket);
        freeResultList(l_linkResults);
        return -1;
    }

    int l_result = 0;
    int l_numLinks = interpretLinks(l_socket, l_linkResults, ifap);
    if(l_numLinks == -1 || interpretAddrs(l_socket, l_addrResults, ifap, l_numLinks) == -1)
    {
        l_result = -1;
    }

    freeResultList(l_linkResults);
    freeResultList(l_addrResults);
    close(l_socket);
    return l_result;
}

void freeifaddrs(struct ifaddrs *ifa)
{
    struct ifaddrs *l_cur;
    while(ifa)
    {
        l_cur = ifa;
        ifa = ifa->ifa_next;
        free(l_cur);
    }
}




SINT32 ps_get_ra_ipv6_addr_by_mode(UINT8 pdp_cid, char *ra_addr,UINT8 mode)
{
    struct ifaddrs *ifa, *p;
    int family;
    int ret = ERR_UNKNOWN;
    char *local_addr=NULL;
    char *iface=NULL;
    PDP_INFO_ST *pdp_info_ptr = NULL;

    struct in6_addr multicast_addr6 ;

    if (!ra_addr )
    {
        RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode]  ra_addr and iface can't be NULL!");
        return ERR_INVALID_PARAM;
    }

    RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode] pdp_cid is %d", pdp_cid);
    /* Check if the pdp is already activated. */
    pdp_info_ptr = ps_get_pdp_info_by_pdp_cid( pdp_cid );
    if(!pdp_info_ptr )
    {
        RLOGD("[RIL-PS]ps_get_ra_ipv6_addr_by_mode] cid get pdp info failed" );
        return ERR_INVALID_PARAM;
    }
    local_addr = pdp_info_ptr->pdp_network_info.ipv6_link_local_addr;
    iface = pdp_info_ptr->ifname;

    pdp_info_ptr->pdp_network_info.ipv6_prefix_len = 64;

    if(mode == AUTOCONF_ON)
    {
        struct in6_addr local_addr6 ;

        inet_pton(AF_INET6, local_addr, &local_addr6);

        int wait_count = 0;
        for (wait_count = 0; wait_count < ATA_PS_IPV6_RA_RETRY_MAX_COUNT; wait_count++)
        {

            if(ps_get_pdp_state(pdp_cid) == PDP_DEACTIVED)
            {
                RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode] pdp %d is DEACTIVED",pdp_cid);
                return ERR_UNKNOWN;
            }
        
            if (getifaddrs(&ifa))
            {
                RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode] getifaddrs error");
                return ERR_INVALID_PARAM;
            }

            for (p = ifa; p != NULL ; p = p->ifa_next)
            {

                if(p->ifa_name == NULL)
                {
                    continue;
                }

                if(p->ifa_addr == NULL)
                {
                    continue;
                }

                family = p->ifa_addr->sa_family;

               // RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode] ifa_name = %s, family = 0x%X(%s)", p->ifa_name, family,
               //       (family == AF_PACKET) ? "AF_PACKET" :
               //       (family == AF_INET) ?   "AF_INET" :
               //       (family == AF_INET6) ?  "AF_INET6" : "");

                /* Just check IPv6 address */
                if (family != AF_INET6)
                {
                    continue;
                }

                multicast_addr6 = ((struct sockaddr_in6 *)(p->ifa_addr))->sin6_addr;

                if (!strcmp(iface, p->ifa_name) && (!IN6_IS_ADDR_LINKLOCAL(&multicast_addr6)))
                {
                    if(IN6_ARE_INTERFACE_ADDR_EQUAL(&multicast_addr6, &local_addr6))
                    {
                        if (inet_ntop(AF_INET6, &multicast_addr6, ra_addr, PDP_IP_ADDR_LENGTH_IPV6))
                        {
                            char prefix_addr[PDP_IP_ADDR_LENGTH_IPV6]={0};    /*ipv6  prefix_addr */
                            RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode] find out %s's linklocal IPv6 address: %s", iface, ra_addr);
                            freeifaddrs(ifa);
                             ret = get_ipv6_prefix_addr(ra_addr,prefix_addr,PDP_IP_ADDR_LENGTH_IPV6);
                             if(ret<0)
                             {
                                RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode] get_ipv6_prefix_addr");
                                return ERR_UNKNOWN;
                             }
                             else
                             {
                                del_lmi_ipv6_route(iface, prefix_addr,DEFAULT_PREFIX_LEN);
                                return ERR_NONE;
                            }
                        }
                    }
                }
            }
            freeifaddrs(ifa);
            RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode] update ra ipv6 addr faile, count is %d" , wait_count);
            sleep(1);
        }
    }
    else//(mode == AUTOCONF_OFF)
    {
        char prop_name[256] ={0};
        char prop_value[256] ={0};
        char cmdbuf[256] ={0};
        char cmdvalue[256] ={0};
        char prefix[128] ={0};
        char prefix_len[128] ={0};
        char interface_id[128] ={0};
        char interface_len[128] ={0};
        int mflag =-1;
        int oflag =-1;
        char * dev_name = iface;
	int count=0;


	snprintf(prop_name,sizeof(prop_name),"setprop  %s.pdp.interface_id %s",dev_name,pdp_info_ptr->pdp_network_info.ipv6_interface_id);
	RLOGD("[RIL-PS] JACK cmd1 =%s",prop_name);
	system(prop_name);
	
	memset(prop_name,0,sizeof(prop_name));
	snprintf(prop_name,sizeof(prop_name),"setprop  %s.pdp.interface_len %d",dev_name,strlen(pdp_info_ptr->pdp_network_info.ipv6_interface_id));
	system(prop_name);
	 RLOGD("[RIL-PS] JACK cmd2 =%s",prop_name);

	
	memset(prop_name,0,sizeof(prop_name));
	snprintf(prop_name,sizeof(prop_name),"setprop  %s.pdp.dns1 %s",dev_name,pdp_info_ptr->pdp_network_info.ipv6_dns1);
	system(prop_name);
	 RLOGD("[RIL-PS] JACK cmd3 =%s",prop_name);
	 
	memset(prop_name,0,sizeof(prop_name));
	snprintf(prop_name,sizeof(prop_name),"setprop  %s.pdp.dns2 %s",dev_name,pdp_info_ptr->pdp_network_info.ipv6_dns2);
	system(prop_name);
	 RLOGD("[RIL-PS] JACK cmd4 =%s",prop_name);

        
        snprintf(prop_name,sizeof(prop_name),"%s.RA.result",NDP_RA_PRO);

        for(count=0;count<ATA_PS_IPV6_RA_RETRY_MAX_COUNT;count++ ) 
        {
		if(ps_get_pdp_state(pdp_cid) == PDP_DEACTIVED)
		{
	            RLOGD("[RIL-PS][ps_get_ra_ipv6_addr_by_mode] pdp %d is DEACTIVED",pdp_cid);
	            return ERR_UNKNOWN;
		}
        
	        if(ril_wait_for_ra_propery(prop_name, NULL, 1) <0)
	        {
	            RLOGD("[RIL-PS][MIFI_1860] wait timeout %d",count );
	        }
        }
        
        if(!property_get(prop_name,prop_value,NULL))
        {
            RLOGD("[RIL-PS][MIFI_1860] wait error" );
        }
        else
        {
            if(!strcmp(prop_value,"ok"))
            {
                get_ra_flag(&mflag, &oflag);
                if(MFLAG_ON == mflag)
                {
                    /* get prefix from dhcpv6_pd */
                    snprintf(cmdbuf,sizeof(cmdbuf),"net.pd.%s.prefix",dev_name);
                    property_get(cmdbuf,prefix,NULL);
                    RLOGD("[RIL-PS] 1860_MIFI getprop prefix %s",prefix);
                    memset(cmdbuf,0,sizeof(cmdbuf));
                    snprintf(cmdbuf,sizeof(cmdbuf),"net.pd.%s.plen",dev_name);
                    property_get(cmdbuf,prefix_len,NULL);
                    RLOGD("[RIL-PS] 1860_MIFI getprop prefix_len %s",prefix_len);
                }
                else
                {
                    /* get prefix from icmpv6 RA packet */
                    snprintf(cmdbuf,sizeof(cmdbuf),"%s.prefix_len",NDP_RA_PRO);
                    property_get(cmdbuf,prefix_len, NULL);
                    RLOGD("[RIL-PS] 1860_MIFI getprop prefix_len %s",prefix_len);
                    memset(cmdbuf,0,sizeof(cmdbuf));
                    snprintf(cmdbuf,sizeof(cmdbuf),"%s.prefix_addr",NDP_RA_PRO);
                    property_get(cmdbuf,prefix, NULL);
                    RLOGD("[RIL-PS] 1860_MIFI getprop prefix %s",prefix);
                }
                /* get interface_id form PDP */
                get_pdp_interface_id(interface_id, interface_len, dev_name);
                RLOGD("[RIL-PS] 1860_MIFI getprop interface_id   %s",interface_id);
                if(strlen(interface_id) && strlen(interface_len))
                {
                    if(atoi(prefix_len) >=DEFAULT_PREFIX_LEN)
                    {
                        char tmp[128] = {0};
                        int count=0;
                        memcpy(tmp,prefix,sizeof(tmp));
                        count = char_count(tmp,':');
                        if(DEFAULT_PREFIX_COLON_LEN == count)
                        {
                        	tmp[strlen(tmp)-1]='\0';
                        }
			
                        snprintf(cmdvalue,sizeof(cmdvalue),"%s%s",tmp,interface_id);
                        RLOGD("[RIL-PS] 1860_MIFI cmdvalue  %s",cmdvalue);
                        del_lmi_ipv6_route(dev_name, prefix,atoi(prefix_len));
                        memcpy(ra_addr,cmdvalue,PDP_IP_ADDR_LENGTH_IPV6);
                        pdp_info_ptr->pdp_network_info.ipv6_prefix_len = atoi(prefix_len);
                        set_inteface_static_ipv6_addr(ra_addr ,dev_name,pdp_info_ptr->pdp_network_info.ipv6_prefix_len);
                        return ERR_NONE;
                    }
                }

            }
            else
            {
                RLOGD("[RIL-PS] 1860_MIFI set lmi autoconf ON");
            }
        }
    }
    return ERR_UNKNOWN;
}


SINT32 ps_get_ra_ipv6_addr(UINT8 pdp_cid, char *ra_addr)
{
    SINT32 ret= ERR_NONE;
    ret = ps_get_ra_ipv6_addr_by_mode(pdp_cid, ra_addr ,AUTOCONF_ON);
    if (ERR_NONE != ret)
    {
        ret = ps_get_ra_ipv6_addr_by_mode(pdp_cid, ra_addr ,AUTOCONF_OFF);;
    }
    return ret;
}


BOOL ps_check_lmi_ip_exist(char *iface)
{
    struct ifaddrs *ifa, *p;
    int family;
    BOOL if_ip_exist = FALSE;

    struct in6_addr multicast_addr6 ;

    if (!iface)
    {
        RLOGD("[RIL-PS][ps_check_lmi_ip_exist]  iface can't be NULL!");
        return FALSE;
    }


    if (getifaddrs(&ifa))
    {
        RLOGD("[RIL-PS][ps_check_lmi_ip_exist] getifaddrs error");
        return TRUE;//tread this case as  ip exist
    }

    for (p = ifa; p != NULL ; p = p->ifa_next)
    {

        if(p->ifa_name == NULL)
        {
            continue;
        }

        if(p->ifa_addr == NULL)
        {
            continue;
        }


        family = p->ifa_addr->sa_family;


        RLOGD("[RIL-PS][ps_check_lmi_ip_exist] ifa_name = %s, family = 0x%X(%s)", p->ifa_name, family,
              (family == AF_PACKET) ? "AF_PACKET" :
              (family == AF_INET) ?   "AF_INET" :
              (family == AF_INET6) ?  "AF_INET6" : "");

        if (!strcmp(iface, p->ifa_name))
        {
            RLOGD("[RIL-PS][ps_check_lmi_ip_exist] find ip on %s", iface);
            if_ip_exist = TRUE;
            break;
        }

    }

    freeifaddrs(ifa);

    RLOGD("[RIL-PS][ps_check_lmi_ip_exist] return %d", if_ip_exist);

    return if_ip_exist;

}

void ps_set_ra_auto_mode(char *iface,BOOL flag)
{
    if(!iface)
    {
    	return;
    }

    if(flag)
    {
        set_lmi_ipv6_autoconf(iface,AUTOCONF_ON);
        set_lmi_ipv6_accept_ra(iface, AUTOCONF_ON);
    }
    else
    {
        set_lmi_ipv6_autoconf(iface,AUTOCONF_OFF);
        set_lmi_ipv6_accept_ra(iface, AUTOCONF_OFF);
    }
}

