/* //device/system/reference-ril/atchannel.c
**
** Copyright 2006, The Android Open Source Project
**
** Licensed under the Apache License, Version 2.0 (the "License");
** you may not use this file except in compliance with the License.
** You may obtain a copy of the License at
**
**     http://www.apache.org/licenses/LICENSE-2.0
**
** Unless required by applicable law or agreed to in writing, software
** distributed under the License is distributed on an "AS IS" BASIS,
** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
** See the License for the specific language governing permissions and
** limitations under the License.
*/

#include "atchannel.h"
#include "at_tok.h"

#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <ctype.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>

//Add for Multi channel, by chenchi 2011-02-16  start
#include <termios.h>
#include <telephony/ril.h>
#include <telephony/multichannel.h>
//Add for Multi channel, by chenchi 2011-02-16  end

#include <sys/system_properties.h>

#define LOG_NDEBUG 0
#define LOG_TAG "XT_RIL_AT"
#include <utils/Log.h>

#include "misc.h"

#ifdef HAVE_PTHREAD_COND_TIMEDWAIT_RELATIVE
#define USE_NP 1
#endif /* HAVE_PTHREAD_COND_TIMEDWAIT_RELATIVE */


#define NUM_ELEMS(x) (sizeof(x)/sizeof(x[0]))
#define MAX_AT_RESPONSE (8 * 1024)
#define HANDSHAKE_RETRY_COUNT 8
#define HANDSHAKE_TIMEOUT_MSEC 250

static pthread_t s_tid_reader;
static int s_fd = -1;    /* fd of the AT channel */
static ATUnsolHandler s_unsolHandler;

/* for input buffering */

static char s_ATBuffer[MAX_AT_RESPONSE+1]="";//chenchi add
static char *s_ATBufferCur = s_ATBuffer;


// add by leadcore for MSMS
static int s_simid = 0;
 
#define RESET_PROCESS_SIGNAL    12
#define MAX_TIMEOUT_COUNT 3
static int g_timeoutCount = 0;
static int g_ReadCount = 0;

static const struct timeval TIMEVAL_RESET = {0,500000};
extern void requestResetModemCallback(const struct timeval *relativeTime);
extern void requestAtTimeOutCallback(const struct timeval *relativeTime);
//Add for Multi channel, by chenchi 2011-02-16  start

const char *at_ch_name[] = {
    DEV_CHANNEL1,
    DEV_CHANNEL2,
    DEV_CHANNEL3,
    DEV_CHANNEL4,
    DEV_CHANNEL5,
    DEV_CHANNEL6,
    DEV_CHANNEL7,
    DEV_CHANNEL8,
    DEV_CHANNEL9,
    DEV_CHANNEL10,
    DEV_CHANNEL11,
    DEV_CHANNEL12,
    DEV_CHANNEL13,
    DEV_CHANNEL14,
    DEV_CHANNEL15,
    DEV_CHANNEL16
};

Ril_requestAtSender s_ATSender[RIL_DEVICE_MAX_COUNT];

Ril_requestAtSender * trans_request_param(void) {
    RLOGD("====:%s - %s() - Line:%d  " , __FILE__, __func__, __LINE__ );

    return s_ATSender;
}

extern int property_get(const char *key, char *value, const char *default_value);
extern int strrpl(char*s, char a, char b);

Ril_requestAtSender *sp_request_param;
static int s_max_fd;

extern int g_modemtype_s;


char readBuf[MAX_AT_RESPONSE];
char procBuf[MAX_AT_RESPONSE];
char smsBuf[MAX_AT_RESPONSE];//added by wyy 0613
static int sms_flag = 0;//added by wyy 0613
int sms_cmd_len;//added by wyy 0613

#define DB_MCH 0 /*For multi channel debug*/
//Add for Multi channel, by chenchi 2011-02-16  end

#define DB_CMD 0 /*For debug the cmd info*/
#define DB_CMD_DETAIL 0 /*For detail debug the cmd info*/
#define DBBD(l,s) {if (l) s;}

struct sockaddr_in remote_addr;
int remote_len = sizeof(struct sockaddr);

#if AT_DEBUG
void  AT_DUMP(const char*  prefix, const char*  buff, int  len)
{
    if (len < 0)
        len = strlen(buff);
    RLOGD("[panda:wyy_AT_DUMP]%.*s", len, buff);
}
#endif

/*
 * for current pending command
 * these are protected by s_commandmutex
 */

/*FOR Multi at channel*/
static pthread_mutex_t s_commandmutex[RIL_DEVICE_MAX_COUNT] = {PTHREAD_COND_INITIALIZER};

static pthread_cond_t s_commandcond[RIL_DEVICE_MAX_COUNT] = {PTHREAD_MUTEX_INITIALIZER};

static ATCommandType s_type;
static const char *s_responsePrefix = NULL;
static const char *s_smsPDU = NULL;
static ATResponse *sp_response = NULL;

static void (*s_onTimeout)(void) = NULL;
static void (*s_onReaderClosed)(void) = NULL;
static int s_readerClosed = 1;

static void onReaderClosed();
static int writeCtrlZ (const char *s, int m);
//static int writeline (const char *s, int m);
static int writeSpecCtrlZ (int m);

#ifndef USE_NP
static void setTimespecRelative(struct timespec *p_ts, long long msec)
{
    struct timeval tv;

    gettimeofday(&tv, (struct timezone *) NULL);

    /* what's really funny about this is that I know
       pthread_cond_timedwait just turns around and makes this
       a relative time again */
    p_ts->tv_sec = tv.tv_sec + (msec / 1000);
    p_ts->tv_nsec = (tv.tv_usec + (msec % 1000) * 1000L ) * 1000L;
}
#endif /*USE_NP*/

static void sleepMsec(long long msec)
{
    struct timespec ts;
    int err;

    ts.tv_sec = (msec / 1000);
    ts.tv_nsec = (msec % 1000) * 1000 * 1000;

    do {
        err = nanosleep (&ts, &ts);
    } while (err < 0 && errno == EINTR);
}

void write_flag_file_by_rilId(char *enable, int rilId)
{
    char propString[32] = {0};

    sprintf(propString, RIL_MODEM_EXCEP_FLAG"%d", rilId);
    RLOGD("write_flag_file_by_rilId(), property string = %s", propString);
    __system_property_set(propString, enable);
    RLOGD("write_flag_file_by_rilId(), set property: %s = %s success", propString, enable);
}

void onResetModem()
{
    RLOGD("onResetModem(), linkId = %d", s_simid);
    write_flag_file_by_rilId("1", s_simid);
    kill(getpid(), RESET_PROCESS_SIGNAL);
}

/** add an intermediate response to sp_response*/
static void addIntermediate(const char *line, int m)
{
    ATLine *p_new;

    p_new = (ATLine  *) malloc(sizeof(ATLine));

    p_new->line = strdup(line);

    /* note: this adds to the head of the list, so the list
       will be in reverse order of lines received. the order is flipped
       again before passing on to the command issuer */
    p_new->p_next = (sp_request_param[m].mp_response)->p_intermediates;
    (sp_request_param[m].mp_response)->p_intermediates = p_new;
}


/**
 * returns 1 if line is a final response indicating error
 * See 27.007 annex B
 * WARNING: NO CARRIER and others are sometimes unsolicited
 */
static const char * s_finalResponsesError[] = {
    "ERROR",
    "+CMS ERROR:",
    "+CME ERROR:",
/*Fixed Bug00000179,Couldn't return normal while Enter airplane mode int Calling, add by chenchi,2011-2-14*/
//    "NO CARRIER", /* sometimes! */
    "NO ANSWER",
    "NO DIALTONE",
};
static int isFinalResponseError(const char *line)
{
    size_t i;

    for (i = 0 ; i < NUM_ELEMS(s_finalResponsesError) ; i++) {
        if (strStartsWith(line, s_finalResponsesError[i])) {
            return 1;
        }
    }

    return 0;
}

/**
 * returns 1 if line is a final response indicating success
 * See 27.007 annex B
 * WARNING: NO CARRIER and others are sometimes unsolicited
 */
static const char * s_finalResponsesSuccess[] = {
    "OK",
    "CONNECT"       /* some stacks start up data on another channel */
};
static int isFinalResponseSuccess(const char *line)
{
    size_t i;

    for (i = 0 ; i < NUM_ELEMS(s_finalResponsesSuccess) ; i++) {
        if (strStartsWith(line, s_finalResponsesSuccess[i])) {
            return 1;
        }
    }

    return 0;
}

/**
 * returns 1 if line is a final response, either  error or success
 * See 27.007 annex B
 * WARNING: NO CARRIER and others are sometimes unsolicited
 */
static int isFinalResponse(const char *line)
{
    return isFinalResponseSuccess(line) || isFinalResponseError(line);
}


/**
 * returns 1 if line is the first line in (what will be) a two-line
 * SMS unsolicited response
 */
static const char * s_smsUnsoliciteds[] = {
    "+CMT:",
    "+CDS:",
    "+CBM:"
};
static int isSMSUnsolicited(const char *line)
{
    size_t i;

    for (i = 0 ; i < NUM_ELEMS(s_smsUnsoliciteds) ; i++) {
        if (strStartsWith(line, s_smsUnsoliciteds[i])) {
            return 1;
        }
    }

    return 0;
}


/** assumes s_commandmutex is held */
static void handleFinalResponse(const char *line, int m)
{
    sp_request_param[m].mp_response->finalResponse = strdup(line);
    //RLOGD("==thread_id :%d,fd=%d,m=%d",sp_request_param[m].m_thread_id,sp_request_param[m].m_fd,m);
    pthread_cond_signal(&s_commandcond[m]);
}

static void handleUnsolicited(const char *line)
{
    if (s_unsolHandler != NULL) {
        s_unsolHandler(line, NULL);
    }
}

//add by zss 20110509 for Req00000322
int strInLline(const char *line, const char *str)
{
    char *p_first = NULL;
    if ((str == NULL)||(line == NULL)) {
        return 0;
    }
    p_first = strstr(line, str);
    if(p_first == NULL)
        return 0;
    else
        return 1;
}
//add end

static void processLine(const char *line, int m)
{
    pthread_mutex_lock(&s_commandmutex[m]);
    DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
    RLOGD("%s, mp_response = %p, mp_response->success = %d, m_type = %d, \n", 
        __FUNCTION__,
        sp_request_param[m].mp_response, 
        sp_request_param[m].mp_response != NULL?sp_request_param[m].mp_response->success:0,
        sp_request_param[m].m_type);
    if (sp_request_param[m].mp_response == NULL) {
        /* no command pending */
        handleUnsolicited(line);
    } else if (isFinalResponseSuccess(line)) {
        sp_request_param[m].mp_response->success = 1;
        handleFinalResponse(line, m);
    } else if (isFinalResponseError(line)) {
        sp_request_param[m].mp_response->success = 0;
        handleFinalResponse(line, m);
    } else if (sp_request_param[m].m_smsPDU != NULL && 0 == strcmp(line, "> ")) {
        // See eg. TS 27.005 4.3
        // Commands like AT+CMGS have a "> " prompt
        int ret = writeCtrlZ(sp_request_param[m].m_smsPDU,m);
		RLOGD("Process line SMS, ret = %d", ret);
		if(0==ret)
			sp_request_param[m].mp_response->success = 1;
		else
			sp_request_param[m].mp_response->success = 0;

        sp_request_param[m].m_smsPDU = NULL;
    } else if (sp_request_param[m].m_smsPDU  == NULL && 0 == strcmp(line, "> ")) {
        // See eg. TS 27.005 4.3
        // Commands like AT+CMGS have a "> " prompt
        int ret = writeSpecCtrlZ(m);
		if(0==ret)
			sp_request_param[m].mp_response->success = 1;
		else
			sp_request_param[m].mp_response->success = 0;
    } else switch (sp_request_param[m].m_type) {
        case NO_RESULT:
            handleUnsolicited(line);
            break;
        case NUMERIC:
            if (sp_request_param[m].mp_response->p_intermediates == NULL && isdigit(line[0])) {
                addIntermediate(line, m);
            } else {
                /* either we already have an intermediate response or
                   the line doesn't begin with a digit */
                handleUnsolicited(line);
            }
            break;
        case SINGLELINE:
            if ((sp_request_param[m].mp_response)->p_intermediates == NULL
                && strStartsWith (line, sp_request_param[m].m_responsePrefix)) {
                DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
                addIntermediate(line, m);
            } else {
                DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
                /* we already have an intermediate response */
                handleUnsolicited(line);
            }
            break;
        case MULTILINE:
            if (strStartsWith (line, sp_request_param[m].m_responsePrefix)) {
                DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
                addIntermediate(line, m);
                DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
            } else {
                DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
                handleUnsolicited(line);
                DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
            }
            break;
//add by zss 20110509 for Req00000322
        case MULTILINE_1:
            if (strInLline (line, "AT^")) {
                DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
                addIntermediate(line, m);
            } else if(0==strcmp(line, "^DDBTRACE: 0,1,")) {
                RLOGD("equal");
                addIntermediate(line, m);                    
            }                            
            break;
//add end
        default: /* this should never be reached */
            RLOGE("Unsupported AT command type %d\n", sp_request_param[m].m_type);
            handleUnsolicited(line);
            break;
    }

    pthread_mutex_unlock(&s_commandmutex[m]);
}


/**
 * Returns a pointer to the end of the next line
 * special-cases the "> " SMS prompt
 *
 * returns NULL if there is no complete line
 */
static char * findNextEOL(char *cur)
{
    if (cur[0] == '>' && cur[1] == ' ' && cur[2] == '\0') {
        /* SMS prompt character...not \r terminated */
        return cur+2;
    }

    // Find next newline
    while (*cur != '\0' && *cur != '\r' && *cur != '\n') cur++;

    /*Fixed Bug00001488, by chenchi 2011-04-06*/
    //return *cur == '\0' ? NULL : cur;
    return cur;
}


/**
 * Reads a line from the AT channel, returns NULL on timeout.
 * Assumes it has exclusive read access to the FD
 *
 * This line is valid only until the next call to readline
 *
 * This function exists because as of writing, android libc does not
 * have buffered stdio.
 */

static const char *readline()
{
    ssize_t count;

    char *p_read = NULL;
    char *p_eol = NULL;
    char *ret;
    DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
    /* this is a little odd. I use *s_ATBufferCur == 0 to
     * mean "buffer consumed completely". If it points to a character, than
     * the buffer continues until a \0
     */
    if (*s_ATBufferCur == '\0') {
        /* empty buffer */
        s_ATBufferCur = s_ATBuffer;
        *s_ATBufferCur = '\0';
        p_read = s_ATBuffer;
    } else {   /* *s_ATBufferCur != '\0' */
        /* there's data in the buffer from the last read */

        // skip over leading newlines
        while (*s_ATBufferCur == '\r' || *s_ATBufferCur == '\n')
            s_ATBufferCur++;

        p_eol = findNextEOL(s_ATBufferCur);

        if (p_eol == NULL) {
            /* a partial line. move it up and prepare to read more */
            size_t len;

            len = strlen(s_ATBufferCur);

            memmove(s_ATBuffer, s_ATBufferCur, len + 1);
            p_read = s_ATBuffer + len;
            s_ATBufferCur = s_ATBuffer;
        }
        /* Otherwise, (p_eol !- NULL) there is a complete line  */
        /* that will be returned the while () loop below        */
    }

    while (p_eol == NULL) {
        if (0 == MAX_AT_RESPONSE - (p_read - s_ATBuffer)) {
            RLOGE("ERROR: Input line exceeded buffer\n");
            /* ditch buffer and start over again */
            s_ATBufferCur = s_ATBuffer;
            *s_ATBufferCur = '\0';
            p_read = s_ATBuffer;
        }

        do {
            DBBD(DB_CMD,RLOGD("%d, %s\n",__LINE__,__FUNCTION__));			
#ifdef  AT_CHANNEL_UDP
			// RLOGD("[panda:wyy] recvfrom called",0);	
            count=recvfrom(s_fd, p_read, MAX_AT_RESPONSE - (p_read - s_ATBuffer),0,(struct sockaddr *)&remote_addr,(socklen_t*)&remote_len);
#else
			count = read(s_fd, p_read, MAX_AT_RESPONSE - (p_read - s_ATBuffer));
#endif
			DBBD(DB_CMD,RLOGD("count=%zd,p_read = %s, err:%s\n", count,p_read,strerror(errno)));

#if  DB_CMD_DETAIL
			int k=0;
			for(k=0; k< count;k++) {
				DBBD(1,RLOGD("__pread[%d] = %c",k,p_read[k]));
			}
#endif
        } while (count < 0 && errno == EINTR);

 /*Deal with: \x00<CR><LF>ERROR<CR><LF>\x00\x00\x00\x00...*/
        if (count > 0) {
            if(0x00 == p_read[0]
                && '\r' == p_read[1]
                && '\n' == p_read[2]
                && 'E' == p_read[3]
                && 'R' == p_read[4]
                && 'R' == p_read[5]
                && 'O' == p_read[6]
                && 'R' == p_read[7]
                && '\r' == p_read[8]
                && '\n' == p_read[9])
            {
            	   DBBD(DB_CMD,RLOGD("___JUST for error response"));
                memmove(&p_read[0], &p_read[1], 9);
                count = 9;
            }

            AT_DUMP( "<< ", p_read, count );

            p_read[count] = '\0';

            // skip over leading newlines
            while (*s_ATBufferCur == '\r' || *s_ATBufferCur == '\n')
                s_ATBufferCur++;

            p_eol = findNextEOL(s_ATBufferCur);
            p_read += count;
        } else if (count <= 0) {
            /* read error encountered or EOF reached */
            if(count == 0) {
                RLOGD("atchannel: EOF reached");
            } else {
                RLOGD("atchannel: read error %s", strerror(errno));
            }
            return NULL;
        }
    }

    /* a full line in the buffer. Place a \0 over the \r and return */

    ret = s_ATBufferCur;
    *p_eol = '\0';
    s_ATBufferCur = p_eol + 1; /* this will always be <= p_read,    */
                              /* and there will be a \0 at *p_read */

    RLOGD("AT< %s\n", ret);
    return ret;
}


static void onReaderClosed()
{
    if (s_onReaderClosed != NULL && s_readerClosed == 0) {

        int m = 0;
        for(m = 0; m < RIL_DEVICE_MAX_COUNT; m++) {
            pthread_mutex_lock(&s_commandmutex[m]);

            s_readerClosed = 1;

            pthread_cond_signal(&s_commandcond[m]);

            pthread_mutex_unlock(&s_commandmutex[m]);
        }

        s_onReaderClosed();
    }
}

static void at_buffer_handler(int n)
{
    int read_num;
//    static int g_read_time = 0;
    char broadcastAtLevel[2] = {'\0'};
    char strbuf[200] = {0};
    char* temp = NULL;
	
#ifdef AT_CHANNEL_UDP
		read_num=recvfrom(sp_request_param[n].m_fd, readBuf, MAX_AT_RESPONSE,0,(struct sockaddr *)&remote_addr,(socklen_t*)&remote_len);
#else
    read_num = read(sp_request_param[n].m_fd, readBuf, MAX_AT_RESPONSE);
#endif
    //DBBD(DB_MCH, RLOGD("at buffer handler, read_num = %d", read_num));
    readBuf[read_num] = '\0';
    //DBBD(DB_MCH, RLOGD("at buffer handler, sp_request_param[%d].m_fd = %d", n, sp_request_param[n].m_fd));
    if(read_num > 0)
    {
        char *processBuf = readBuf;
		RLOGD("[wyy_0613]read_num =%d, Total processBuf:%s",read_num,processBuf);
        DBBD(DB_MCH, RLOGD("read_num =%d, Total processBuf:%s",read_num,processBuf));

        while(processBuf < (readBuf + read_num))
        {
            //RLOGD("____read_num =%d,Total processBuf : %s, line=%d\n",read_num,processBuf,__LINE__);

            while (*processBuf == '\r' || *processBuf == '\n')
                processBuf++;

            char *tmpBuf = findNextEOL(processBuf);

            if(tmpBuf == NULL)
            {
                break;
            }
            else if(tmpBuf > readBuf + read_num) /* skip these buffer */
            {
                RLOGE("in read cmd thrd, find end rn met a mistake");
                break;
            }

            //cmdLen is the length of one piece of cmd
            int cmdLen = tmpBuf - processBuf;
            if(0 >= cmdLen) break;
			RLOGD("[wyy_0613 cmdLen = %d\n]",cmdLen);

            strncpy(procBuf, processBuf, cmdLen);
            procBuf[cmdLen] = '\0';

            if (!strStartsWith(procBuf, "^SCPBR:"))
                RLOGD("AT<[%d] %s\n", n, procBuf);
            property_get("sys.xt.broadcast.at.level", broadcastAtLevel, "0");
            if(0 == strcmp(broadcastAtLevel, "1")) {
                if(strstr(procBuf, " ")) {
                    temp = strdup(procBuf);
                    strrpl(temp, ' ', '!');
                }
                snprintf(strbuf,
                     sizeof(strbuf)-1,
                     "am broadcast -a android.intent.action.InfoCommand.result --ei channle_id %d --ei direction %d --es ats %s ",
                     n,1,temp == NULL ? procBuf : temp);
                system(strbuf);
                if(temp != NULL) {
                    free(temp);
                }
             }
			if(isSMSUnsolicited(procBuf))
			{
				sms_cmd_len = read_num;
				sms_flag = 1;
				strncpy(smsBuf, procBuf, sms_cmd_len);
				RLOGD("[wyy_0613]smsBuf = %s\n",smsBuf);
				break;
			}

            //RLOGD("____cmdLen=%d,content: %s, %d, %s\n",cmdLen,procBuf,__LINE__,__FUNCTION__);

            if(sms_flag == 1) {
                char *line1;
                //const char *line2;
                char line2[1024];

                // The scope of string returned by 'readline()' is valid only
                // till next call to 'readline()' hence making a copy of line
                // before calling readline again.
                //line1 = strdup(procBuf);
                
				line1 = strdup(smsBuf);

                //procBuf += cmdLen;

               // while (*procBuf == '\r' || *procBuf == '\n')
                    //    procBuf++;
                char *tmpBuf1 = findNextEOL(procBuf);

                int cmdLen1 = tmpBuf1 - procBuf;
                //RLOGD("cmd len is %d", cmdLen1);

                strncpy(line2, procBuf, cmdLen1);
                line2[cmdLen1] = '\0';
                //RLOGD("____cmdLen1=%d,The SMS content : %s, %d, %s\n",cmdLen1,line2,__LINE__,__FUNCTION__);
                RLOGD("AT<[%d] %s\n", n, line2);

                if (line2[0] == '\0') {
					RLOGD("SMSUnsolicited have no pdu !");
                    free(line1);
                    break;
                }

                if (s_unsolHandler != NULL) {
                    s_unsolHandler (line1, line2);
                }
                free(line1);
				sms_flag = 0;
				memset(smsBuf, 0, MAX_AT_RESPONSE);
            } else {
                //RLOGD("processLine,m=%d,procBuf : %s",m,procBuf);
                processLine(procBuf,n);
            }

            //skip one cmd
            processBuf +=  (cmdLen + 0); //original is 2, to deal with:  \r\nABCD\r\n1234\r\n
            memset(procBuf, 0, MAX_AT_RESPONSE);
        }//end of while

        memset(readBuf, 0, MAX_AT_RESPONSE);
    }
    else if(read_num == 0)
    {
        g_ReadCount++;
        if(g_ReadCount < 10) {
            RLOGE("There is no data read from the device, g_ReadCount = %d !!!!!", g_ReadCount);
            RLOGE("at_buffer_handler, sp_request_param[%d].m_fd = %d, m_at_ch_name = %s", n, sp_request_param[n].m_fd, sp_request_param[n].m_at_ch_name);
        }else if(g_ReadCount == 10) {
            RLOGE( "Reset modem: There is no data read from the device");
            onResetModem();
        } else {
            g_ReadCount = 11;
        }
    }
    else
    {
        g_ReadCount++;
        if(g_ReadCount < 10) {
            RLOGE("at_buffer_handler, read_num = %d", read_num);
            RLOGE("at_buffer_handler, read buffer error, g_ReadCount = %d !!!!!", g_ReadCount);
            RLOGE("at_buffer_handler, sp_request_param[%d].m_fd = %d, m_at_ch_name = %s", n, sp_request_param[n].m_fd, sp_request_param[n].m_at_ch_name);
        }else if(g_ReadCount == 10) {
            RLOGE("Reset modem: read buffer error");
            onResetModem();
        } else {
            g_ReadCount = 11;
        }
    }

    return;
}

static void *readerLoop(void *arg)
{
    fd_set read_fds;
    int ret_val;
    int n = 0;

    for (;;) {
        FD_ZERO(&read_fds );
        for(n = 0; n < RIL_DEVICE_MAX_COUNT; n++) {
            //RLOGD("readerLoop, sp_request_param[%d].m_fd=%d",n, sp_request_param[n].m_fd);
            FD_SET(sp_request_param[n].m_fd, &read_fds );
        }

        DBBD(0, RLOGD("readerLoop, start to select ..."));
        ret_val = select((s_max_fd + 1), &read_fds, NULL, NULL, NULL);
        if(ret_val > 0 )
        {
            //DBBD(DB_MCH, RLOGD("select OK==="));
            for(n = 0; n < RIL_DEVICE_MAX_COUNT; n++)
            {
                if(FD_ISSET(sp_request_param[n].m_fd, &read_fds))
                {
                    DBBD(DB_MCH, RLOGD("select OK, s_fd=%d, n=%d, %s", s_fd, n, sp_request_param[n].m_at_ch_name));
                    break;
                }
            }
            at_buffer_handler(n);
        }
        else
        {
            RLOGE("Select error or timeout, ret_val = %d", ret_val);
        }
#if 0
        const char * line;
	 DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
        line = readline();
	 DBBD(DB_CMD,RLOGD("____ %d, %s\n",__LINE__,__FUNCTION__));
        if (line == NULL) {
            break;
        }

        if(isSMSUnsolicited(line)) {
            char *line1;
            const char *line2;

            // The scope of string returned by 'readline()' is valid only
            // till next call to 'readline()' hence making a copy of line
            // before calling readline again.
            line1 = strdup(line);
            line2 = readline();

            if (line2 == NULL) {
                break;
            }

            if (s_unsolHandler != NULL) {
                s_unsolHandler (line1, line2);
            }
            free(line1);
        } else {
            processLine(line);
        }

#endif

    }

    onReaderClosed();

    return NULL;
}

/**
 * Sends string s to the radio with a \r appended.
 * Returns AT_ERROR_* on error, 0 on success
 *
 * This function exists because as of writing, android libc does not
 * have buffered stdio.
 */
int writeline (const char *s, int m)
{
    size_t cur = 0;
    size_t len ;//= strlen(s);
    ssize_t written;
    char broadcatAtLevel[2]={'\0'};
    char strbuf[200] = {0};
    char *temp = NULL;
	char * cmd = NULL;
  
	if(0 == m){
		asprintf(&cmd,"%s\r\n" , s);
		//asprintf(&cmd,"0%s\r\n" , s); 
		//cmd[0] = 0;
		}
	else if(2 == m){
		/*
		sp_request_param[m].m_fd = 12;
		asprintf(&cmd,"1%s\r\n" , s); 
		cmd[0] = 1;
		RLOGD("[wywywywywy] writline m=2 cmd[]=%s", cmd);
		*/
	}	
	
   
   //len=strlen(cmd);
   //len = strlen(s) + 3;
   len = strlen(s) + 2;

   int i;
   for(i = 0;(size_t)i <len;i++)
	{
		RLOGD("[panda:wyy] writline cmd[%d]=%x~~~~~~~~~~~~~~~~", i, cmd[i]);
	}
	   
   #if 0
	   int newlen = strlen(s)+3;
	   char *cmd = (char *)malloc(newlen);
		memset(cmd , 0, newlen);
		cmd[0] = 0;
		int i = 0;
		for(i=1;i< strlen(s)+1;i++ )
		{
			cmd[i] = *(s+i-1);
		}
		cmd[strlen(s)+1] = 0x0d;
		cmd[strlen(s)+2] = 0x0a;
	
	   
		len=newlen;
	   RLOGD("[panda:wyy] writline len =% d, strlen(s) = %d" ,len,strlen(s));
		//RLOGD("[panda:wyy] writline s_send=%s, len = %d", cmd, len);
		for(i = 0;i <newlen;i++)
		{
			RLOGD("[panda:wyy] writline cmd[%d]=%x~~~~~~~~~~~~~~~~", i, cmd[i]);
		}
	
	  
#endif
//    if ((sp_request_param[m].m_fd) < 0 || s_readerClosed > 0) {
//        return AT_ERROR_CHANNEL_CLOSED;
//    }

    property_get("sys.xt.broadcast.at.level", broadcatAtLevel, "0");
    if(0 == strcmp(broadcatAtLevel,"1")) {
        if(strstr(s, " ")) {
            temp = strdup(s);
            strrpl(temp, ' ', '!');
        }
        snprintf(strbuf,
             sizeof(strbuf)-1,
             "am broadcast -a android.intent.action.InfoCommand.result --ei channle_id %d --ei direction %d --es ats %s ",
             m,0,temp == NULL ? s:temp);
        system(strbuf);
        if(temp != NULL) {
            free(temp);
        }
    }
   
    RLOGD("[panda:wyy] AT>[%d] %s\n",m, s);

    AT_DUMP( ">> ", s, strlen(s) );
	RLOGD("[wywywywy] sp_request_param[m].m_fd = %d\n",sp_request_param[m].m_fd);

    /* the main string */
    while (cur < len) {
        do {	
#ifdef AT_CHANNEL_UDP
				  //RLOGD("[panda:wyy] sendto be called\n",0);
				  //RLOGD("[panda:wyy-123456] fd=%d,remote_len=%d,remote_addr=%s",sp_request_param[m].m_fd,remote_len,remote_addr);
				  written = sendto((sp_request_param[m].m_fd),cmd+ cur, len - cur,0,(struct sockaddr *)&remote_addr,remote_len);


				 //written = sendto((sp_request_param[m].m_fd),s+ cur, len - cur,0,(struct sockaddr *)&remote_addr,remote_len);
				  //written=sendto((sp_request_param[m].m_fd), s + cur, len - cur,0,(struct sockaddr *)&remote_addr,remote_len);
#else
            written = write ((sp_request_param[m].m_fd), s + cur, len - cur);
#endif
        } while (written < 0 && errno == EINTR);
        if (written < 0) {
            return AT_ERROR_GENERIC;
        }

        cur += written;
    }

    /* the \r  */
#if 0
		do {
#ifdef AT_CHANNEL_UDP
		  written=sendto((sp_request_param[m].m_fd), "\r" , 1,0,(struct sockaddr *)&remote_addr,remote_len);
#else
        written = write ((sp_request_param[m].m_fd), "\r" , 1);
#endif
    } while ((written < 0 && errno == EINTR) || (written == 0));

    if (written < 0) {
        return AT_ERROR_GENERIC;
    }
#endif
    return 0;
}

//add by leadcore for sms start
static int writeSpecCtrlZ (int m )
{
    ssize_t written;

    if (sp_request_param[m].m_fd < 0 || s_readerClosed > 0) {
        return AT_ERROR_CHANNEL_CLOSED;
    }

    AT_DUMP( ">* ", "00D300", strlen("00D300") );

#ifdef AT_CHANNEL_UDP
		   written=sendto(sp_request_param[m].m_fd, "00D300", strlen("00D300"),0,(struct sockaddr *)&remote_addr,remote_len);
#else
    written = write (sp_request_param[m].m_fd, "00D300", strlen("00D300"));
#endif

    if (written < 0) {
        return AT_ERROR_GENERIC;
    }

    /* the ^Z  */
    do {		
#ifdef AT_CHANNEL_UDP
		written=sendto(sp_request_param[m].m_fd, "\032" , 1,0,(struct sockaddr *)&remote_addr,remote_len);
#else
        written = write (sp_request_param[m].m_fd, "\032" , 1);
#endif

    } while ((written < 0 && errno == EINTR) || (written == 0));

    if (written < 0) {
        return AT_ERROR_GENERIC;
    }

    return 0;
}
//add by leadcore for sms end


static int writeCtrlZ (const char *s, int m)
{
    size_t cur = 0;
    size_t len ;//= strlen(s);
    ssize_t written;
	char * cmd = NULL;

    if (sp_request_param[m].m_fd < 0 || s_readerClosed > 0) {
        return AT_ERROR_CHANNEL_CLOSED;
    }

/*
   asprintf(&cmd,"0%s000" ,s); 
   len = strlen(s) + 4;
   cmd[0] = 0;
*/ 
   //len=strlen(cmd);
   asprintf(&cmd,"%s000" ,s); 
   len = strlen(s) + 3;
   cmd[len-1] = 0x0a;
   cmd[len-2] = 0x0d;
   cmd[len-3] = 0x1a;
  

   int i;
   for(i = 0;(size_t)i <len;i++)
	{
		RLOGD("[panda:wyy] writline data[%d]=%x~~~~~~~~~~~~~~~~", i, cmd[i]);
	}
	

    //RLOGD("AT> %s^Z\n", s);

    AT_DUMP( ">* ", s, strlen(s) );

    /* the main string */
    while (cur < len) {
		RLOGD("[wyy_0614]cur = %zu,len = %zu",cur,len);
        do {			
#ifdef AT_CHANNEL_UDP
				  written=sendto(sp_request_param[m].m_fd, cmd + cur, len - cur,0,(struct sockaddr *)&remote_addr,remote_len);
#else
            written = write (sp_request_param[m].m_fd, s + cur, len - cur);
#endif

        } while (written < 0 && errno == EINTR);

        if (written < 0) {
            return AT_ERROR_GENERIC;
        }
		RLOGD("[WYY_0614]written =%zd\n",written);

        cur += written;
    }

    /* the ^Z  */

    do {
#ifdef AT_CHANNEL_UDP
			  written=sendto(sp_request_param[m].m_fd, "\032" , 1,0,(struct sockaddr *)&remote_addr,remote_len);
#else
        written = write (sp_request_param[m].m_fd, "\032" , 1);
#endif

    } while ((written < 0 && errno == EINTR) || (written == 0));

    if (written < 0) {
        return AT_ERROR_GENERIC;
    }

    return 0;
}

static void clearPendingCommand(int m)
{
    if (sp_request_param[m].mp_response != NULL) {
        at_response_free(sp_request_param[m].mp_response);
    }

    sp_request_param[m].mp_response = NULL;
    sp_request_param[m].m_responsePrefix = NULL;
    sp_request_param[m].m_smsPDU = NULL;
}




/**
 * Starts AT handler on stream "fd'
 * returns 0 on success, -1 on error
 */
int at_open_ex(int fd, ATUnsolHandler h, int sim_id,  int port, char *ip)
{
    int m;
    int ret = 0;
    pthread_t tid;
    pthread_attr_t attr;
    char tmp_buf[20];
	 //added by wyy 2020.5.11
	 bzero(&remote_addr, sizeof(remote_addr));	 
	 remote_addr.sin_family = AF_INET;	 
	 remote_addr.sin_port =htons(port);
	 remote_addr.sin_addr.s_addr =inet_addr(ip);//INADDR_ANY
	
	 //memcpy( remote_addr.sin_addr.s_addr ,  saddr->sin_addr.s_addr,sizeof(remote_addr.sin_addr.s_addr));
	 
	 remote_len=sizeof(remote_addr);
	 //RLOGD("[panda:wyy] at_open_ex remote_addr=%s ,port=%d",inet_ntoa(remote_addr.sin_addr),remote_addr.sin_port);
	 
	 
	//RLOGD("panda:at_open_ex",fd);
    
    for(int n = 0; n < RIL_DEVICE_MAX_COUNT; n++) {
        s_ATSender[n].m_at_ch_name = at_ch_name[n];
        s_ATSender[n].m_fd = -1; // fix 2011-09-22
        //RLOGD("%d, %s, n = %d\n",__LINE__,__FUNCTION__, n);
    }
	
    s_simid = sim_id;
    sp_request_param = trans_request_param();

    for(m = 0; m < RIL_DEVICE_MAX_COUNT; m++) {
        if(0 == m) {
            sp_request_param[m].m_fd = fd;
            RLOGD("===>Open the first channel name %s", sp_request_param[m].m_at_ch_name);
        } else {
            sp_request_param[m].m_fd = open(sp_request_param[m].m_at_ch_name, O_RDWR);
            if(sp_request_param[m].m_fd > 0)
            {
                RLOGD("Open bufan channel %s Success, fd:%d",sp_request_param[m].m_at_ch_name,sp_request_param[m].m_fd );
            }
            else
                RLOGE("ERROR:while open %s,m=%d " , sp_request_param[m].m_at_ch_name,m);
        }
        RLOGD("at_open_ex, bufan m=%d, channel name:%s, m_fd=%d\n",m,sp_request_param[m].m_at_ch_name,sp_request_param[m].m_fd);
    }

    for(m = 0; m < RIL_DEVICE_MAX_COUNT; m++) {
        RLOGD("==== at_open_ex, m=%d, sim_id =%d", m, sim_id);
        if(0 == sim_id) {
#ifdef AT_CHANNEL_UDP
					 char tmp[] = "AT^DMPCHN=0\r\n";
		
					 //tmp[0] = 0;
				//int slen=sendto(sp_request_param[m].m_fd , tmp, strlen("AT^DMPCHN=0\r\n"), 0, (struct sockaddr *)&remote_addr, remote_len);
		
				//int rlen=recvfrom(sp_request_param[m].m_fd, tmp_buf, 20, 0, (struct sockaddr *)&remote_addr, (socklen_t*)&remote_len);
				//int rlen=recvfrom(sp_request_param[m].m_fd, tmp_buf, 20, 0, NULL, &remote_len);
#else

            write(sp_request_param[m].m_fd , "AT^DMPCHN=0\r\n", strlen("AT^DMPCHN=0\r\n"));
            read(sp_request_param[m].m_fd, tmp_buf, 20);
#endif

        } else if(1 == sim_id) {
#ifdef AT_CHANNEL_UDP
				 char *tmp = "AT^DMPCHN=1\r\n";
				 //tmp[0] = 0;
			sendto(sp_request_param[m].m_fd , tmp, strlen("AT^DMPCHN=1\r\n"),0,(struct sockaddr *)&remote_addr,remote_len);
			recvfrom(sp_request_param[m].m_fd, tmp_buf, 20,0,(struct sockaddr *)&remote_addr,(socklen_t*)&remote_len);
			//recvfrom(sp_request_param[m].m_fd, tmp_buf, 20,0,NULL,&remote_len);
#else
            write(sp_request_param[m].m_fd , "AT^DMPCHN=1\r\n", strlen("AT^DMPCHN=1\r\n"));
            read(sp_request_param[m].m_fd, tmp_buf, 20);
#endif
        } else {
            RLOGD("==== at_open_ex, ERROR, Unknow sim_id\n");
        }
    }

    for(m = 0; m < RIL_DEVICE_MAX_COUNT; m++) {
        if(sp_request_param[m].m_fd > 0)
        {
            RLOGD("Open channel %s Success, fd:%d",sp_request_param[m].m_at_ch_name,sp_request_param[m].m_fd );
#ifdef AT_CHANNEL_UDP
			if((RIL_DEVICE_MAX_COUNT - 1) ==  m) {
					//  RLOGD("==== at_open_ex, sendto AT_DLKS ", 0);
					  char tmp[] = "AT^DLKS=1\r\n";
					  //tmp[0] = 0;
					  
							ret = sendto(sp_request_param[m].m_fd , tmp, strlen("AT^DLKS=1\r\n"),0,(struct sockaddr *)&remote_addr,remote_len);
						} else {
							char *tmp = "AT^DLKS=0\r\n";
					  //tmp[0] = 0;
					  
							ret = sendto(sp_request_param[m].m_fd , tmp, strlen("AT^DLKS=0\r\n"),0,(struct sockaddr *)&remote_addr,remote_len);
						}
			
#else
						if((RIL_DEVICE_MAX_COUNT - 1) ==  m) {
                ret = write(sp_request_param[m].m_fd , "AT^DLKS=1\r\n", strlen("AT^DLKS=1\r\n"));
            } else {
                ret = write(sp_request_param[m].m_fd , "AT^DLKS=0\r\n", strlen("AT^DLKS=0\r\n"));
            }
#endif

            RLOGD("kkkkkk, write ret = %d",ret);

            if(ret < 0)
            {
                RLOGE("Write fd %d Error",sp_request_param[m].m_fd );
            }
            else
            {            
#ifdef AT_CHANEL_UDP
					ret=recvfrom(sp_request_param[m].m_fd, tmp_buf, 20,0,(struct sockaddr *)&remote_addr,&remote_len);
					//ret=recvfrom(sp_request_param[m].m_fd, tmp_buf, 20,0,NULL,&remote_len);
#else
                ret = read(sp_request_param[m].m_fd, tmp_buf, 20);
#endif

                RLOGD("===>at_open_ex the read ret=%d, tmp_buf : %s", ret, tmp_buf);
            }
        }
        else {
            RLOGD("==== at_open_ex, ERROR!!!!" );
        }
    }

    int k = 0;
    s_max_fd = sp_request_param[0].m_fd;
    for(k = 1; k < RIL_DEVICE_MAX_COUNT; k++) {
        if(sp_request_param[k].m_fd > sp_request_param[k-1].m_fd) {
            s_max_fd = sp_request_param[k].m_fd;
        } else {
            s_max_fd = sp_request_param[k-1].m_fd;
        }
    }

    RLOGD("____ %d, %s, s_fd=%d, fd=%d\n",__LINE__,__FUNCTION__,s_fd,fd);

    s_unsolHandler = h;
    s_readerClosed = 0;

    for(k = 0; k < RIL_DEVICE_MAX_COUNT; k++) {
        sp_request_param[k].m_responsePrefix = NULL;
        sp_request_param[k].m_smsPDU = NULL;
        sp_request_param[k].mp_response = NULL;
    }


    pthread_attr_init (&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    ret = pthread_create(&s_tid_reader, &attr, readerLoop, &attr);
    if (ret < 0) {
        perror ("pthread_create");
        return -1;
    }

    return 0;
}

/**
 * Starts AT handler on stream "fd'
 * returns 0 on success, -1 on error
 */
int at_open(int fd, ATUnsolHandler h)
{
    int ret = 0;
    pthread_t tid;
    pthread_attr_t attr;
    char tmp_buf[20];
    sp_request_param = trans_request_param();

    int m;
    /*Here begin to open the 3 channel,donot do it in the request_handler_thread func*/
    for(m = 0; m < RIL_DEVICE_MAX_COUNT; m++) {
        if(0 == m) {
            sp_request_param[m].m_fd = fd;
            /*Fixed Enh00000413, by chenchi , 2011-04-02 begin*/
#ifdef AT_CHANNEL_UDP
				sendto(sp_request_param[m].m_fd , "AT^DLKS=0\r\n", strlen("AT^DLKS=0\r\n"),0,(struct sockaddr *)&remote_addr,remote_len);
				recvfrom(sp_request_param[m].m_fd, tmp_buf, 20,0,(struct sockaddr *)&remote_addr,&remote_len);
#else
            write(sp_request_param[m].m_fd , "AT^DLKS=0\r\n", strlen("AT^DLKS=0\r\n"));
            read(sp_request_param[m].m_fd, tmp_buf, 20);
#endif
            RLOGD("===>start Open the first channel, read ret=%d, tmp_buf : %s", ret, tmp_buf);
            /*Fixed Enh00000413, by chenchi , 2011-04-02 end*/
        } else {
				sp_request_param[m].m_fd = fd;//open(sp_request_param[m].m_at_ch_name, O_RDWR);
            if(sp_request_param[m].m_fd > 0)
            {
                RLOGD("Open channel %s Success, fd:%d",sp_request_param[m].m_at_ch_name,sp_request_param[m].m_fd );
                if((RIL_DEVICE_MAX_COUNT - 1) ==  m) {
#ifdef AT_CHANNEL_UDP
								ret=sendto(sp_request_param[m].m_fd , "AT^DLKS=1\r\n", strlen("AT^DLKS=1\r\n"),0,(struct sockaddr *)&remote_addr,remote_len);
#else
                    ret = write(sp_request_param[m].m_fd , "AT^DLKS=1\r\n", strlen("AT^DLKS=1\r\n"));
#endif

				} else {
#ifdef AT_CHANNEL_UDP
				ret = sendto(sp_request_param[m].m_fd , "AT^DLKS=0\r\n", strlen("AT^DLKS=0\r\n"),0,(struct sockaddr *)&remote_addr,remote_len);
#else
                    ret = write(sp_request_param[m].m_fd , "AT^DLKS=0\r\n", strlen("AT^DLKS=0\r\n"));
#endif

				}
                if(ret < 0)
                {
                    RLOGE("Write fd %d Error",sp_request_param[m].m_fd );
                }
                else
                {
#ifdef AT_CHANNEL_UDP
								 ret=recvfrom(sp_request_param[m].m_fd, tmp_buf, 20,0,(struct sockaddr *)&remote_addr,&remote_len);
					
#else
                    ret = read(sp_request_param[m].m_fd, tmp_buf, 20);
#endif

                    RLOGD("===>the at_open read ret=%d, tmp_buf : %s", ret, tmp_buf);
                }
            }
            else
                RLOGE("ERROR:while open %s,m=%d " , sp_request_param[m].m_at_ch_name,m);
        }
        RLOGD("at_open,m=%d,channel name:%s,m_fd=%d\n",m,sp_request_param[m].m_at_ch_name,sp_request_param[m].m_fd);
    }

    int k = 0;
    s_max_fd = sp_request_param[0].m_fd;
    for(k = 1; k < RIL_DEVICE_MAX_COUNT; k++) {
        if(sp_request_param[k].m_fd > sp_request_param[k-1].m_fd) {
            s_max_fd = sp_request_param[k].m_fd;
        } else {
            s_max_fd = sp_request_param[k-1].m_fd;
        }
    }

    RLOGD("____ %d, %s,s_fd=%d,fd=%d\n",__LINE__,__FUNCTION__,s_fd,fd);

    s_unsolHandler = h;
    s_readerClosed = 0;


    for(k = 0; k < RIL_DEVICE_MAX_COUNT; k++) {
        sp_request_param[k].m_responsePrefix = NULL;
        sp_request_param[k].m_smsPDU = NULL;
        sp_request_param[k].mp_response = NULL;
    }


    //s_responsePrefix = NULL;
    //s_smsPDU = NULL;
    //sp_response = NULL;


    pthread_attr_init (&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    ret = pthread_create(&s_tid_reader, &attr, readerLoop, &attr);
    if (ret < 0) {
        perror ("pthread_create");
        return -1;
    }


    return 0;
}

/* FIXME is it ok to call this from the reader and the command thread? */
void at_close()
{
    if (s_fd >= 0) {
        close(s_fd);
    }
    s_fd = -1;
#if 0
    pthread_mutex_lock(&s_commandmutex);

    s_readerClosed = 1;

    pthread_cond_signal(&s_commandcond);

    pthread_mutex_unlock(&s_commandmutex);
#else

        int m = 0;
        for(m = 0; m < RIL_DEVICE_MAX_COUNT; m++) {
            pthread_mutex_lock(&s_commandmutex[m]);

            s_readerClosed = 1;

            pthread_cond_signal(&s_commandcond[m]);

            pthread_mutex_unlock(&s_commandmutex[m]);
        }
#endif
    /* the reader thread should eventually die */
}

static ATResponse * at_response_new()
{
    return (ATResponse *) calloc(1, sizeof(ATResponse));
}

void at_response_free(ATResponse *p_response)
{
    ATLine *p_line;

    if (p_response == NULL) return;

    p_line = p_response->p_intermediates;

    while (p_line != NULL) {
        ATLine *p_toFree;

        p_toFree = p_line;
        p_line = p_line->p_next;

        free(p_toFree->line);
        free(p_toFree);
    }

    free (p_response->finalResponse);
    free (p_response);
}

/**
 * The line reader places the intermediate responses in reverse order
 * here we flip them back
 */
static void reverseIntermediates(ATResponse *p_response)
{
    ATLine *pcur,*pnext;

    pcur = p_response->p_intermediates;
    p_response->p_intermediates = NULL;

    while (pcur != NULL) {
        pnext = pcur->p_next;
        pcur->p_next = p_response->p_intermediates;
        p_response->p_intermediates = pcur;
        pcur = pnext;
    }
}

/**
 * Internal send_command implementation
 * Doesn't lock or call the timeout callback
 *
 * timeoutMsec == 0 means infinite timeout
 */

static int at_send_command_full_nolock (const char *command, ATCommandType type,
                    const char *responsePrefix, const char *smspdu,
                    long long timeoutMsec, ATResponse **pp_outResponse, int m)
{
    int err = 0;

#ifndef USE_NP
    struct timespec ts;
#endif /*USE_NP*/

#if 0
    int m;
    pthread_t mthread_self = pthread_self();
    for(m = 0; m < RIL_DEVICE_MAX_COUNT; m++)
    {
        if(pthread_equal(mthread_self, sp_request_param[m].m_thread_id)) {
            DBBD(DB_MCH,RLOGD("%s() -thread_id :%ld  " , __func__,sp_request_param[m].m_thread_id));
            break;
        } else {
            if((RIL_DEVICE_MAX_COUNT - 1) == m) {  //None of the request_handler_thread
                DBBD(DB_MCH,RLOGD("Use default value m:%d",m));
                break;
            }
        }
    }
#endif
    err = writeline (command, m);
    if (err < 0) {
        goto error;
    }

    sp_request_param[m].m_type = type;
    sp_request_param[m].m_responsePrefix = responsePrefix;
    sp_request_param[m].m_smsPDU = smspdu;
    sp_request_param[m].mp_response = at_response_new();
    if(sp_request_param[m].mp_response == NULL) {
        RLOGD("Attention : calloc fail, do it again!");
        sp_request_param[m].mp_response = at_response_new();
    }

    if(0 == timeoutMsec) {
        timeoutMsec = 120*1000; /*Max 120 second*/
    }
    //RLOGD("timeoutMsec %lld ",timeoutMsec);

#ifndef USE_NP
    if (timeoutMsec != 0) {
        setTimespecRelative(&ts, timeoutMsec);
    }
#endif /*USE_NP*/

    while (sp_request_param[m].mp_response!=NULL&&sp_request_param[m].mp_response->finalResponse == NULL && s_readerClosed == 0) {
        if (timeoutMsec != 0) {
#ifdef USE_NP
            err = pthread_cond_timeout_np(&s_commandcond[m], &s_commandmutex[m], timeoutMsec);
#else
            err = pthread_cond_timedwait(&s_commandcond[m], &s_commandmutex[m], &ts);
#endif /*USE_NP*/
        } else {
            err = pthread_cond_wait(&s_commandcond[m], &s_commandmutex[m]);
        }

        //RLOGD("the err %d,%d",err,ETIMEDOUT);
        if(err == ETIMEDOUT) {
            RLOGD("cmd resp ttime out, m=[%d]",m);
            if(NULL != sp_request_param[m].mp_response) {/* FIX L1609_Bug00001019  2012-01-12 chenchi add */
                (sp_request_param[m].mp_response)->success = 0;
                sp_request_param[m].mp_response->finalResponse = strdup("\r\n+CME ERROR: 100\r\n");
            } else {
                RLOGD("===sp_request_param[%d].mp_response is NULL",m);
            }
            err = 0;    /*This is a normal response of ERROR*/

            /* Fixed Enh00001117, by chenchi ,2011-08-11 */
            g_timeoutCount++;
            if(MAX_TIMEOUT_COUNT == g_timeoutCount) {
                //RIL_requestTimedCallback(requestResetModem, NULL, &TIMEVAL_RESET);
                RLOGD("cmd resp 3times out");
                //requestAtTimeOutCallback(&TIMEVAL_RESET);
            }
            //goto error;
        } else {
            err = 0;
            g_timeoutCount = 0;
        }
    }

    if (pp_outResponse == NULL) {
        at_response_free(sp_request_param[m].mp_response);
    } else {
        /* line reader stores intermediate responses in reverse order */
        reverseIntermediates(sp_request_param[m].mp_response);
        *pp_outResponse = sp_request_param[m].mp_response;
    }

    sp_request_param[m].mp_response = NULL;

    if(s_readerClosed > 0) {
        err = AT_ERROR_CHANNEL_CLOSED;
        goto error;
    }

    //err = 0;
error:
    clearPendingCommand(m);

    return err;
}

/**
 * Internal send_command implementation
 *
 * timeoutMsec == 0 means infinite timeout
 */
static int at_send_command_full (const char *command, ATCommandType type,
                    const char *responsePrefix, const char *smspdu,
                    long long timeoutMsec, ATResponse **pp_outResponse)
{
    int err;

    if (0 != pthread_equal(s_tid_reader, pthread_self())) {
		
	DBBD(DB_MCH, RLOGD("at_send_command_full AT_ERROR_INVALID_THREAD"));
        /* cannot be called from reader thread */
        //return AT_ERROR_INVALID_THREAD;
    }

    int m = 0;
    pthread_t mthread_self = pthread_self();
	
    DBBD(DB_MCH, RLOGD("at_send_command_full, default, mthread_self:%d",mthread_self));

    for(m = 0; m < RIL_DEVICE_MAX_COUNT; m++)
    {
        if(pthread_equal(mthread_self, sp_request_param[m].m_thread_id)) {
            DBBD(DB_MCH, RLOGD("==1-1==, m=%d, thread_id:%ld, fd=%d",m,sp_request_param[m].m_thread_id,sp_request_param[m].m_fd));
            break;
        } else {
            if((RIL_DEVICE_MAX_COUNT - 1) == m) {
                DBBD(DB_MCH, RLOGD("==1-1==, default, m:%d",m));
                break;
            }
        }
    }
 
    pthread_mutex_lock(&s_commandmutex[m]);

    if (sp_request_param[m].mp_response != NULL || s_readerClosed > 0) {
        int temp = 100;  //modified by jiangxuqin for L1860_Bug20150123-47612 @ 2015-01-29

        RLOGD("at_send_command_full(): sp_request_param[%d].mp_response != NULL", m);
        for (; temp>0; temp--) {
            pthread_mutex_unlock(&s_commandmutex[m]);
            usleep(50*1000);
            pthread_mutex_lock(&s_commandmutex[m]);
            if (sp_request_param[m].mp_response == NULL) {
                break;
            }
        }

        RLOGD("at_send_command_full(): temp = %d", temp);
        if (temp <= 0) {
            pthread_mutex_unlock(&s_commandmutex[m]);
            return AT_ERROR_COMMAND_PENDING;
        }
    }

    DBBD(DB_MCH, RLOGD("++2-1++, m =%d, thread_id:%ld, fd:%d",m,sp_request_param[m].m_thread_id,sp_request_param[m].m_fd));

    err = at_send_command_full_nolock(command, type,
                    responsePrefix, smspdu,
                    timeoutMsec, pp_outResponse, m);

    DBBD(DB_MCH, RLOGD("++2-2++, m =%d, thread_id:%ld, fd:%d, err: %d",m,sp_request_param[m].m_thread_id,sp_request_param[m].m_fd, err));
    pthread_mutex_unlock(&s_commandmutex[m]);
    DBBD(DB_MCH, RLOGD("==1-2==, m=%d, thread_id:%ld, fd=%d",m,sp_request_param[m].m_thread_id,sp_request_param[m].m_fd));

    if (err == AT_ERROR_TIMEOUT && s_onTimeout != NULL) {
        DBBD(DB_MCH, RLOGD("!!!!TIME OUT, %s",__FUNCTION__));
        s_onTimeout();
    }

    return err;
}


/**
 * Issue a single normal AT command with no intermediate response expected
 *
 * "command" should not include \r
 * pp_outResponse can be NULL
 *
 * if non-NULL, the resulting ATResponse * must be eventually freed with
 * at_response_free
 */
int at_send_command (const char *command, ATResponse **pp_outResponse)
{
    int err;
	
    err = at_send_command_full (command, NO_RESULT, NULL,
                                    NULL, 0, pp_outResponse);

    return err;
}


int at_send_command_singleline (const char *command,
                                const char *responsePrefix,
                                 ATResponse **pp_outResponse)
{
    int err;

    err = at_send_command_full (command, SINGLELINE, responsePrefix,
                                    NULL, 0, pp_outResponse);

    if (err == 0 && pp_outResponse != NULL
        && (*pp_outResponse)->success > 0
        && (*pp_outResponse)->p_intermediates == NULL
    ) {
        /* successful command must have an intermediate response */
        at_response_free(*pp_outResponse);
        *pp_outResponse = NULL;
        return AT_ERROR_INVALID_RESPONSE;
    }

    return err;
}



//add by zss 20110509 for Req00000322
int at_send_command_multiline_1 (const char *command,
                                const char *responsePrefix,
                                 ATResponse **pp_outResponse)
{
    int err;

    err = at_send_command_full (command, MULTILINE_1, responsePrefix,
                                    NULL, 0, pp_outResponse);

    RLOGD("at_send_command_multiline_1. err = %d",err);
    if (err == 0 && pp_outResponse != NULL
        && (*pp_outResponse)->success > 0
        && (*pp_outResponse)->p_intermediates == NULL
    ) {
        /* successful command must have an intermediate response */
        RLOGD("at_send_command_multiline_1.AT_ERROR_INVALID_RESPONSE");
        at_response_free(*pp_outResponse);
        *pp_outResponse = NULL;
        return AT_ERROR_INVALID_RESPONSE;
    }

    return err;
}
//add end

#if 1   //MCC

int at_send_command_singleline_timeout (const char *command,
					const char *responsePrefix,
					int timeout,
					ATResponse **pp_outResponse)
{
    int err;

    //RLOGD("at_send_command_singleline_timeout(), command = %s", command);
    err = at_send_command_full (command, SINGLELINE, responsePrefix,
                                    NULL, timeout, pp_outResponse);

    if (err == 0 && pp_outResponse != NULL
        && (*pp_outResponse)->success > 0
        && (*pp_outResponse)->p_intermediates == NULL
    ) {
        /* successful command must have an intermediate response */
        at_response_free(*pp_outResponse);
        *pp_outResponse = NULL;
        return AT_ERROR_INVALID_RESPONSE;
    }

    return err;
}
#endif

int at_send_command_numeric (const char *command,
                                 ATResponse **pp_outResponse)
{
    int err;

    err = at_send_command_full (command, NUMERIC, NULL,
                                    NULL, 0, pp_outResponse);

    if (err == 0 && pp_outResponse != NULL
        && (*pp_outResponse)->success > 0
        && (*pp_outResponse)->p_intermediates == NULL
    ) {
        /* successful command must have an intermediate response */
        at_response_free(*pp_outResponse);
        *pp_outResponse = NULL;
        return AT_ERROR_INVALID_RESPONSE;
    }

    return err;
}


int at_send_command_sms (const char *command,
                                const char *pdu,
                                const char *responsePrefix,
                                 ATResponse **pp_outResponse)
{
    int err;
	ATResponse *p_response = NULL;

	if(g_modemtype_s ==0){
	    //need send "AT+CMMS=1" before sending SMS.
		err = at_send_command("AT+CMMS=1", &p_response);
	    
		if (err < 0/* || p_response->success == 0*/) { // deleted [by chenshu 2012-07-10] for fix Bug00000670
	        //LOG_ERR( ERR_UNKNOWN);
	        return err;
		}
	    
	    // add [by chenshu 2012-07-10] for fix Bug00000670
	    if (p_response->success == 0) {
	        err = AT_ERROR_CMMS_TIMEOUT;
	        RLOGD("at_send_command_sms: CMMS failed ");
	        return err;
	    }
		at_response_free(p_response);
	    p_response = NULL;
	    // add [by chenshu 2012-07-10] end
	}
    RLOGD("at_send_command_sms :strlen(pdu) =%d",strlen(pdu)); 
	RLOGD("requestSendSMS : pdu : %s",pdu);
	
    err = at_send_command_full (command, SINGLELINE, responsePrefix,
                                    pdu, 0, pp_outResponse);

    if (err == 0 && pp_outResponse != NULL
        && (*pp_outResponse)->success > 0
        && (*pp_outResponse)->p_intermediates == NULL
    ) {
        /* successful command must have an intermediate response */
        at_response_free(*pp_outResponse);
        *pp_outResponse = NULL;
        return AT_ERROR_INVALID_RESPONSE;
    }

    return err;
}


int at_send_command_multiline (const char *command,
                                const char *responsePrefix,
                                 ATResponse **pp_outResponse)
{
    int err;

    err = at_send_command_full (command, MULTILINE, responsePrefix,
                                    NULL, 0, pp_outResponse);

    return err;
}

#if 1   //MCC   enfora
int at_send_command_multiline_timeout (const char *command,
				       const char *responsePrefix, 
				       int timeout,
				       ATResponse **pp_outResponse)
{
    int err;

    err = at_send_command_full (command, MULTILINE, responsePrefix,
                                    NULL, timeout, pp_outResponse);

    return err;
}
#endif 

/** This callback is invoked on the command thread */
void at_set_on_timeout(void (*onTimeout)(void))
{
    s_onTimeout = onTimeout;
}

/**
 *  This callback is invoked on the reader thread (like ATUnsolHandler)
 *  when the input stream closes before you call at_close
 *  (not when you call at_close())
 *  You should still call at_close()
 */

void at_set_on_reader_closed(void (*onClose)(void))
{
    s_onReaderClosed = onClose;
}


/**
 * Periodically issue an AT command and wait for a response.
 * Used to ensure channel has start up and is active
 */

int at_handshake()
{
    int i;
    int err = 0;

    if (0 != pthread_equal(s_tid_reader, pthread_self())) {
        /* cannot be called from reader thread */
        return AT_ERROR_INVALID_THREAD;
    }

    pthread_mutex_lock(&(s_commandmutex[RIL_DEVICE_MAX_COUNT-1]));
    for (i = 0 ; i < HANDSHAKE_RETRY_COUNT ; i++) {
        /* some stacks start with verbose off */
        err = at_send_command_full_nolock ("AT", NO_RESULT,
                    NULL, NULL, HANDSHAKE_TIMEOUT_MSEC, NULL, (RIL_DEVICE_MAX_COUNT-1));         

        if (err == 0) {
            break;
        }
    }

    if (err == 0) {
        /* pause for a bit to let the input buffer drain any unmatched OK's
           (they will appear as extraneous unsolicited responses) */

        sleepMsec(HANDSHAKE_TIMEOUT_MSEC);
    }

    pthread_mutex_unlock(&(s_commandmutex[RIL_DEVICE_MAX_COUNT-1]));

    return err;
}

/**
 * Returns error code from response
 * Assumes AT+CMEE=1 (numeric) mode
 */
AT_CME_Error at_get_cme_error(const ATResponse *p_response)
{
    int ret;
    int err;
    char *p_cur;

    if (p_response->success > 0) {
        return CME_SUCCESS;
    }

    if (p_response->finalResponse == NULL
        || !strStartsWith(p_response->finalResponse, "+CME ERROR:")
    ) {
        return CME_ERROR_NON_CME;
    }

    p_cur = p_response->finalResponse;
    err = at_tok_start(&p_cur);

    if (err < 0) {
        return CME_ERROR_NON_CME;
    }

    err = at_tok_nextint(&p_cur, &ret);

    if (err < 0) {
        return CME_ERROR_NON_CME;
    }

    return (AT_CME_Error) ret;
}

