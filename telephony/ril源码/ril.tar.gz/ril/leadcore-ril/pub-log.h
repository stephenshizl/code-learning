/*******************************************************************************
 *          COPYRIGHT DATANG MOBILE COMMUNICATIONS EQUIPMENT CO.,LTD
 ******************************************************************************/

/*******************************************************************************
 * FileName : pub-log.h
 * Version  : 1.0.0
 * Purpose  :
 * Authors  : zoufeng
 * Date     : 2008.06.01
 * Notes    :
 * ----------------------------
 * HISTORY OF CHANGES
 * ----------------------------
 *
 ******************************************************************************/



#ifndef PUB_LOG_H
#define PUB_LOG_H



/*-------------------------- include external file ---------------------------*/

#include "pub-sys.h"
#include "pub-aos.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */



/*---------------------- external variable declaration -----------------------*/



/*----------------------------- macro definition -----------------------------*/

/* Summary:
 *     LOG_XXX
 *         LOG_START()
 *         LOG_STOP()
 *         LOG_FUNC()
 *         LOG_ERR( err_code )
 *         LOG_ERR_EXT( err_code, x )
 *         LOG_FATAL_ERR( err_code )
 *         LOG_SYS_ERR( sys_func_name_ptr )
 *         LOG_INFO( x )
 *         LOG_WARNING( x )
 *         LOG_FUNC_PARAM( x )
 *         LOG_AT_CMD( direction_en, mux_port_idx, at_data_ptr, at_data_len )
 *         LOG_DATA( prompt_ptr, data_ptr, data_len )
 *         LOG_USER_MSG( direction_en, msg_name_ptr, msg_data_ptr, msg_data_len )
 *         LOG_IPC_MSG( direction_en, ipc_msg_ptr )
 *
 *     LOG2_XXX
 *         LOG2_START( log_dst, file_ptr )
 *         LOG2_STOP( log_obj )
 *         LOG2_FUNC( log_obj )
 *         LOG2_ERR( log_obj, err_code )
 *         LOG2_ERR_EXT( log_obj, err_code, x )
 *         LOG2_FATAL_ERR( log_obj, err_code )
 *         LOG2_SYS_ERR( log_obj, sys_func_name_ptr )
 *         LOG2_INFO( log_obj, x )
 *         LOG2_WARNING( log_obj, x )
 *         LOG2_FUNC_PARAM( log_obj, x )
 *         LOG2_AT_CMD( log_obj, direction_en, mux_port_idx, at_data_ptr, at_data_len )
 *         LOG2_DATA( log_obj, prompt_ptr, data_ptr, data_len )
 *         LOG2_USER_MSG( log_obj, direction_en, msg_name_ptr, msg_data_ptr, msg_data_len )
 *         LOG2_IPC_MSG( log_obj, direction_en, ipc_msg_ptr )
 *
 *     example:
 *         LOG_START();
 *         LOG_STOP();
 *         LOG_FUNC();
 *         LOG_ERR( ERR_INVALID_PARAM );
 *         LOG_ERR_EXT( ERR_INVALID_PARAM, ("%s: %d", "test error ext", 1) );
 *         LOG_FATAL_ERR( ERR_INVALID_PARAM );
 *         LOG_SYS_ERR( "fopen" );
 *         LOG_INFO( ("%s: %d", "info", 9) );
 *         LOG_WARNING( ("%s: %d", "warning", 9) );
 *         LOG_FUNC_PARAM( ("%s: %d", "param", 9) );
 *         LOG_AT_CMD( DIRCTION_RECEIVE, 9, (UINT8 *)"\r\nAT+TEST: 9\r\n", strlen("\r\nAT+TEST: 9\r\n") );
 *         LOG_DATA( "data: ", data_a, sizeof(data_a) );
 *         LOG_USER_MSG( DIRCTION_RECEIVE, "TestMsg", NULL, 0 );
 *         LOG_IPC_MSG( DIRCTION_RECEIVE, ipc_msg_ptr );
 *
 *         LOG_OBJ log_obj = LOG_INVALID_OBJ;
 *         log_obj = LOG2_START( LOG_TO_FILE, "test.log" );
 *         LOG2_STOP( log_obj );
 *         LOG2_FUNC( log_obj );
 *         LOG2_ERR( log_obj, ERR_INVALID_PARAM );
 *         LOG2_ERR_EXT( log_obj, ERR_INVALID_PARAM, ("%s: %d", "test error ext", 1) );
 *         LOG2_FATAL_ERR( log_obj, ERR_INVALID_PARAM );
 *         LOG2_SYS_ERR( log_obj, "fopen" );
 *         LOG2_INFO( log_obj, ("%s: %d", "info", 9) );
 *         LOG2_WARNING( log_obj, ("%s: %d", "warning", 9) );
 *         LOG2_FUNC_PARAM( log_obj, ("%s: %d", "param", 9) );
 *         LOG2_AT_CMD( log_obj, DIRCTION_RECEIVE, 9, (UINT8 *)"\r\nAT+TEST: 9\r\n", strlen("\r\nAT+TEST: 9\r\n") );
 *         LOG2_DATA( log_obj, "data: ", data_a, sizeof(data_a) );
 *         LOG2_USER_MSG( log_obj, DIRCTION_RECEIVE, "TestMsg", NULL, 0 );
 *         LOG2_IPC_MSG( log_obj, DIRCTION_RECEIVE, ipc_msg_ptr );
 */



#define CHECK_SYS_ERR( err_code, func_name )                                    \
        do                                                                      \
        {                                                                       \
            if( err_code != ERR_NONE )                                          \
            {                                                                   \
                LOG_SYS_ERR( func_name );                                       \
            }                                                                   \
        } while(0);



#ifdef OPT_LOG_ENABLE_LOG

/* Log level */
#define LOG_LEVEL_INFO                      0x00000001
#define LOG_LEVEL_FUNC                      0x00000002
#define LOG_LEVEL_FUNC_PARAM                0x00000004
#define LOG_LEVEL_WARNING                   0x00000008
#define LOG_LEVEL_ERR                       0x00000010
#define LOG_LEVEL_FATAL_ERR                 0x00000020
#define LOG_LEVEL_SYS_ERR                   0x00000040
#define LOG_LEVEL_IPC_MSG                   0x00000080
#define LOG_LEVEL_USER_MSG                  0x00000100
#define LOG_LEVEL_AT_CMD                    0x00000200
#define LOG_LEVEL_DATA                      0x00000400

/* Value of LOG2_START parameter, they can be combination. */
#define LOG_TO_DEFAULT                      0x01
#define LOG_TO_FILE                         0x02

/* Direction info, it always used for log at/user message/IPC message. */
typedef enum
{
    DIRCTION_RECEIVE = 0,
    DIRCTION_SEND,
#ifdef OPT_LOG_SUPPORT_PTY
    DIRCTION_PTM_RECEIVE,
    DIRCTION_PTM_SEND,
    DIRCTION_PTS_RECEIVE,
    DIRCTION_PTS_SEND,
#endif
    DIRCTION_RECEIVE_SINGLE,
    DIRCTION_SEND_SINGLE,
    DIRCTION_MAX,
} LOG_DIRCTION_EN;

#define LOG_INVALID_OBJ                     NULL

/* Description:
 *     Start log function.
 * Parameter:
 *     log_dst  : UINT8, value:
 *                    LOG_TO_DEFAULT
 *                    LOG_TO_FILE
 *     file_ptr : char *, log file name without path info(if it has, the path will be ingnored).
 *                Valid only when log_dst&LOG_TO_FILE, and if it is NULL, the name of the
 *                log file will be same as the program name.
 * Return:
 *     LOG_OBJ
 * Example:
 *     LOG_OBJ log_obj = LOG_INVALID_OBJ;
 *
 *     LOG2_START( LOG_TO_DEFAULT, NULL );
 *
 *     log_obj = LOG2_START( LOG_TO_FILE, NULL );
 *     log_obj = LOG2_START( LOG_TO_FILE, "test.log" );
 */
#define LOG2_START( log_dst, file_ptr )                                         \
        sfw_log_start( log_dst, file_ptr )

/* Description:
 *     Stop log function.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 * Example:
 *     LOG2_STOP( log_obj );
 */
#define LOG2_STOP( log_obj )                                                    \
        sfw_log_stop( log_obj )

/*******************************************************************************
 * Note of x:
 *     The "x" must be the format(including the parentheses):
 *         (const char *format, ...)
 *     Parameter is same as that of function printf().
 *
 * Example:
 *     LOG2_INFO( log_obj, ( "test: %d", 1 ) );
 ******************************************************************************/


/* Description:
 *     Log basic info. Commonly don't use it directly.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     log_level        : log level
 * Example:
 *     LOG2_BASE( log_obj, LOG_LEVEL_FUNC );
 */
#define LOG2_BASE( log_obj, log_level )                                         \
        do                                                                      \
        {                                                                       \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    log_level,                                                  \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    0,                                                          \
                    DIRCTION_MAX,                                               \
                    NULL,                                                       \
                    0,                                                          \
                    0,                                                          \
                    NULL,                                                       \
                    NULL,                                                       \
                    NULL );                                                     \
        } while(0);

/* Description:
 *     Log extended info. Commonly don't use it directly.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     log_level        : log level
 *     x                : see "note of x"
 * Example:
 *     LOG2_EXTEND( log_obj, LOG_LEVEL_INFO, ("info: %d", 1) );
 */
#define LOG2_EXTEND( log_obj, log_level, x )                                    \
        do                                                                      \
        {                                                                       \
            sfw_log_start_build_extend_info( log_obj );                         \
            sfw_log_build_extended_info x;                                      \
            LOG2_BASE( log_obj, log_level );                                    \
        } while(0);

/* Description:
 *     Log current function info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
       (none)
 * Example:
 *     LOG2_FUNC( log_obj );
 */
#define LOG2_FUNC( log_obj )                                                    \
        LOG2_BASE( log_obj, LOG_LEVEL_FUNC )

/* Description:
 *     Log error info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     err_code         : SINT32
 * Example:
 *     LOG2_ERR( log_obj, -1 );
 */
#define LOG2_ERR( log_obj, err_code )                                           \
        do                                                                      \
        {                                                                       \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    LOG_LEVEL_ERR,                                              \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    err_code,                                                   \
                    DIRCTION_MAX,                                               \
                    NULL,                                                       \
                    0,                                                          \
                    0,                                                          \
                    NULL,                                                       \
                    NULL,                                                       \
                    NULL );                                                     \
        } while(0);

/* Description:
 *     Log error info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     err_code         : SINT32
 *     x                : see "note of x"
 * Example:
 *     LOG2_ERR_EXT( log_obj, -1, ("%s: %d", "test", 1) );
 */
#define LOG2_ERR_EXT( log_obj, err_code, x )                                    \
        do                                                                      \
        {                                                                       \
            sfw_log_start_build_extend_info( log_obj );                         \
            sfw_log_build_extended_info x;                                      \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    LOG_LEVEL_ERR,                                              \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    err_code,                                                   \
                    DIRCTION_MAX,                                               \
                    NULL,                                                       \
                    0,                                                          \
                    0,                                                          \
                    NULL,                                                       \
                    NULL,                                                       \
                    NULL );                                                     \
        } while(0);

/* Description:
 *     Log fatal error info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     err_code         : SINT32
 * Example:
 *     LOG2_FATAL_ERR( log_obj, -1 );
 */
#define LOG2_FATAL_ERR( log_obj, err_code )                                     \
        do                                                                      \
        {                                                                       \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    LOG_LEVEL_FATAL_ERR,                                        \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    err_code,                                                   \
                    DIRCTION_MAX,                                               \
                    NULL,                                                       \
                    0,                                                          \
                    0,                                                          \
                    NULL,                                                       \
                    NULL,                                                       \
                    NULL );                                                     \
        } while(0);

/* Description:
 *     Log error that generated when call a system/standard C function.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     func_name_ptr    : const char *, can be NULL
 * Example:
 *     LOG2_SYS_ERR( log_obj, NULL );
 *     LOG2_SYS_ERR( log_obj, "fopen" );
 */
#define LOG2_SYS_ERR( log_obj, sys_func_name_ptr )                              \
        do                                                                      \
        {                                                                       \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    LOG_LEVEL_SYS_ERR,                                          \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    errno,                                                      \
                    DIRCTION_MAX,                                               \
                    NULL,                                                       \
                    0,                                                          \
                    0,                                                          \
                    sys_func_name_ptr,                                          \
                    NULL,                                                       \
                    NULL );                                                     \
        } while(0);

/* Description:
 *     Log normal info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     x                : see "note of x"
 * Example:
 *     LOG2_INFO( log_obj, ( "test: %d", 1 ) );
 */
#define LOG2_INFO( log_obj, x )                                                 \
        LOG2_EXTEND( log_obj, LOG_LEVEL_INFO, x )

/* Description:
 *     Log warning info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     x                : see "note of x"
 * Example:
 *     LOG2_WARNING( log_obj, ( "warning: %d", 1 ) );
 */
#define LOG2_WARNING( log_obj, x )                                              \
        LOG2_EXTEND( log_obj, LOG_LEVEL_WARNING, x )

/* Description:
 *     Log parameter(of function) info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     x                : see "note of x"
 * Example:
 *     LOG2_FUNC_PARAM( log_obj, ( "in parameter: %d", 1 ) );
 */
#define LOG2_FUNC_PARAM( log_obj, x )                                           \
        LOG2_EXTEND( log_obj, LOG_LEVEL_FUNC_PARAM, x )

/* Description:
 *     Log at info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     direction_en     : LOG_DIRCTION_EN
 *     mux_port_idx     : UINT8
 *     at_data_ptr      : UINT8 *
 *     at_data_len      : UINT32
 * Example:
 *     LOG2_AT_CMD( log_obj, DIRCTION_RECEIVE, 1, "\r\n+CREG: 1\r\n", strlen("\r\n+CREG: 1\r\n") );
 */
#define LOG2_AT_CMD( log_obj,                                                   \
                          direction_en,                                         \
                          mux_port_idx,                                         \
                          at_data_ptr,                                          \
                          at_data_len )                                         \
        do                                                                      \
        {                                                                       \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    LOG_LEVEL_AT_CMD,                                           \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    0,                                                          \
                    direction_en,                                               \
                    at_data_ptr,                                                \
                    at_data_len,                                                \
                    mux_port_idx,                                               \
                    NULL,                                                       \
                    NULL,                                                       \
                    NULL );                                                     \
        } while(0);

/* Description:
 *     Log data info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     prompt_ptr       : char *, can be NULL
 *     data_ptr         : UINT8 *
 *     data_len         : UINT32
 * Example:
 *     UINT8  test_data_a[3] = { 1, 2, 3 };
 *     LOG2_DATA( log_obj, "test data:", test_data_a, sizeof(test_data_a) );
 */
#define LOG2_DATA( log_obj, prompt_ptr, data_ptr, data_len )                    \
        do                                                                      \
        {                                                                       \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    LOG_LEVEL_DATA,                                             \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    0,                                                          \
                    DIRCTION_MAX,                                               \
                    data_ptr,                                                   \
                    data_len,                                                   \
                    0,                                                          \
                    prompt_ptr,                                                 \
                    NULL,                                                       \
                    NULL );                                                     \
        } while(0);

/* Description:
 *     Log user message info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     direction_en     : LOG_DIRCTION_EN
 *     msg_name_ptr     : char *
 *     msg_data_ptr     : UINT8 *
 *     msg_data_len     : UINT32
 * Example:
 *     LOG2_USER_MSG( log_obj, DIRCTION_RECEIVE, "TestMsg", NULL, 0 );
 */
#define LOG2_USER_MSG( log_obj,                                                 \
                            direction_en,                                       \
                            msg_name_ptr,                                       \
                            msg_data_ptr,                                       \
                            msg_data_len )                                      \
        do                                                                      \
        {                                                                       \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    LOG_LEVEL_USER_MSG,                                         \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    0,                                                          \
                    direction_en,                                               \
                    msg_data_ptr,                                               \
                    msg_data_len,                                               \
                    0,                                                          \
                    NULL,                                                       \
                    msg_name_ptr,                                               \
                    NULL );                                                     \
        } while(0);

#ifdef OPT_LOG_ENABLE_IPC_MSG
/* Description:
 *     Log IPC message info.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     direction_en     : LOG_DIRCTION_EN
 *     ipc_msg_ptr      : const AspIpcMessage *
 * Example:
 *     LOG2_IPC_MSG( log_obj, DIRCTION_RECEIVE, ipc_msg_ptr );
 */
#define LOG2_IPC_MSG( log_obj, direction_en, ipc_msg_ptr )                      \
        do                                                                      \
        {                                                                       \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    LOG_LEVEL_IPC_MSG,                                          \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    0,                                                          \
                    direction_en,                                               \
                    NULL,                                                       \
                    0,                                                          \
                    0,                                                          \
                    NULL,                                                       \
                    NULL,                                                       \
                    (const void *)ipc_msg_ptr );                                \
        } while(0);
#else
#define LOG2_IPC_MSG( log_obj, direction_en, ipc_msg_ptr )
#endif /* #ifdef OPT_LOG_ENABLE_IPC_MSG */

/* Description:
 *     Log full info. Commonly don't use it directly.
 * Parameter:
 *     log_obj          : LOG_OBJ, returned by LOG2_START
 *     log_level        : UINT32, log level
 *     direction_en     : LOG_DIRCTION_EN
 *     data_ptr         : UINT8 *
 *     data_len         : UINT32
 *     mux_port_idx     : UINT8
 *     prompt_ptr       : char *
 *     msg_name_ptr     : char *
 *     ipc_msg_ptr      : const AspIpcMessage *
 *     x                : see "note of x"
 * Example:
 *     LOG2_FULL( log_obj, LOG_LEVEL_INFO, 0, DIRCTION_MAX, NULL, 0, 0, NULL, NULL, NULL, ("info: %d", 1) );
 *     LOG2_FULL( log_obj, LOG_LEVEL_FUNC, 0, DIRCTION_MAX, NULL, 0, 0, NULL, NULL, NULL, ( NULL ) );
 *     LOG2_FULL( log_obj, LOG_LEVEL_FUNC_PARAM, 0, DIRCTION_MAX, NULL, 0, 0, NULL, NULL, NULL, ("param1=%d", 1) );
 *     LOG2_FULL( log_obj, LOG_LEVEL_WARNING, 0, DIRCTION_MAX, NULL, 0, 0, NULL, NULL, NULL, ("warning: %s", "test") );
 *     LOG2_FULL( log_obj, LOG_LEVEL_ERR, ERR_INVALID_PARAM, DIRCTION_MAX, NULL, 0, 0, NULL, NULL, NULL, ( NULL ) );
 *     LOG2_FULL( log_obj, LOG_LEVEL_FATAL_ERR, ERR_INVALID_PARAM, DIRCTION_MAX, NULL, 0, 0, NULL, NULL, NULL, ( NULL ) );
 *     LOG2_FULL( log_obj, LOG_LEVEL_IPC_MSG, 0, DIRCTION_RECEIVE, NULL, 0, 0, NULL, NULL, ipc_msg_ptr, ( NULL ) );
 *     LOG2_FULL( log_obj, LOG_LEVEL_USER_MSG, 0, DIRCTION_RECEIVE, user_msg_data_ptr, user_msg_data_len, 0, NULL, "user_msg_test", NULL, ( NULL ) );
 *     LOG2_FULL( log_obj, LOG_LEVEL_AT_CMD, 0, DIRCTION_RECEIVE, "\r\n+CREG=1\r\n", strlen("\r\n+CREG=1\r\n"), 1, NULL, NULL, NULL, ( NULL ) );
 *     LOG2_FULL( log_obj, LOG_LEVEL_DATA, 0, DIRCTION_MAX, data_ptr, data_len, 0, "data", NULL, NULL, ( NULL ) );
 */
#define LOG2_FULL( log_obj,                                                     \
                        log_level,                                              \
                        err_code,                                               \
                        direction_en,                                           \
                        data_ptr,                                               \
                        data_len,                                               \
                        mux_port_idx,                                           \
                        prompt_ptr,                                             \
                        msg_name_ptr,                                           \
                        ipc_msg_ptr,                                            \
                        x )                                                     \
        do                                                                      \
        {                                                                       \
            if( LOG_LEVEL_INFO == log_level                                     \
                || LOG_LEVEL_FUNC_PARAM == log_level                            \
                || LOG_LEVEL_WARNING == log_level )                             \
            {                                                                   \
                sfw_log_start_build_extend_info( log_obj );                     \
                sfw_log_build_extended_info x;                                  \
            }                                                                   \
                                                                                \
            sfw_log_full(                                                       \
                    log_obj,                                                    \
                    LOG_MODULE_NAME,                                            \
                    log_level,                                                  \
                    __FILE__,                                                   \
                    __LINE__,                                                   \
                    __func__,                                                   \
                    err_code,                                                   \
                    direction_en,                                               \
                    data_ptr,                                                   \
                    data_len,                                                   \
                    mux_port_idx,                                               \
                    prompt_ptr,                                                 \
                    msg_name_ptr,                                               \
                    (const void *)ipc_msg_ptr );                                \
        } while(0);



#define LOG_START()                                                             \
        LOG2_START( LOG_TO_DEFAULT, NULL )

#define LOG_STOP()                                                              \
        LOG2_STOP( NULL )

#define LOG_SET_PATH( path_ptr )                                                \
        sfw_log_set_path( path_ptr )

#define LOG_GET_PATH()                                                          \
        sfw_log_get_path()

#define LOG_SET_HEADER_POS()                                                    \
        sfw_log_set_header_pos()

#define LOG_SET_SIZE(size)                                                      \
        sfw_log_set_size(size)

#define LOG_BACKUP_LOG(count)                                                   \
        sfw_log_backup_log(count)

#define LOG_BASE( log_level )                                                   \
        LOG2_BASE( NULL, log_level )

#define LOG_EXTEND( log_level, x )                                              \
        LOG2_EXTEND( NULL, log_level, x )

#define LOG_FUNC()                                                              \
        LOG2_FUNC( NULL )

#define LOG_ERR( err_code )                                                     \
        LOG2_ERR( NULL, err_code )

#define LOG_ERR_EXT( err_code, x )                                              \
        LOG2_ERR_EXT( NULL, err_code, x )

#define LOG_FATAL_ERR( err_code )                                               \
        LOG2_FATAL_ERR( NULL, err_code )

#define LOG_SYS_ERR( sys_func_name_ptr )                                        \
        LOG2_SYS_ERR( NULL, sys_func_name_ptr )

#define LOG_INFO( x )                                                           \
        LOG2_INFO( NULL, x )

#define LOG_WARNING( x )                                                        \
        LOG2_WARNING( NULL, x )

#define LOG_FUNC_PARAM( x )                                                     \
        LOG2_FUNC_PARAM( NULL, x )

#define LOG_AT_CMD( direction_en, mux_port_idx, at_data_ptr, at_data_len )      \
        LOG2_AT_CMD( NULL,                                                      \
                            direction_en,                                       \
                            mux_port_idx,                                       \
                            at_data_ptr,                                        \
                            at_data_len )

#define LOG_DATA( prompt_ptr, data_ptr, data_len )                              \
        LOG2_DATA( NULL, prompt_ptr, data_ptr, data_len )

#define LOG_USER_MSG( direction_en,                                             \
                            msg_name_ptr,                                       \
                            msg_data_ptr,                                       \
                            msg_data_len )                                      \
        LOG2_USER_MSG( NULL,                                                    \
                            direction_en,                                       \
                            msg_name_ptr,                                       \
                            msg_data_ptr,                                       \
                            msg_data_len )

#define LOG_IPC_MSG( direction_en, ipc_msg_ptr )                                \
        LOG2_IPC_MSG( NULL, direction_en, ipc_msg_ptr )

#define LOG_FULL( log_level,                                                    \
                        err_code,                                               \
                        direction_en,                                           \
                        data_ptr,                                               \
                        data_len,                                               \
                        mux_port_idx,                                           \
                        prompt_ptr,                                             \
                        msg_name_ptr,                                           \
                        ipc_msg_ptr,                                            \
                        x )                                                     \
        LOG2_FULL( NULL,                                                        \
                        log_level,                                              \
                        err_code,                                               \
                        direction_en,                                           \
                        data_ptr,                                               \
                        data_len,                                               \
                        mux_port_idx,                                           \
                        prompt_ptr,                                             \
                        msg_name_ptr,                                           \
                        ipc_msg_ptr,                                            \
                        x )


#else /* #ifdef OPT_LOG_ENABLE_LOG */


#define LOG_START()

#define LOG_STOP()

#define LOG_SET_PATH( path_ptr )

#define LOG_GET_PATH( path_ptr )

#define LOG_SET_HEADER_POS()

#define LOG_SET_SIZE( size )

#define LOG_BACKUP_LOG(count)

#define LOG_BASE( log_level )

#define LOG_EXTEND( log_level, x )

#define LOG_FUNC()

#define LOG_ERR( err_code )

#define LOG_ERR_EXT( err_code, x )

#define LOG_FATAL_ERR( err_code )

#define LOG_SYS_ERR( sys_func_name_ptr )

#define LOG_INFO( x )

#define LOG_WARNING( x )

#define LOG_FUNC_PARAM( x )

#define LOG_AT_CMD( direction_en, mux_port_idx, at_data_ptr, at_data_len )

#define LOG_DATA( prompt_ptr, data_ptr, data_len )

#define LOG_USER_MSG( direction_en, msg_name_ptr, msg_data_ptr, msg_data_len )

#define LOG_IPC_MSG( direction_en, ipc_msg_ptr )

#define LOG_FULL( log_level, err_code, direction_en, data_ptr, data_len, mux_port_idx, prompt_ptr, msg_name_ptr, ipc_msg_ptr, x )



#define LOG2_START( log_dst, file_ptr )

#define LOG2_STOP( log_obj )

#define LOG2_BASE( log_obj, log_level )

#define LOG2_EXTEND( log_obj, log_level, x )

#define LOG2_FUNC( log_obj )

#define LOG2_ERR( log_obj, err_code )

#define LOG2_ERR_EXT( log_obj, err_code, x )

#define LOG2_FATAL_ERR( log_obj, err_code )

#define LOG2_SYS_ERR( log_obj, sys_func_name_ptr )

#define LOG2_INFO( log_obj, x )

#define LOG2_WARNING( log_obj, x )

#define LOG2_FUNC_PARAM( log_obj, x )

#define LOG2_AT_CMD( log_obj, direction_en, mux_port_idx, at_data_ptr, at_data_len )

#define LOG2_DATA( log_obj, prompt_ptr, data_ptr, data_len )

#define LOG2_USER_MSG( log_obj, direction_en, msg_name_ptr, msg_data_ptr, msg_data_len )

#define LOG2_IPC_MSG( log_obj, direction_en, ipc_msg_ptr )

#define LOG2_FULL( log_obj, log_level, err_code, direction_en, data_ptr, data_len, mux_port_idx, prompt_ptr, msg_name_ptr, ipc_msg_ptr, x )

#endif /* #ifdef OPT_LOG_ENABLE_LOG */



/*----------------------- constant and type definition -----------------------*/

typedef struct _LOG_ST_ *                   LOG_OBJ;



/*--------------------------- variables definition ---------------------------*/



/*---------------------- function prototype declaration ----------------------*/

#ifdef OPT_LOG_ENABLE_LOG


void sfw_log_backup_log( UINT8 count );

void sfw_log_set_path( const char *path_ptr );
char *sfw_log_get_path(void);
void sfw_log_set_header_pos( void );
void sfw_log_set_size(UINT32 size);

LOG_OBJ sfw_log_start( const UINT32 log_dst, const char *file_ptr );

void sfw_log_stop( LOG_OBJ log_obj );

void sfw_log_start_build_extend_info( LOG_OBJ log_obj );

void sfw_log_build_extended_info( const char *user_param_ptr, ... );

void sfw_log_full(
    LOG_OBJ  log_obj,
    const char      *module_name_ptr,
    const UINT32    log_level,
    const char      *file_name_ptr,
    const int       line,
    const char      *func_ptr,
    const SINT32    err_code,
    const LOG_DIRCTION_EN   direction_en,
    const UINT8     *data_ptr,
    const UINT32    data_len,
    const UINT8     mux_port_idx,
    const char      *prompt_ptr,
    const char      *msg_name_ptr,
    const void      *ipc_msg_ptr );

void sfw_log_set_file_line_func(
    LOG_OBJ  log_obj,
    const char      *file_name_ptr,
    const int       line,
    const char      *func_ptr );

void sfw_log_info(
    const char      *module_name_ptr,
    const UINT32    log_level,
    const char      *info_ptr,
    ... );


#endif /* #ifdef OPT_LOG_ENABLE_LOG */



#ifdef __cplusplus
}
#endif



#endif /* PUB_LOG_H */
